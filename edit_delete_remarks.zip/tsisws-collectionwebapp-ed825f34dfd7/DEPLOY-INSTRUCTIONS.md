# 🚀 Deploy Your App in 3 Simple Steps

## Method 1: Interactive Deployment (Easiest)

I've created an interactive script that will guide you through the deployment:

```bash
./deploy-interactive.sh
```

This will show you a menu with options:
1. First Time Setup
2. Full Deployment ⭐ (Choose this)
3. Quick Update
4. Check Server Status
5. View Logs

**Just run it and choose option 2!**

---

## Method 2: One Command Deployment

Copy and paste this single command in your terminal:

```bash
ssh root@172.235.5.83 "cd /opt/react_web_app/collection-app && git pull origin collection-app-ts-tsv1 && chmod +x deploy/deploy.sh && ./deploy/deploy.sh"
```

When prompted, enter password: `c0llectech@1234`

---

## Method 3: Step-by-Step Manual

### Step 1: Open Terminal and SSH

```bash
ssh root@172.235.5.83
```

Password: `c0llectech@1234`

### Step 2: Navigate to App Directory

```bash
cd /opt/react_web_app/collection-app
```

### Step 3: Pull Latest Code

```bash
git pull origin collection-app-ts-tsv1
```

### Step 4: Deploy

```bash
chmod +x deploy/deploy.sh
./deploy/deploy.sh
```

### Step 5: Open Browser

Go to: http://172.235.5.83

---

## First Time Setup?

If this is the first time deploying, run this first:

```bash
ssh root@172.235.5.83 "cd /opt/react_web_app/collection-app && git pull origin collection-app-ts-tsv1 && chmod +x deploy/server-setup.sh && ./deploy/server-setup.sh"
```

Then configure the .env file:

```bash
ssh root@172.235.5.83
cd /opt/react_web_app/collection-app
cp .env.example .env
nano .env
```

Update `VITE_API_BASE_URL=http://172.235.1.82:8078`

Press `Ctrl+X`, then `Y`, then `Enter` to save.

Then run the deployment command above.

---

## ✅ What Happens During Deployment

1. ✅ Pulls latest code from GitHub
2. ✅ Installs npm dependencies
3. ✅ Builds the React application
4. ✅ Configures Nginx
5. ✅ Reloads Nginx
6. ✅ Your app goes live!

---

## 🎯 Recommended: Use Interactive Script

The easiest way is to use the interactive script:

```bash
./deploy-interactive.sh
```

Then choose option **2** for Full Deployment.

---

## 📞 Need Help?

If you encounter any issues:

1. **Check if Nginx is running:**
   ```bash
   ssh root@172.235.5.83 "systemctl status nginx"
   ```

2. **View error logs:**
   ```bash
   ssh root@172.235.5.83 "tail -f /var/log/nginx/collection-app-error.log"
   ```

3. **Restart Nginx:**
   ```bash
   ssh root@172.235.5.83 "systemctl restart nginx"
   ```

---

## 🚀 Quick Deploy Command (Copy & Paste)

**For regular deployments, just copy and paste this:**

```bash
ssh root@172.235.5.83 "cd /opt/react_web_app/collection-app && git pull origin collection-app-ts-tsv1 && chmod +x deploy/deploy.sh && ./deploy/deploy.sh"
```

**Password:** c0llectech@1234

**That's it!** Your app will be live at http://172.235.5.83

---

## 📱 After Deployment

Once deployed, you can:

- **View your app:** http://172.235.5.83
- **Check logs:** Use the interactive script (option 5)
- **Update later:** Run the same command again or use option 3 (Quick Update)

---

## 💡 Pro Tip

Save this command as an alias in your `~/.bashrc` or `~/.zshrc`:

```bash
alias deploy-collection="ssh root@172.235.5.83 'cd /opt/react_web_app/collection-app && git pull origin collection-app-ts-tsv1 && ./deploy/deploy.sh'"
```

Then you can just type:
```bash
deploy-collection
```

---

**Ready to deploy? Run the interactive script or copy the one-command deployment above!** 🚀

