# 🚀 Deploy to Server NOW - Quick Guide

## Server Information
- **IP:** 172.235.5.83
- **User:** root
- **Password:** c0llectech@1234
- **App Location:** /opt/react_web_app/collection-app

## Option 1: Deploy on Server (Recommended)

### Step 1: SSH into Server

```bash
ssh root@172.235.5.83
# Enter password: c0llectech@1234
```

### Step 2: Navigate to App Directory

```bash
cd /opt/react_web_app/collection-app
```

### Step 3: Pull Latest Changes

```bash
git pull origin collection-app-ts-tsv1
```

### Step 4: Run Deployment Script

```bash
chmod +x deploy/deploy.sh
./deploy/deploy.sh
```

**That's it!** Your app will be live at: http://172.235.5.83

---

## Option 2: Quick Deploy from Local Machine

### Step 1: Run Quick Deploy Script

From your local machine (in the project directory):

```bash
./deploy/quick-deploy.sh
```

You'll be prompted for the password: `c0llectech@1234`

**Done!** Your app will be live at: http://172.235.5.83

---

## First Time Setup (If Nginx Not Configured)

If this is the first time deploying, you need to set up the server:

### 1. SSH into Server

```bash
ssh root@172.235.5.83
```

### 2. Navigate to App

```bash
cd /opt/react_web_app/collection-app
```

### 3. Pull Latest Code

```bash
git pull origin collection-app-ts-tsv1
```

### 4. Run Server Setup (One-time)

```bash
chmod +x deploy/server-setup.sh
./deploy/server-setup.sh
```

### 5. Configure Environment

```bash
cp .env.example .env
nano .env
```

Update the API URL:
```
VITE_API_BASE_URL=http://172.235.1.82:8078
```

Press `Ctrl+X`, then `Y`, then `Enter` to save.

### 6. Deploy

```bash
chmod +x deploy/deploy.sh
./deploy/deploy.sh
```

### 7. Verify

Open browser: http://172.235.5.83

---

## Future Updates

For future updates, just run:

```bash
ssh root@172.235.5.83
cd /opt/react_web_app/collection-app
./deploy/update-app.sh
```

---

## Troubleshooting

### App Not Loading?

```bash
# Check Nginx status
systemctl status nginx

# Check logs
tail -f /var/log/nginx/collection-app-error.log

# Restart Nginx
systemctl restart nginx
```

### Need to Rebuild?

```bash
cd /opt/react_web_app/collection-app
npm run build
systemctl reload nginx
```

### Check if Build Files Exist

```bash
ls -la /opt/react_web_app/collection-app/dist
```

---

## Quick Commands Reference

| Task | Command |
|------|---------|
| SSH to server | `ssh root@172.235.5.83` |
| Go to app | `cd /opt/react_web_app/collection-app` |
| Pull changes | `git pull origin collection-app-ts-tsv1` |
| Deploy | `./deploy/deploy.sh` |
| Quick update | `./deploy/update-app.sh` |
| View logs | `tail -f /var/log/nginx/collection-app-access.log` |
| Restart Nginx | `systemctl restart nginx` |

---

## 📖 Full Documentation

For complete documentation, see:
- **[deploy/DEPLOYMENT.md](deploy/DEPLOYMENT.md)** - Complete deployment guide
- **[deploy/README.md](deploy/README.md)** - Deployment scripts reference
- **[README.md](README.md)** - Application documentation

---

## ✅ Checklist

- [ ] SSH into server (172.235.5.83)
- [ ] Navigate to /opt/react_web_app/collection-app
- [ ] Pull latest changes from git
- [ ] Run ./deploy/deploy.sh
- [ ] Verify app is running at http://172.235.5.83
- [ ] Check logs if any issues

**Need help?** Check [deploy/DEPLOYMENT.md](deploy/DEPLOYMENT.md) for detailed troubleshooting.

