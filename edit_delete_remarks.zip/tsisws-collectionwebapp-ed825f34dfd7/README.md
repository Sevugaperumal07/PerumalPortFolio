# AccountServ - Loan Account Management Application

A modern loan account management system built with React, TypeScript, and Vite. This application provides a comprehensive dashboard for managing users, roles, security groups, and bank details with authentication and authorization.

## 🚀 Features

- **User Management**: Create, view, edit, and manage users
- **Role-Based Access Control**: Define and manage user roles
- **Security Groups**: Organize users into security groups
- **Bank Details Management**: Manage bank account information
- **Authentication**: Secure login with JWT token-based authentication
- **GraphQL API Integration**: Efficient data fetching with GraphQL
- **Modern UI**: Built with Radix UI components and Tailwind CSS
- **Form Validation**: Robust form handling with React Hook Form and Zod
- **Responsive Design**: Mobile-friendly interface

## 📋 Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js** (v18 or higher)
- **npm** (v9 or higher) or **yarn** or **pnpm**
- **Docker** (optional, for containerized deployment)
- **Docker Compose** (optional, for containerized deployment)

## 🛠️ Technology Stack

### Core Technologies
- **Frontend Framework**: React 19.1.1
- **Language**: TypeScript 5.9.3
- **Build Tool**: Vite 7.1.7
- **Package Manager**: npm / yarn / pnpm

### Libraries & Frameworks
- **Routing**: React Router DOM 6.28.0
- **State Management**: React Context API
- **API Client**: GraphQL Request 6.1.0
- **Form Handling**: React Hook Form 7.66.0
- **Validation**: Zod 3.25.76
- **Table**: TanStack React Table 8.19.3
- **Date Utilities**: date-fns 3.6.0

### UI & Styling
- **CSS Framework**: Tailwind CSS 3.4.1
- **UI Component Library**: Radix UI (shadcn/ui)
  - Alert Dialog 1.1.15
  - Checkbox 1.3.3
  - Dialog 1.1.15
  - Dropdown Menu 2.1.16
  - Label 2.1.7
  - Select 2.2.6
  - Separator 1.1.7
  - Slot 1.2.3
  - Toast 1.2.15
  - Tooltip 1.2.8
- **Icons**: Lucide React 0.475.0
- **Utility Libraries**:
  - clsx 2.1.1
  - class-variance-authority 0.7.1
  - tailwind-merge 3.0.1
  - tailwindcss-animate 1.0.7

### Development Tools
- **Linting**: ESLint 9.36.0
  - @eslint/js 9.36.0
  - typescript-eslint 8.45.0
  - eslint-plugin-react-hooks 5.2.0
  - eslint-plugin-react-refresh 0.4.22
- **CSS Processing**:
  - PostCSS 8.4.47
  - Autoprefixer 10.4.20
- **Type Definitions**:
  - @types/node 24.6.0
  - @types/react 19.1.16
  - @types/react-dom 19.1.9
- **Build Plugin**: @vitejs/plugin-react 5.0.4

## 📦 Installation

### Local Development Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd collection-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   yarn install
   # or
   pnpm install
   ```

3. **Configure environment variables**

   Create a `.env` file in the root directory:
   ```bash
   cp .env.example .env
   ```

   Edit the `.env` file and set your API base URL:
   ```env
   VITE_API_BASE_URL=http://172.235.1.82:8078
   ```

4. **Start the development server**
   ```bash
   npm run dev
   # or
   yarn dev
   # or
   pnpm dev
   ```

5. **Open your browser**

   Navigate to `http://localhost:5173` (default Vite port)

## 🚀 Production Deployment

### Ubuntu Server with Nginx

For detailed deployment instructions to Ubuntu server with Nginx, see [DEPLOYMENT.md](deploy/DEPLOYMENT.md).

**Quick Deploy:**

```bash
# On the server (172.235.5.83)
cd /opt/react_web_app/collection-app
./deploy/deploy.sh
```

**Quick Update:**

```bash
# On the server
cd /opt/react_web_app/collection-app
./deploy/update-app.sh
```

**From Local Machine:**

```bash
# Build and deploy from your local machine
./deploy/quick-deploy.sh
```

See the [Deployment Guide](deploy/DEPLOYMENT.md) for complete instructions including:
- Initial server setup
- Nginx configuration
- SSL/HTTPS setup
- Troubleshooting
- Monitoring and maintenance

## 🐳 Docker Deployment

### Using Docker

1. **Build the Docker image**
   ```bash
   docker build -t collection-app .
   ```

2. **Run the container**
   ```bash
   docker run -p 3000:80 -e VITE_API_BASE_URL=http://172.235.1.82:8078 collection-app
   ```

3. **Access the application**

   Navigate to `http://localhost:3000`

### Using Docker Compose

1. **Configure environment variables**

   Edit the `docker-compose.yml` file or create a `.env` file with:
   ```env
   VITE_API_BASE_URL=http://172.235.1.82:8078
   ```

2. **Start the application**
   ```bash
   docker-compose up -d
   ```

3. **Stop the application**
   ```bash
   docker-compose down
   ```

4. **View logs**
   ```bash
   docker-compose logs -f
   ```

## 🏗️ Build for Production

1. **Build the application**
   ```bash
   npm run build
   # or
   yarn build
   # or
   pnpm build
   ```

2. **Preview the production build**
   ```bash
   npm run preview
   # or
   yarn preview
   # or
   pnpm preview
   ```

The build output will be in the `dist` directory.

## 📝 Available Scripts

| Script | Description |
|--------|-------------|
| `npm run dev` | Start development server with hot reload |
| `npm run build` | Build for production (TypeScript compilation + Vite build) |
| `npm run lint` | Run ESLint to check code quality |
| `npm run preview` | Preview production build locally |
| `npm test` | Run tests in watch mode |
| `npm run test:ui` | Run tests with interactive UI |
| `npm run test:coverage` | Run tests with coverage report |

## 🔧 Configuration

### Environment Variables

The application uses the following environment variables:

| Variable | Description | Default |
|----------|-------------|---------|
| `VITE_API_BASE_URL` | Backend API base URL | `http://172.235.1.82:8078` |

### API Endpoints

The application connects to the following endpoints:

- **Authentication**: `POST /api/v1/auth/authenticate`
- **GraphQL**: `POST /graphql`

## 📁 Project Structure

```
collection-app/
├── public/              # Static assets
├── src/
│   ├── assets/         # Images, fonts, etc.
│   ├── components/     # Reusable React components
│   │   ├── layout/    # Layout components
│   │   ├── ui/        # UI components (shadcn/ui)
│   │   └── ProtectedRoute.tsx
│   ├── contexts/       # React Context providers
│   │   └── AuthContext.tsx
│   ├── hooks/          # Custom React hooks
│   ├── lib/            # Utility functions and API clients
│   │   ├── api/       # REST API clients
│   │   ├── graphql/   # GraphQL clients and queries
│   │   └── utils.ts   # Utility functions
│   ├── pages/          # Page components
│   │   ├── dashboard/ # Dashboard pages
│   │   └── Login.tsx  # Login page
│   ├── App.tsx         # Main App component
│   ├── main.tsx        # Application entry point
│   └── index.css       # Global styles
├── .dockerignore       # Docker ignore file
├── .env.example        # Example environment variables
├── Dockerfile          # Docker configuration
├── docker-compose.yml  # Docker Compose configuration
├── package.json        # Dependencies and scripts
├── tsconfig.json       # TypeScript configuration
├── vite.config.ts      # Vite configuration
└── tailwind.config.ts  # Tailwind CSS configuration
```

## 🔐 Authentication

The application uses JWT token-based authentication:

1. Users log in with email and password
2. Upon successful authentication, a JWT token is stored in `sessionStorage`
3. The token is included in all subsequent API requests via the `Authorization` header
4. Protected routes redirect to login if no valid token is found

## 🎨 UI Components

The application uses [shadcn/ui](https://ui.shadcn.com/) components built on top of Radix UI primitives, styled with Tailwind CSS.

## 🧪 Development

### Code Style

The project uses ESLint for code linting. Run the linter with:

```bash
npm run lint
```

### Path Aliases

The project uses `@/` as an alias for the `src/` directory:

```typescript
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/AuthContext'
```

## 🧪 Testing

### Current Status

✅ **Testing framework is fully configured and ready to use!**

This project uses **Vitest** as the testing framework with **React Testing Library** for component testing.

### Test Coverage

The project includes comprehensive test suites:

- **Unit Tests**:
  - ✅ Utility functions (`src/lib/__tests__/utils.test.ts`)
  - ✅ UI Components (`src/components/ui/__tests__/`)
    - Button component (17 tests)
    - Input component (13 tests)
  - ✅ Context providers (`src/contexts/__tests__/AuthContext.test.tsx`) (7 tests)

- **Integration Tests**:
  - ✅ Login flow (`src/test/integration/login.test.tsx`) (6 tests)
  - ✅ Authentication flow (`src/test/integration/auth-flow.test.tsx`) (8 tests)

**Total: 58 tests** covering utilities, components, contexts, and user flows.

### Running Tests

```bash
# Run all tests in watch mode
npm test

# Run all tests once
npm test -- --run

# Run tests with UI
npm run test:ui

# Run tests with coverage report
npm run test:coverage
```

### Test Scripts

| Script | Description |
|--------|-------------|
| `npm test` | Run tests in watch mode (re-runs on file changes) |
| `npm test -- --run` | Run all tests once and exit |
| `npm run test:ui` | Open Vitest UI for interactive testing |
| `npm run test:coverage` | Generate and display code coverage report |

### Writing Tests

Tests are located alongside the code they test:

- **Component tests**: `src/components/**/__tests__/*.test.tsx`
- **Utility tests**: `src/lib/__tests__/*.test.ts`
- **Context tests**: `src/contexts/__tests__/*.test.tsx`
- **Integration tests**: `src/test/integration/*.test.tsx`

Example test structure:

```typescript
import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Button } from '../button'

describe('Button', () => {
  it('should render button with text', () => {
    render(<Button>Click me</Button>)
    expect(screen.getByRole('button', { name: /click me/i })).toBeInTheDocument()
  })
})
```

### Testing Configuration

The testing setup includes:

- **Vitest 4.0.7**: Fast unit test framework
- **@testing-library/react 16.3.0**: React component testing utilities
- **@testing-library/jest-dom 6.9.1**: Custom matchers for DOM assertions
- **@testing-library/user-event 14.6.1**: User interaction simulation
- **jsdom 27.1.0**: DOM implementation for Node.js
- **@vitest/ui 4.0.7**: Interactive UI for test results

Configuration is in `vite.config.ts` with test setup in `src/test/setup.ts`.

### CI/CD Integration

To run tests in CI/CD pipelines:

```bash
# Run tests with coverage in CI
npm test -- --run --coverage

# Generate coverage reports
npm run test:coverage
```

### Coverage Reports

Coverage reports are generated in the `coverage/` directory and include:
- HTML report: `coverage/index.html`
- JSON report: `coverage/coverage-final.json`
- Text summary in terminal

### Additional Testing Setup (Previously Documented)

#### For Reference: How Testing Was Set Up

The following steps were already completed for this project. This is for reference only:

#### 1. Testing Dependencies Installed

```bash
npm install -D vitest @vitest/ui @testing-library/react @testing-library/jest-dom @testing-library/user-event jsdom happy-dom
```

#### 2. Vite Configuration Updated

Test configuration in `vite.config.ts`:

```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  optimizeDeps: {
    include: ['@tanstack/react-table'],
  },
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: './src/test/setup.ts',
    css: true,
  },
})
```

#### 3. Test Setup File Created

File `src/test/setup.ts` includes:

```typescript
import { expect, afterEach } from 'vitest'
import { cleanup } from '@testing-library/react'
import * as matchers from '@testing-library/jest-dom/matchers'

expect.extend(matchers)

afterEach(() => {
  cleanup()
})
```

#### 4. Test Scripts Added to `package.json`

Scripts are already configured and ready to use (see "Running Tests" section above).

#### 5. Test Files Created

The project includes comprehensive test files:
- Component tests in `src/components/ui/__tests__/`
- Context tests in `src/contexts/__tests__/`
- Utility tests in `src/lib/__tests__/`
- Integration tests in `src/test/integration/`

### Alternative: Jest Setup

If you prefer Jest over Vitest:

```bash
npm install -D jest @types/jest ts-jest @testing-library/react @testing-library/jest-dom @testing-library/user-event jest-environment-jsdom
```

Create `jest.config.js`:

```javascript
export default {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  setupFilesAfterEnv: ['<rootDir>/src/test/setup.ts'],
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1',
    '\\.(css|less|scss|sass)$': 'identity-obj-proxy',
  },
}
```

### Testing Best Practices

When you set up testing, consider testing:

- **Components**: UI components render correctly
- **Hooks**: Custom hooks behave as expected
- **Utils**: Utility functions return correct values
- **Integration**: User flows work end-to-end
- **API Calls**: Mock API responses and test error handling
- **Authentication**: Login/logout flows
- **Forms**: Form validation and submission

## 🚢 Deployment

### Production Deployment

1. Build the application: `npm run build`
2. Deploy the `dist` folder to your web server or hosting platform
3. Configure your web server to serve `index.html` for all routes (SPA routing)

### Docker Deployment

Use the provided Dockerfile and docker-compose.yml for containerized deployment.

## 📄 License

This project is private and proprietary.

## 🤝 Contributing

Please follow the existing code style and conventions when contributing to this project.

## 📞 Support

For support and questions, please contact the development team.
