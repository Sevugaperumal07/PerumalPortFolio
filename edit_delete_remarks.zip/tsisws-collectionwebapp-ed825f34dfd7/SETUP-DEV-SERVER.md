# Setup Development Server with Nginx Reverse Proxy

This guide will help you set up Nginx on port 80 to proxy to your Vite dev server on port 5173.

## 🎯 Goal

- **Nginx** (port 80) → **Vite Dev Server** (port 5173)
- Access your app at: http://172.235.5.83 or http://172.235.5.83:5173
- Login page: http://172.235.5.83:5173/login
- Hot Module Replacement (HMR) will work through the proxy

---

## ✅ Files Already Uploaded

The following files have been uploaded to your server:
- ✅ Source code: `/tmp/collection-app-src.tar.gz`
- ✅ Nginx config: `/tmp/nginx-dev-proxy.conf`

---

## 📋 Step-by-Step Instructions

### Step 1: SSH into your server

```bash
ssh root@172.235.5.83
```

Password: `c0llectech@1234`

---

### Step 2: Extract source code

```bash
cd /opt/react_web_app/collection-app
tar -xzf /tmp/collection-app-src.tar.gz
```

---

### Step 3: Install dependencies

```bash
npm install
```

This will take a few minutes.

---

### Step 4: Create .env file (if not exists)

```bash
cat > .env << 'EOF'
VITE_API_BASE_URL=http://172.235.1.82:8078
EOF
```

---

### Step 5: Configure Nginx

```bash
# Copy nginx config
cp /tmp/nginx-dev-proxy.conf /etc/nginx/sites-available/collection-app

# Enable the site
ln -sf /etc/nginx/sites-available/collection-app /etc/nginx/sites-enabled/collection-app

# Remove default site
rm -f /etc/nginx/sites-enabled/default

# Test nginx configuration
nginx -t

# Reload nginx
systemctl reload nginx
```

---

### Step 6: Start Vite dev server

```bash
# Kill any existing dev server
pkill -f "vite" || true

# Start dev server in background
cd /opt/react_web_app/collection-app
nohup npm run dev -- --host 0.0.0.0 --port 5173 > /var/log/vite-dev.log 2>&1 &
```

---

### Step 7: Verify it's running

```bash
# Wait a few seconds for the server to start
sleep 5

# Check if dev server is responding
curl http://localhost:5173

# Check the logs
tail -f /var/log/vite-dev.log
```

Press `Ctrl+C` to exit the log viewer.

---

### Step 8: Access your application

Open your browser and go to:

**👉 http://172.235.5.83** (via Nginx proxy on port 80)

**OR**

**👉 http://172.235.5.83:5173** (direct access to Vite dev server)

**Login Page:** http://172.235.5.83:5173/login

You should see your application running with HMR enabled!

---

## 🔧 Useful Commands

### View dev server logs
```bash
tail -f /var/log/vite-dev.log
```

### Restart dev server
```bash
pkill -f "vite"
cd /opt/react_web_app/collection-app
nohup npm run dev -- --host 0.0.0.0 --port 5173 > /var/log/vite-dev.log 2>&1 &
```

### Stop dev server
```bash
pkill -f "vite"
```

### Check if dev server is running
```bash
ps aux | grep vite
curl http://localhost:5173
```

### View Nginx logs
```bash
tail -f /var/log/nginx/collection-app-access.log
tail -f /var/log/nginx/collection-app-error.log
```

### Restart Nginx
```bash
systemctl restart nginx
```

### Test Nginx configuration
```bash
nginx -t
```

---

## 🎨 How It Works

```
Browser (http://172.235.5.83:80)
         ↓
    Nginx (port 80)
         ↓ (reverse proxy)
    Vite Dev Server (port 5173)
         ↓
    Your React App (with HMR)
```

- Nginx listens on port 80 (standard HTTP port)
- Nginx forwards all requests to Vite dev server on port 5173
- WebSocket connections for HMR are properly proxied
- You can access the app without specifying port number

---

## 🐛 Troubleshooting

### Dev server not starting?
```bash
# Check the logs
tail -f /var/log/vite-dev.log

# Make sure port 5173 is not in use
lsof -i :5173

# Try starting manually to see errors
cd /opt/react_web_app/collection-app
npm run dev -- --host 0.0.0.0 --port 5173
```

### Nginx errors?
```bash
# Check nginx error log
tail -f /var/log/nginx/collection-app-error.log

# Test configuration
nginx -t

# Check nginx status
systemctl status nginx
```

### Can't access from browser?
```bash
# Check if nginx is running
systemctl status nginx

# Check if dev server is running
curl http://localhost:5173

# Check firewall
ufw status
```

---

## 📝 Notes

- The dev server runs in the background using `nohup`
- Logs are written to `/var/log/vite-dev.log`
- HMR (Hot Module Replacement) works through the Nginx proxy
- Changes to your code will automatically reload in the browser
- To make code changes, you'll need to edit files on the server or use a sync tool

---

## 🔄 Making Code Changes

Since the code is on the server, you have a few options:

1. **Edit directly on server** (using vim, nano, etc.)
2. **Use rsync to sync local changes**:
   ```bash
   rsync -avz --exclude='node_modules' --exclude='dist' --exclude='.git' \
     ./ root@172.235.5.83:/opt/react_web_app/collection-app/
   ```
3. **Use git** (if you set up git authentication on the server)

---

---

## 🌐 Access URLs

Once setup is complete, you can access your application at:

- **Via Nginx (port 80):** http://172.235.5.83
- **Direct to Vite (port 5173):** http://172.235.5.83:5173
- **Login Page:** http://172.235.5.83:5173/login

---

That's it! Your development server should now be accessible! 🎉

