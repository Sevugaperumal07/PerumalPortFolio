#!/bin/bash

# Deploy Build Files Only - No Git Required on Server
# This script builds locally and uploads the dist folder

set -e

SERVER_IP="172.235.5.83"
SERVER_USER="root"
APP_DIR="/opt/react_web_app/collection-app"

echo "=========================================="
echo "🚀 Deploy Build Files to Server"
echo "=========================================="
echo ""
echo "This will:"
echo "  1. Build the application locally"
echo "  2. Upload dist/ folder to server"
echo "  3. Configure Nginx"
echo "  4. Reload Nginx"
echo ""
read -p "Continue? (y/n): " confirm

if [ "$confirm" != "y" ]; then
    echo "Deployment cancelled."
    exit 0
fi

# Step 1: Build locally
echo ""
echo "🔨 Building application locally..."
npm run build

if [ ! -d "dist" ]; then
    echo "❌ Error: dist folder not found after build"
    exit 1
fi

echo "✅ Build complete!"

# Step 2: Upload dist folder
echo ""
echo "📤 Uploading dist/ folder to server..."
echo "You will be prompted for password: c0llectech@1234"
scp -r dist/ ${SERVER_USER}@${SERVER_IP}:${APP_DIR}/

echo "✅ Upload complete!"

# Step 3: Upload deploy files if they don't exist
echo ""
echo "📤 Uploading deployment configuration..."
scp deploy/nginx-production.conf ${SERVER_USER}@${SERVER_IP}:${APP_DIR}/deploy/ 2>/dev/null || \
    ssh ${SERVER_USER}@${SERVER_IP} "mkdir -p ${APP_DIR}/deploy" && \
    scp deploy/nginx-production.conf ${SERVER_USER}@${SERVER_IP}:${APP_DIR}/deploy/

# Step 4: Configure and reload Nginx
echo ""
echo "🔧 Configuring Nginx on server..."
ssh ${SERVER_USER}@${SERVER_IP} << 'EOF'
    cd /opt/react_web_app/collection-app
    
    # Copy Nginx config
    cp deploy/nginx-production.conf /etc/nginx/sites-available/collection-app
    
    # Enable site
    ln -sf /etc/nginx/sites-available/collection-app /etc/nginx/sites-enabled/collection-app
    
    # Remove default site if it exists
    rm -f /etc/nginx/sites-enabled/default
    
    # Test Nginx config
    nginx -t
    
    # Reload Nginx
    systemctl reload nginx
    
    echo ""
    echo "✅ Nginx configured and reloaded!"
EOF

echo ""
echo "=========================================="
echo "✅ Deployment Complete!"
echo "=========================================="
echo ""
echo "Your application is now live at:"
echo "👉 http://${SERVER_IP}"
echo ""
echo "To check logs:"
echo "  ssh ${SERVER_USER}@${SERVER_IP}"
echo "  tail -f /var/log/nginx/collection-app-access.log"
echo ""

