#!/bin/bash

# Interactive Deployment Helper
# This script will guide you through the deployment process

set -e

SERVER_IP="172.235.5.83"
SERVER_USER="root"
APP_DIR="/opt/react_web_app/collection-app"

echo "=========================================="
echo "🚀 Interactive Deployment Helper"
echo "=========================================="
echo ""
echo "This script will help you deploy to:"
echo "  Server: ${SERVER_IP}"
echo "  User: ${SERVER_USER}"
echo "  Path: ${APP_DIR}"
echo ""
echo "You will be prompted for the password: c0llectech@1234"
echo ""

# Function to run command on server
run_on_server() {
    echo ""
    echo "📡 Connecting to server..."
    ssh ${SERVER_USER}@${SERVER_IP} "$1"
}

# Main menu
echo "Choose deployment option:"
echo ""
echo "1) First Time Setup (Install Node.js, Nginx, etc.)"
echo "2) Full Deployment (Pull code, build, configure Nginx)"
echo "3) Quick Update (Just rebuild and reload)"
echo "4) Check Server Status"
echo "5) View Logs"
echo "6) Exit"
echo ""
read -p "Enter your choice [1-6]: " choice

case $choice in
    1)
        echo ""
        echo "🔧 Running first-time server setup..."
        echo "This will install Node.js, Nginx, PM2, and configure firewall."
        read -p "Continue? (y/n): " confirm
        if [ "$confirm" = "y" ]; then
            run_on_server "cd ${APP_DIR} && git pull origin collection-app-ts-tsv1 && chmod +x deploy/server-setup.sh && ./deploy/server-setup.sh"
            echo ""
            echo "✅ Server setup complete!"
            echo ""
            echo "Next steps:"
            echo "1. Configure .env file on server"
            echo "2. Run option 2 (Full Deployment)"
        fi
        ;;
    2)
        echo ""
        echo "🚀 Running full deployment..."
        echo "This will pull latest code, install dependencies, build, and configure Nginx."
        read -p "Continue? (y/n): " confirm
        if [ "$confirm" = "y" ]; then
            run_on_server "cd ${APP_DIR} && git pull origin collection-app-ts-tsv1 && chmod +x deploy/deploy.sh && ./deploy/deploy.sh"
            echo ""
            echo "=========================================="
            echo "✅ Deployment Complete!"
            echo "=========================================="
            echo ""
            echo "Your application is now live at:"
            echo "👉 http://${SERVER_IP}"
            echo ""
        fi
        ;;
    3)
        echo ""
        echo "⚡ Running quick update..."
        echo "This will pull code, rebuild, and reload Nginx."
        read -p "Continue? (y/n): " confirm
        if [ "$confirm" = "y" ]; then
            run_on_server "cd ${APP_DIR} && git pull origin collection-app-ts-tsv1 && chmod +x deploy/update-app.sh && ./deploy/update-app.sh"
            echo ""
            echo "✅ Update complete!"
            echo "👉 http://${SERVER_IP}"
        fi
        ;;
    4)
        echo ""
        echo "📊 Checking server status..."
        run_on_server "systemctl status nginx --no-pager && echo '' && echo 'App directory:' && ls -la ${APP_DIR}/dist 2>/dev/null || echo 'Build not found'"
        ;;
    5)
        echo ""
        echo "Choose log to view:"
        echo "1) Access Log (last 50 lines)"
        echo "2) Error Log (last 50 lines)"
        echo "3) Nginx Status"
        read -p "Enter choice [1-3]: " log_choice
        case $log_choice in
            1)
                run_on_server "tail -n 50 /var/log/nginx/collection-app-access.log"
                ;;
            2)
                run_on_server "tail -n 50 /var/log/nginx/collection-app-error.log"
                ;;
            3)
                run_on_server "systemctl status nginx --no-pager"
                ;;
        esac
        ;;
    6)
        echo "Goodbye!"
        exit 0
        ;;
    *)
        echo "Invalid choice!"
        exit 1
        ;;
esac

echo ""
echo "=========================================="
echo "Done!"
echo "=========================================="

