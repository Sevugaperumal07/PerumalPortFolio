# Deployment Guide - Ubuntu Server with Nginx

This guide covers deploying the AccountServ Collection App to an Ubuntu server with Nginx.

## Server Information

- **Server IP**: 172.235.5.83
- **User**: root
- **Application Path**: `/opt/react_web_app/collection-app`
- **Web Server**: Nginx

## Prerequisites

- Ubuntu Server (18.04 or later)
- Root access to the server
- Node.js 18.x
- Nginx
- Git (optional, for version control)

## Deployment Methods

### Method 1: Full Deployment on Server (Recommended for First Time)

This method sets up everything on the server and builds the application there.

#### Step 1: Initial Server Setup

SSH into your server:

```bash
ssh root@172.235.5.83
# Password: c0llectech@1234
```

Run the server setup script (one-time setup):

```bash
cd /opt/react_web_app/collection-app
chmod +x deploy/server-setup.sh
./deploy/server-setup.sh
```

This will install:
- Node.js 18.x
- Nginx
- PM2 (process manager)
- Essential build tools

#### Step 2: Configure Environment

Create and configure the `.env` file:

```bash
cd /opt/react_web_app/collection-app
cp .env.example .env
nano .env
```

Update the API URL:
```
VITE_API_BASE_URL=http://172.235.1.82:8078
```

#### Step 3: Deploy the Application

Run the deployment script:

```bash
cd /opt/react_web_app/collection-app
chmod +x deploy/deploy.sh
./deploy/deploy.sh
```

This script will:
1. Pull latest changes from git (if applicable)
2. Install dependencies
3. Build the application
4. Configure Nginx
5. Reload Nginx

#### Step 4: Verify Deployment

Open your browser and navigate to:
```
http://172.235.5.83
```

### Method 2: Quick Deploy from Local Machine

This method builds the application locally and uploads only the build files to the server.

#### Prerequisites

- SSH access configured
- Application already set up on server

#### Steps

From your local machine:

```bash
# Make the script executable
chmod +x deploy/quick-deploy.sh

# Run the quick deploy script
./deploy/quick-deploy.sh
```

You'll be prompted for the server password: `c0llectech@1234`

This script will:
1. Build the application locally
2. Upload the `dist/` folder to the server
3. Upload the `.env` file
4. Update Nginx configuration
5. Reload Nginx

## Manual Deployment Steps

If you prefer to deploy manually:

### 1. Build the Application

```bash
# On your local machine or on the server
cd /opt/react_web_app/collection-app
npm install
npm run build
```

### 2. Configure Nginx

```bash
# Copy the Nginx configuration
sudo cp deploy/nginx-production.conf /etc/nginx/sites-available/collection-app

# Enable the site
sudo ln -s /etc/nginx/sites-available/collection-app /etc/nginx/sites-enabled/

# Test Nginx configuration
sudo nginx -t

# Reload Nginx
sudo systemctl reload nginx
```

### 3. Set Permissions

```bash
sudo chown -R root:root /opt/react_web_app/collection-app
sudo chmod -R 755 /opt/react_web_app/collection-app/dist
```

## Nginx Configuration

The Nginx configuration includes:

- ✅ Gzip compression for better performance
- ✅ Security headers (X-Frame-Options, X-Content-Type-Options, etc.)
- ✅ Static asset caching (1 year for images, fonts, CSS, JS)
- ✅ SPA routing support (all routes redirect to index.html)
- ✅ Access and error logging
- ✅ API proxy configuration (commented out, enable if needed)

Configuration file: `deploy/nginx-production.conf`

## Environment Variables

The application requires the following environment variable:

```bash
VITE_API_BASE_URL=http://172.235.1.82:8078
```

This is configured in the `.env` file at the root of the project.

## Useful Commands

### Nginx Commands

```bash
# Test Nginx configuration
sudo nginx -t

# Reload Nginx (without downtime)
sudo systemctl reload nginx

# Restart Nginx
sudo systemctl restart nginx

# Check Nginx status
sudo systemctl status nginx

# View access logs
tail -f /var/log/nginx/collection-app-access.log

# View error logs
tail -f /var/log/nginx/collection-app-error.log
```

### Application Commands

```bash
# Navigate to app directory
cd /opt/react_web_app/collection-app

# Install dependencies
npm install

# Build for production
npm run build

# Run tests
npm test

# Preview production build locally
npm run preview
```

## Troubleshooting

### Application Not Loading

1. **Check Nginx is running:**
   ```bash
   sudo systemctl status nginx
   ```

2. **Check Nginx error logs:**
   ```bash
   tail -f /var/log/nginx/collection-app-error.log
   ```

3. **Verify build files exist:**
   ```bash
   ls -la /opt/react_web_app/collection-app/dist
   ```

4. **Check file permissions:**
   ```bash
   sudo chmod -R 755 /opt/react_web_app/collection-app/dist
   ```

### API Connection Issues

1. **Verify .env file:**
   ```bash
   cat /opt/react_web_app/collection-app/.env
   ```

2. **Check API is accessible:**
   ```bash
   curl http://172.235.1.82:8078/api/v1/health
   ```

3. **Enable API proxy in Nginx** (if API is on same server):
   - Uncomment the API proxy section in `nginx-production.conf`
   - Reload Nginx

### 502 Bad Gateway

This usually means Nginx can't connect to the backend. Check:
- Backend API is running
- Firewall allows connections
- API URL in .env is correct

### 404 Errors on Page Refresh

This means SPA routing is not configured correctly:
- Verify `try_files $uri $uri/ /index.html;` is in Nginx config
- Reload Nginx configuration

## SSL/HTTPS Setup (Optional)

To enable HTTPS with Let's Encrypt:

### 1. Install Certbot

```bash
sudo apt install certbot python3-certbot-nginx
```

### 2. Obtain SSL Certificate

```bash
sudo certbot --nginx -d yourdomain.com
```

### 3. Auto-renewal

Certbot automatically sets up renewal. Test it:

```bash
sudo certbot renew --dry-run
```

## Monitoring and Maintenance

### Log Rotation

Nginx logs are automatically rotated by logrotate. Configuration is in:
```
/etc/logrotate.d/nginx
```

### Disk Space

Monitor disk space regularly:

```bash
df -h
```

### Updates

Keep the system updated:

```bash
sudo apt update && sudo apt upgrade -y
```

## Rollback

If deployment fails, you can rollback:

### 1. Using Git

```bash
cd /opt/react_web_app/collection-app
git checkout <previous-commit-hash>
npm install
npm run build
sudo systemctl reload nginx
```

### 2. Using Backup

Keep backups of the `dist/` folder:

```bash
# Before deployment
cp -r dist dist.backup.$(date +%Y%m%d_%H%M%S)

# To rollback
rm -rf dist
cp -r dist.backup.YYYYMMDD_HHMMSS dist
sudo systemctl reload nginx
```

## Performance Optimization

### 1. Enable HTTP/2

Already configured in the SSL section of nginx-production.conf

### 2. Optimize Images

Use optimized images in your application:
- WebP format for better compression
- Lazy loading for images
- Responsive images

### 3. CDN (Optional)

Consider using a CDN for static assets:
- Cloudflare
- AWS CloudFront
- DigitalOcean Spaces

## Security Best Practices

1. **Keep system updated:**
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

2. **Configure firewall:**
   ```bash
   sudo ufw status
   sudo ufw allow 80/tcp
   sudo ufw allow 443/tcp
   sudo ufw enable
   ```

3. **Use HTTPS** (see SSL setup above)

4. **Regular backups:**
   - Database backups
   - Application code backups
   - Configuration backups

5. **Monitor logs regularly:**
   ```bash
   tail -f /var/log/nginx/collection-app-access.log
   tail -f /var/log/nginx/collection-app-error.log
   ```

## Support

For issues or questions:
- Check the logs first
- Review this documentation
- Check the main README.md for application-specific information

## Quick Reference

| Task | Command |
|------|---------|
| Deploy | `cd /opt/react_web_app/collection-app && ./deploy/deploy.sh` |
| Build | `npm run build` |
| Reload Nginx | `sudo systemctl reload nginx` |
| View logs | `tail -f /var/log/nginx/collection-app-access.log` |
| Test Nginx config | `sudo nginx -t` |
| Check Nginx status | `sudo systemctl status nginx` |



