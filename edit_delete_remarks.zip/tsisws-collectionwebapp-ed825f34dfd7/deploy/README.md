# Deployment Scripts

This directory contains all deployment scripts and configurations for the AccountServ Collection App.

## 📁 Files Overview

| File | Description |
|------|-------------|
| `DEPLOYMENT.md` | Complete deployment guide with detailed instructions |
| `server-setup.sh` | Initial server setup (Node.js, Nginx, PM2) |
| `deploy.sh` | Full deployment script (build + configure + deploy) |
| `update-app.sh` | Quick update script (pull + build + reload) |
| `quick-deploy.sh` | Deploy from local machine to server |
| `nginx-production.conf` | Production Nginx configuration |

## 🚀 Quick Start

### First Time Deployment

**On the server (172.235.5.83):**

```bash
# 1. Setup server (one-time)
cd /opt/react_web_app/collection-app
./deploy/server-setup.sh

# 2. Configure environment
cp .env.example .env
nano .env  # Update VITE_API_BASE_URL

# 3. Deploy
./deploy/deploy.sh
```

### Updating the Application

**On the server:**

```bash
cd /opt/react_web_app/collection-app
./deploy/update-app.sh
```

**From your local machine:**

```bash
./deploy/quick-deploy.sh
```

## 📋 Script Details

### server-setup.sh

Sets up the server environment (run once):
- Installs Node.js 18.x
- Installs Nginx
- Installs PM2
- Configures firewall
- Creates application directory

**Usage:**
```bash
sudo ./deploy/server-setup.sh
```

### deploy.sh

Full deployment process:
- Pulls latest code from git
- Installs dependencies
- Builds the application
- Configures Nginx
- Reloads Nginx

**Usage:**
```bash
./deploy/deploy.sh
```

### update-app.sh

Quick update (faster than full deploy):
- Pulls latest code
- Installs dependencies
- Builds application
- Reloads Nginx

**Usage:**
```bash
./deploy/update-app.sh
```

### quick-deploy.sh

Deploy from local machine:
- Builds application locally
- Uploads build files via SCP
- Updates Nginx configuration
- Reloads Nginx on server

**Usage:**
```bash
./deploy/quick-deploy.sh
```

**Note:** Requires SSH access to the server.

### nginx-production.conf

Production-ready Nginx configuration with:
- Gzip compression
- Security headers
- Static asset caching
- SPA routing support
- Logging configuration
- SSL/HTTPS ready (commented out)

## 🔧 Configuration

### Server Details

- **IP Address:** 172.235.5.83
- **User:** root
- **App Directory:** /opt/react_web_app/collection-app
- **Nginx Config:** /etc/nginx/sites-available/collection-app
- **Access Log:** /var/log/nginx/collection-app-access.log
- **Error Log:** /var/log/nginx/collection-app-error.log

### Environment Variables

Create `.env` file with:

```bash
VITE_API_BASE_URL=http://172.235.1.82:8078
```

## 📖 Documentation

For complete deployment instructions, troubleshooting, and best practices, see:

**[DEPLOYMENT.md](DEPLOYMENT.md)**

This includes:
- Detailed deployment steps
- Manual deployment instructions
- Troubleshooting guide
- SSL/HTTPS setup
- Security best practices
- Performance optimization
- Monitoring and maintenance

## 🆘 Quick Troubleshooting

### Application not loading?

```bash
# Check Nginx status
sudo systemctl status nginx

# Check error logs
tail -f /var/log/nginx/collection-app-error.log

# Verify build files exist
ls -la /opt/react_web_app/collection-app/dist
```

### Need to rebuild?

```bash
cd /opt/react_web_app/collection-app
npm run build
sudo systemctl reload nginx
```

### Nginx configuration issues?

```bash
# Test configuration
sudo nginx -t

# Reload Nginx
sudo systemctl reload nginx
```

## 📞 Support

For detailed help, refer to:
- [DEPLOYMENT.md](DEPLOYMENT.md) - Complete deployment guide
- [../README.md](../README.md) - Application documentation

