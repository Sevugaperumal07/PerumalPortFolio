#!/bin/bash

# Deployment Script for Collection App
# Run this script on the server at /opt/react_web_app/collection-app

set -e

APP_DIR="/opt/react_web_app/collection-app"
NGINX_CONF="/etc/nginx/sites-available/collection-app"
NGINX_ENABLED="/etc/nginx/sites-enabled/collection-app"

echo "=========================================="
echo "AccountServ - Deployment Script"
echo "=========================================="

# Navigate to application directory
cd $APP_DIR

# Pull latest changes (if using git)
if [ -d ".git" ]; then
    echo "📥 Pulling latest changes from git..."
    git pull origin collection-app-ts-tsv1
else
    echo "⚠️  Not a git repository. Skipping git pull."
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "📝 Creating .env file..."
    cp .env.example .env
    echo "⚠️  Please update .env with your configuration!"
fi

# Build the application
echo "🔨 Building application..."
npm run build

# Copy Nginx configuration
echo "🌐 Configuring Nginx..."
cp deploy/nginx-production.conf $NGINX_CONF

# Enable the site
if [ ! -L $NGINX_ENABLED ]; then
    ln -s $NGINX_CONF $NGINX_ENABLED
    echo "✅ Nginx site enabled"
fi

# Test Nginx configuration
echo "🧪 Testing Nginx configuration..."
nginx -t

# Reload Nginx
echo "🔄 Reloading Nginx..."
systemctl reload nginx

# Set correct permissions
echo "🔐 Setting permissions..."
chown -R root:root $APP_DIR
chmod -R 755 $APP_DIR/dist

echo ""
echo "=========================================="
echo "✅ Deployment completed successfully!"
echo "=========================================="
echo ""
echo "Application is now running at:"
echo "http://172.235.5.83"
echo ""
echo "Useful commands:"
echo "  - View Nginx logs: tail -f /var/log/nginx/collection-app-access.log"
echo "  - View error logs: tail -f /var/log/nginx/collection-app-error.log"
echo "  - Restart Nginx: systemctl restart nginx"
echo ""

