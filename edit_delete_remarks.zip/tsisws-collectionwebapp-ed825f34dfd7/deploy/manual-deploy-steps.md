# Manual Deployment Steps - Server Doesn't Have Git Access

Since the server doesn't have GitHub authentication configured, here are alternative deployment methods:

## Option 1: Deploy Build Files from Local Machine (Fastest)

This builds locally and uploads only the compiled files to the server.

### Step 1: Build Locally

```bash
npm run build
```

### Step 2: Upload to Server

```bash
scp -r dist/ root@172.235.5.83:/opt/react_web_app/collection-app/
```

Password: `c0llectech@1234`

### Step 3: Configure Nginx on Server

```bash
ssh root@172.235.5.83
# Password: c0llectech@1234

# Once connected:
cd /opt/react_web_app/collection-app

# Copy Nginx config
cp deploy/nginx-production.conf /etc/nginx/sites-available/collection-app

# Enable site
ln -sf /etc/nginx/sites-available/collection-app /etc/nginx/sites-enabled/collection-app

# Test Nginx config
nginx -t

# Reload Nginx
systemctl reload nginx
```

### Step 4: Verify

Open browser: http://172.235.5.83

---

## Option 2: Upload Entire Project and Build on Server

### Step 1: Create Archive Locally

```bash
# Exclude node_modules and build files
tar -czf collection-app.tar.gz \
  --exclude='node_modules' \
  --exclude='dist' \
  --exclude='.git' \
  --exclude='*.log' \
  .
```

### Step 2: Upload to Server

```bash
scp collection-app.tar.gz root@172.235.5.83:/tmp/
```

Password: `c0llectech@1234`

### Step 3: Extract and Build on Server

```bash
ssh root@172.235.5.83
# Password: c0llectech@1234

# Once connected:
cd /opt/react_web_app/collection-app

# Backup current files (optional)
mv dist dist.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true

# Extract new files
tar -xzf /tmp/collection-app.tar.gz -C /opt/react_web_app/collection-app/

# Install dependencies
npm install

# Build
npm run build

# Configure Nginx
cp deploy/nginx-production.conf /etc/nginx/sites-available/collection-app
ln -sf /etc/nginx/sites-available/collection-app /etc/nginx/sites-enabled/collection-app

# Test and reload Nginx
nginx -t && systemctl reload nginx

# Clean up
rm /tmp/collection-app.tar.gz
```

---

## Option 3: Setup Git Authentication on Server (For Future Deployments)

### Method A: Using Personal Access Token (Recommended)

1. **Create GitHub Personal Access Token:**
   - Go to: https://github.com/settings/tokens
   - Click "Generate new token (classic)"
   - Select scopes: `repo` (full control of private repositories)
   - Generate and copy the token

2. **Configure on Server:**

```bash
ssh root@172.235.5.83
# Password: c0llectech@1234

cd /opt/react_web_app/collection-app

# Configure git to use token
git remote set-url origin https://YOUR_GITHUB_USERNAME:YOUR_TOKEN@github.com/pankaj3399/collection-app.git

# Test
git pull origin collection-app-ts-tsv1
```

### Method B: Using SSH Key

```bash
ssh root@172.235.5.83
# Password: c0llectech@1234

# Generate SSH key
ssh-keygen -t ed25519 -C "server@172.235.5.83" -f ~/.ssh/id_ed25519 -N ""

# Display public key
cat ~/.ssh/id_ed25519.pub
```

Copy the output and add it to GitHub:
- Go to: https://github.com/settings/keys
- Click "New SSH key"
- Paste the key and save

Then update the remote URL:

```bash
cd /opt/react_web_app/collection-app
git remote set-url origin git@github.com:pankaj3399/collection-app.git
git pull origin collection-app-ts-tsv1
```

---

## Quick Deploy Script (After Git is Configured)

Once git authentication is set up, you can use:

```bash
ssh root@172.235.5.83 "cd /opt/react_web_app/collection-app && git pull origin collection-app-ts-tsv1 && npm install && npm run build && systemctl reload nginx"
```

---

## Recommended: Use Option 1 for Now

**Option 1 is the fastest and doesn't require git setup:**

```bash
# On your local machine:
npm run build
scp -r dist/ root@172.235.5.83:/opt/react_web_app/collection-app/

# Then SSH and configure Nginx:
ssh root@172.235.5.83
cp /opt/react_web_app/collection-app/deploy/nginx-production.conf /etc/nginx/sites-available/collection-app
ln -sf /etc/nginx/sites-available/collection-app /etc/nginx/sites-enabled/collection-app
nginx -t && systemctl reload nginx
```

Your app will be live at: http://172.235.5.83

