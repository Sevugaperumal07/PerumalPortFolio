#!/bin/bash

# Quick Deployment Script - Run this locally to deploy to server
# Usage: ./deploy/quick-deploy.sh

set -e

SERVER_IP="172.235.5.83"
SERVER_USER="root"
APP_DIR="/opt/react_web_app/collection-app"

echo "=========================================="
echo "Quick Deploy to Server"
echo "=========================================="

# Build locally
echo "🔨 Building application locally..."
npm run build

# Upload dist folder to server
echo "📤 Uploading build to server..."
scp -r dist/ ${SERVER_USER}@${SERVER_IP}:${APP_DIR}/

# Upload .env if it exists
if [ -f ".env" ]; then
    echo "📤 Uploading .env file..."
    scp .env ${SERVER_USER}@${SERVER_IP}:${APP_DIR}/
fi

# Upload nginx configuration
echo "📤 Uploading Nginx configuration..."
scp deploy/nginx-production.conf ${SERVER_USER}@${SERVER_IP}:${APP_DIR}/deploy/

# Restart Nginx on server
echo "🔄 Restarting Nginx on server..."
ssh ${SERVER_USER}@${SERVER_IP} << 'EOF'
    cp /opt/react_web_app/collection-app/deploy/nginx-production.conf /etc/nginx/sites-available/collection-app
    ln -sf /etc/nginx/sites-available/collection-app /etc/nginx/sites-enabled/collection-app
    nginx -t && systemctl reload nginx
EOF

echo ""
echo "=========================================="
echo "✅ Quick deployment completed!"
echo "=========================================="
echo ""
echo "Application is now running at:"
echo "http://${SERVER_IP}"
echo ""

