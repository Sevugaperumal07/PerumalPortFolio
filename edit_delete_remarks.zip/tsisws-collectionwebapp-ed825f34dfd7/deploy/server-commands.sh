#!/bin/bash
set -e

APP_DIR="/opt/react_web_app/collection-app"

echo "📂 Extracting source code..."
cd $APP_DIR
tar -xzf /tmp/collection-app-src.tar.gz

echo "📦 Installing dependencies..."
npm install

echo "📝 Creating .env file..."
if [ ! -f ".env" ]; then
    cat > .env << 'EOF'
VITE_API_BASE_URL=http://172.235.1.82:8078
EOF
    echo "✅ .env file created"
else
    echo "ℹ️  .env file already exists"
fi

echo "🌐 Configuring Nginx..."
cp /tmp/nginx-dev-proxy.conf /etc/nginx/sites-available/collection-app
ln -sf /etc/nginx/sites-available/collection-app /etc/nginx/sites-enabled/collection-app
rm -f /etc/nginx/sites-enabled/default

echo "🧪 Testing Nginx configuration..."
nginx -t

echo "🔄 Reloading Nginx..."
systemctl reload nginx

echo "🚀 Starting Vite dev server..."
# Kill any existing dev server
pkill -f "vite" || true

# Start dev server in background with nohup
cd $APP_DIR
nohup npm run dev -- --host 0.0.0.0 --port 5173 > /var/log/vite-dev.log 2>&1 &

echo "✅ Dev server started!"

# Clean up
rm -f /tmp/collection-app-src.tar.gz /tmp/nginx-dev-proxy.conf

echo ""
echo "Waiting for dev server to start..."
sleep 5

# Check if dev server is running
if curl -s http://localhost:5173 > /dev/null; then
    echo "✅ Dev server is running on port 5173"
else
    echo "⚠️  Dev server might still be starting..."
    echo "Check logs: tail -f /var/log/vite-dev.log"
fi

echo ""
echo "=========================================="
echo "✅ Setup Complete!"
echo "=========================================="
echo "Access your app at: http://172.235.5.83"

