#!/bin/bash

# Server Setup Script for Ubuntu
# This script sets up Node.js, Nginx, and required dependencies

set -e

echo "=========================================="
echo "AccountServ - Server Setup Script"
echo "=========================================="

# Update system packages
echo "📦 Updating system packages..."
apt update && apt upgrade -y

# Install essential tools
echo "🔧 Installing essential tools..."
apt install -y curl wget git build-essential

# Install Node.js 18.x
echo "📦 Installing Node.js 18.x..."
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs

# Verify Node.js and npm installation
echo "✅ Node.js version: $(node --version)"
echo "✅ npm version: $(npm --version)"

# Install Nginx
echo "🌐 Installing Nginx..."
apt install -y nginx

# Install PM2 globally for process management
echo "⚙️  Installing PM2..."
npm install -g pm2

# Ensure application directory exists and has correct permissions
echo "📁 Setting up application directory..."
mkdir -p /opt/react_web_app/collection-app
chown -R root:root /opt/react_web_app/collection-app

# Configure firewall (UFW)
echo "🔥 Configuring firewall..."
ufw allow 'Nginx Full'
ufw allow OpenSSH
ufw --force enable

# Enable Nginx to start on boot
echo "🚀 Enabling Nginx..."
systemctl enable nginx
systemctl start nginx

# Create directory for SSL certificates (if needed later)
mkdir -p /etc/nginx/ssl

echo ""
echo "=========================================="
echo "✅ Server setup completed successfully!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Application is located at /opt/react_web_app/collection-app"
echo "2. Configure Nginx with the provided configuration"
echo "3. Build and start your application"
echo ""

