#!/bin/bash

# Setup Development Server with Nginx Reverse Proxy
# This script configures Nginx to proxy port 80 to Vite dev server on port 5173

set -e

SERVER_IP="172.235.5.83"
SERVER_USER="root"
APP_DIR="/opt/react_web_app/collection-app"

echo "=========================================="
echo "🔧 Setup Dev Server with Nginx Proxy"
echo "=========================================="
echo ""
echo "This will:"
echo "  1. Upload source code to server"
echo "  2. Install dependencies on server"
echo "  3. Configure Nginx to proxy port 80 → 5173"
echo "  4. Start Vite dev server on port 5173"
echo "  5. Access via http://${SERVER_IP}"
echo ""
read -p "Continue? (y/n): " confirm

if [ "$confirm" != "y" ]; then
    echo "Setup cancelled."
    exit 0
fi

# Step 1: Create tarball of source code (exclude node_modules, dist, .git)
echo ""
echo "📦 Creating source code archive..."
tar -czf /tmp/collection-app-src.tar.gz \
  --exclude='node_modules' \
  --exclude='dist' \
  --exclude='.git' \
  --exclude='*.log' \
  --exclude='.env' \
  .

echo "✅ Archive created!"

# Step 2: Upload to server
echo ""
echo "📤 Uploading source code to server..."
echo "You will be prompted for password: c0llectech@1234"
scp /tmp/collection-app-src.tar.gz ${SERVER_USER}@${SERVER_IP}:/tmp/

echo "✅ Upload complete!"

# Step 3: Upload nginx dev proxy config
echo ""
echo "📤 Uploading Nginx configuration..."
scp deploy/nginx-dev-proxy.conf ${SERVER_USER}@${SERVER_IP}:/tmp/

# Step 4: Extract, install, and configure on server
echo ""
echo "🔧 Setting up on server..."
ssh ${SERVER_USER}@${SERVER_IP} << 'ENDSSH'
    set -e
    
    APP_DIR="/opt/react_web_app/collection-app"
    
    echo "📂 Extracting source code..."
    cd $APP_DIR
    tar -xzf /tmp/collection-app-src.tar.gz
    
    echo "📦 Installing dependencies..."
    npm install
    
    echo "📝 Creating .env file..."
    if [ ! -f ".env" ]; then
        cat > .env << 'EOF'
VITE_API_BASE_URL=http://172.235.1.82:8078
EOF
        echo "✅ .env file created"
    else
        echo "ℹ️  .env file already exists"
    fi
    
    echo "🌐 Configuring Nginx..."
    cp /tmp/nginx-dev-proxy.conf /etc/nginx/sites-available/collection-app
    ln -sf /etc/nginx/sites-available/collection-app /etc/nginx/sites-enabled/collection-app
    rm -f /etc/nginx/sites-enabled/default
    
    echo "🧪 Testing Nginx configuration..."
    nginx -t
    
    echo "🔄 Reloading Nginx..."
    systemctl reload nginx
    
    echo "🚀 Starting Vite dev server..."
    # Kill any existing dev server
    pkill -f "vite" || true
    
    # Start dev server in background with nohup
    cd $APP_DIR
    nohup npm run dev -- --host 0.0.0.0 --port 5173 > /var/log/vite-dev.log 2>&1 &
    
    echo "✅ Dev server started!"
    
    # Clean up
    rm -f /tmp/collection-app-src.tar.gz /tmp/nginx-dev-proxy.conf
    
    echo ""
    echo "Waiting for dev server to start..."
    sleep 5
    
    # Check if dev server is running
    if curl -s http://localhost:5173 > /dev/null; then
        echo "✅ Dev server is running on port 5173"
    else
        echo "⚠️  Dev server might still be starting..."
        echo "Check logs: tail -f /var/log/vite-dev.log"
    fi
ENDSSH

# Clean up local temp file
rm -f /tmp/collection-app-src.tar.gz

echo ""
echo "=========================================="
echo "✅ Setup Complete!"
echo "=========================================="
echo ""
echo "Your dev server is now accessible at:"
echo "👉 http://${SERVER_IP}"
echo ""
echo "Nginx (port 80) → Vite Dev Server (port 5173)"
echo ""
echo "Useful commands:"
echo "  - View dev server logs: ssh ${SERVER_USER}@${SERVER_IP} 'tail -f /var/log/vite-dev.log'"
echo "  - Restart dev server: ssh ${SERVER_USER}@${SERVER_IP} 'cd ${APP_DIR} && pkill -f vite && nohup npm run dev -- --host 0.0.0.0 --port 5173 > /var/log/vite-dev.log 2>&1 &'"
echo "  - Stop dev server: ssh ${SERVER_USER}@${SERVER_IP} 'pkill -f vite'"
echo ""

