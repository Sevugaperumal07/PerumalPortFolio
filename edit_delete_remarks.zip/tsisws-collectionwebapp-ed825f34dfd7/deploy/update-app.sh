#!/bin/bash

# Quick Update Script - Run this on the server to update the app
# Usage: ./deploy/update-app.sh

set -e

APP_DIR="/opt/react_web_app/collection-app"

echo "=========================================="
echo "Updating Collection App"
echo "=========================================="

cd $APP_DIR

# Pull latest changes if git repo
if [ -d ".git" ]; then
    echo "📥 Pulling latest changes..."
    git pull
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Build
echo "🔨 Building application..."
npm run build

# Reload Nginx
echo "🔄 Reloading Nginx..."
systemctl reload nginx

echo ""
echo "✅ Update completed!"
echo "Application is running at: http://172.235.5.83"
echo ""

