import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { UserRoleProvider } from '@/contexts/UserRoleContext';
import { ExportProvider } from '@/contexts/ExportContext';
import { OtpProvider } from '@/contexts/OtpContext';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Toaster } from '@/components/ui/toaster';
import Login from '@/pages/login/Login';
import ResetPassword from '@/pages/login/ResetPassword';
import OtpVerification from '@/pages/login/OtpVerification';
import Unauthorized from '@/pages/Unauthorized';
import UsersList from '@/pages/dashboard/users/UsersList';
import AddUser from '@/pages/dashboard/users/AddUser';
import ViewUser from '@/pages/dashboard/users/ViewUser';
import EditUser from '@/pages/dashboard/users/EditUser';
import RolesList from '@/pages/dashboard/roles/RolesList';
import AddRole from '@/pages/dashboard/roles/AddRole';
import ViewRole from '@/pages/dashboard/roles/ViewRole';
import EditRole from '@/pages/dashboard/roles/EditRole';
import CloneRole from '@/pages/dashboard/roles/CloneRole';
import SecurityGroupsList from '@/pages/dashboard/security-groups/SecurityGroupsList';
import AddSecurityGroup from '@/pages/dashboard/security-groups/AddSecurityGroup';
import EditSecurityGroup from '@/pages/dashboard/security-groups/EditSecurityGroup';
import BankDetailsList from '@/pages/dashboard/bank-details/BankDetailsList';
import AddBankDetail from '@/pages/dashboard/bank-details/AddBankDetail';
import EditBankDetail from '@/pages/dashboard/bank-details/EditBankDetail';
import TrackAgent from './pages/dashboard/maps/TrackAgent';
import Dashboard from './pages/dashboard/Dashboard';
import TasksList from './pages/dashboard/tasks/TasksList';
import CasesList from './pages/dashboard/cases/CasesList';
import AcceptancePendingList from './pages/dashboard/deposits/AcceptancePendingList';
import InHandBranchList from './pages/dashboard/deposits/InHandBranchList';
import VerifyDepositsList from './pages/dashboard/deposits/VerifyDepositsList';
import VerifiedDepositsList from './pages/dashboard/deposits/VerifiedDepositsList';
import RejectedDepositsList from './pages/dashboard/deposits/RejectedDepositsList';
import NotificationsList from './pages/dashboard/notes/NotificationsList';
import { SessionTimeoutHandler } from './components/session/SessionTimeoutHandler';
import { NavigateSetter } from './lib/utils/NavigateService';

function App() {
  return (
    <AuthProvider>
      <OtpProvider>
        <UserRoleProvider>
          <ExportProvider>
            <BrowserRouter>
              <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/login/verify-otp" element={<OtpVerification />} />
                <Route path="/login/reset-password" element={<ResetPassword />} />
                <Route path="/unauthorized" element={<Unauthorized />} />
                <Route
                  path="/dashboard"
                  element={
                    <ProtectedRoute>
                      <DashboardLayout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<ProtectedRoute category="Dashboard"><Dashboard /></ProtectedRoute>} />

                  {/* User Management */}
                  <Route path="users" element={<ProtectedRoute category="User"><UsersList /></ProtectedRoute>} />
                  <Route path="users/new" element={<ProtectedRoute category="User"><AddUser /></ProtectedRoute>} />
                  <Route path="users/:id" element={<ProtectedRoute category="User"><ViewUser /></ProtectedRoute>} />
                  <Route path="users/:id/edit" element={<ProtectedRoute category="User"><EditUser /></ProtectedRoute>} />

                  {/* Role Management */}
                  <Route path="roles" element={<ProtectedRoute category="AclRole"><RolesList /></ProtectedRoute>} />
                  <Route path="roles/new" element={<ProtectedRoute category="AclRole"><AddRole /></ProtectedRoute>} />
                  <Route path="roles/:id" element={<ProtectedRoute category="AclRole"><ViewRole /></ProtectedRoute>} />
                  <Route path="roles/:id/edit" element={<ProtectedRoute category="AclRole"><EditRole /></ProtectedRoute>} />
                  <Route path="roles/:id/clone" element={<ProtectedRoute category="AclRole"><CloneRole /></ProtectedRoute>} />

                  {/* Security Groups */}
                  <Route path="security-groups" element={<ProtectedRoute category="SecurityGroups"><SecurityGroupsList /></ProtectedRoute>} />
                  <Route path="security-groups/new" element={<ProtectedRoute category="SecurityGroups"><AddSecurityGroup /></ProtectedRoute>} />
                  <Route path="security-groups/:id/edit" element={<ProtectedRoute category="SecurityGroups"><EditSecurityGroup /></ProtectedRoute>} />

                  {/* Bank Details */}
                  <Route path="bank-details" element={<ProtectedRoute category="BankDetails"><BankDetailsList /></ProtectedRoute>} />
                  <Route path="bank-details/new" element={<ProtectedRoute category="BankDetails"><AddBankDetail /></ProtectedRoute>} />
                  <Route path="bank-details/:id/edit" element={<ProtectedRoute category="BankDetails"><EditBankDetail /></ProtectedRoute>} />

                  {/* Tasks and Cases */}
                  <Route path="tasks" element={<ProtectedRoute category="Case"><TasksList /></ProtectedRoute>} />
                  <Route path="cases" element={<ProtectedRoute category="Account"><CasesList /></ProtectedRoute>} />

                  {/* Deposits */}
                  <Route path="deposits/in-hand-branch" element={<ProtectedRoute category="InHandBranch"><InHandBranchList /></ProtectedRoute>} />
                  <Route path="deposits/acceptance-pending" element={<ProtectedRoute category="AcceptancePending"><AcceptancePendingList /></ProtectedRoute>} />
                  <Route path="deposits/verify" element={<ProtectedRoute category="VerificationPending"><VerifyDepositsList /></ProtectedRoute>} />
                  <Route path="deposits/verified" element={<ProtectedRoute category="VerificationCompleted"><VerifiedDepositsList /></ProtectedRoute>} />
                  <Route path="deposits/rejected" element={<ProtectedRoute category="Rejected"><RejectedDepositsList /></ProtectedRoute>} />

                {/* Maps and Notes */}
                <Route path="maps" element={<ProtectedRoute category="MapScreen"><TrackAgent /></ProtectedRoute>} />
                <Route path="notes" element={<NotificationsList />} />
              </Route>
              <Route path="/" element={<Navigate to="/login" replace />} />
            </Routes>
            <Toaster />
            <NavigateSetter />
            <SessionTimeoutHandler />
          </BrowserRouter>
        </ExportProvider>
      </UserRoleProvider>
    </OtpProvider>
    </AuthProvider>
  );
}

export default App;
