import { useState, useEffect } from "react";
import {
    Sheet,
    SheetContent,
    SheetDescription,
    SheetHeader,
    SheetTitle,
    SheetFooter,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, MapPin, RefreshCw } from "lucide-react";
import type { Case } from "@/lib/types";
import { useAddAddress } from "@/hooks/Cases/useAddAddress";
import { useGeolocation } from "@/hooks/useGeolocation";
import { useGeoLocation as useGeoLocationCheck } from "@/hooks/use-location";
import { useToast } from "@/hooks/use-toast";

type AddAddressProps = {
    isOpen: boolean;
    onOpenChange: (open: boolean) => void;
    caseData: Case | null;
    initialCoords?: { latitude: number; longitude: number } | null;
    onSuccess?: () => void;
};

export function AddAddress({ isOpen, onOpenChange, caseData, initialCoords, onSuccess }: AddAddressProps) {
    const [locname, setLocname] = useState("");
    const [address, setAddress] = useState("");
    const [coords, setCoords] = useState<{ latitude: number; longitude: number } | null>(null);
    const { addAddress, isLoading } = useAddAddress();
    const { getCurrentLocation, isFetching: isLocating } = useGeolocation();
    const { withLocation, isChecking } = useGeoLocationCheck();
    const [isFetchingAddress, setIsFetchingAddress] = useState(false);
    const { toast } = useToast();



    const fetchAddressFromCoords = async (lat: number, lng: number) => {
        setIsFetchingAddress(true);
        try {
            const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
            if (!apiKey) {
                console.error("VITE_GOOGLE_MAPS_API_KEY is missing");
                return;
            }

            const response = await fetch(
                `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${apiKey}`
            );
            const data = await response.json();

            if (data.status === "OK" && data.results && data.results.length > 0) {
                setAddress(data.results[0].formatted_address);
            } else {
                console.error("Geocoding API error:", data.status);
                toast({
                    title: "Address Error",
                    description: "Could not detect address for this location.",
                    variant: "destructive"
                });
            }
        } catch (error) {
            console.error("Failed to fetch address:", error);
        } finally {
            setIsFetchingAddress(false);
        }
    };

    const handleDetectLocation = async () => {
        await withLocation(async () => {
            try {
                const location = await getCurrentLocation();
                setCoords(location);
                await fetchAddressFromCoords(location.latitude, location.longitude);
            } catch (error) {
                console.error("Location detection failed:", error);
            }
        });
    };

    // Auto-detect location when sheet opens
    useEffect(() => {
        if (isOpen) {
            if (initialCoords) {
                setCoords(initialCoords);
                fetchAddressFromCoords(initialCoords.latitude, initialCoords.longitude);
            } else if (!coords || !address) {
                handleDetectLocation();
            }
        }
    }, [isOpen, initialCoords]);

    const handleSave = async () => {
        if (!caseData || !locname.trim() || !address.trim() || !coords) return;

        const result = await addAddress(caseData, {
            locname: locname.trim(),
            address: address.trim(),
            latitude: coords.latitude,
            longitude: coords.longitude,
        });

        if (result) {
            setLocname("");
            setAddress("");
            setCoords(null);
            onSuccess?.();
            onOpenChange(false);
        }
    };

    if (!caseData) return null;

    return (
        <Sheet open={isOpen} onOpenChange={onOpenChange}>
            <SheetContent side="right" className="w-full sm:max-w-md">
                <SheetHeader>
                    <SheetTitle>Add Address</SheetTitle>
                    <SheetDescription>
                        Detect and add a new address for case {caseData.account?.lanNumber || caseData.caseNumber}.
                    </SheetDescription>
                </SheetHeader>
                <div className="py-6 space-y-6">
                    <div className="space-y-2">
                        <Label htmlFor="locname">Address Type <span className="text-red-500 ml-0.5">*</span></Label>
                        <Input
                            id="locname"
                            placeholder="e.g. Home, Office, Property"
                            value={locname}
                            onChange={(e) => setLocname(e.target.value)}
                        />
                    </div>

                    <div className="space-y-3 p-4 rounded-lg bg-muted/50 border border-dashed border-gray-200">
                        <div className="flex items-center justify-between">
                            <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                                <MapPin className="h-3.5 w-3.5" />
                                Current Address
                            </Label>
                            <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 text-xs gap-1"
                                onClick={handleDetectLocation}
                                disabled={isLocating || isChecking || isFetchingAddress}
                            >
                                <RefreshCw className={`h-3 w-3 ${isLocating || isFetchingAddress ? 'animate-spin' : ''}`} />
                                Refresh
                            </Button>
                        </div>

                        {isFetchingAddress || isLocating || isChecking ? (
                            <div className="flex items-center gap-2 text-sm text-muted-foreground py-2">
                                <Loader2 className="h-4 w-4 animate-spin" />
                                Detecting location...
                            </div>
                        ) : address ? (
                            <p className="text-sm font-medium leading-relaxed">
                                {address}
                            </p>
                        ) : (
                            <p className="text-sm text-muted-foreground italic">
                                No location detected. Click refresh to try again.
                            </p>
                        )}
                    </div>
                </div>
                <SheetFooter>
                    <Button
                        type="submit"
                        className="w-full"
                        onClick={handleSave}
                        disabled={isLoading || isLocating || isChecking || isFetchingAddress || !locname.trim() || !address.trim()}
                    >
                        {isLoading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                            </>
                        ) : (
                            "Save Address"
                        )}
                    </Button>
                </SheetFooter>
            </SheetContent>
        </Sheet>
    );
}
