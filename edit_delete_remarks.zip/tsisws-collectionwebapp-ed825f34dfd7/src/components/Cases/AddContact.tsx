import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";
import type { Case } from "@/lib/types";
import { useAddContact } from "@/hooks/Cases/useAddContact";
import { useGeolocation } from "@/hooks/useGeolocation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const contactFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  phone: z
    .string()
    .min(1, "Phone number is required")
    .regex(/^[6789][0-9]{9}$/, "Please enter a valid phone number"),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

type AddContactProps = {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  caseData: Case | null;
  onSuccess?: () => void;
};

export function AddContact({ isOpen, onOpenChange, caseData, onSuccess }: AddContactProps) {
  const { addContact, isLoading: isSaving } = useAddContact();
  const { getCurrentLocation, isFetching: isLocating } = useGeolocation();

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    mode: "onChange",
    defaultValues: {
      name: "",
      phone: "",
    },
  });

  const handleSubmit = async (data: ContactFormValues) => {
    if (!caseData) return;

    try {
      const location = await getCurrentLocation();
      const result = await addContact(caseData, {
        name: data.name,
        phone: data.phone,
        latitude: location.latitude,
        longitude: location.longitude,
      });

      if (result) {
        form.reset();
        onSuccess?.();
        onOpenChange(false);
      }
    } catch (error) {
      // Geolocation hook handles its own error toasts
      console.error("Submission failed:", error);
    }
  };

  const isLoading = isSaving || isLocating;
  const isFormValid = form.formState.isValid;

  if (!caseData) return null;

  return (
    <Sheet open={isOpen} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-md">
        <SheetHeader>
          <SheetTitle>Add New Contact</SheetTitle>
          <SheetDescription>
            Add a new contact for case{" "}
            {caseData.account?.applicationNumber ||
              caseData.account?.lanNumber ||
              caseData.caseNumber}
            .
          </SheetDescription>
        </SheetHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6 py-6">
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Name <span className="text-red-500 ml-0.5">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input placeholder="Contact Name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Phone Number <span className="text-red-500 ml-0.5">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="tel"
                        placeholder="1234567890"
                        maxLength={10}
                        {...field}
                        onChange={(e) => {
                          const rawValue = e.target.value;
                          const strippedValue = rawValue.replace(/[^0-9]/g, "");

                          field.onChange(strippedValue);

                          if (rawValue !== strippedValue) {
                            setTimeout(() => {
                              form.setError("phone", {
                                type: "manual",
                                message: "Only numbers are allowed",
                              });
                            }, 0);
                          } else if (strippedValue.length > 0 && !/^[6-9]/.test(strippedValue)) {
                            setTimeout(() => {
                              form.setError("phone", {
                                type: "manual",
                                message: "Please enter a valid number",
                              });
                            }, 0);
                          } else {
                            if (form.formState.errors.phone?.type === "manual") {
                              form.clearErrors("phone");
                            }
                          }
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <SheetFooter>
              <Button
                type="submit"
                className="w-full"
                disabled={isLoading || !isFormValid}
              >
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Save Contact
              </Button>
            </SheetFooter>
          </form>
        </Form>
      </SheetContent>
    </Sheet>
  );
}
