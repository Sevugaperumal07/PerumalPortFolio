import {
    Sheet,
    SheetContent,
    SheetDescription,
    SheetHeader,
    SheetTitle,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SearchableSelect } from "@/components/ui/searchable-select";
import type { AdvancedFilterParamsCases, StateSecurityGroup, BranchRecord} from "@/lib/types";

interface Agent {
    id: string;
    userName: string;
}

interface AdvanceSearchCasesProps {
    isOpen: boolean;
    setIsOpen: (open: boolean) => void;
    filters: AdvancedFilterParamsCases;
    updateFilter: (filters: Partial<AdvancedFilterParamsCases>) => void;
    states: StateSecurityGroup[];
    branches: BranchRecord[];
    agents: Agent[];
    isLoadingAgents: boolean;
    onApplyFilters: () => void;
    onResetFilters: () => void;
}

export function AdvanceSearchCases({
    isOpen,
    setIsOpen,
    filters,
    updateFilter,
    states,
    branches,
    agents,
    isLoadingAgents,
    onApplyFilters,
    onResetFilters,
}: AdvanceSearchCasesProps) {


        return (
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetContent side="right" className="w-full sm:max-w-md overflow-y-auto bg-white">
                <SheetHeader>
                    <SheetTitle className="text-xl font-bold text-gray-900">
                        Advanced Search
                    </SheetTitle>
                    <SheetDescription className="text-sm text-gray-600">
                        Filter tasks by multiple criteria.
                    </SheetDescription>
                </SheetHeader>
                <div className="space-y-6 mt-6">
                    {/* State */}
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">State</Label>
                        <SearchableSelect
                            value={filters.state || "all"}
                            onValueChange={(val) => updateFilter({ state: val === "all" ? "" : val })}
                            placeholder="Select State"
                            options={[
                                { value: "all", label: "All States" },
                                ...Array.from(new Map((states || []).filter(s => s && s.stateName).map(s => [s.stateName, s])).values()).map((state) => ({
                                    value: state.stateName,
                                    label: state.stateName
                                }))
                            ]}
                        />
                    </div>

                    {/* Branch - Always visible, disabled until state is selected */}
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">Branch</Label>
                        <SearchableSelect
                            value={filters.branch || "all"}
                            onValueChange={(val) => updateFilter({ branch: val === "all" ? "" : val })}
                            disabled={!filters.state || filters.state === "all"}
                            placeholder={!filters.state || filters.state === "all" ? "Select state first" : "Select branch"}
                            options={[
                                { value: "all", label: "All Branches" },
                                ...Array.from(new Map((branches || []).filter(b => b && b.name).map(b => [b.name, b])).values()).map((branch) => ({
                                    value: String(branch.name),
                                    label: String(branch.name)
                                }))
                            ]}
                        />
                    </div>

                    {/* Agent - Always visible, disabled until branch is selected */}
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">Agent</Label>
                        <SearchableSelect
                            value={filters.agent || "all"}
                            onValueChange={(val) => updateFilter({ agent: val === "all" ? "" : val })}
                            disabled={!filters.branch || filters.branch === "all" || isLoadingAgents}
                            placeholder={
                                !filters.branch || filters.branch === "all"
                                    ? "Select branch first"
                                    : isLoadingAgents
                                        ? "Loading agents..."
                                        : "Select agent"
                            }
                            options={[
                                { value: "all", label: "All Agents" },
                                ...Array.from(new Map((agents || []).filter(a => a && a.id).map(a => [a.id, a])).values()).map((agent) => ({
                                    value: agent.userName,
                                    label: agent.userName
                                }))
                            ]}
                        />
                    </div>


                    {/* LAN Number */}
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">LAN Number</Label>
                        <Input
                            placeholder="Enter LAN number"
                            value={filters.lan}
                            onChange={(e) => updateFilter({ lan: e.target.value })}
                        />
                    </div>


                    {/* Action Buttons */}
                    <div className="flex gap-3 pt-4 justify-end items-center mx-auto">
                        <button
                            className="flex text-gray-900 hover:text-white hover:bg-rose-500 cursor-pointer rounded-md p-2 justify-center items-center"
                            onClick={onResetFilters}
                        >
                            Reset
                        </button>
                        <Button
                            className="flex bg-blue-800 text-white hover:bg-blue-900"
                            onClick={onApplyFilters}
                        >
                            Apply Filters
                        </Button>
                    </div>
                </div>
            </SheetContent>
        </Sheet>
    );
}
