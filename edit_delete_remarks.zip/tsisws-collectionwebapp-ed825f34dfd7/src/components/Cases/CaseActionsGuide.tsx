import {
    Sheet,
    SheetContent,
    SheetDescription,
    SheetHeader,
    SheetTitle,
} from "@/components/ui/sheet";
import {
    Info,
    File,
    ListTodo,
    History,
    Eye,
    // UserPlus,
    // Home,
} from "lucide-react";

interface CaseActionsGuideProps {
    isOpen: boolean;
    setIsOpen: (open: boolean) => void;
}

export function CaseActionsGuide({ isOpen, setIsOpen }: CaseActionsGuideProps) {
    return (
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetContent side="right" className="w-full sm:max-w-md overflow-y-auto bg-white">
                <SheetHeader>
                    <SheetTitle className="text-xl font-bold text-gray-900">
                        Case Actions Guide
                    </SheetTitle>
                    <SheetDescription className="text-sm text-gray-600">
                        A quick reference for the actions available on this page.
                    </SheetDescription>
                </SheetHeader>
                <div className="space-y-4 mt-6">
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <Info className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Action Descriptions</h3>
                            <p className="text-sm text-gray-600">
                                Displays this guide to all available actions.
                            </p>
                        </div>
                    </div>

                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <File className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Add Notes</h3>
                            <p className="text-sm text-gray-600">
                                Add notes to selected cases or use AI-generated suggestions.
                            </p>
                        </div>
                    </div>

                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <ListTodo className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">View Tasks</h3>
                            <p className="text-sm text-gray-600">
                                See all recovery tasks for the case when disbursed and has tasks.
                            </p>
                        </div>
                    </div>

                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <History className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">View History</h3>
                            <p className="text-sm text-gray-600">
                                Access the detailed note history for a single case.
                            </p>
                        </div>
                    </div>

                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <Eye className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">View Details</h3>
                            <p className="text-sm text-gray-600">
                                Open a side sheet with complete case, customer, and co-applicant info.
                            </p>
                        </div>
                    </div>

                    {/* <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <UserPlus className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Add Contact</h3>
                            <p className="text-sm text-gray-600">
                                Add a new contact person to a case.
                            </p>
                        </div>
                    </div>

                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <Home className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Add Address</h3>
                            <p className="text-sm text-gray-600">
                                Add a new address (e.g., property, correspondence) to a case.
                            </p>
                        </div>
                    </div> */}
                </div>
            </SheetContent>
        </Sheet>
    );
}
