import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/contexts/UserRoleContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  category?: string;
}

/**
 * ProtectedRoute handles both Authentication and Authorization.
 * It ensures the user is logged in, and if a category is provided,
 * verifies they have the required permissions.
 */
export function ProtectedRoute({ children, category }: ProtectedRouteProps) {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const { canAccessCategory, roleMatrixData, isInitialized } = useUserRole();
  const location = useLocation();

  // 1. Loading State: Wait for Auth and the first Role fetch to complete
  const isLoading = authLoading || (isAuthenticated && !isInitialized);
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background/50 backdrop-blur-sm">
        <div className="flex flex-col items-center gap-4 p-8 rounded-2xl bg-card shadow-xl border animate-in fade-in zoom-in duration-300">
          <div className="relative">
            <div className="h-12 w-12 animate-spin rounded-full border-4 border-rose-500/20 border-t-rose-500" />
            <div className="absolute inset-0 h-12 w-12 animate-ping rounded-full border-4 border-rose-500/10" />
          </div>
          <div className="flex flex-col items-center gap-1">
            <h3 className="font-semibold text-foreground">
              {authLoading ? 'Authenticating...' : 'Syncing Permissions...'}
            </h3>
            <p className="text-xs text-muted-foreground animate-pulse">
              Please wait while we prepare your workspace
            </p>
          </div>
        </div>
      </div>
    );
  }

  // 2. Authentication Check
  if (!isAuthenticated) {
    // Save the attempted location so we can redirect back after login
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  // 3. Data Integrity Check
  // If authenticated but no role data, we should stay in loading or redirect to unauthorized
  if (!roleMatrixData) {
    return <Navigate to="/unauthorized" replace />;
  }

  // 4. Global WebApp Access Check
  if (!canAccessCategory("WebApp", "ACCESS")) {
    return <Navigate to="/unauthorized" replace />;
  }

  // 5. Authorization Check (Category-based)
  if (category && !canAccessCategory(category)) {
    return <Navigate to="/unauthorized" replace />;
  }

  // 6. Access Granted
  return <>{children}</>;
}

