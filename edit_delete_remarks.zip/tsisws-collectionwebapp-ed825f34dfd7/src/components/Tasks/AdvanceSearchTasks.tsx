import { useState, useEffect } from "react";
import { format } from "date-fns";
import {
    Sheet,
    SheetContent,
    SheetDescription,
    SheetHeader,
    SheetTitle,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "@/components/ui/popover";
import { SearchableSelect } from "@/components/ui/searchable-select";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Calendar as CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import type { AdvancedFilterParams, StateSecurityGroup, BranchRecord, EmiPendingBucket, CommonDateType } from "@/lib/types";

interface Agent {
    id: string;
    userName: string;
}

interface AdvanceSearchTasksProps {
    isOpen: boolean;
    setIsOpen: (open: boolean) => void;
    filters: AdvancedFilterParams;
    updateFilter: (filters: Partial<AdvancedFilterParams>) => void;
    states: StateSecurityGroup[];
    branches: BranchRecord[];
    agents: Agent[];
    isLoadingAgents: boolean;
    emiPendings: EmiPendingBucket[];
    isLoadingEmiPendings: boolean;
    onApplyFilters: () => void;
    onResetFilters: () => void;
}

const STATUS_OPTIONS = [
    { label: "Terminated", value: "TERMINATED" },
    { label: "Broken PTP", value: "BROKEN_PTP" },
    { label: "Closed By System", value: "CLOSED_BY_SYSTEM" },
    { label: "Additional Payment", value: "ADDITIONAL_PAYMENT" },
    { label: "Pending", value: "PENDING" },
    { label: "Partial Payment", value: "PARTIAL_PAYMENT" },
    { label: "Completed", value: "COMPLETED" },
    { label: "Refuse To Pay", value: "REFUSE_TO_PAY" },
    { label: "Promise To Pay", value: "PROMISE_TO_PAY" },
    { label: "House Lock", value: "HOUSE_LOCK" },
];

export function AdvanceSearchTasks({
    isOpen,
    setIsOpen,
    filters,
    updateFilter,
    states,
    branches,
    agents,
    isLoadingAgents,
    emiPendings,
    isLoadingEmiPendings,
    onApplyFilters,
    onResetFilters,
}: AdvanceSearchTasksProps) {
    const [dateRangePopoverOpen, setDateRangePopoverOpen] = useState(false);
    const [tempDateRange, setTempDateRange] = useState<{ from?: Date; to?: Date }>(filters.dateRange);

    const handleApplyDateRange = () => {
        updateFilter({ dateRange: tempDateRange });
        setDateRangePopoverOpen(false);
    };

    const handleCancelDateRange = () => {
        setTempDateRange(filters.dateRange);
        setDateRangePopoverOpen(false);
    };

    const handleOpenChange = (open: boolean) => {
        if (open) {
            setTempDateRange(filters.dateRange);
        }
        setDateRangePopoverOpen(open);
    };

    useEffect(() => {
        setTempDateRange(filters.dateRange);
    }, [filters.dateRange]);
    return (
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetContent side="right" className="w-full sm:max-w-md overflow-y-auto bg-white">
                <SheetHeader>
                    <SheetTitle className="text-xl font-bold text-gray-900">
                        Advanced Search
                    </SheetTitle>
                    <SheetDescription className="text-sm text-gray-600">
                        Filter tasks by multiple criteria.
                    </SheetDescription>
                </SheetHeader>
                <div className="space-y-6 mt-6">
                    {/* Date Filter - Combined Type Selector and Range Picker */}
                    <div className="space-y-2">
                        <div className="flex items-center gap-1">
                            <Label className="text-sm font-medium text-gray-700">
                                {filters.dateType === "ACTIVITY_DATE" ? "Activity Date" : "Date Modified"}
                            </Label>
                            <Select
                                value={filters.dateType}
                                onValueChange={(val) => updateFilter({ dateType: val as CommonDateType })}
                            >
                                <SelectTrigger className="w-8 h-8 border-none bg-transparent shadow-none p-0 focus:ring-0 focus:ring-offset-0">
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="ACTIVITY_DATE">Activity Date</SelectItem>
                                    <SelectItem value="MODIFIED_DATE">Date Modified</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <Popover open={dateRangePopoverOpen} onOpenChange={handleOpenChange}>
                            <PopoverTrigger asChild>
                                <Button
                                    variant="outline"
                                    className={cn(
                                        "w-full justify-start text-left font-normal",
                                        !filters.dateRange.from && "text-muted-foreground"
                                    )}
                                >
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {tempDateRange.from ? (
                                        tempDateRange.to ? (
                                            <>
                                                {format(tempDateRange.from, "yyyy MMM dd")} -{" "}
                                                {format(tempDateRange.to, "yyyy MMM dd")}
                                            </>
                                        ) : (
                                            format(tempDateRange.from, "yyyy MMM dd")
                                        )
                                    ) : (
                                        <span>Pick a date range</span>
                                    )}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                    mode="range"
                                    selected={{ from: tempDateRange.from, to: tempDateRange.to }}
                                    onSelect={(range) => {
                                        setTempDateRange({
                                            from: range?.from,
                                            to: range?.to,
                                        });
                                    }}
                                    numberOfMonths={1}
                                    initialFocus
                                    disabled={{ after: new Date() }}
                                />
                                <div className="flex items-center justify-end gap-2 p-3 border-t bg-gray-50">
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={handleCancelDateRange}
                                        className="h-8 text-xs text-gray-600 hover:text-gray-900"
                                    >
                                        Cancel
                                    </Button>
                                    <Button
                                        size="sm"
                                        onClick={handleApplyDateRange}
                                        className="h-8 text-xs bg-blue-800 text-white hover:bg-blue-900 px-4"
                                    >
                                        Apply
                                    </Button>
                                </div>
                            </PopoverContent>
                        </Popover>
                    </div>

                    {/* State */}
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">State</Label>
                        <SearchableSelect
                            value={filters.state || "all"}
                            onValueChange={(val) => updateFilter({ state: val === "all" ? "" : val })}
                            placeholder="Select State"
                            options={[
                                { value: "all", label: "All States" },
                                ...Array.from(new Map((states || []).filter(s => s && s.stateName).map(s => [s.stateName, s])).values()).map((state) => ({
                                    value: state.stateName,
                                    label: state.stateName
                                }))
                            ]}
                        />
                    </div>

                    {/* Branch - Always visible, disabled until state is selected */}
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">Branch</Label>
                        <SearchableSelect
                            value={filters.branch || "all"}
                            onValueChange={(val) => updateFilter({ branch: val === "all" ? "" : val })}
                            disabled={!filters.state || filters.state === "all"}
                            placeholder={!filters.state || filters.state === "all" ? "Select state first" : "Select branch"}
                            options={[
                                { value: "all", label: "All Branches" },
                                ...Array.from(new Map((branches || []).filter(b => b && b.name).map(b => [b.name, b])).values()).map((branch) => ({
                                    value: String(branch.name),
                                    label: String(branch.name)
                                }))
                            ]}
                        />
                    </div>

                    {/* Agent - Always visible, disabled until branch is selected */}
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">Agent</Label>
                        <SearchableSelect
                            value={filters.agent || "all"}
                            onValueChange={(val) => updateFilter({ agent: val === "all" ? "" : val })}
                            disabled={!filters.branch || filters.branch === "all" || isLoadingAgents}
                            placeholder={
                                !filters.branch || filters.branch === "all"
                                    ? "Select branch first"
                                    : isLoadingAgents
                                        ? "Loading agents..."
                                        : "Select agent"
                            }
                            options={[
                                { value: "all", label: "All Agents" },
                                ...Array.from(new Map((agents || []).filter(a => a && a.id).map(a => [a.id, a])).values()).map((agent) => ({
                                    value: agent.userName,
                                    label: agent.userName
                                }))
                            ]}
                        />
                    </div>

                    {/* Status */}
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">Status</Label>
                        <SearchableSelect
                            value={filters.status || "all"}
                            onValueChange={(val) => updateFilter({ status: val === "all" ? "" : val })}
                            placeholder="Select Status"
                            options={[
                                { value: "all", label: "All Statuses" },
                                ...STATUS_OPTIONS.map((status) => ({
                                    value: status.value,
                                    label: status.label
                                }))
                            ]}
                        />
                    </div>

                    {/* EMI-Pending */}
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">EMI-Pending</Label>
                        <SearchableSelect
                            value={filters.emiPendingBucket || "all"}
                            onValueChange={(val) => {
                                if (val === "all") {
                                    updateFilter({
                                        emiPendingBucket: "",
                                        dpdFrom: undefined,
                                        dpdTo: undefined
                                    });
                                } else {
                                    const bucket = emiPendings.find(b => b.bucketCode === val);
                                    updateFilter({
                                        emiPendingBucket: val,
                                        dpdFrom: bucket?.fromRange,
                                        dpdTo: bucket?.toRange
                                    });
                                }
                            }}
                            disabled={isLoadingEmiPendings}
                            placeholder={isLoadingEmiPendings ? "Loading buckets..." : "Select EMI Bucket"}
                            options={[
                                { value: "all", label: "All EMI-Pending" },
                                ...(emiPendings || []).map((bucket) => ({
                                    value: bucket.bucketCode,
                                    label: bucket.bucketCode
                                }))
                            ]}
                        />
                    </div>

                    {/* LAN Number */}
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">LAN Number</Label>
                        <Input
                            placeholder="Enter LAN number"
                            value={filters.lan}
                            onChange={(e) => updateFilter({ lan: e.target.value })}
                        />
                    </div>

                    {/* Receipt No */}
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">Receipt No</Label>
                        <Input
                            placeholder="Enter receipt number"
                            value={filters.receipt}
                            onChange={(e) => updateFilter({ receipt: e.target.value })}
                        />
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-3 pt-4 justify-end items-center mx-auto">
                        <button
                            className="flex text-gray-900 hover:text-white hover:bg-rose-500 cursor-pointer rounded-md p-2 justify-center items-center"
                            onClick={onResetFilters}
                        >
                            Reset
                        </button>
                        <Button
                            className="flex bg-blue-800 text-white hover:bg-blue-900"
                            onClick={onApplyFilters}
                        >
                            Apply Filters
                        </Button>
                    </div>
                </div>
            </SheetContent>
        </Sheet>
    );
}
