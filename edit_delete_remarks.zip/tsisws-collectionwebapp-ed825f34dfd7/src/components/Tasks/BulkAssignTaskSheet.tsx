import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
    Sheet,
    SheetContent,
    SheetDescription,
    SheetHeader,
    SheetTitle
} from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import { useBulkAssignTask } from "@/hooks/Tasks/useBulkAssignTask";
import type { AgentRecord, Task } from "@/lib/types";
import { cn } from "@/lib/utils";
import { CheckCircle2, Loader2, Search, UserPlus, X, Info } from "lucide-react";
import { useCallback, useEffect, useRef } from "react";

interface BulkAssignTaskSheetProps {
    isOpen: boolean;
    onOpenChange: (open: boolean) => void;
    selectedTasks: Task[];
    onSuccess: () => void;
    securityGroupId: string | null;
}

export function BulkAssignTaskSheet({
    isOpen,
    onOpenChange,
    selectedTasks,
    onSuccess,
    securityGroupId
}: BulkAssignTaskSheetProps) {
    const {
        step,
        selectedAgentId,
        setSelectedAgentId,
        isSubmitting,
        assignmentType,
        setAssignmentType,
        agents,
        searchTerm,
        setSearchTerm,
        loadingAgents,
        hasNext,
        handleLoadMore,
        handleAssign,
        fetchAgents,
        hasFetchedInitial
    } = useBulkAssignTask({
        isOpen,
        selectedTasks,
        onOpenChange,
        onSuccess,
        securityGroupId
    });

    const sentinelRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen && step === 'agent_selection' && !hasFetchedInitial && !loadingAgents) {
            fetchAgents(0, "");
        }
    }, [isOpen, step, hasFetchedInitial, loadingAgents, fetchAgents]);

    // Intersection observer for infinite scroll
    const onIntersection = useCallback((entries: IntersectionObserverEntry[]) => {
        const [entry] = entries;
        if (entry.isIntersecting && hasNext && !loadingAgents) {
            handleLoadMore();
        }
    }, [hasNext, loadingAgents, handleLoadMore]);

    useEffect(() => {
        const observer = new IntersectionObserver(onIntersection, {
            root: null,
            rootMargin: '100px',
            threshold: 0.1
        });

        if (sentinelRef.current) observer.observe(sentinelRef.current);
        return () => observer.disconnect();
    }, [onIntersection]);

    // Handle search debounce
    useEffect(() => {
        if (!isOpen) return;
        const timer = setTimeout(() => {
            fetchAgents(0, searchTerm);
        }, 500);
        return () => clearTimeout(timer);
    }, [searchTerm, isOpen, fetchAgents]);

    return (
        <Sheet open={isOpen} onOpenChange={onOpenChange}>
            <SheetContent side="right" className="w-full sm:max-w-md flex flex-col h-full bg-white p-0 overflow-hidden">
                {/* Sticky Header */}
                <SheetHeader className="p-6 border-b bg-white shrink-0 z-20">
                    <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
                            <UserPlus className="h-5.5 w-5.5" />
                        </div>
                        <div>
                            <SheetTitle className="text-xl font-bold text-slate-900">Assign Case And Task</SheetTitle>
                            <SheetDescription className="text-slate-500 font-medium">
                                Assign {selectedTasks.length} selected items to an agent.
                            </SheetDescription>
                        </div>
                    </div>
                </SheetHeader>

                {/* Main Scrollable Area */}
                <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col min-h-0 bg-white">
                    {step === 'loading' && (
                        <div className="flex-1 flex flex-col items-center justify-center p-12 space-y-4">
                            <Loader2 className="h-10 w-10 text-blue-600 animate-spin" />
                            <p className="text-sm text-gray-500 font-medium">Checking assignment status...</p>
                        </div>
                    )}

                    {step === 'agent_selection' && (
                        <div className="flex flex-col h-full">
                            {/* Content Section */}
                            <div className="p-6 space-y-8 flex-1">
                                <div className="space-y-5">
                                    <RadioGroup
                                        value={assignmentType}
                                        onValueChange={(val) => setAssignmentType(val as any)}
                                        className="flex items-center gap-8"
                                    >
                                        <div className="flex items-center space-x-2.5 cursor-pointer group">
                                            <RadioGroupItem value="ASSIGN_BOTH" id="assign-both" className="h-5 w-5 text-blue-600 border-slate-300" />
                                            <Label
                                                htmlFor="assign-both"
                                                className="text-[13px] font-semibold text-slate-600 flex items-center gap-2 cursor-pointer"
                                            >
                                                Assign Task And Case
                                            </Label>
                                        </div>
                                        <div className="flex items-center space-x-2.5 cursor-pointer group">
                                            <RadioGroupItem value="ASSIGN_TASK" id="assign-task" className="h-5 w-5 text-blue-600 border-slate-300" />
                                            <Label
                                                htmlFor="assign-task"
                                                className="text-[13px] font-semibold text-slate-600 flex items-center gap-2 cursor-pointer"
                                            >
                                                Assign Task
                                            </Label>
                                        </div>
                                    </RadioGroup>

                                    <div className="space-y-3">
                                        {assignmentType === 'ASSIGN_BOTH' ? (
                                            <div className="flex gap-3 p-3.5 bg-blue-50/50 rounded-xl border-l-4 border-blue-500 animate-in fade-in slide-in-from-left-2 duration-300">
                                                <Info className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
                                                <div className="space-y-1">
                                                    <p className="text-[12px] font-bold text-blue-900">Assign Case and Task</p>
                                                    <p className="text-[11px] leading-relaxed text-slate-600">
                                                        Current LAN task and future tasks until changed again will be assigned to the selected user. 
                                                        <span className="block mt-1 text-blue-700 font-semibold italic">Best for permanent reassignments.</span>
                                                    </p>
                                                </div>
                                            </div>
                                        ) : (
                                            <div className="flex gap-3 p-3.5 bg-amber-50/50 rounded-xl border-l-4 border-amber-500 animate-in fade-in slide-in-from-left-2 duration-300">
                                                <Info className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                                                <div className="space-y-1">
                                                    <p className="text-[12px] font-bold text-amber-900">Assign Task Only</p>
                                                    <p className="text-[11px] leading-relaxed text-slate-600">
                                                        This is a temporary assignment for the current task only. 
                                                        <span className="block mt-1 text-amber-700 font-semibold italic">Use for sick leave or temporary cover.</span>
                                                    </p>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <div className="space-y-3">
                                    <Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                        Selected LANs ({selectedTasks.length}):
                                    </Label>
                                    <div className="flex flex-wrap gap-1.5 p-2 bg-slate-50/50 rounded-xl border border-slate-100 max-h-[120px] overflow-y-auto custom-scrollbar">
                                        {selectedTasks.map((task) => (
                                            <Badge key={task.id} variant="secondary" className="text-[10px] h-5 bg-white border-slate-200 text-slate-600">
                                                {task.lan}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>

                                <div className="space-y-4">
                                    <Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                        Find & Select Agent:
                                    </Label>
                                    <div className="relative group">
                                        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                                        <Input
                                            placeholder="Search agents by name..."
                                            className="pl-10 h-11 border-slate-200 rounded-xl focus:ring-blue-100 transition-all bg-slate-50/30"
                                            value={searchTerm}
                                            onChange={(e) => setSearchTerm(e.target.value)}
                                        />
                                        {searchTerm ? (
                                            <button
                                                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                                                onClick={() => setSearchTerm("")}
                                            >
                                                <X className="h-4 w-4" />
                                            </button>
                                        ) : (
                                            <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-300 pointer-events-none">
                                                <Search className="h-4 w-4" />
                                            </div>
                                        )}
                                    </div>
                                    <div className="flex items-center justify-between text-[11px] text-gray-500 font-bold uppercase tracking-tighter px-1">
                                        <span>Click below to select an agent</span>
                                        <span>Scroll for more</span>
                                    </div>

                                    <div className="space-y-1.5 max-h-[320px] overflow-y-auto custom-scrollbar pr-2 py-1 -mr-2">
                                        {agents.map((agent: AgentRecord) => (
                                            <div
                                                key={agent.id}
                                                className={cn(
                                                    "flex items-center justify-between p-3.5 rounded-xl cursor-pointer border transition-all",
                                                    selectedAgentId === agent.id
                                                        ? "bg-blue-50 border-blue-200 shadow-sm"
                                                        : "hover:bg-slate-50 border-transparent hover:border-slate-100"
                                                )}
                                                onClick={() => setSelectedAgentId(agent.id)}
                                            >
                                                <div className="flex items-center gap-3.5">
                                                    <div className={cn(
                                                        "h-9 w-9 rounded-full flex items-center justify-center text-xs font-bold transition-colors",
                                                        selectedAgentId === agent.id ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-600"
                                                    )}>
                                                        {agent.userName.split(' ').map((n: string) => n[0]).join('').toUpperCase()}
                                                    </div>
                                                    <span className={cn(
                                                        "text-[13px] font-semibold transition-colors",
                                                        selectedAgentId === agent.id ? "text-blue-700" : "text-slate-700"
                                                    )}>{agent.userName}</span>
                                                </div>
                                                {selectedAgentId === agent.id ? (
                                                    <div className="h-5 w-5 bg-blue-600 rounded-full flex items-center justify-center">
                                                        <div className="h-1.5 w-1.5 bg-white rounded-full" />
                                                    </div>
                                                ) : (
                                                    <div className="h-5 w-5 rounded-full border border-slate-200 bg-white" />
                                                )}
                                            </div>
                                        ))}
                                        {loadingAgents && Array.from({ length: 3 }).map((_, i) => (
                                            <div key={`skel-${i}`} className="flex items-center gap-3.5 p-3.5">
                                                <Skeleton className="h-9 w-9 rounded-full" />
                                                <Skeleton className="h-4 w-32" />
                                            </div>
                                        ))}
                                        <div ref={sentinelRef} className="h-4 w-full" />
                                        {!loadingAgents && agents.length === 0 && (
                                            <div className="text-center py-12 text-sm text-slate-400 bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
                                                No agents found.
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>

                            {/* Sticky Footer Area - Stay bottom of steps */}
                            <div className="p-6 border-t bg-slate-50/30 space-y-2 shrink-0 mt-auto">
                                <Button
                                    className="w-full bg-blue-600 hover:bg-blue-700 text-white h-12 font-bold shadow-md shadow-blue-100 disabled:opacity-50 transition-all"
                                    disabled={!selectedAgentId || isSubmitting}
                                    onClick={handleAssign}
                                >
                                    {isSubmitting ? (
                                        <>
                                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                            Processing...
                                        </>
                                    ) : (
                                        `Assign ${assignmentType === 'ASSIGN_BOTH' ? 'Task and Case' : 'Task'}`
                                    )}
                                </Button>
                                <Button
                                    variant="ghost"
                                    className="w-full h-12 text-slate-500 font-medium"
                                    onClick={() => onOpenChange(false)}
                                    disabled={isSubmitting}
                                >
                                    Cancel
                                </Button>
                            </div>
                        </div>
                    )}

                    {step === 'success' && (
                        <div className="flex-1 flex flex-col items-center justify-center p-12 text-center space-y-5 bg-white">
                            <div className="h-24 w-24 bg-green-50 rounded-full flex items-center justify-center border border-green-100 mb-2">
                                <CheckCircle2 className="h-12 w-12 text-green-600" />
                            </div>
                            <div className="space-y-2">
                                <h2 className="text-2xl font-bold text-slate-900">Success!</h2>
                                <p className="text-slate-500 max-w-xs mx-auto">
                                    Assigned <strong>{selectedTasks.length}</strong> items successfully.
                                </p>
                            </div>
                            <p className="text-xs text-slate-400 mt-12 px-6 py-2 bg-slate-50 rounded-full font-medium">Closing in 2 seconds...</p>
                        </div>
                    )}
                </div>
            </SheetContent>
        </Sheet>
    );
}