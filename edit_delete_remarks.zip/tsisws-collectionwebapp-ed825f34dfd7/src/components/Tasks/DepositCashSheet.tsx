import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetDescription,
    SheetFooter,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useState, useEffect, useMemo } from "react";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { SearchableSelect } from "@/components/ui/searchable-select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Loader2, Upload } from "lucide-react";
import { cn } from "@/lib/utils";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import type { Task } from "@/lib/types";
import type { BankDetail } from "@/lib/types";
import { useDepositCash } from "@/hooks/Tasks/useDepositCash";
import { useToast } from "@/hooks/use-toast";

interface DepositCashSheetProps {
    isOpen: boolean;
    onOpenChange: (isOpen: boolean) => void;
    tasks: Task[];
    bankDetails: BankDetail[];
    onSuccess?: () => void;
}

export function DepositCashSheet({
    isOpen,
    onOpenChange,
    tasks,
    bankDetails,
    onSuccess,
}: DepositCashSheetProps) {
    const [depositDate, setDepositDate] = useState<Date | undefined>(new Date());
    const [isDatePickerOpen, setIsDatePickerOpen] = useState(false);
    const [selectedBank, setSelectedBank] = useState<BankDetail | null>(null);
    const [remarks, setRemarks] = useState("");
    const [depositSlip, setDepositSlip] = useState<File | null>(null);
    const { toast } = useToast();

    const { isSubmitting, handleDeposit } = useDepositCash({
        onSuccess,
        onOpenChange,
    });

    useEffect(() => {
        if (!isOpen) {
            setDepositDate(new Date());
            setSelectedBank(null);
            setRemarks("");
            setDepositSlip(null);
        }
    }, [isOpen]);

    const filteredBankDetails = useMemo(() => {
        if (tasks.length === 0) return [];
        return bankDetails;
    }, [tasks, bankDetails]);

    const totalAmount = useMemo(() => {
        return tasks.reduce(
            (sum, task) => sum + (task.receivedAmount || 0),
            0
        );
    }, [tasks]);

    const handleBankChange = (bankId: string) => {
        const bank = bankDetails.find((b) => b.id === bankId);
        setSelectedBank(bank || null);
    };

    const handleFileChange = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        const file = event.target.files?.[0];
        if (file) {
            if (!file.type.startsWith("image/")) {
                toast({
                    title: "Invalid file type",
                    description: "Please upload an image file (jpg, png, etc.)",
                    variant: "destructive",
                });
                event.target.value = "";
                return;
            }
            setDepositSlip(file);
        }
    };

    const handleSubmit = async () => {
        if (!depositDate || !selectedBank || !remarks) {
            return;
        }

        await handleDeposit({
            tasks,
            bankName: selectedBank.bankName,
            accountNo: selectedBank.accountNumber,
            depositDate,
            remarks,
            depositSlip,
        });
    };

    if (tasks.length === 0) return null;

    return (
        <Sheet open={isOpen} onOpenChange={onOpenChange}>
            <SheetContent className="sm:max-w-md flex flex-col">
                <SheetHeader>
                    <SheetTitle>Deposit Cash in Bank</SheetTitle>
                    <SheetDescription>
                        Record the cash deposit for {tasks.length} selected task(s).
                    </SheetDescription>
                </SheetHeader>

                <div className="flex-1 overflow-y-auto -mr-6 pr-6">
                    <div className="py-4 space-y-4 ml-1">

                        {/* Selected Tasks */}
                        <div className="p-3 border rounded-lg space-y-3 bg-muted/50">
                            <div className="text-sm font-medium">
                                Selected Tasks
                            </div>

                            <ScrollArea className="h-24">
                                <div className="space-y-2 pr-4">
                                    {tasks.map((task) => (
                                        <div
                                            key={task.id}
                                            className="flex justify-between items-center text-xs"
                                        >
                                            <div>
                                                <p className="font-semibold">
                                                    LAN No : {task.lan}
                                                </p>
                                                <p className="text-muted-foreground">
                                                    Receipt: {task.receiptNo || "N/A"}
                                                </p>
                                            </div>

                                            <p className="font-medium">
                                                {(task.receivedAmount || 0).toLocaleString(
                                                    "en-IN",
                                                    {
                                                        style: "currency",
                                                        currency: "INR",
                                                    }
                                                )}
                                            </p>
                                        </div>
                                    ))}
                                </div>
                            </ScrollArea>

                            <Separator />

                            <div className="flex justify-between items-center font-bold text-sm">
                                <p>Total Deposit Amount:</p>
                                <p>
                                    {totalAmount.toLocaleString("en-IN", {
                                        style: "currency",
                                        currency: "INR",
                                    })}
                                </p>
                            </div>
                        </div>

                        {/* Deposit Date */}
                        <div className="space-y-2">
                            <Label htmlFor="deposit-date">
                                Deposit Date <span className="text-red-500 ml-0.5">*</span>
                            </Label>

                            <Popover open={isDatePickerOpen} onOpenChange={setIsDatePickerOpen}>
                                <PopoverTrigger asChild>
                                    <Button
                                        id="deposit-date"
                                        variant={"outline"}
                                        className={cn(
                                            "w-full justify-start text-left font-normal",
                                            !depositDate &&
                                            "text-muted-foreground"
                                        )}
                                    >
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {depositDate
                                            ? format(depositDate, "PPP")
                                            : "Pick a date"}
                                    </Button>
                                </PopoverTrigger>

                                <PopoverContent className="w-auto p-0">
                                    <Calendar
                                        mode="single"
                                        selected={depositDate}
                                        onSelect={(date) => {
                                            setDepositDate(date);
                                            setIsDatePickerOpen(false);
                                        }}
                                        disabled={{ after: new Date() }}
                                        initialFocus
                                    />
                                </PopoverContent>
                            </Popover>
                        </div>

                        {/* Bank Select */}
                        <div className="space-y-2">
                            <Label htmlFor="bank-select">
                                Deposit to Bank Account <span className="text-red-500 ml-0.5">*</span>
                            </Label>

                            <SearchableSelect
                                id="bank-select"
                                placeholder="Select a bank account"
                                onValueChange={handleBankChange}
                                value={selectedBank?.id || ""}
                                options={filteredBankDetails.map((bank) => ({
                                    value: bank.id,
                                    label: `${bank.bankName} - ${bank.branchName}`
                                }))}
                            />
                        </div>

                        {/* Account Info */}
                        {selectedBank && (
                            <div className="grid grid-cols-2 gap-4 text-sm p-3 border rounded-md bg-muted/50">
                                <div>
                                    <p className="font-medium text-muted-foreground">
                                        Account No.
                                    </p>
                                    <p>{selectedBank.accountNumber}</p>
                                </div>
                                <div>
                                    <p className="font-medium text-muted-foreground">
                                        IFSC Code
                                    </p>
                                    <p>{selectedBank.ifscCode}</p>
                                </div>
                            </div>
                        )}

                        {/* File Upload */}
                        <div className="space-y-2">
                            <Label htmlFor="deposit-slip">
                                Deposit Slip <span className="text-red-500 ml-0.5">*</span>
                            </Label>

                            <div className="flex items-center gap-2">
                                <Input
                                    id="deposit-slip"
                                    type="file"
                                    accept="image/*"
                                    className="hidden"
                                    onChange={handleFileChange}
                                />

                                <Label
                                    htmlFor="deposit-slip"
                                    className="flex-1"
                                >
                                    <Button asChild variant="outline">
                                        <div>
                                            <Upload className="mr-2 h-4 w-4" />
                                            {depositSlip
                                                ? "Change File"
                                                : "Upload Image"}
                                        </div>
                                    </Button>
                                </Label>

                                {depositSlip && (
                                    <p className="text-sm text-muted-foreground truncate">
                                        {depositSlip.name}
                                    </p>
                                )}
                            </div>
                        </div>

                        {/* Remarks */}
                        <div className="space-y-2">
                            <Label htmlFor="deposit-remarks">
                                Remarks <span className="text-red-500 ml-0.5">*</span>
                            </Label>
                            <Textarea
                                id="deposit-remarks"
                                className="resize-none"
                                placeholder="Enter deposit details or reference numbers..."
                                value={remarks}
                                onChange={(e) =>
                                    setRemarks(e.target.value)
                                }
                                required
                            />
                        </div>
                    </div>
                </div>

                <SheetFooter className="mt-auto pt-4">
                    <Button
                        variant="outline"
                        onClick={() => onOpenChange(false)}
                    >
                        Cancel
                    </Button>

                    <Button
                        onClick={handleSubmit}
                        disabled={
                            isSubmitting || !selectedBank || !remarks || !depositSlip
                        }
                    >
                        {isSubmitting && (
                            <Loader2 className="animate-spin mr-2 h-4 w-4" />
                        )}
                        Confirm Deposit
                    </Button>
                </SheetFooter>
            </SheetContent>
        </Sheet>
    );
}
