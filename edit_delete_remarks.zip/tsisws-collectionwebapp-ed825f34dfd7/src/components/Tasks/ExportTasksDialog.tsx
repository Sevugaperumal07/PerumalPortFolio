import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";

interface ExportTasksDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    onConfirm: (option: "current" | "all" | "bankDepositDetails") => void;
    isExporting: boolean;
    currentTabName: string;
}

export function ExportTasksDialog({
    open,
    onOpenChange,
    onConfirm,
    isExporting,
    currentTabName,
}: ExportTasksDialogProps) {
    const [exportOption, setExportOption] = useState<"current" | "all">("current");

    // Reset option when dialog opens
    useEffect(() => {
        if (open) {
            setExportOption("current");
        }
    }, [open]);

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Export Tasks</DialogTitle>
                    <DialogDescription>
                        Choose what data you want to export.
                    </DialogDescription>
                </DialogHeader>

                <div className="py-6">
                    <RadioGroup
                        value={exportOption}
                        onValueChange={(val: string) => setExportOption(val as "current" | "all")}
                        className="flex flex-col space-y-3"
                    >
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="current" id="r1" />
                            <Label htmlFor="r1" className="text-base font-normal">
                                Export the current Tab <span className="text-sm ml-1">({currentTabName})</span>(.csv)
                            </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="all" id="r2" />
                            <Label htmlFor="r2" className="text-base font-normal">
                                Export all the Tab (.csv)
                            </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="bankDepositDetails" id="r3" />
                            <Label htmlFor="r3" className="text-base font-normal">
                                Export Bank Deposit Details (.xlsx)
                            </Label>
                        </div>
                    </RadioGroup>
                </div>

                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isExporting}>
                        Cancel
                    </Button>
                    <Button
                        onClick={() => onConfirm(exportOption as "current" | "all" | "bankDepositDetails")}
                        disabled={isExporting}
                        className="min-w-[100px]"
                    >
                        {isExporting ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Exporting...
                            </>
                        ) : (
                            "Export"
                        )}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
