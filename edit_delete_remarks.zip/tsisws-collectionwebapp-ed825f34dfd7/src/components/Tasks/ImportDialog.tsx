import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useEffect, useState, useRef } from "react";
import { FileSpreadsheet, FileDown, X, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ImportDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    onConfirm: (file: File) => void;
}

export function ImportDialog({
    open,
    onOpenChange,
    onConfirm,
}: ImportDialogProps) {
    const [file, setFile] = useState<File | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const { toast } = useToast();

    // Reset state when dialog opens/closes
    useEffect(() => {
        if (!open) {
            setFile(null);
        }
    }, [open]);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (selectedFile) {
            if (selectedFile.name.endsWith('.xlsx') || selectedFile.name.endsWith('.xls')) {
                setFile(selectedFile);
            } else {
                toast({
                    title: "Invalid file type",
                    description: "Please select an Excel file (.xlsx or .xls).",
                    variant: "destructive",
                });
            }
        }
    };

    const handleImport = () => {
        if (!file) return;
        onConfirm(file);
        onOpenChange(false);
    };

    const triggerFileInput = () => {
        fileInputRef.current?.click();
    };

    const removeFile = (e: React.MouseEvent) => {
        e.stopPropagation();
        setFile(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="w-[95vw] max-w-[425px] sm:w-full overflow-hidden rounded-2xl">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <FileSpreadsheet className="h-5 w-5 text-green-600" />
                        Import LMS Data
                    </DialogTitle>
                    <DialogDescription>
                        Upload an Excel file to import LMS reverse feed data.
                    </DialogDescription>
                </DialogHeader>

                <div className="py-6 min-w-0">
                    <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileChange}
                        accept=".xlsx,.xls"
                        className="hidden"
                    />
                    
                    {!file ? (
                        <div 
                            onClick={triggerFileInput}
                            className="border-2 border-dashed border-gray-200 rounded-xl p-8 flex flex-col items-center justify-center gap-3 cursor-pointer hover:border-blue-400 hover:bg-blue-50/50 transition-all group w-full"
                        >
                            <div className="h-12 w-12 rounded-full bg-blue-50 flex items-center justify-center group-hover:scale-110 transition-transform shrink-0">
                                <FileDown className="h-6 w-6 text-blue-600" />
                            </div>
                            <div className="text-center min-w-0">
                                <p className="text-sm font-medium text-gray-700">Click to upload or drag and drop</p>
                                <p className="text-xs text-gray-500 mt-1">Excel files (.xlsx) or (.xls) only</p>
                            </div>
                        </div>
                    ) : (
                        <div className="bg-green-50/50 border border-green-100 rounded-xl p-4 flex items-center gap-4 w-full overflow-hidden">
                            <div className="h-10 w-10 rounded-lg bg-green-100 flex items-center justify-center shrink-0">
                                <FileSpreadsheet className="h-5 w-5 text-green-700" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-gray-900 truncate">{file.name}</p>
                                <p className="text-xs text-gray-500">{(file.size / 1024).toFixed(1)} KB</p>
                            </div>
                            <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8 text-gray-400 hover:text-red-500 hover:bg-red-50"
                                onClick={removeFile}
                            >
                                <X className="h-4 w-4" />
                            </Button>
                        </div>
                    )}
                </div>

                <DialogFooter className="flex flex-col sm:flex-row gap-3 sm:gap-2">
                    <Button 
                        variant="outline" 
                        onClick={() => onOpenChange(false)}
                        className="rounded-lg w-full sm:w-auto order-2 sm:order-1"
                    >
                        Cancel
                    </Button>
                    <Button
                        onClick={handleImport}
                        disabled={!file}
                        className="min-w-[120px] bg-blue-600 hover:bg-blue-700 rounded-lg w-full sm:w-auto order-1 sm:order-2"
                    >
                        <CheckCircle2 className="mr-2 h-4 w-4" />
                        Import Excel
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
