import { useRef, useEffect, useCallback, useState } from "react";
import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetDescription
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Search, UserPlus, Loader2, CheckCircle2, X } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Task } from "@/lib/types";
import { useSingleAssignTask } from "@/hooks/Tasks/useSingleAssignTask";

interface SingleAssignTaskSheetProps {
    isOpen: boolean;
    onOpenChange: (open: boolean) => void;
    task: Task | null;
    onSuccess: (agentName?: string) => void;
    securityGroupId: string | null;
}

export function SingleAssignTaskSheet({
    isOpen,
    onOpenChange,
    task,
    onSuccess,
    securityGroupId
}: SingleAssignTaskSheetProps) {
    const {
        step,
        selectedAgentId,
        setSelectedAgentId,
        isSubmitting,
        agents,
        searchTerm,
        setSearchTerm,
        loadingAgents,
        hasNext,
        handleLoadMore,
        handleAssign,
    } = useSingleAssignTask({
        isOpen,
        task,
        onOpenChange,
        onSuccess,
        securityGroupId
    });

    // Controls which actions to perform
    const [showAssignTask, setShowAssignTask] = useState(true);
    const [showAssignCase, setShowAssignCase] = useState(true);
    const [errorMsg, setErrorMsg] = useState("");



    useEffect(() => {
        if (isOpen && task) {
            setShowAssignTask(true);
            setShowAssignCase(false);
            setErrorMsg("");
        }
    }, [isOpen, task]);

    // Clear checkbox error when a checkbox is selected
    useEffect(() => {
        if ((showAssignTask || showAssignCase) && errorMsg === "select any assign case or task") {
            setErrorMsg("");
        }
    }, [showAssignTask, showAssignCase, errorMsg]);

    // Clear agent error when an agent is selected
    useEffect(() => {
        if (selectedAgentId && errorMsg === "select the agents") {
            setErrorMsg("");
        }
    }, [selectedAgentId, errorMsg]);

    const sentinelRef = useRef<HTMLDivElement>(null);

    const onIntersection = useCallback((entries: IntersectionObserverEntry[]) => {
        const [entry] = entries;
        if (entry.isIntersecting && hasNext && !loadingAgents) {
            handleLoadMore();
        }
    }, [hasNext, loadingAgents, handleLoadMore]);

    useEffect(() => {
        const observer = new IntersectionObserver(onIntersection, {
            root: null,
            rootMargin: '100px',
            threshold: 0.1
        });

        if (sentinelRef.current) {
            observer.observe(sentinelRef.current);
        }

        return () => {
            if (sentinelRef.current) {
                observer.unobserve(sentinelRef.current);
            }
        };
    }, [onIntersection]);

    if (!task && isOpen) return null;

    return (
        <Sheet open={isOpen} onOpenChange={onOpenChange}>
            <SheetContent side="right" className="w-full sm:max-w-md flex flex-col h-full bg-white p-0">
                <SheetHeader className="p-6 border-b">
                    <SheetTitle className="text-xl font-bold flex items-center gap-2">
                        <UserPlus className="h-5 w-5 text-blue-600" />
                        Assign Task and Case
                    </SheetTitle>
                    <SheetDescription>
                        {step === 'agent_selection' && "Select an agent to assign this task."}
                        {step === 'success' && "Assignment successful!"}
                    </SheetDescription>

                    {/* Checkboxes to control assignment logic */}
                    {step === 'agent_selection' && (
                        <div className="flex gap-10 mt-3 px-5">
                            <label className="flex items-center gap-2 cursor-pointer select-none">
                                <input
                                    type="checkbox"
                                    checked={showAssignTask && showAssignCase}
                                    onChange={(e) => {
                                        if (e.target.checked) {
                                            setShowAssignTask(true);
                                            setShowAssignCase(true);
                                        }
                                    }}
                                    className="accent-primary w-4 h-4"
                                />
                                <span className="text-sm font-medium text-gray-700">Assign Task And Case</span>
                            </label>
                            <label className="flex items-center gap-2 cursor-pointer select-none">
                                <input
                                    type="checkbox"
                                    checked={showAssignTask && !showAssignCase}
                                    onChange={(e) => {
                                        if (e.target.checked) {
                                            setShowAssignTask(true);
                                            setShowAssignCase(false);
                                        }
                                    }}
                                    className="accent-primary w-4 h-4"
                                />
                                <span className="text-sm font-medium text-gray-700">Assign Task</span>
                            </label>
                        </div>
                    )}
                </SheetHeader>

                <div className="flex-1 overflow-hidden">
                    {step === 'agent_selection' && (
                        <div className="flex flex-col h-full overflow-hidden">
                            <div className="px-6 py-4 border-b space-y-4 shrink-0">
                                <div className="flex flex-col gap-2">
                                    <Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Selected Task:</Label>
                                    <div className="flex flex-wrap gap-1.5 p-1">
                                        <Badge variant="secondary" className="text-xs px-2 py-0.5 h-6">
                                            {task?.lan}
                                        </Badge>
                                    </div>
                                </div>

                                <div className="relative">
                                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                                    <Input
                                        placeholder="Search agents by name..."
                                        className="pl-9 h-11 border-gray-200"
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                    {searchTerm && (
                                        <button
                                            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                            onClick={() => setSearchTerm("")}
                                        >
                                            <X className="h-4 w-4" />
                                        </button>
                                    )}
                                </div>
                                <div className="flex items-center justify-between text-[10px] text-gray-500 font-bold uppercase tracking-tighter">
                                    <span>Selected: {selectedAgentId ? agents.find(a => a.id === selectedAgentId)?.userName : 'None'}</span>
                                    <span>Assigning 1 Task</span>
                                </div>
                            </div>

                            <ScrollArea className="flex-1 p-0">
                                <div className="p-6 pt-2 space-y-1">
                                    {agents.map((agent) => (
                                        <div
                                            key={agent.id}
                                            className={cn(
                                                "flex items-center justify-between p-3 rounded-lg cursor-pointer border transition-all",
                                                selectedAgentId === agent.id
                                                    ? "bg-blue-50 border-blue-200 ring-1 ring-blue-200"
                                                    : "hover:bg-gray-50 border-transparent"
                                            )}
                                            onClick={() => setSelectedAgentId(agent.id)}
                                        >
                                            <div className="flex items-center gap-3">
                                                <div className={cn(
                                                    "h-8 w-8 rounded-full flex items-center justify-center text-xs font-bold",
                                                    selectedAgentId === agent.id ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"
                                                )}>
                                                    {agent.userName.split(' ').map(n => n[0]).join('').toUpperCase()}
                                                </div>
                                                <span className="text-sm font-medium text-gray-900">{agent.userName}</span>
                                            </div>
                                            {selectedAgentId === agent.id && (
                                                <CheckCircle2 className="h-5 w-5 text-blue-600" />
                                            )}
                                        </div>
                                    ))}

                                    {loadingAgents && Array.from({ length: 3 }).map((_, i) => (
                                        <div key={`skeleton-${i}`} className="flex items-center gap-3 p-3">
                                            <Skeleton className="h-8 w-8 rounded-full" />
                                            <Skeleton className="h-4 w-32" />
                                        </div>
                                    ))}

                                    <div ref={sentinelRef} className="h-4 w-full" />

                                    {!loadingAgents && agents.length === 0 && (
                                        <div className="text-center py-10">
                                            <p className="text-sm text-gray-500">No agents found.</p>
                                        </div>
                                    )}
                                </div>
                            </ScrollArea>

                            <div className="p-6 border-t bg-gray-50/50 flex flex-col gap-2">
                                {(() => {
                                    let buttonLabel = "Assign Task & Case";

                                    if (showAssignTask && showAssignCase) {
                                        buttonLabel = "Assign Task & Case";
                                    } else if (showAssignTask) {
                                        buttonLabel = "Assign Task";
                                    } else if (showAssignCase) {
                                        buttonLabel = "Assign Case";
                                    }

                                    return (
                                        <>
                                            {errorMsg && (
                                                <p className="text-red-600 text-sm font-medium text-center">
                                                    {errorMsg}
                                                </p>
                                            )}
                                            <Button
                                                className="w-full bg-blue-600 hover:bg-blue-700 text-white h-11"
                                                disabled={isSubmitting || !selectedAgentId || (!showAssignTask && !showAssignCase)}
                                                onClick={() => {
                                                    if (!showAssignTask && !showAssignCase) {
                                                        setErrorMsg("Select Assign Task or Assign Case");
                                                        return;
                                                    }

                                                    if (!selectedAgentId) {
                                                        setErrorMsg("Select The Agents");
                                                        return;
                                                    }

                                                    setErrorMsg("");
                                                    handleAssign({
                                                        assignCase: showAssignCase,
                                                        assignTask: showAssignTask
                                                    });
                                                }}
                                            >
                                                {isSubmitting ? (
                                                    <>
                                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                                        Assigning...
                                                    </>
                                                ) : (
                                                    buttonLabel
                                                )}
                                            </Button>
                                        </>
                                    );
                                })()}

                                <Button
                                    variant="ghost"
                                    className="w-full"
                                    onClick={() => onOpenChange(false)}
                                    disabled={isSubmitting}
                                >
                                    Cancel
                                </Button>
                            </div>
                        </div>
                    )}

                    {step === 'success' && (
                        <div className="h-full flex flex-col items-center justify-center p-6 text-center space-y-4">
                            <div className="h-16 w-16 bg-green-100 rounded-full flex items-center justify-center mb-2">
                                <CheckCircle2 className="h-10 w-10 text-green-600" />
                            </div>
                            <h2 className="text-2xl font-bold text-gray-900">
                                {showAssignCase && showAssignTask ? "Case & Task Assigned!" :
                                    showAssignTask ? "Task Assigned!" : "Case Assigned!"}
                            </h2>
                            <p className="text-gray-500 max-w-xs">
                                {showAssignCase && showAssignTask ? "Case and Task have" :
                                    showAssignTask ? "Task has" : "Case has"} been successfully assigned to <strong>{agents.find(a => a.id === selectedAgentId)?.userName}</strong>.
                            </p>
                            <p className="text-xs text-gray-400 pt-10">Closing sheet in 2 seconds...</p>
                        </div>
                    )}
                </div>
            </SheetContent>
        </Sheet>
    );
}
