import {
    Sheet,
    SheetContent,
    SheetDescription,
    SheetHeader,
    SheetTitle,
} from "@/components/ui/sheet";
import {
    Info,
    Filter,
    FileDown,
    Pencil,
    HandCoins,
    UserPlus,
    QrCode,
    File,
    Trash,
    FileUp
} from "lucide-react";

interface TaskActionsGuideProps {
    isOpen: boolean;
    setIsOpen: (open: boolean) => void;
}

export function TaskActionsGuide({ isOpen, setIsOpen }: TaskActionsGuideProps) {
    return (
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetContent side="right" className="w-full sm:max-w-md overflow-y-auto bg-white">
                <SheetHeader>
                    <SheetTitle className="text-xl font-bold text-gray-900">
                        Task Actions Guide
                    </SheetTitle>
                    <SheetDescription className="text-sm text-gray-600">
                        A quick reference for the actions available on this page.
                    </SheetDescription>
                </SheetHeader>
                <div className="space-y-4 mt-6">
                    {/* Action Descriptions */}
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <Info className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Action Descriptions</h3>
                            <p className="text-sm text-gray-600">
                                Displays this guide to all available actions.
                            </p>
                        </div>
                    </div>

                    {/* Advanced Search */}
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <Filter className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Advanced Search</h3>
                            <p className="text-sm text-gray-600">
                                Open a dialog to filter tasks by multiple criteria including date ranges, branch, agent, and more.
                            </p>
                        </div>
                    </div>

                    {/* Export to Excel */}
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <FileUp className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Export to Excel</h3>
                            <p className="text-sm text-gray-600">
                                Downloads the currently filtered list of tasks as a CSV file.
                            </p>
                        </div>
                    </div>

                    {/* Import as Excel */}
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <FileDown className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Import as Excel</h3>
                            <p className="text-sm text-gray-600">
                                Upload an Excel file for LMS feed.
                            </p>
                        </div>
                    </div>

                    {/* Edit Receipt */}
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <Pencil className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Edit Receipt</h3>
                            <p className="text-sm text-gray-600">
                                Update the collected EMI, bounce, and penalty amounts for a single receipt. The "Received Amount" will be recalculated automatically.
                            </p>
                        </div>
                    </div>

                    {/* Deposit Cash in Bank */}
                    {/* <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <Banknote className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Deposit Cash in Bank</h3>
                            <p className="text-sm text-gray-600">
                                Record cash deposits into a bank account. Enabled for tasks with "In-Hand Branch" status.
                            </p>
                        </div>
                    </div> */}

                    {/* Accept/Reject Cash */}
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <HandCoins className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Accept/Reject Cash</h3>
                            <p className="text-sm text-gray-600">
                                Accept or reject cash payments collected by agents. Enabled for tasks with "Acceptance Pending" status.
                            </p>
                        </div>
                    </div>

                    {/* Assign Tasks */}
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <UserPlus className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Assign Tasks</h3>
                            <p className="text-sm text-gray-600">
                                Assign one or more selected tasks to an agent.
                            </p>
                        </div>
                    </div>

                    {/* Generate UPI Payment */}
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <QrCode className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Generate UPI Payment</h3>
                            <p className="text-sm text-gray-600">
                                Generate a UPI QR code for a single selected task to facilitate payment.
                            </p>
                        </div>
                    </div>

                    {/* Add Notes */}
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <File className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Add Notes</h3>
                            <p className="text-sm text-gray-600">
                                Add notes to one or more selected tasks.
                            </p>
                        </div>
                    </div>

                    {/* Edit or Reverse Receipt */}
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
                            <Trash className="h-6 w-6 text-blue-800" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">Delete Receipt</h3>
                            <p className="text-sm text-gray-600">
                                Delete a payment receipt for a single task.
                            </p>
                        </div>
                    </div>
                </div>
            </SheetContent>
        </Sheet>
    );
}