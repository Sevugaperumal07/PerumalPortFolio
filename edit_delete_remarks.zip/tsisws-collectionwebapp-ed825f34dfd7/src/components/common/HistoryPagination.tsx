import { ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface HistoryPaginationProps {
    currentPage: number;
    totalPages: number;
    totalRecords: number;
    pageSize?: number;
    onPageChange: (page: number) => void;
    hasNext?: boolean;
    hasPrevious?: boolean;
    isLoading?: boolean;
    className?: string;
}

export function HistoryPagination({
    currentPage,
    totalPages,
    totalRecords,
    onPageChange,
    hasNext,
    hasPrevious,
    isLoading = false,
    className
}: HistoryPaginationProps) {
    if (totalRecords === 0) return null;

    const prevDisabled = (hasPrevious !== undefined ? !hasPrevious : currentPage <= 1) || isLoading;
    const nextDisabled = (hasNext !== undefined ? !hasNext : currentPage >= totalPages) || isLoading;

    return (
        <div className={cn(
            "flex items-center justify-between py-2.5 px-1",
            className
        )}>
            {/* Left: Direct Stats */}
            <div className="flex items-center gap-2 text-gray-400 font-medium select-none">
                <div className="flex items-center gap-1">
                    <span className="text-[10px] uppercase text-gray-700 tracking-wider">Total</span>
                    <span className="text-[11px] font-bold text-gray-700">
                        {totalRecords}
                    </span>
                </div>
            </div>

            {/* Right: Minimal Navigation */}
            <div className="flex items-center gap-1">
                {/* Previous Button */}
                <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onPageChange(currentPage - 2)}
                    disabled={prevDisabled}
                    className="h-7 w-7 rounded-md text-gray-400 hover:text-blue-600 hover:bg-blue-50/30 disabled:opacity-30 transition-all"
                >
                    <ChevronLeft className="h-3.5 w-3.5" />
                </Button>

                {/* Page Indicator */}
                <div className="flex items-center justify-center min-w-[50px] h-7 px-2">
                    {isLoading ? (
                        <Loader2 className="h-3 w-3 animate-spin text-blue-500" />
                    ) : (
                        <div className="flex items-center gap-1 text-[10px] font-bold">
                            <span className="text-gray-900">{currentPage}</span>
                            <span className="text-gray-300">/</span>
                            <span className="text-gray-400">{totalPages || 1}</span>
                        </div>
                    )}
                </div>

                {/* Next Button */}
                <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onPageChange(currentPage)}
                    disabled={nextDisabled}
                    className="h-7 w-7 rounded-md text-gray-400 hover:text-blue-600 hover:bg-blue-50/50 disabled:opacity-30 transition-all"
                >
                    <ChevronRight className="h-3.5 w-3.5" />
                </Button>
            </div>
        </div>
    );
}
