import { Info } from "lucide-react";
import React from "react";
import { getCategoryInfo } from "@/lib/data/category-descriptions";
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "@/components/ui/popover";


export interface ActionDescription {
    action: string;
    description: string;
}

interface RoleAccessDescriptionProps {
    category: string;
    actionDescriptions?: ActionDescription[];
}

export const RoleAccessDescription: React.FC<RoleAccessDescriptionProps> = ({
    category,
    actionDescriptions,
}) => {
    return (
        <Popover>
            <PopoverTrigger asChild>
                <button
                    className="inline-flex items-center justify-center rounded-sm hover:bg-slate-100 p-0.5 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 group"
                    aria-label={`Show description for ${category}`}
                    type="button"
                >
                    <Info className="h-3.5 w-3.5 text-gray-400 group-hover:text-gray-600 transition-colors" />
                </button>
            </PopoverTrigger>
            <PopoverContent side="right" align="center" sideOffset={10} className="w-80 border shadow-2xl p-0 overflow-hidden bg-white z-[100]">
                <div className="bg-slate-50/80 border-b px-4 py-3">
                    <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                        <div className="w-6 h-6 bg-white rounded border border-slate-200 flex items-center justify-center">
                            <Info className="h-3.5 w-3.5 text-gray-500" />
                        </div>
                        {category}
                    </h3>
                </div>
                <div className="p-4">
                    <div className="space-y-1.5">
                        <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">Description</h4>
                        {actionDescriptions && actionDescriptions.length > 0 ? (
                            <div className="space-y-2">
                                {actionDescriptions.map((ad) => (
                                    <div key={ad.action} className="text-[13px] text-slate-600 leading-relaxed">
                                        <span className="font-semibold text-slate-700">{ad.action}:</span>{' '}
                                        {ad.description}
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-[13px] text-slate-600 leading-relaxed">
                                {getCategoryInfo(category).about}
                            </p>
                        )}
                    </div>
                </div>
            </PopoverContent>
        </Popover>
    );
};
