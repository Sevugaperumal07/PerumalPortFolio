import { List } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface PaginationProps {
    table: any;
    totalRecords: number;
    totalPages: number;
    pageIndex: number;
    setPageIndex: (index: number) => void;
    hasNext: boolean;
    hasPrevious: boolean;
    loading: boolean;
    entityName?: string;
    selectionCount?: number;
    onClearSelection?: () => void;
}

export function Pagination({
    table,
    totalRecords,
    totalPages,
    pageIndex,
    setPageIndex,
    hasNext,
    hasPrevious,
    loading,
    entityName = "Records",
    selectionCount = 0,
    onClearSelection
}: PaginationProps) {
    const isFirstPage = pageIndex === 0;
    const isLastPage = pageIndex === totalPages - 1 || totalPages === 0;

    return (
        <div className="sticky bottom-0 z-30 pt-2 pb-2 bg-gradient-to-t from-white via-white/95 to-transparent">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 px-2">
                {/* Left Section - Selection Info */}
                <div className="flex items-center justify-center lg:justify-start gap-3">
                    <div className="bg-gray-100/80 backdrop-blur-sm text-gray-700 px-4 py-2 rounded-lg border border-gray-200 shadow-sm">
                        <div className="flex items-center gap-2">
                            <svg className="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            <span className="text-xs font-semibold whitespace-nowrap">
                                {selectionCount} selected out of {totalRecords} {entityName}
                            </span>
                            {selectionCount > 0 && onClearSelection && (
                                <Button
                                    variant="link"
                                    size="sm"
                                    className="h-auto p-0 text-blue-600 hover:text-blue-800 text-[10px] font-bold ml-2 underline uppercase tracking-wider"
                                    onClick={onClearSelection}
                                >
                                    Clear All
                                </Button>
                            )}
                        </div>
                    </div>
                </div>

                {/* Right Section - Pagination Controls */}
                <div className="flex flex-col md:flex-row items-center justify-center lg:justify-end gap-3">
                    {/* Stats Badges */}
                    <div className="flex flex-wrap items-center justify-center gap-2">
                        <div className="bg-gray-100/80 backdrop-blur-sm text-gray-700 px-4 py-2 rounded-lg border border-gray-200 shadow-sm">
                            <div className="flex items-center gap-2">
                                <List className="w-3.5 h-3.5" />
                                <span className="text-[11px] font-bold whitespace-nowrap">
                                    {table.getRowModel().rows.length} {entityName} on this page
                                </span>
                            </div>
                        </div>
                        <div className="bg-gray-100/80 backdrop-blur-sm text-gray-700 px-4 py-2 rounded-lg border border-gray-200 shadow-sm">
                            <div className="flex items-center gap-2">
                                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                                </svg>
                                <span className="text-[11px] font-bold whitespace-nowrap">
                                    {totalPages || 1} Page{totalPages !== 1 ? 's' : ''}
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Pagination Navigation */}
                    <div className="flex items-center gap-1 h-8 w-100 p-1">
                        {/* First Page */}
                        <Button
                            variant="ghost"
                            size="sm"
                            className={cn(
                                "h-8 w-8 p-0 bg-blue-50 hover:bg-blue-100 hover:text-blue-700 transition-all",
                                (isFirstPage || loading) && "opacity-40 cursor-not-allowed"
                            )}
                            onClick={() => setPageIndex(0)}
                            disabled={isFirstPage || loading}
                            title="First page"
                        >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
                            </svg>
                        </Button>

                        {/* Previous Page */}
                        <Button
                            variant="ghost"
                            size="sm"
                            className={cn(
                                "h-8 px-2 sm:px-3 bg-blue-50 hover:bg-blue-100 hover:text-blue-700 transition-all font-medium",
                                (!hasPrevious || loading) && "opacity-40 cursor-not-allowed"
                            )}
                            onClick={() => setPageIndex(Math.max(0, pageIndex - 1))}
                            disabled={!hasPrevious || loading}
                        >
                            <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                            </svg>
                            <span className="hidden xs:inline">Prev</span>
                        </Button>

                        {/* Page Info */}
                        <div className="flex items-center gap-1.5 px-3 py-2 bg-gray-100 rounded-lg">
                            <span className="text-[10px] font-bold text-gray-900 uppercase tracking-wider">
                                {pageIndex + 1}
                            </span>
                            <span className="text-[10px] font-bold text-gray-500 tracking-wider">of</span>
                            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">
                                {totalPages || 1}
                            </span>
                        </div>

                        {/* Next Page */}
                        <Button
                            variant="ghost"
                            size="sm"
                            className={cn(
                                "h-8 px-2 sm:px-3 bg-blue-50 hover:bg-blue-100 hover:text-blue-700 transition-all font-medium",
                                (!hasNext || loading) && "opacity-40 cursor-not-allowed"
                            )}
                            onClick={() => setPageIndex(pageIndex + 1)}
                            disabled={!hasNext || loading}
                        >
                            <span className="hidden xs:inline mr-1">Next</span>
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                        </Button>

                        {/* Last Page */}
                        <Button
                            variant="ghost"
                            size="sm"
                            className={cn(
                                "h-8 w-8 p-0 bg-blue-50 hover:bg-blue-100 hover:text-blue-700 transition-all",
                                (isLastPage || loading) && "opacity-40 cursor-not-allowed"
                            )}
                            onClick={() => setPageIndex(totalPages - 1)}
                            disabled={isLastPage || loading}
                            title="Last page"
                        >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" />
                            </svg>
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}