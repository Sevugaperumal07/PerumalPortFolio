import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { createCaseNote } from "@/lib/services/notes";
import type { Case } from "@/lib/types";

interface AddCaseNotesDialogProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  cases: Case[];
}

export function AddCaseNotesDialog({
  isOpen,
  onOpenChange,
  cases,
}: AddCaseNotesDialogProps) {
  const [notes, setNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  // Get user data from localStorage
  const getUserData = () => {
    try {
      const stored = localStorage.getItem("userData");
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (error) {
      console.error("[AddCaseNotesDialog] Error reading userData from localStorage:", error);
    }
    return null;
  };

  const handleSubmit = async () => {
    if (!notes.trim()) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please enter a note before submitting.",
      });
      return;
    }

    const userData = getUserData();

    if (!userData?.id) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "User not found. Please log in again.",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const promises = cases.map((caseItem) => {
        const loanNumber = caseItem.account?.lanNumber || caseItem.caseNumber || "";
        const authorRole = userData.roles?.[0]?.name || "Agent";
        const authorName = `${userData.firstName || ""} ${userData.lastName || ""}`.trim() || userData.userName;

        return createCaseNote(
          caseItem.id, // Case ID goes in caseId field
          notes.trim(),
          loanNumber,
          userData.id,
          authorRole,
          authorName
        );
      });

      await Promise.all(promises);

      toast({
        title: "Notes Submitted",
        description: `Notes have been successfully added to ${cases.length} case(s).`,
      });

      setNotes("");
      onOpenChange(false);
    } catch (error) {
      console.error("[AddCaseNotesDialog] Error creating notes:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create notes. Please try again.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setNotes("");
    }
    onOpenChange(open);
  };

  if (!cases || cases.length === 0) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[625px]">
        <DialogHeader>
          <DialogTitle>Add Case Notes</DialogTitle>
          <DialogDescription>
            Add notes for {cases.length} selected case(s). (noteTypeId = 1)
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="flex flex-col gap-2">
            <Label>Selected Cases (LAN Numbers):</Label>
            <div className="flex flex-wrap gap-2">
              {cases.map((caseItem) => (
                <Badge key={caseItem.id} variant="secondary">
                  {caseItem.account?.lanNumber || caseItem.caseNumber || caseItem.id}
                </Badge>
              ))}
            </div>
          </div>
          <div className="grid w-full gap-2">
            <Label htmlFor="notes">Case Notes</Label>
            <Textarea
              id="notes"
              placeholder="Type your case notes here..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={8}
              disabled={isSubmitting}
            />
          </div>
        </div>
        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => handleOpenChange(false)}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!notes.trim() || isSubmitting}>
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Submitting...
              </>
            ) : (
              "Submit Notes"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
