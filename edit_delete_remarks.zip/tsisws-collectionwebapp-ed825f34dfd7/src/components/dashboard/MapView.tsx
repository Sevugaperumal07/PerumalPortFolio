import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { GoogleMap, useLoadScript } from "@react-google-maps/api"

const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ""

const libraries: ("places" | "drawing" | "geometry" | "visualization")[] = ["geometry"]

type CoordinateInput = string | { lat: number; lng: number }
type PathPoint = { lat: number; lng: number; title?: string; type?: string; sequenceNumber?: number; eventTime?: string; duration?: number }

interface MapViewProps {
    coordinates?: CoordinateInput
    path?: PathPoint[]
    eventTitle?: string
    eventTime?: string
    eventDetails?: React.ReactNode
    totalDistance?: number
    highlightedLocation?: { lat: number; lng: number; startTime?: string } | null
}

// Format readable label
const formatCoordinateLabel = (coords: CoordinateInput): string | null => {
    if (typeof coords === "string") return coords
    const latD = coords.lat >= 0 ? "N" : "S"
    const lngD = coords.lng >= 0 ? "E" : "W"
    return `${Math.abs(coords.lat).toFixed(4)}°${latD}, ${Math.abs(coords.lng).toFixed(4)}°${lngD}`
}

// Parse components
const parseCoordinateComponent = (segment: string, negativePattern: RegExp, positivePattern: RegExp) => {
    const cleaned = segment.replace(/[^0-9.\-]/g, "")
    if (!cleaned) return undefined
    let value = Number(cleaned)
    if (Number.isNaN(value)) return undefined
    if (negativePattern.test(segment) && value > 0) value = -value
    if (positivePattern.test(segment) && value < 0) value = Math.abs(value)
    return value
}

// Parse full coordinate string
const parseCoordinatesString = (coordStr: string): [number, number] | null => {
    const parts = coordStr.split(",")
    if (parts.length < 2) return null

    const lat = parseCoordinateComponent(parts[0], /[Ss]/i, /[Nn]/i)
    const lng = parseCoordinateComponent(parts[1], /[Ww]/i, /[Ee]/i)

    if (lat === undefined || lng === undefined) return null
    return [lng, lat]
}

// Normalize into [lng, lat]
// Helper function to get ordinal suffix (1st, 2nd, 3rd, etc.)
const getOrdinalSuffix = (num: number): string => {
    const j = num % 10
    const k = num % 100
    if (j === 1 && k !== 11) return "st"
    if (j === 2 && k !== 12) return "nd"
    if (j === 3 && k !== 13) return "rd"
    return "th"
}

// Helper function to format duration
const formatDuration = (seconds: number): string => {
    if (seconds < 60) return `${seconds}s`
    const minutes = Math.floor(seconds / 60)
    if (minutes < 60) return `${minutes}m`
    const hours = Math.floor(minutes / 60)
    const remainingMinutes = minutes % 60
    return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}m` : `${hours}h`
}

const normalizeCoordinates = (coords: CoordinateInput): [number, number] | null => {
    if (typeof coords === "string") return parseCoordinatesString(coords)
    if (typeof coords.lat === "number" && typeof coords.lng === "number") {
        return [coords.lng, coords.lat]
    }
    return null
}

export function MapView({ coordinates, path, eventTitle, eventTime, eventDetails, totalDistance, highlightedLocation }: MapViewProps) {
    const resolved = useMemo(() => {
        if (coordinates) {
            return normalizeCoordinates(coordinates)
        }
        return null
    }, [coordinates])

    const label = useMemo(() => {
        if (coordinates) {
            return formatCoordinateLabel(coordinates)
        }
        return null
    }, [coordinates])

    const pathPoints = useMemo(() => {
        if (!path || path.length === 0) return []
        return path.filter((p) => typeof p.lat === "number" && typeof p.lng === "number")
    }, [path])

    const keyPoints = useMemo(() => {
        if (!path || path.length === 0) return []
        return path.filter((p) => p.type && p.type !== "movement")
    }, [path])

    const bounds = useMemo(() => {
        if (pathPoints.length === 0) return null

        const lats = pathPoints.map((p) => p.lat)
        const lngs = pathPoints.map((p) => p.lng)

        return {
            north: Math.max(...lats),
            south: Math.min(...lats),
            east: Math.max(...lngs),
            west: Math.min(...lngs),
        }
    }, [pathPoints])

    const mapCenter = useMemo(() => {
        if (bounds) {
            return {
                lat: (bounds.north + bounds.south) / 2,
                lng: (bounds.east + bounds.west) / 2,
            }
        }
        if (resolved) {
            const [lng, lat] = resolved
            return { lat, lng }
        }
        return { lat: 0, lng: 0 }
    }, [bounds, resolved])

    const hasApiKey = GOOGLE_MAPS_API_KEY && GOOGLE_MAPS_API_KEY.trim() !== ""
    const [mapInstance, setMapInstance] = useState<google.maps.Map | null>(null)

    useEffect(() => {
        const style = document.createElement('style')
        style.textContent = `
            .gm-ui-hover-effect {
                display: none !important;
            }
            button[aria-label*="Close" i],
            button[title*="Close" i],
            .gm-style-iw-c button {
                display: none !important;
            }
            .gm-style-iw-c,
            .gm-style-iw-d {
                border-radius: 0 !important;
            }
        `
        document.head.appendChild(style)
        return () => {
            document.head.removeChild(style)
        }
    }, [])

    const { isLoaded, loadError } = useLoadScript({
        googleMapsApiKey: GOOGLE_MAPS_API_KEY || "",
        libraries,
        id: "google-map-script",
    })

    const mapRef = useRef<google.maps.Map | null>(null)
    const directionsRendererRef = useRef<google.maps.DirectionsRenderer | null>(null)
    const markersRef = useRef<google.maps.Marker[]>([])
    const infoWindowsRef = useRef<google.maps.InfoWindow[]>([])
    const lastHighlightedKeyRef = useRef<string | null>(null)

    // State to track current map zoom and center to avoid resetting on re-render
    const [currentZoom, setCurrentZoom] = useState<number>(bounds ? 13 : 14)
    const [currentCenter, setCurrentCenter] = useState<google.maps.LatLngLiteral>(mapCenter)

    // Sync internal state when mapCenter or bounds changes (e.g., new agent/date)
    // We use a custom comparison to avoid loops or unnecessary resets
    useEffect(() => {
        const isNewCenter = Math.abs(mapCenter.lat - currentCenter.lat) > 0.001 ||
            Math.abs(mapCenter.lng - currentCenter.lng) > 0.001

        if (isNewCenter) {
            setCurrentCenter(mapCenter)
            setCurrentZoom(bounds ? 13 : 14)
        }
    }, [mapCenter, bounds])

    const onLoad = useCallback((map: google.maps.Map) => {
        mapRef.current = map
        setMapInstance(map)
        if (bounds && pathPoints.length > 0) {
            const boundsObj = new google.maps.LatLngBounds(
                new google.maps.LatLng(bounds.south, bounds.west),
                new google.maps.LatLng(bounds.north, bounds.east)
            )
            map.fitBounds(boundsObj)
        }
    }, [bounds, pathPoints])

    useEffect(() => {
        if (!isLoaded || !mapInstance) return

        if (directionsRendererRef.current) {
            directionsRendererRef.current.setMap(null)
            directionsRendererRef.current = null
        }

        if (markersRef.current.length > 0) {
            markersRef.current.forEach((marker) => marker.setMap(null))
            markersRef.current = []
        }

        if (infoWindowsRef.current.length > 0) {
            infoWindowsRef.current.forEach((infoWindow) => infoWindow.close())
            infoWindowsRef.current = []
        }

        if (pathPoints.length < 2) {
            return
        }

        const origin = pathPoints[0]
        const destination = pathPoints[pathPoints.length - 1]

        const waypoints = pathPoints
            .slice(1, -1)
            .map((point) => ({
                location: new google.maps.LatLng(point.lat, point.lng),
                stopover: false,
            }))
            .slice(0, 23)

        const directionsService = new google.maps.DirectionsService()
        const directionsRenderer = new google.maps.DirectionsRenderer({
            suppressMarkers: true,
            polylineOptions: {
                strokeColor: "#0066ff",
                strokeWeight: 5,
            },
        })

        directionsRenderer.setMap(mapInstance)
        directionsRendererRef.current = directionsRenderer

        directionsService.route(
            {
                origin,
                destination,
                waypoints,
                travelMode: google.maps.TravelMode.DRIVING,
                optimizeWaypoints: true,
            },
            (response, status) => {
                if (status === "OK" && response) {
                    directionsRenderer.setDirections(response)

                    if (response.routes[0].bounds) {
                        mapInstance.fitBounds(response.routes[0].bounds)
                    }
                } else {
                    console.error("Directions failed:", status)
                }
            }
        )

        return () => {
            if (directionsRendererRef.current) {
                directionsRendererRef.current.setMap(null)
                directionsRendererRef.current = null
            }
            if (markersRef.current.length > 0) {
                markersRef.current.forEach((marker) => marker.setMap(null))
                markersRef.current = []
            }
            if (infoWindowsRef.current.length > 0) {
                infoWindowsRef.current.forEach((infoWindow) => infoWindow.close())
                infoWindowsRef.current = []
            }
        }
    }, [isLoaded, mapInstance, pathPoints])

    const createMarkerIcon = (type?: string, isHighlighted?: boolean): google.maps.Icon => {
        let fillColor = "#3b82f6"
        let centerColor = "#1d4ed8"

        if (type === "checkin" || type === "start") {
            fillColor = "#10b981"
            centerColor = "#047857"
        } else if (type === "checkout" || type === "end") {
            fillColor = "#ef4444"
            centerColor = "#b91c1c"
        } else if (type === "collection") {
            fillColor = "#a855f7"
            centerColor = "#7e22ce"
        } else if (type === "halt") {
            fillColor = "#f59e0b"
            centerColor = "#d97706"
        }

        // Larger size and glow effect for highlighted marker
        const size = isHighlighted ? 48 : 32
        const height = isHighlighted ? 66 : 44
        const strokeWidth = isHighlighted ? 3 : 0
        const strokeColor = isHighlighted ? "#ffffff" : "none"
        const glowFilter = isHighlighted ? `
            <defs>
                <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                    <feMerge>
                        <feMergeNode in="coloredBlur"/>
                        <feMergeNode in="SourceGraphic"/>
                    </feMerge>
                </filter>
            </defs>
        ` : ""

        const svg = `
            <svg width="${size}" height="${height}" viewBox="0 0 32 44" xmlns="http://www.w3.org/2000/svg">
                ${glowFilter}
                <path d="M16 0C7.163 0 0 7.163 0 16c0 12 16 28 16 28s16-16 16-28c0-8.837-7.163-16-16-16z"
                      fill="${fillColor}"
                      stroke="${strokeColor}"
                      stroke-width="${strokeWidth}"
                      ${isHighlighted ? 'filter="url(#glow)"' : ''}/>
                <circle cx="16" cy="16" r="6" fill="${centerColor}"/>
            </svg>
        `

        return {
            url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg),
            scaledSize: new google.maps.Size(size, height),
            anchor: new google.maps.Point(size / 2, height),
        }
    }

    // Helper to check if a point matches the highlighted location
    const isPointHighlighted = useCallback((pointLat: number, pointLng: number, pointEventTime?: string) => {
        if (!highlightedLocation) return false
        const latMatch = Math.abs(pointLat - highlightedLocation.lat) < 0.0001
        const lngMatch = Math.abs(pointLng - highlightedLocation.lng) < 0.0001
        // If startTime is provided, also match on that for more precision
        if (highlightedLocation.startTime && pointEventTime) {
            return latMatch && lngMatch && pointEventTime === highlightedLocation.startTime
        }
        return latMatch && lngMatch
    }, [highlightedLocation])

    useEffect(() => {
        if (!isLoaded || !mapInstance) return

        if (markersRef.current.length > 0) {
            markersRef.current.forEach((marker) => marker.setMap(null))
            markersRef.current = []
        }

        if (infoWindowsRef.current.length > 0) {
            infoWindowsRef.current.forEach((infoWindow) => infoWindow.close())
            infoWindowsRef.current = []
        }

        const highlighted: { marker: google.maps.Marker | null; infoWindow: google.maps.InfoWindow | null } = {
            marker: null,
            infoWindow: null,
        }

        const addMarker = (position: google.maps.LatLngLiteral, title: string, type?: string, sequenceNumber?: number, eventTime?: string, duration?: number) => {
            const isHighlighted = isPointHighlighted(position.lat, position.lng, eventTime)

            const markerOptions: google.maps.MarkerOptions = {
                position,
                map: mapInstance,
                title,
                icon: createMarkerIcon(type, isHighlighted),
                zIndex: isHighlighted ? 1000 : 1, // Bring highlighted marker to front
            }

            const marker = new google.maps.Marker(markerOptions)
            markersRef.current.push(marker)

            // Apply bounce animation to highlighted marker
            if (isHighlighted) {
                marker.setAnimation(google.maps.Animation.BOUNCE)
                // Stop bouncing after 2 seconds
                setTimeout(() => {
                    marker.setAnimation(null)
                }, 2000)
                highlighted.marker = marker
            }

            let infoContent = ""

            if (sequenceNumber !== undefined && type !== "start" && type !== "end") {
                // Format duration if available
                const durationText = duration ? ` - Duration: ${formatDuration(duration)}` : ""

                infoContent = `
                    <div style="
                        padding: 4px 3px;
                        font-family: system-ui, -apple-system, sans-serif;
                        min-width: 200px;
                    ">
                        <div style="
                            font-weight: 600;
                            font-size: 14px;
                            color: #1f2937;
                            margin-bottom: 4px;
                        ">
                            ${sequenceNumber}${getOrdinalSuffix(sequenceNumber)} at ${eventTime || ""} - ${title}
                        </div>
                        <div style="
                            font-size: 12px;
                            color: #6b7280;
                        ">
                            ${eventTime || ""}${durationText}
                        </div>
                    </div>
                `
            } else {
                infoContent = `
                    <div style="
                        padding: 4px 3px;
                        font-family: system-ui, -apple-system, sans-serif;
                    ">
                        <div style="
                            font-weight: 600;
                            font-size: 14px;
                            color: #1f2937;
                        ">
                            ${title}
                        </div>
                    </div>
                `
            }

            const infoWindow = new google.maps.InfoWindow({
                content: infoContent,
            })
            infoWindowsRef.current.push(infoWindow)

            // Keep info window open for highlighted marker
            if (isHighlighted) {
                highlighted.infoWindow = infoWindow
            }

            // Show info window on hover
            marker.addListener("mouseover", () => {
                infoWindow.open(mapInstance, marker)
            })

            marker.addListener("mouseout", () => {
                // Don't close if this is the highlighted marker
                if (!isHighlighted) {
                    infoWindow.close()
                }
            })
        }

        if (pathPoints.length > 0) {
            addMarker({ lat: pathPoints[0].lat, lng: pathPoints[0].lng }, "Start", "start")

            if (pathPoints.length > 1) {
                const last = pathPoints[pathPoints.length - 1]
                addMarker({ lat: last.lat, lng: last.lng }, "End", "end")
            }
        }

        if (keyPoints.length > 0) {
            keyPoints.forEach((point) => {
                addMarker(
                    { lat: point.lat, lng: point.lng },
                    point.title || point.type || "Location",
                    point.type,
                    point.sequenceNumber,
                    point.eventTime,
                    point.duration
                )
            })
        } else if (resolved) {
            const [lng, lat] = resolved
            addMarker({ lat, lng }, eventTitle || "Location", undefined)
        }

        // Pan to highlighted marker and open its info window ONLY if it's a new selection
        if (highlighted.marker && highlightedLocation) {
            const currentKey = `${highlightedLocation.lat}-${highlightedLocation.lng}-${highlightedLocation.startTime || ""}`

            if (lastHighlightedKeyRef.current !== currentKey) {
                lastHighlightedKeyRef.current = currentKey
                // Only zoom in if we're not already zoomed in enough
                const mapZoom = mapInstance.getZoom() || 0
                if (mapZoom < 16) {
                    const nextZoom = 16
                    mapInstance.setZoom(nextZoom)
                    setCurrentZoom(nextZoom)
                }

                const newCenter = { lat: highlightedLocation.lat, lng: highlightedLocation.lng }
                mapInstance.panTo(newCenter)
                setCurrentCenter(newCenter)
            }

            if (highlighted.infoWindow) {
                highlighted.infoWindow.open(mapInstance, highlighted.marker)
            }
        } else if (!highlightedLocation) {
            lastHighlightedKeyRef.current = null
        }

        return () => {
            if (markersRef.current.length > 0) {
                markersRef.current.forEach((marker) => marker.setMap(null))
                markersRef.current = []
            }
            if (infoWindowsRef.current.length > 0) {
                infoWindowsRef.current.forEach((infoWindow) => infoWindow.close())
                infoWindowsRef.current = []
            }
        }
    }, [isLoaded, mapInstance, pathPoints, keyPoints, resolved, eventTitle, highlightedLocation, isPointHighlighted])

    const hasValidData = pathPoints.length > 0 || resolved !== null

    if (!hasValidData) {
        return (
            <div className="space-y-4">
                <div className="rounded-lg border bg-muted/50 p-4">
                    <h3 className="font-semibold mb-2">Location Details</h3>
                    <p className="text-sm text-muted-foreground">
                        Unable to render the map because no valid coordinates were provided.
                    </p>

                    {eventTitle && (
                        <div className="mt-4 space-y-1 text-sm">
                            <p><span className="text-muted-foreground">Event:</span> {eventTitle}</p>
                            {eventTime && <p><span className="text-muted-foreground">Time:</span> {eventTime}</p>}
                            {label && <p><span className="text-muted-foreground">Location:</span> {label}</p>}
                        </div>
                    )}

                    {eventDetails && <div className="mt-3 border-t pt-3">{eventDetails}</div>}
                </div>
            </div>
        )
    }

    // Check if API key is configured
    if (!GOOGLE_MAPS_API_KEY || GOOGLE_MAPS_API_KEY.trim() === "") {
        return (
            <div className="space-y-4">
                <div className="rounded-lg border bg-muted/50 p-4">
                    <h3 className="font-semibold mb-2">Location Details</h3>
                    <div className="rounded-lg border border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-950 p-4 mb-4">
                        <p className="text-sm font-medium text-amber-800 dark:text-amber-200 mb-2">
                            Google Maps API Key Not Configured
                        </p>
                        <p className="text-xs text-amber-700 dark:text-amber-300">
                            Please set <code className="bg-amber-100 dark:bg-amber-900 px-1 py-0.5 rounded">VITE_GOOGLE_MAPS_API_KEY</code> in your <code className="bg-amber-100 dark:bg-amber-900 px-1 py-0.5 rounded">.env</code> file.
                            See <code className="bg-amber-100 dark:bg-amber-900 px-1 py-0.5 rounded">GOOGLE-MAPS-SETUP.md</code> for setup instructions.
                        </p>
                    </div>
                    {eventTitle && (
                        <div className="mt-4 space-y-1 text-sm">
                            <p><span className="text-muted-foreground">Event:</span> {eventTitle}</p>
                            {eventTime && <p><span className="text-muted-foreground">Time:</span> {eventTime}</p>}
                            {label && <p><span className="text-muted-foreground">Location:</span> {label}</p>}
                        </div>
                    )}
                    {eventDetails && <div className="mt-3 border-t pt-3">{eventDetails}</div>}
                </div>
            </div>
        )
    }

    const mapContainerStyle: React.CSSProperties = {
        width: "100%",
        height: "100%",
        minHeight: "350px",
    }

    const mapOptions = useMemo(() => ({
        disableDefaultUI: false,
        zoomControl: true,
        streetViewControl: true,
        mapTypeControl: true,
        fullscreenControl: true,
    }), [])

    if (hasApiKey && !isLoaded) {
        return (
            <div className="space-y-4">
                <div className="rounded-lg border bg-muted/50 p-4">
                    <h3 className="font-semibold mb-4">Location Details</h3>
                    <div className="rounded-lg overflow-hidden border w-full flex items-center justify-center" style={{ height: "350px", minHeight: "350px" }}>
                        <div className="text-center">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
                            <p className="text-sm text-muted-foreground">Loading map...</p>
                        </div>
                    </div>
                    <div className="mt-4 space-y-2">
                        <div className="rounded-lg border bg-background p-4">
                            <h4 className="font-semibold">{eventTitle}</h4>
                            {eventTime && <p className="text-sm text-muted-foreground mt-1">{eventTime}</p>}
                            {eventDetails && <div className="mt-2">{eventDetails}</div>}
                            <div className="mt-3 pt-3 border-t">
                                <p className="text-sm">
                                    <span className="text-muted-foreground">Location:</span>{" "}
                                    {label ?? "Unavailable"}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    if (loadError) {
        return (
            <div className="space-y-4">
                <div className="rounded-lg border bg-muted/50 p-4">
                    <h3 className="font-semibold mb-4">Location Details</h3>
                    <div className="rounded-lg border border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950 p-4 mb-4">
                        <p className="text-sm font-medium text-red-800 dark:text-red-200 mb-2">
                            Failed to load Google Maps
                        </p>
                        <p className="text-xs text-red-700 dark:text-red-300">
                            {loadError.message || "An error occurred while loading the map. Please check your API key and try again."}
                        </p>
                    </div>
                    <div className="mt-4 space-y-2">
                        <div className="rounded-lg border bg-background p-4">
                            <h4 className="font-semibold">{eventTitle}</h4>
                            {eventTime && <p className="text-sm text-muted-foreground mt-1">{eventTime}</p>}
                            {eventDetails && <div className="mt-2">{eventDetails}</div>}
                            <div className="mt-3 pt-3 border-t">
                                <p className="text-sm">
                                    <span className="text-muted-foreground">Location:</span>{" "}
                                    {label ?? "Unavailable"}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <div className="space-y-4">
            <div className="rounded-lg border bg-muted/50 p-4">
                <h3 className="text-center font-semibold mb-4 ">Location Details</h3>

                {/* Map */}
                <div className="rounded-lg overflow-hidden border w-full" style={{ height: "350px", minHeight: "350px" }}>
                    <GoogleMap
                        mapContainerStyle={mapContainerStyle}
                        center={currentCenter}
                        zoom={currentZoom}
                        options={mapOptions}
                        onLoad={onLoad}
                        onIdle={() => {
                            if (mapInstance) {
                                const newCenter = mapInstance.getCenter()?.toJSON()
                                const newZoom = mapInstance.getZoom()

                                if (newCenter && (Math.abs(newCenter.lat - currentCenter.lat) > 0.0001 ||
                                    Math.abs(newCenter.lng - currentCenter.lng) > 0.0001)) {
                                    setCurrentCenter(newCenter)
                                }

                                if (newZoom !== undefined && newZoom !== currentZoom) {
                                    setCurrentZoom(typeof newZoom === 'number' ? Math.floor(newZoom) : newZoom)
                                }
                            }
                        }}
                    >
                    </GoogleMap>
                </div>

                {(eventTitle || eventTime || eventDetails || totalDistance !== undefined) && (
                    <div className="mt-4 space-y-2">
                        <div className="rounded-lg border bg-background p-4">
                            {totalDistance !== undefined && path && path.length > 0 ? (
                                <h4 className="font-semibold">Total Distance Travelled: {totalDistance.toFixed(2)} km</h4>
                            ) : eventTitle ? (
                                <h4 className="font-semibold">{eventTitle}</h4>
                            ) : null}

                            {eventTime && <p className="text-sm text-muted-foreground mt-1">{eventTime}</p>}

                            {eventDetails && <div className="mt-2">{eventDetails}</div>}

                            {label && (
                                <div className="mt-3 pt-3 border-t">
                                    <p className="text-sm">
                                        <span className="text-muted-foreground">Location:</span> {label}
                                    </p>
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    )
}
