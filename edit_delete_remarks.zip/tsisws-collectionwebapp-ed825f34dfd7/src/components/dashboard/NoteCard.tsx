import { StickyNote } from "lucide-react";
import { formatNoteDate } from "@/lib/utils";
import type { NoteFromCriteriaAPI } from "@/lib/types";
import { Badge } from "@/components/ui/badge";

interface NoteCardProps {
  note: NoteFromCriteriaAPI;
  fallbackLabel?: string;
}

function getNoteType(note: NoteFromCriteriaAPI): "CASE" | "TASK" | "UNKNOWN" {
  const normalized = note.noteTypeName?.toUpperCase();
  if (normalized === "TASK") return "TASK";
  if (normalized === "CASE") return "CASE";
  if (note.noteTypeId === 2) return "TASK";
  if (note.noteTypeId === 1) return "CASE";
  return "UNKNOWN";
}

function getCaseId(note: NoteFromCriteriaAPI) {
  return note.associations?.find((assoc) => assoc.caseId)?.caseId ?? note.caseId;
}


export function NoteCard({ note, fallbackLabel }: NoteCardProps) {
  const noteType = getNoteType(note);
  const isTask = noteType === "TASK";
  const isCase = noteType === "CASE";
  const caseId = getCaseId(note);
  const taskNumber = note.taskNumber;

  const primaryLabel = isTask
    ? taskNumber || caseId || fallbackLabel || "Unknown"
    : isCase
      ? caseId || taskNumber || fallbackLabel || "Unknown"
      : fallbackLabel || caseId || taskNumber || "Unknown";

  return (
    <div className="rounded-lg border bg-gray-50 p-3 shadow-sm space-y-2">
      <div className="flex justify-between items-start gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <StickyNote className="h-4 w-4 text-primary flex-shrink-0" />
          <p className="text-primary truncate">
            <Badge variant={isTask ? "secondary" : "outline"} className="uppercase text-[12px]">
              {noteType}
            </Badge>  #{primaryLabel}
          </p>
        </div>
        <span className="text-xs text-muted-foreground whitespace-nowrap flex-shrink-0">
          {formatNoteDate(note.createdAt)}
        </span>
      </div>
      <p className="text-sm text-gray-800 whitespace-pre-wrap">
        {note.content || "Note"}
      </p>
      {note.authorName && (
        <p className="text-xs text-muted-foreground text-right">
          Noted by: {note.authorName}
          {note.authorRole && (
            <span className="text-gray-400 ml-1">({note.authorRole})</span>
          )}
        </p>
      )}
    </div>
  );
}
