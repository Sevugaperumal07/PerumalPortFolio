import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { useCallback, useMemo, useState } from "react";

import { useToast } from "@/hooks/use-toast";
import {
  checkReceiptEditable,
  deleteReceipt,
  recreateReceipt,
} from "@/lib/services/receipts";
import type { CollReceipt, RecreateReceiptInput } from "@/lib/types";
import { AlertCircle, Loader2 } from "lucide-react";

interface ReceiptManagementProps {
  receipt: CollReceipt | null;
  isServiceChargeType?: boolean;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  mode: "edit" | "delete" | "check";
  allowDelete?: boolean;
}

export function ReceiptManagement({
  receipt,
  isServiceChargeType = false,
  isOpen,
  onClose,
  onSuccess,
  mode,
  allowDelete = false,
}: ReceiptManagementProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [checkResult, setCheckResult] = useState<{
    editable: boolean;
    reasons: string[];
  } | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [hasReversedForEdit, setHasReversedForEdit] = useState(false);

  // Edit form state
  const [newEmiAmount, setNewEmiAmount] = useState<string>("");
  const [newBounceAmount, setNewBounceAmount] = useState<string>("0");
  const [newPenaltyAmount, setNewPenaltyAmount] = useState<string>("0");
  const [newTransactionRefNo, setNewTransactionRefNo] = useState<string>("");
  const [newReceiptDate, setNewReceiptDate] = useState<Date | undefined>();
  const [newServicePayment, setNewServicePayment] = useState<string>("0");
  const [reason, setReason] = useState<string>("");
  const [deleteReason, setDeleteReason] = useState<string>("");
  const resetForm = useCallback(() => {
    setCheckResult(null);
    setShowDeleteConfirm(false);
    setShowEditForm(false);
    setHasReversedForEdit(false);
    setNewEmiAmount("");
    setNewBounceAmount("0");
    setNewPenaltyAmount("0");
    setNewTransactionRefNo("");
    setNewReceiptDate(undefined);
    setNewServicePayment("0");
    setReason("");
    setDeleteReason("");
  }, []);
  const handleClose = useCallback(() => {
    resetForm();
    onClose();
  }, [resetForm, onClose]);

  // Change detection logic using useMemo (Senior Developer implementation)
  const isServicePaymentChanged = useMemo(() => {
    return parseFloat(newServicePayment) !== (receipt?.totalAmount || 0);
  }, [newServicePayment, receipt?.totalAmount]);

  const areOtherAmountsChanged = useMemo(() => {
    const pEmi = parseFloat(newEmiAmount) || 0;
    const pBounce = parseFloat(newBounceAmount) || 0;
    const pPenalty = parseFloat(newPenaltyAmount) || 0;
    const isRefNoChanged = (newTransactionRefNo || "").trim() !== (receipt?.transactionRefNo || "").trim();

    return (
      pEmi !== (receipt?.collectedEmiAmount || 0) ||
      pBounce !== (receipt?.collectedBounceAmount || 0) ||
      pPenalty !== (receipt?.collectedPenaltyAmount || 0) ||
      isRefNoChanged
    );
  }, [newEmiAmount, newBounceAmount, newPenaltyAmount, newTransactionRefNo, receipt]);

  const isTransactionRefValid = useMemo(() => {
    const pt = receipt?.paymentType?.toUpperCase();
    if (!pt) return true;

    switch (pt) {
      case "UPI":
      case "IMPS":
        return newTransactionRefNo.length === 12 && /^\d{12}$/.test(newTransactionRefNo) &&
        !/^0+$/.test(newTransactionRefNo);
      case "CHEQUE":
        return newTransactionRefNo.length === 6 && /^\d{6}$/.test(newTransactionRefNo) &&
        !/^0+$/.test(newTransactionRefNo);
      case "RTGS":
        return newTransactionRefNo.length === 22 && /^[a-zA-Z0-9]{22}$/.test(newTransactionRefNo) &&
        !/^0+$/.test(newTransactionRefNo);
      case "NEFT":
        return newTransactionRefNo.length === 16 && /^[a-zA-Z0-9]{16}$/.test(newTransactionRefNo) &&
        !/^0+$/.test(newTransactionRefNo);
      default:
        return true;
    }
  }, [receipt?.paymentType, newTransactionRefNo]);

  const isDataUnchanged = useMemo(() => {
    const isRefNoChanged = (newTransactionRefNo || "").trim() !== (receipt?.transactionRefNo || "").trim();
    if (isServiceChargeType) {
      return !(isServicePaymentChanged || isRefNoChanged);
    }
    return !(isServicePaymentChanged || areOtherAmountsChanged);
  }, [isServiceChargeType, isServicePaymentChanged, areOtherAmountsChanged, newTransactionRefNo, receipt?.transactionRefNo]);

  const isSaveDisabled = useMemo(() => {
    const isEmiInvalid = !isServiceChargeType && Number(newEmiAmount) === 0;
    const isServicePaymentInvalid = isServiceChargeType && Number(newServicePayment) === 0;
    const isReasonInvalid = !reason.trim();

    return (
      loading ||
      isDataUnchanged ||
      isEmiInvalid ||
      isServicePaymentInvalid ||
      !isTransactionRefValid ||
      isReasonInvalid
    );
  }, [loading, isDataUnchanged, isServiceChargeType, newEmiAmount, newServicePayment, isTransactionRefValid, reason]);

  const newReceivedAmount = useMemo(() => {
    if (isServiceChargeType) {
      return parseFloat(newServicePayment) || 0;
    }
    const pEmi = parseFloat(newEmiAmount) || 0;
    const pBounce = parseFloat(newBounceAmount) || 0;
    const pPenalty = parseFloat(newPenaltyAmount) || 0;
    return pEmi + pBounce + pPenalty;
  }, [isServiceChargeType, newServicePayment, newEmiAmount, newBounceAmount, newPenaltyAmount]);

  const transactionLabel = useMemo(() => {
    switch (receipt?.paymentType?.toUpperCase()) {
      case "CHEQUE": return "Cheque Number";
      case "RTGS": return "Transaction ID";
      case "NEFT": return "Reference ID";
      case "IMPS": return "Reference Number";
      case "UPI": return "UTR Number";
      default: return "Transaction ID";
    }
  }, [receipt?.paymentType]);

  // Check if receipt is editable
  const handleCheckEditable = useCallback(async () => {
    if (!receipt?.receiptNo) {
      toast({
        title: "Error",
        description: "Receipt number is missing",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const result = await checkReceiptEditable(receipt.receiptNo);
      setCheckResult(result);

      if (result.editable) {
        if (mode === "delete") {
          setShowDeleteConfirm(true);
        } else if (mode === "edit") {
          // Pre-fill form with existing values
          setNewEmiAmount(String(receipt.collectedEmiAmount || 0));
          setNewBounceAmount(String(receipt.collectedBounceAmount || 0));
          setNewPenaltyAmount(String(receipt.collectedPenaltyAmount || 0));
          setNewServicePayment(String(receipt.totalAmount || 0));
          setNewTransactionRefNo(receipt.transactionRefNo || "");
          if (receipt.receiptdate) {
            const parsedDate = new Date(`${receipt.receiptdate}T00:00:00`);
            setNewReceiptDate(Number.isNaN(parsedDate.getTime()) ? undefined : parsedDate);
          }
          setShowEditForm(true);
        }
      } else {
        toast({
          title: "Cannot Modify Receipt",
          description: result.reasons.join(", ") || "This receipt cannot be modified.",
          variant: "destructive",
        });
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to check receipt status";
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [receipt, mode, toast]);

  // Delete receipt
  const handleDelete = useCallback(async () => {
    if (!receipt?.receiptNo) {
      toast({
        title: "Error",
        description: "Receipt number is missing",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const result = await deleteReceipt(receipt.receiptNo, deleteReason);
      toast({
        title: "Success",
        description: result.message || "Receipt deleted successfully",
      });
      handleClose();
      onSuccess();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to delete receipt";
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [receipt, toast, handleClose, onSuccess, deleteReason]);

  // Helper to render amount change message below a field
  const renderAmountChangeMessage = (newValue: number, originalValue: number, fieldLabel: string) => {
    const diff = newValue - originalValue;
    if (diff === 0) return null;
    const isIncrease = diff > 0;
    return (
      <p className={`mt-1 flex items-center gap-1 text-xs font-medium ${isIncrease ? "text-green-600" : "text-red-600"
        }`}>
        The {fieldLabel} is {isIncrease ? "Greater" : "Lesser"}
      </p>
    );
  };

 const handleAmountKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
  if (e.key.length === 1 && !/[0-9.]/.test(e.key)) {
    e.preventDefault();
  }
};

  const handleAmountChange = (val: string, setter: (value: string) => void) => {
    // Allow only digits and one decimal point
    const sanitized = val.replace(/[^0-9.]/g, "").replace(/(\..*)\./g, "$1");
    setter(sanitized);
  };

  const handleTransactionRefChange = (val: string) => {
    const pt = receipt?.paymentType?.toUpperCase();
    let sanitized = val;

    switch (pt) {
      case "UPI":
      case "IMPS":
        sanitized = val.replace(/\D/g, "").slice(0, 12);
        break;
      case "CHEQUE":
        sanitized = val.replace(/\D/g, "").slice(0, 6);
        break;
      case "RTGS":
        sanitized = val.replace(/[^a-zA-Z0-9]/g, "").slice(0, 22);
        break;
      case "NEFT":
        sanitized = val.replace(/[^a-zA-Z0-9]/g, "").slice(0, 16);
        break;
      default:
        break;
    }

    setNewTransactionRefNo(sanitized);
  };

  // Edit receipt
  const handleEdit = useCallback(async () => {
    if (!receipt?.receiptNo) {
      toast({
        title: "Error",
        description: "Receipt number is missing",
        variant: "destructive",
      });
      return;
    }

    const newEmi = parseFloat(newEmiAmount) || 0;
    const newBounce = parseFloat(newBounceAmount) || 0;
    const newPenalty = parseFloat(newPenaltyAmount) || 0;
    const newTotalAmount = parseFloat(newServicePayment) || 0;

    let reversedForEdit = hasReversedForEdit;
    setLoading(true);
    try {
      const input: RecreateReceiptInput = {
        oldReceiptNo: receipt.receiptNo,
        newCollectedEmiAmount: newEmi,
        newCollectedBounceAmount: newBounce,
        newCollectedPenaltyAmount: newPenalty,
        ...(isServicePaymentChanged && { newAmountCollected: newTotalAmount }),
        newTransactionRefNo: newTransactionRefNo || null,
        newReceiptDate: newReceiptDate ? format(newReceiptDate, "yyyy-MM-dd") : null,
        remarks: reason || null,
      };

      if (!reversedForEdit) {
        await deleteReceipt(receipt.receiptNo, reason);
        reversedForEdit = true;
        setHasReversedForEdit(true);
      }

      const result = await recreateReceipt(input);

      toast({
        title: "Success",
        description: result.message || "Receipt updated successfully",
      });
      handleClose();
      onSuccess();
    } catch (error) {
      console.error("[ReceiptManagement] Edit Receipt Error:", error);

      const errorMessage = error instanceof Error ? error.message : "Failed to update receipt";
      toast({
        title: "Error",
        description: reversedForEdit
          ? `Receipt reversed, but recreation failed. ${errorMessage}`
          : errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [
    receipt,
    newEmiAmount,
    newBounceAmount,
    newPenaltyAmount,
    newTransactionRefNo,
    newReceiptDate,
    newServicePayment,
    reason,
    hasReversedForEdit,
    isServicePaymentChanged,
    toast,
    handleClose,
    onSuccess,
  ]);

  if (!receipt) return null;

  return (
    <>
      {/* Main Dialog for Check/Edit */}
      <Dialog open={isOpen && !showDeleteConfirm} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-[500px] bg-white h-[90vh] flex flex-col overflow-hidden">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold text-gray-900">
              {mode === "delete" ? "Delete Receipt" : mode === "edit" ? "Edit Receipt" : "Check Receipt"}
            </DialogTitle>
            <DialogDescription className="text-sm text-gray-600">
              Receipt No: {receipt.receiptNo || "-"}
            </DialogDescription>
          </DialogHeader>

          {/* Initial state - show receipt info and check button */}
          {!checkResult && !showEditForm && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 py-4">
                <div>
                  <Label className="text-xs text-gray-500">Customer Name</Label>
                  <p className="text-sm font-medium">{receipt.customerName || "-"}</p>
                </div>
                <div>
                  <Label className="text-xs text-gray-500">LAN Number</Label>
                  <p className="text-sm font-medium">{receipt.lanNumber || "-"}</p>
                </div>
                <div>
                  <Label className="text-xs text-gray-500">EMI Amount</Label>
                  <p className="text-sm font-medium">
                    {receipt.collectedEmiAmount != null
                      ? `₹${receipt.collectedEmiAmount.toLocaleString("en-IN")}`
                      : "-"}
                  </p>
                </div>
                <div>
                  <Label className="text-xs text-gray-500">Receipt Date</Label>
                  <p className="text-sm font-medium">{receipt.receiptdate || "-"}</p>
                </div>
                <div>
                  <Label className="text-xs text-gray-500">Payment Type</Label>
                  <p className="text-sm font-medium">{receipt.paymentType || "-"}</p>
                </div>
                <div>
                  <Label className="text-xs text-gray-500">Status</Label>
                  <p className="text-sm font-medium">{receipt.status || "-"}</p>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={handleClose}>
                  Cancel
                </Button>
                <Button
                  onClick={handleCheckEditable}
                  disabled={loading}
                  className="bg-blue-800 hover:bg-blue-900 text-white"
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {mode === "delete" ? "Check & Delete" : mode === "edit" ? "Check & Edit" : "Check Status"}
                </Button>
              </DialogFooter>
            </div>
          )}

          {/* Check result - not editable */}
          {checkResult && !checkResult.editable && (
            <div className="space-y-4">
              <div className="flex items-start gap-3 p-4 bg-red-50 rounded-lg border border-red-200">
                <AlertCircle className="h-5 w-5 text-red-500 mt-0.5" />
                <div>
                  <p className="font-medium text-red-800">This receipt cannot be modified</p>
                  <ul className="mt-2 text-sm text-red-700 list-disc list-inside">
                    {checkResult.reasons.map((reason, index) => (
                      <li key={index}>{reason}</li>
                    ))}
                  </ul>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={handleClose}>
                  Close
                </Button>
              </DialogFooter>
            </div>
          )}

          {/* Edit Form */}
          {showEditForm && (
            <div className="flex-1 flex flex-col min-h-0">
              <div className="flex-1 overflow-y-auto pr-2 grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="emiAmount">EMI Amount
                      {!isServiceChargeType && <span className="text-red-500 ml-0.5">*</span>}
                    </Label>
                    <Input
                      id="emiAmount"
                      type="number"
                      min="0"
                      value={newEmiAmount}
                      disabled={isServiceChargeType}
                      onKeyDown={handleAmountKeyDown}
                      onChange={(e) => handleAmountChange(e.target.value, setNewEmiAmount)}
                      placeholder="Enter EMI amount"
                    />

                    {renderAmountChangeMessage(parseFloat(newEmiAmount) || 0, receipt?.collectedEmiAmount || 0, "EMI Amount")}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bounceAmount">Bounce Amount</Label>
                    <Input
                      id="bounceAmount"
                      type="number"
                      min="0"
                      value={newBounceAmount}
                      disabled={isServiceChargeType}
                      onKeyDown={handleAmountKeyDown}
                      onChange={(e) => handleAmountChange(e.target.value, setNewBounceAmount)}
                      placeholder="Enter bounce amount"
                    />

                    {renderAmountChangeMessage(parseFloat(newBounceAmount) || 0, receipt?.collectedBounceAmount || 0, "Bounce Amount")}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="penaltyAmount">Penalty Amount</Label>
                    <Input
                      id="penaltyAmount"
                      type="number"
                      min="0"
                      value={newPenaltyAmount}
                      disabled={isServiceChargeType}
                      onKeyDown={handleAmountKeyDown}
                      onChange={(e) => handleAmountChange(e.target.value, setNewPenaltyAmount)}
                      placeholder="Enter penalty amount"
                    />

                    {renderAmountChangeMessage(parseFloat(newPenaltyAmount) || 0, receipt?.collectedPenaltyAmount || 0, "Penalty Amount")}
                  </div>
                  {["UPI", "RTGS", "NEFT", "CHEQUE", "IMPS"].includes(receipt?.paymentType?.toUpperCase() || "") && (
                    <div className="space-y-2">
                      <Label htmlFor="transactionRef">{transactionLabel}</Label>
                      <Input
                        id="transactionRef"
                        value={newTransactionRefNo}
                        onChange={(e) => handleTransactionRefChange(e.target.value)}
                        placeholder={`Enter ${transactionLabel.toLowerCase()}`}
                      />
                    </div>
                  )}
                </div>

                {isServiceChargeType && (
                  <div className="space-y-2">
                    <Label htmlFor="servicePayment">Service Payment</Label>
                    <Input
                      id="servicePayment"
                      type="number"
                      min="0"
                      value={newServicePayment}
                      onKeyDown={handleAmountKeyDown}
                      onChange={(e) => handleAmountChange(e.target.value, setNewServicePayment)}
                      placeholder="Enter service payment"
                    />

                    {renderAmountChangeMessage(parseFloat(newServicePayment) || 0, receipt?.totalAmount || 0, "Service Payment")}
                  </div>
                )}

                <div className="rounded-lg border border-blue-100 bg-blue-50/60 px-4 py-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-800">New Received Amount:</span>
                    <span className="text-sm font-semibold text-gray-900">
                      ₹{newReceivedAmount.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-gray-600">
                    This will update the "Received Amount" in the tasks table after saving.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="remarks">Remarks <span className="text-red-500">*</span></Label>
                  <Textarea
                    id="remarks"
                    placeholder="Enter remarks for approval or rejection..."
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    className="min-h-[80px] resize-none"
                  />
                </div>
              </div>

              <DialogFooter className="flex-shrink-0 border-t pt-4 mt-4">
                {allowDelete && (
                  <Button
                    variant="outline"
                    onClick={() => setShowDeleteConfirm(true)}
                    className="border-red-600 text-red-600 hover:bg-red-50"
                  >
                    Delete Receipt
                  </Button>
                )}
                <Button variant="outline" onClick={handleClose}>
                  Cancel
                </Button>
                <Button
                  onClick={handleEdit}
                  disabled={isSaveDisabled}
                  className="bg-blue-800 hover:bg-blue-900 text-white"
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Save Changes
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent className="bg-white">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Receipt</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete receipt #{receipt.receiptNo}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>

          <div className="py-4 space-y-2">
            <Label htmlFor="deleteRemarks">Remarks <span className="text-red-500">*</span></Label>
            <Textarea
              id="deleteRemarks"
              placeholder="Enter remarks for deletion..."
              value={deleteReason}
              onChange={(e) => setDeleteReason(e.target.value)}
              className="min-h-[80px] resize-none"
            />
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel onClick={handleClose}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={loading || !deleteReason.trim()}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

export default ReceiptManagement;