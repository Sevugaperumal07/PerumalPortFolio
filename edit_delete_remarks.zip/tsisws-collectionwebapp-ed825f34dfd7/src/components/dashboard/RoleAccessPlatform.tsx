import React from "react";
import { Monitor, Smartphone, Layers } from "lucide-react";

export type PlatformType = "mobile" | "webapp" | "general";

type TabConfig = {
  label: string;
  value: PlatformType;
  icon: React.ReactNode;
};

const TABS: TabConfig[] = [
  {
    label: "Mobile",
    value: "mobile",
    icon: <Smartphone size={16} />,
  },
  {
    label: "Web App",
    value: "webapp",
    icon: <Monitor size={16} />,
  },
  {
    label: "General",
    value: "general",
    icon: <Layers size={16} />,
  },
];

type Props = {
  value: PlatformType;
  onChange: (value: PlatformType) => void;
  className?: string;
};

const AccessPlatformTabs: React.FC<Props> = ({
  value,
  onChange,
  className = "",
}) => {
  return (
    <div
      className={`flex items-center gap-2 border-b pb-3 ${className}`}
      role="tablist"
    >
      {TABS.map((tab) => {
        const isActive = value === tab.value;

        return (
          <button
            key={tab.value}
            role="tab"
            aria-selected={isActive}
            onClick={() => onChange(tab.value)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150
              
              ${
                isActive
                  ? "bg-blue-600 text-white shadow-sm"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }

              focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1
            `}
          >
            {tab.icon}
            {tab.label}
          </button>
        );
      })}
    </div>
  );
};

export default React.memo(AccessPlatformTabs);