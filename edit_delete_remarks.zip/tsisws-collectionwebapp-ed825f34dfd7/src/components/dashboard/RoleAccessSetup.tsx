import { useMemo, useState, useEffect } from 'react';
import { ChevronDown, Info, Check } from 'lucide-react';
import { getPermissionLevels } from '@/lib/services/roles';
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from '@/components/ui/table';
import {
    Tooltip,
    TooltipContent,
    TooltipTrigger,
} from '@/components/ui/tooltip';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { RoleAccessDescription,type ActionDescription } from '@/components/common/RoleAccessDescription';
import AccessPlatformTabs,{type PlatformType} from './RoleAccessPlatform';


export interface ActionPermission {
    action: string;
    defaultLevel: number;
    effectiveLevel: number;
    usageType?: number;
    usageTypeName?: string;
}

export interface CategoryMatrix {
    category: string;
    actions: ActionPermission[];
}

export interface RoleMatrixResponse {
    roleId: string;
    matrix: CategoryMatrix[];
}

export interface PermissionLevel {
    code: string;
    value: number;
    label: string;
    description: string;
}

interface PermissionData {
    defaultLevel: number;
    effectiveLevel: number;
    usageTypeName?: string;
}

 
// Maps platform tab values to backend usageType numbers
const PLATFORM_USAGE_TYPE: Record<PlatformType, number> = {
    mobile: 1,
    webapp: 2,
    general: 3,
};

// Actions with this usageType are internal/system-level and must never be shown in the UI
const HIDDEN_USAGE_TYPE = 4;

const RESTRICTED_ACTIONS = ['ACCESS', 'FILTER_BY_STATE', 'FILTER_BY_BRANCH', 'FILTER_BY_USER', 'SELECTALL', 'SELECTOWN'];



interface RoleAccessSetupProps {
    data?: RoleMatrixResponse;
    onChange?: (category: string, action: string, effectiveLevel: number) => void;
    readOnly?: boolean;
    showPlatformTabs?: boolean;
    permissionLevels?: PermissionLevel[];
}

export function RoleAccessSetup({ 
    data, 
    onChange, 
    readOnly = false, 
    showPlatformTabs = false,
    permissionLevels: externalPermissionLevels = []
}: RoleAccessSetupProps) {
    const [platform,setPlatform] =useState<PlatformType>("mobile")
    const [internalPermissionLevels, setInternalPermissionLevels] = useState<PermissionLevel[]>([]);
    const [loadingLevels, setLoadingLevels] = useState(false);

    // If external permission levels are provided, use them. Otherwise, fall back to internal fetching (for backward compatibility)
    const permissionLevels = externalPermissionLevels.length > 0 ? externalPermissionLevels : internalPermissionLevels;

    // Fetch permission levels on mount ONLY if not provided via props
    useEffect(() => {
        if (externalPermissionLevels.length > 0) {
            setLoadingLevels(false);
            return;
        }

        const loadPermissionLevels = async () => {
            try {
                setLoadingLevels(true);
                const levels = await getPermissionLevels();
                setInternalPermissionLevels(levels);
            } catch (error) {
                console.error('Failed to load permission levels:', error);
            } finally {
                setLoadingLevels(false);
            }
        };
        loadPermissionLevels();
    }, [externalPermissionLevels]);

    // Build dynamic mappings from fetched permission levels
    const { levelToLabel, labelToLevel } = useMemo(() => {
        const levelMap: Record<number, string> = {};
        const labelMap: Record<string, number> = {};
        const options: string[] = [];

        permissionLevels.forEach(level => {
            levelMap[level.value] = level.label;
            labelMap[level.label] = level.value;
            options.push(level.label);
        });

        // Sort options by value (descending) to maintain logical order
        options.sort((a, b) => {
            const valA = labelMap[a] ?? 0;
            const valB = labelMap[b] ?? 0;
            return valB - valA;
        });

        return {
            levelToLabel: levelMap,
            labelToLevel: labelMap,
            dropdownOptions: options,
        };
    }, [permissionLevels]);

    const getLabelFromLevel = (level: number): string => {
        return levelToLabel[level] ?? 'None';
    };

    const getLevelFromLabel = (label: string): number => {
        return labelToLevel[label] ?? 0;
    };

    const getFilteredOptions = (actionName: string): string[] => {
        const sortedAllOptions = [...permissionLevels]
            .sort((a, b) => b.value - a.value)
            .map(l => l.label);

        if (platform === 'webapp') {
            return permissionLevels
                .filter(l => l.code === 'ENABLED' || l.code === 'DISABLED')
                .sort((a, b) => b.value - a.value)
                .map(l => l.label);
        }

        if (platform === 'mobile' || platform === 'general') {
            if (RESTRICTED_ACTIONS.includes(actionName.toUpperCase())) {
                return permissionLevels
                    .filter(l => l.code === 'ENABLED' || l.code === 'DISABLED')
                    .sort((a, b) => b.value - a.value)
                    .map(l => l.label);
            } else {
                return permissionLevels
                    .filter(l => ['OWNER', 'GROUP', 'ALL', 'NONE'].includes(l.code))
                    .sort((a, b) => b.value - a.value)
                    .map(l => l.label);
            }
        }

        return sortedAllOptions;
    };

    // Build dynamic structure from matrix API response
    const { categories, actions, permissionMap, categoryDescriptions } = useMemo(() => {
        if (!data?.matrix || data.matrix.length === 0) {
            return { categories: [], actions: [], permissionMap: {}, categoryDescriptions: {} };
        }

       // Filter matrix by usageType when platform tabs are enabled
        const filteredMatrix = showPlatformTabs
            ? data.matrix.filter(categoryMatrix =>
                categoryMatrix.actions.some(a => a.usageType === PLATFORM_USAGE_TYPE[platform])
              )
            : data.matrix;

        // Extract categories from filtered matrix
        const uniqueCategories = filteredMatrix.map(m => m.category).sort();
        const targetUsageType = showPlatformTabs ? PLATFORM_USAGE_TYPE[platform] : null;

        // Extract unique actions across all categories in the system (not just the visible ones)
        const allActions = new Set<string>();
        data.matrix.forEach(categoryMatrix => {
            categoryMatrix.actions
                .filter(actionPerm => actionPerm.usageType !== HIDDEN_USAGE_TYPE)
                .forEach(actionPerm => {
                    allActions.add(actionPerm.action);
                });
        });
        const uniqueActions = Array.from(allActions).sort();

        // Build lookup map: permissionMap[category][action] = { defaultLevel, effectiveLevel }
        // Only include actions that match the current platform's usageType
        const map: Record<string, Record<string, PermissionData>> = {};
        filteredMatrix.forEach(categoryMatrix => {
            if (!map[categoryMatrix.category]) {
                map[categoryMatrix.category] = {};
            }
            categoryMatrix.actions
                .filter(actionPerm => {
                    if (actionPerm.usageType === HIDDEN_USAGE_TYPE) return false;
                    if (targetUsageType !== null) return actionPerm.usageType === targetUsageType;
                    return true;
                })
                .forEach(actionPerm => {
                    map[categoryMatrix.category][actionPerm.action] = {
                        defaultLevel: actionPerm.defaultLevel,
                        effectiveLevel: actionPerm.effectiveLevel,
                        usageTypeName: actionPerm.usageTypeName,
                    };
                });
        });

        // Build category descriptions from usageTypeName, filtered by platform
        const catDescs: Record<string, ActionDescription[]> = {};
        filteredMatrix.forEach(categoryMatrix => {
            catDescs[categoryMatrix.category] = categoryMatrix.actions
                .filter(a => {
                    if (!a.usageTypeName || a.usageType === HIDDEN_USAGE_TYPE) return false;
                    if (targetUsageType !== null) return a.usageType === targetUsageType;
                    return true;
                })
                .map(a => ({ action: a.action, description: a.usageTypeName! }));
        });


        return {
            categories: uniqueCategories,
            actions: uniqueActions,
            permissionMap: map,
            categoryDescriptions: catDescs,
        };
    }, [data, platform,showPlatformTabs]);

    const getCellData = (category: string, action: string): PermissionData | null => {
        return permissionMap[category]?.[action] ?? null;
    };

    const hasPermission = (category: string, action: string): boolean => {
        return getCellData(category, action) !== null;
    };

    const handleCellChange = (category: string, action: string, label: string) => {
        const level = getLevelFromLabel(label);
        onChange?.(category, action, level);
    };

    const handleColumnHeaderChange = (action: string, label: string) => {
        const level = getLevelFromLabel(label);
        categories.forEach(category => {
            if (hasPermission(category, action)) {
                onChange?.(category, action, level);
            }
        });
    };

    const getColumnHeaderValue = (action: string): string | null => {
        const effectiveLevels = categories
            .filter(cat => hasPermission(cat, action))
            .map(cat => getCellData(cat, action)!.effectiveLevel);
        
        if (effectiveLevels.length === 0) return null;

        // Check if all visible cells have the same effectiveLevel
        const firstLevel = effectiveLevels[0];
        const allSame = effectiveLevels.every(level => level === firstLevel);
        
        return allSame ? getLabelFromLevel(firstLevel) : null;
    };


    if (loadingLevels) {
        return (
            <div className="space-y-4 mt-10 bg-white border border-gray-300 shadow-xl rounded-lg p-4">
                <div>
                    <h3 className="text-lg font-bold text-gray-900">Role Access Setup</h3>
                    <p className="text-sm text-gray-600 mt-1">Loading permission levels...</p>
                </div>
            </div>
        );
    }

    if (!data) {
    return (
        <div className="p-4">No permissions data available</div>
    );
}

    return (
        <div className="space-y-4 mt-10 bg-white border border-gray-300 shadow-xl rounded-lg p-4">
            <div>
                <h3 className="text-lg font-bold text-gray-900">Role Access Setup</h3>
                <p className="text-sm text-gray-600 mt-1">
                    {readOnly ? 'View role permissions' : 'Click on a cell to change its value.'}
                </p>
            </div>

            {showPlatformTabs && (
                <AccessPlatformTabs value={platform} onChange={setPlatform} />
            )}

            <div className="border border-gray-200 rounded-lg bg-white">
                <div
                    className="overflow-auto max-h-[600px] scrollbar-thin"
                >
                    <div style={{ width: `${Math.max(1500, actions.length * 120 + 150)}px`, minWidth: `${Math.max(1500, actions.length * 120 + 150)}px` }}>
                        <Table style={{ width: '100%', tableLayout: 'auto' }}>
                            <TableHeader className="sticky top-0 z-30">
                                <TableRow className="bg-gray-50 hover:bg-gray-30">
                                    <TableHead className="font-semibold text-gray-900 min-w-[150px] sticky left-0 bg-gray-50 z-30 border-r border-gray-200">
                                        Category
                                    </TableHead>
                                    {actions.map((action) => {
                                        const headerValue = getColumnHeaderValue(action);
                                        return (
                                            <TableHead
                                                key={action}
                                                className="font-semibold text-gray-900 text-center min-w-[120px] whitespace-nowrap z-20"
                                            >
                                                {readOnly ? (
                                                    <div className="flex items-center justify-center gap-1 w-full px-2 py-1">
                                                        <span>{action}</span>
                                                        <Tooltip>
                                                            <TooltipTrigger asChild>
                                                                <Info className="h-3 w-3 text-gray-500 cursor-help" />
                                                            </TooltipTrigger>
                                                            <TooltipContent>
                                                                <p>{action} permission</p>
                                                            </TooltipContent>
                                                        </Tooltip>
                                                    </div>
                                                ) : (
                                                    <DropdownMenu>
                                                        <DropdownMenuTrigger asChild>
                                                            <button className="flex items-center justify-center gap-1 w-full hover:bg-gray-100 rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer">
                                                                <span>{action}</span>
                                                                <ChevronDown className="h-3 w-3 text-gray-500" />
                                                                <Tooltip>
                                                                    <TooltipTrigger asChild>
                                                                        <Info className="h-3 w-3 text-gray-500 cursor-help" />
                                                                    </TooltipTrigger>
                                                                    <TooltipContent>
                                                                        <p>{action} permission</p>
                                                                    </TooltipContent>
                                                                </Tooltip>
                                                            </button>
                                                        </DropdownMenuTrigger>
                                                        <DropdownMenuContent align="center" className="w-36 z-20">
                                                            {getFilteredOptions(action).map((opt) => {
                                                                const isSelected = headerValue === opt;
                                                                return (
                                                                    <DropdownMenuItem
                                                                        key={opt}
                                                                        className={`cursor-pointer ${isSelected
                                                                                ? 'bg-rose-500 text-white hover:bg-rose-600 focus:bg-rose-600'
                                                                                : 'text-gray-900 hover:bg-gray-100 focus:bg-gray-100'
                                                                            }`}
                                                                        onSelect={() => {
                                                                            handleColumnHeaderChange(action, opt);
                                                                        }}
                                                                    >
                                                                        <div className="flex items-center gap-2 w-full">
                                                                            {isSelected && (
                                                                                <Check className="h-4 w-4 text-white flex-shrink-0" />
                                                                            )}
                                                                            {!isSelected && <span className="w-4"></span>}
                                                                            <span className={isSelected ? 'text-white' : 'text-gray-900'}>
                                                                                {opt}
                                                                            </span>
                                                                        </div>
                                                                    </DropdownMenuItem>
                                                                );
                                                            })}
                                                        </DropdownMenuContent>
                                                    </DropdownMenu>
                                                )}
                                            </TableHead>
                                        );
                                    })}
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {categories.map((category, index) => (
                                    <TableRow
                                        key={category}
                                        className={index % 2 === 0 ? 'bg-white hover:bg-gray-50' : 'bg-gray-50/50 hover:bg-gray-100/50'}
                                    >
                                        <TableCell className="font-medium text-gray-900 sticky left-0 bg-inherit z-20 border-r border-gray-200 py-3" style={{ backgroundColor: index % 2 === 0 ? 'white' : 'rgba(249, 250, 251)' }}>
                                            <div className="flex items-center justify-between gap-4 w-full pr-2">
                                                <span className="truncate">{category}</span>
                                                <RoleAccessDescription category={category} actionDescriptions={categoryDescriptions[category]} />
                                            </div>
                                        </TableCell>
                                        {actions.map((action) => {
                                            const hasPerm = hasPermission(category, action);
                                            const cellData = getCellData(category, action);
                                            const effectiveLevel = cellData?.effectiveLevel ?? null;
                                            // const defaultLevel = cellData?.defaultLevel ?? null;
                                            const displayValue = hasPerm && effectiveLevel !== null ? getLabelFromLevel(effectiveLevel) : '';
                                            const isDisabled = effectiveLevel === -89;
                                            // const defaultLabel = defaultLevel !== null ? getLabelFromLevel(defaultLevel) : '';

                                            return (
                                                <TableCell
                                                    key={`${category}-${action}`}
                                                    className={`text-center text-gray-700 py-2 z-10 ${isDisabled ? 'text-red-600 opacity-70' : ''}`}
                                                >
                                                    {hasPerm ? (
                                                        <Tooltip>
                                                            <TooltipTrigger asChild>
                                                                <div className="w-full">
                                                                    {readOnly ? (
                                                                        <div className={`w-full text-center px-2 py-1 ${isDisabled ? 'text-red-600 opacity-70' : ''}`}>
                                                                            {displayValue}
                                                                        </div>
                                                                    ) : (
                                                                        <DropdownMenu>
                                                                            <DropdownMenuTrigger asChild>
                                                                                <button
                                                                                    className={`w-full text-center px-2 py-1 rounded hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer ${isDisabled ? 'text-red-600 opacity-70' : ''}`}
                                                                                    type="button"
                                                                                >
                                                                                    {displayValue}
                                                                                </button>
                                                                            </DropdownMenuTrigger>
                                                                            <DropdownMenuContent align="center" className="w-36 z-20">
                                                                                {getFilteredOptions(action).map((opt) => {
                                                                                    const currentLabel = effectiveLevel !== null ? getLabelFromLevel(effectiveLevel) : null;
                                                                                    const isSelected = currentLabel === opt;
                                                                                    return (
                                                                                        <DropdownMenuItem
                                                                                            key={`${category}-${action}-${opt}`}
                                                                                            className={`cursor-pointer ${isSelected
                                                                                                ? 'bg-rose-500 text-white hover:bg-rose-600 focus:bg-rose-600'
                                                                                                : 'text-gray-900 hover:bg-gray-100 focus:bg-gray-100'
                                                                                                }`}
                                                                                            onSelect={() => {
                                                                                                handleCellChange(category, action, opt);
                                                                                            }}
                                                                                        >
                                                                                            <div className="flex items-center gap-2 w-full">
                                                                                                {isSelected && (
                                                                                                    <Check className="h-4 w-4 text-white flex-shrink-0" />
                                                                                                )}
                                                                                                {!isSelected && <span className="w-4"></span>}
                                                                                                <span className={isSelected ? 'text-white' : 'text-gray-900'}>
                                                                                                    {opt}
                                                                                                </span>
                                                                                            </div>
                                                                                        </DropdownMenuItem>
                                                                                    );
                                                                                })}
                                                                            </DropdownMenuContent>
                                                                        </DropdownMenu>
                                                                    )}
                                                                </div>
                                                            </TooltipTrigger>
                                                            {/* <TooltipContent>
                                                                <p>Default: {defaultLabel}</p>
                                                            </TooltipContent> */}
                                                        </Tooltip>
                                                    ) : null}
                                                </TableCell>
                                            );
                                        })}
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                </div>
            </div>
        </div>
    );
}

