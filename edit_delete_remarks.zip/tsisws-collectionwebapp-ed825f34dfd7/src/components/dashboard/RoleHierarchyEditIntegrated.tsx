import React, { useState, useMemo, useEffect } from "react";
import { type RoleNode } from "@/hooks/use-role-hierarchy";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { SearchableSelect, type Option } from '@/components/ui/searchable-select';
import type { Role } from '@/lib/types';

// ─── Depth colour palette ────────────────────────────────────────────────────
const ROOT_PALETTES = [
  ["#0052CC", "#2684FF", "#4C9AFF", "#B3D4FF", "#DEEBFF"],
  ["#0052CC", "#2684FF", "#4C9AFF", "#B3D4FF", "#DEEBFF"],
];

function getDotColor(rootIndex: number, depth: number): string {
  const palette = ROOT_PALETTES[rootIndex % ROOT_PALETTES.length];
  return palette[Math.min(depth, palette.length - 1)];
}

// ─── Tree Node Component ─────────────────────────────────────────────────────
interface TreeNodeProps {
  node: RoleNode & { badgeText?: string };
  depth: number;
  rootIndex: number;
  currentRoleId?: string;
}

const TreeNode: React.FC<TreeNodeProps> = ({ node, depth, rootIndex, currentRoleId }) => {
  const isCurrent = node.id === currentRoleId && !node.badgeText;
  const isnew = node.badgeText === "new";
  const hasChildren = node.children && node.children.length > 0;
  const dotColor = getDotColor(rootIndex, depth);

  return (
    <div className="relative">
      <div
        className={[
          "flex items-center gap-3 px-3 py-[8px] my-[2px] rounded-lg group",
          "border transition-all duration-200",
          isCurrent 
            ? "bg-blue-50/50 border-blue-200/50 shadow-none" 
            : isnew
              ? "bg-amber-50/40 shadow-[0_0_15px_-3px_rgba(245,158,11,0.1)]"
              : "border-transparent hover:bg-slate-50 hover:border-slate-200",
          "relative",
        ].join(" ")}
      >
        {depth > 0 && (
          <span
            className="absolute left-[-24px] top-1/2 w-5 h-[1.5px] bg-slate-200 opacity-60"
            aria-hidden="true"
          />
        )}
        <div 
          className={`flex items-center justify-center rounded-full flex-shrink-0 ${depth === 0 ? "w-3 h-3" : "w-2.5 h-2.5"}`}
          style={{ 
            backgroundColor: isnew ? "#f59e0b30" : `${dotColor}20`, 
            border: `1.5px solid ${isnew ? "#f59e0b" : dotColor}` 
          }}
        />
        <span
          className={[
            "flex-1 transition-colors",
            isCurrent ? "text-blue-600 font-semibold" : isnew ? "text-amber-700 font-bold italic" : "text-slate-700",
            depth === 0 ? "text-sm font-medium" : "text-[13px]",
          ].join(" ")}
        >
          {node.name}
          {isCurrent && (
             <span className="ml-2 text-[10px] uppercase font-extrabold tracking-tight bg-blue-600 text-white px-2 py-0.5 rounded-md shadow-sm">
              CURRENT
            </span>
          )}
          {node.badgeText && !isCurrent && (
             <span className={[
              "ml-2 text-[10px] uppercase font-extrabold tracking-tight px-2 py-0.5 rounded-md shadow-sm",
              isnew ? "bg-amber-500 text-white" : "bg-slate-400 text-white"
             ].join(" ")}>
              {node.badgeText}
            </span>
          )}
        </span>
      </div>
      {hasChildren && (
        <div className="ml-6 border-l-[1.5px] border-slate-200 pl-0 mt-[-2px] mb-1">
          {node.children?.map((child: any) => (
            <TreeNode
              key={child.id + (child.badgeText || '')}
              node={child}
              depth={depth + 1}
              rootIndex={rootIndex}
              currentRoleId={currentRoleId}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// ─── Main Integrated Component ───────────────────────────────────────────────
export interface RoleHierarchyEditIntegratedProps {
  roles: Role[];
  roots: RoleNode[];
  currentRoleName?: string;
  currentRoleId?: string;
  loading?: boolean;
  onHierarchyChange: (data: { parentRoleId: string | null; childRoleId: string | null; isValid: boolean }) => void;
}

function findRootIndex(roots: RoleNode[], targetId: string): number | null {
  const findNode = (nodes: RoleNode[], id: string): boolean => {
    for (const node of nodes) {
      if (node.id === id) return true;
      if (node.children && findNode(node.children, id)) return true;
    }
    return false;
  };

  for (let i = 0; i < roots.length; i++) {
    if (findNode([roots[i]], targetId)) return i;
  }
  return null;
}

function findParentId(nodes: RoleNode[], targetId: string): string | null {
  for (const node of nodes) {
    if (node.children?.some(child => child.id === targetId)) {
      return node.id;
    }
    const found = findParentId(node.children || [], targetId);
    if (found) return found;
  }
  return null;
}

function findChildId(nodes: RoleNode[], targetId: string): string | null {
  const findNode = (nodes: RoleNode[], id: string): RoleNode | null => {
    for (const node of nodes) {
      if (node.id === id) return node;
      const found = findNode(node.children || [], id);
      if (found) return found;
    }
    return null;
  };

  const targetNode = findNode(nodes, targetId);
  return (targetNode && targetNode.children && targetNode.children.length > 0) ? targetNode.children[0].id : null;
}

export const RoleHierarchyEditIntegrated: React.FC<RoleHierarchyEditIntegratedProps> = ({
  roles,
  roots,
  currentRoleName,
  currentRoleId,
  loading,
  onHierarchyChange,
}) => {
  const [activeTab, setActiveTab] = useState(0);
  const [parentRoleId, setParentRoleId] = useState<string | null>(null);
  const [childRoleId, setChildRoleId] = useState<string | null>(null);
  const [initialParentId, setInitialParentId] = useState<string | null>(null);
  const [initialChildId, setInitialChildId] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);
  const [isParentAutoSelected, setIsParentAutoSelected] = useState(false);
  const [isChildAutoSelected, setIsChildAutoSelected] = useState(false);

  useEffect(() => {
    if (!loading && roots.length > 0 && !initialized && currentRoleId) {
      const parent = findParentId(roots, currentRoleId);
      const child = findChildId(roots, currentRoleId);
      setParentRoleId(parent);
      setChildRoleId(child);
      setInitialParentId(parent);
      setInitialChildId(child);
      setInitialized(true);
    }
  }, [loading, roots, currentRoleId, initialized]);

  const hasUserChanged = useMemo(() => {
    return (
      parentRoleId !== initialParentId ||
      childRoleId !== initialChildId
    );
  }, [parentRoleId, childRoleId, initialParentId, initialChildId]);

  // ─── Relationship Mapping ──────────────────────────────────────────────────
  const { parentMap, childrenMap } = useMemo(() => {
    const pMap = new Map<string, string | null>();
    const cMap = new Map<string, string[]>();
    
    const traverse = (node: RoleNode, pId: string | null) => {
      pMap.set(node.id, pId);
      const cIds = node.children?.map(c => c.id) || [];
      cMap.set(node.id, cIds);
      node.children?.forEach(c => traverse(c, node.id));
    };
    
    roots.forEach(r => traverse(r, null));
    return { parentMap: pMap, childrenMap: cMap };
  }, [roots]);

  const allowedHierarchyRoleIds = useMemo(() => {
    if (!currentRoleId || !roots || roots.length === 0) return new Set<string>();
    
    const rootIdx = findRootIndex(roots, currentRoleId);
    if (rootIdx === null) return new Set<string>();
    
    const ids = new Set<string>();
    const extractIds = (node: RoleNode) => {
      ids.add(node.id);
      node.children?.forEach(extractIds);
    };
    
    extractIds(roots[rootIdx]);
    return ids;
  }, [currentRoleId, roots]);

  useEffect(() => {
    onHierarchyChange({ parentRoleId, childRoleId, isValid: true });
  }, [parentRoleId, childRoleId, onHierarchyChange]);

  const handleParentChange = (id: string) => {
    const finalId = id === "none" ? null : id;
    
    // Auto-select child role if the parent has only one child or no child is selected
    const currentChildren = finalId ? (childrenMap.get(finalId) || []) : [];
    if (finalId && currentChildren.length > 0) {
      if (currentChildren.length === 1 || !childRoleId || !currentChildren.includes(childRoleId)) {
        setChildRoleId(currentChildren[0]);
        setIsChildAutoSelected(true); // Lock child if auto-selected
      } else {
        setIsChildAutoSelected(false);
      }
    } else if (childRoleId && !currentChildren.includes(childRoleId)) {
      setChildRoleId(null);
      setIsChildAutoSelected(false);
    } else if (!finalId) {
      setChildRoleId(null);
      setIsChildAutoSelected(false);
    }
    
    setParentRoleId(finalId);
    setIsParentAutoSelected(false); // Manual change unlocks parent

    // Auto-switch tab to the hierarchy containing the new parent
    if (finalId) {
      const rootIdx = findRootIndex(roots, finalId);
      if (rootIdx !== null) {
        setActiveTab(rootIdx);
      }
    }
  };

  const handleChildChange = (id: string) => {
    const finalId = id === "none" ? null : id;

    // Auto-select parent if child is selected
    if (finalId) {
      const pId = parentMap.get(finalId);
      if (pId) {
        setParentRoleId(pId);
        setIsParentAutoSelected(true); // Lock parent if auto-selected
        
        // Auto-switch tab to the hierarchy containing the new parent
        const rootIdx = findRootIndex(roots, pId);
        if (rootIdx !== null) {
          setActiveTab(rootIdx);
        }
      } else {
        setParentRoleId(null);
        setIsParentAutoSelected(false);
      }
    } else {
      setParentRoleId(null);
      setIsParentAutoSelected(false);
    }

    setChildRoleId(finalId);
    setIsChildAutoSelected(false); // Manual change unlocks child
  };

  const parentOptions: Option[] = useMemo(() => {
    // 1. Initial filter based on hierarchy membership
    let filtered = roles.filter(r => {
      // Basic exclusions
      if (r.id === currentRoleId) return false;
      // Hierarchy restriction
      if (allowedHierarchyRoleIds.size > 0 && !allowedHierarchyRoleIds.has(r.id)) return false;
      
      // Filter out initial parent if anything changed
      if (hasUserChanged && r.id === initialParentId) return false;

      return true;
    });
    
    if (childRoleId) {
      const pId = parentMap.get(childRoleId);
      if (pId) {
        filtered = filtered.filter(r => r.id === pId);
      } else {
        // Child is a root node, only None is valid for parent
        filtered = [];
      }
    }
    
    const finalOptions = [
      { value: "none", label: "None" },
      ...filtered.map(r => ({ value: r.id, label: r.name }))
    ];

    // Surgical Fix: Always include the current parentRoleId if it exists
    if (parentRoleId && parentRoleId !== "none" && !finalOptions.find(o => o.value === parentRoleId)) {
      const pRole = roles.find(r => r.id === parentRoleId);
      if (pRole) {
        finalOptions.push({ value: pRole.id, label: pRole.name });
      }
    }

    return finalOptions;
  }, [roles, childRoleId, parentMap, currentRoleId, parentRoleId, allowedHierarchyRoleIds, hasUserChanged, initialParentId]);

  const childOptions: Option[] = useMemo(() => {
    // 1. Initial filter based on hierarchy membership
    let filtered = roles.filter(r => {
      // Basic exclusions
      if (r.id === currentRoleId) return false;
      // Hierarchy restriction
      if (allowedHierarchyRoleIds.size > 0 && !allowedHierarchyRoleIds.has(r.id)) return false;

      // Filter out initial child if anything changed
      if (hasUserChanged && r.id === initialChildId) return false;

      return true;
    });
    
    // 2. Existing relationship-based filtering
    if (parentRoleId) {
      const cIds = childrenMap.get(parentRoleId) || [];
      filtered = filtered.filter(r => cIds.includes(r.id));
    }
    
    const finalOptions = [
      { value: "none", label: "None" },
      ...filtered.map(r => ({ value: r.id, label: r.name }))
    ];

    // Surgical Fix: Always include the current childRoleId if it exists
    if (childRoleId && childRoleId !== "none" && !finalOptions.find(o => o.value === childRoleId)) {
      const cRole = roles.find(r => r.id === childRoleId);
      if (cRole) {
        finalOptions.push({ value: cRole.id, label: cRole.name });
      }
    }

    return finalOptions;
  }, [roles, parentRoleId, childrenMap, currentRoleId, childRoleId, allowedHierarchyRoleIds, hasUserChanged, initialChildId]);

  const parentHelperText = useMemo(() => {
    if (childRoleId) {
      const pId = parentMap.get(childRoleId);
      return pId ? `` : "Root node — no parent available";
    }
  }, [childRoleId, parentMap, roles]);

  const childHelperText = useMemo(() => {
    if (parentRoleId) {
      const cIds = childrenMap.get(parentRoleId) || [];
      return cIds.length > 0 ? `` : "Leaf node — no children available";
    }
  }, [parentRoleId, childrenMap, roles]);

  // ─── new Tree Logic ───────────────────────────────────────────────────
  const newRoots = useMemo(() => {
    const isParentChanged = parentRoleId !== initialParentId;
    const isChildChanged = childRoleId !== initialChildId;
    const hasChange = isParentChanged || isChildChanged;

    // Helper: Deep clone nodes
    const deepClone = (nodes: RoleNode[]): RoleNode[] => {
      return nodes.map(n => ({
        ...n,
        children: n.children ? deepClone(n.children) : []
      }));
    };

    // Helper: Find and remove ALL nodes by ID, returning the removed nodes
    const findAllAndRemoveNodes = (nodes: RoleNode[], id: string): RoleNode[] => {
      let removed: RoleNode[] = [];
      for (let i = nodes.length - 1; i >= 0; i--) {
        if (nodes[i].id === id) {
          removed.push(nodes.splice(i, 1)[0]);
        } else if (nodes[i].children) {
          removed.push(...findAllAndRemoveNodes(nodes[i].children!, id));
        }
      }
      return removed;
    };

    // Helper: Find ALL nodes by ID across all trees
    const findAllNodes = (nodes: RoleNode[], id: string): RoleNode[] => {
      let found: RoleNode[] = [];
      for (const node of nodes) {
        if (node.id === id) found.push(node);
        if (node.children) {
          found.push(...findAllNodes(node.children!, id));
        }
      }
      return found;
    };

    // 1. Always start with the full tree for reference
    let processedRoots = deepClone(roots);

    // Suppress new if no change OR if both are set to "None"
    if (!hasChange || (parentRoleId === null && childRoleId === null)) {
      return processedRoots;
    }

    // 3. Define the new Node Template
    const createnewNode = () => ({
      id: "new-" + (currentRoleId || "new"),
      name: currentRoleName || "New Role",
      badgeText: "new",
      children: [] 
    } as any);

    // Track the original index if the child was a root
    const rootIdxOfChild = childRoleId ? processedRoots.findIndex(r => r.id === childRoleId) : -1;

    // 4. Handle CHILD MOVE (Sandwich logic)
    // Remove all instances of childRoleId from the new trees
    const removedChildren = childRoleId ? findAllAndRemoveNodes(processedRoots, childRoleId) : [];
    const childTemplate = removedChildren.length > 0 ? removedChildren[0] : null;

    // 5. Handle PARENT INSERTION (Multi-tree)
    if (parentRoleId) {
      const targets = findAllNodes(processedRoots, parentRoleId);
      if (targets.length > 0) {
        targets.forEach(target => {
          const newNode = createnewNode();
          if (childTemplate) {
            newNode.children = [deepClone([childTemplate])[0]];
          }
          target.children = [...(target.children || []), newNode];
        });
      } else {
        // Fallback: If no parent found, add as root
        const pNode = createnewNode();
        if (childTemplate) pNode.children = [deepClone([childTemplate])[0]];
        processedRoots.push(pNode);
      }
    } else {
      // If parent is null, it's a root
      const pNode = createnewNode();
      if (childTemplate) pNode.children = [deepClone([childTemplate])[0]];
      
      if (rootIdxOfChild !== -1) {
        // Correct Principle: If the child was a root, the "new" node replaces it at the SAME index
        // This prevents the remaining roots from shifting and swapping labels.
        processedRoots.splice(rootIdxOfChild, 0, pNode);
      } else {
        processedRoots.push(pNode);
      }
    }


    return processedRoots;
  }, [roots, parentRoleId, childRoleId, currentRoleId, currentRoleName, initialParentId, initialChildId]);

  // Ensure activeTab is always within bounds of newRoots
  useEffect(() => {
    if (activeTab >= newRoots.length && newRoots.length > 0) {
      setActiveTab(Math.max(0, newRoots.length - 1));
    }
  }, [newRoots.length, activeTab]);

  return (
    <Card className="border-slate-200 shadow-sm bg-white overflow-hidden">
      <CardHeader className="border-b bg-white py-4 px-6">
        <CardTitle className="text-lg font-bold text-slate-800 flex items-center justify-between">
          Role Hierarchy Details    
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-0 divide-y divide-slate-100">
        {/* 1. Tree Structure Section (Top) */}
        <div className="p-6">
          <div className="mb-6">
            <h3 className="text-sm font-bold text-slate-800 tracking-tight">
              Hierarchy Tree
            </h3>
            <p className="text-[11px] text-slate-500 mt-1">
              Full organisational structure of roles across branches.
            </p>
          </div>
          
          {loading ? (
            <div className="py-12 text-center text-sm text-slate-400 italic">
              Loading hierarchy...
            </div>
          ) : (
            newRoots.length > 0 && (
              <div className="space-y-6">
                {/* Tabs */}
                {newRoots.length > 1 && (
                  <div className="inline-flex p-1 bg-slate-50 rounded-xl border border-slate-100">
                    {newRoots.map((root, idx) => {
                      const titles = ["Credit hierarchy", "Collection hierarchy"];
                      const label = titles[idx] || root.name;
                          
                      return (
                        <button
                          key={root.id}
                          onClick={() => setActiveTab(idx)}
                          className={[
                            "px-6 py-2 rounded-lg text-[12px] font-semibold transition-all duration-200",
                            activeTab === idx
                              ? "bg-white text-[#0052CC] shadow-sm"
                              : "text-slate-400 hover:text-slate-600 hover:bg-slate-100/50",
                          ].join(" ")}
                        >
                          {label}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Active tree */}
                <div className="max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                  {newRoots[activeTab] ? (
                    <TreeNode
                      key={newRoots[activeTab].id}
                      node={newRoots[activeTab]}
                      depth={0}
                      rootIndex={activeTab}
                      currentRoleId={currentRoleId}
                    />
                  ) : (
                    <TreeNode
                      key={newRoots[0]?.id}
                      node={newRoots[0]}
                      depth={0}
                      rootIndex={0}
                      currentRoleId={currentRoleId}
                    />
                  )}
                </div>
              </div>
            )
          )}
        </div>

        {/* 2. Setup / Summary Section (Bottom) */}
        <div className="p-6 bg-slate-50/10">
          <div className="mb-6">
            <h3 className="text-sm font-bold text-slate-800 tracking-tight">
              Structural Summary & Setup
            </h3>
            <p className="text-[11px] text-slate-500 mt-1">
              Identify the immediate relationship context for the role: <span className="text-slate-900 font-semibold">{currentRoleName}</span>
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Parent Box */}
            <div className="space-y-2">
              <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Parent Role</Label>
              <div className="space-y-3">
                <SearchableSelect
                  options={parentOptions}
                  value={parentRoleId === null ? "none" : (parentRoleId || "")}
                  onValueChange={handleParentChange}
                  placeholder="Select parent..."
                  searchPlaceholder="Search roles..."
                  disabled={isParentAutoSelected || (parentOptions.length <= 1 && !!childRoleId)}
                />
                <p className="text-[10px] text-slate-400 italic px-1">{parentHelperText}</p>
              </div>
            </div>
            
            {/* Child Box */}
            <div className="space-y-2">
              <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Child Role</Label>
              <div className="space-y-3">
                <SearchableSelect
                  options={childOptions}
                  value={childRoleId === null ? "none" : (childRoleId || "")}
                  onValueChange={handleChildChange}
                  placeholder="Select child..."
                  searchPlaceholder="Search roles..."
                  disabled={isChildAutoSelected || (childOptions.length <= 1 && !!parentRoleId)}
                />
                <p className="text-[10px] text-slate-400 italic px-1">{childHelperText}</p>
              </div>
            </div>
          </div>

        </div>
      </CardContent>
    </Card>
  );
};
