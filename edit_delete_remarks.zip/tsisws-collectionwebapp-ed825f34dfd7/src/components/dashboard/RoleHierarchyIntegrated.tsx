import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { SearchableSelect, type Option } from '@/components/ui/searchable-select';
import { type RoleNode } from "@/hooks/use-role-hierarchy";
import type { Role } from '@/lib/types';
import { Loader2, } from 'lucide-react';
import React, { useCallback, useEffect, useMemo, useState } from "react";

// ─── Depth colour palette ────────────────────────────────────────────────────
const ROOT_PALETTES = [
  ["#0052CC", "#2684FF", "#4C9AFF", "#B3D4FF", "#DEEBFF"],
  ["#0052CC", "#2684FF", "#4C9AFF", "#B3D4FF", "#DEEBFF"],
];

function getDotColor(rootIndex: number, depth: number): string {
  const palette = ROOT_PALETTES[rootIndex % ROOT_PALETTES.length];
  return palette[Math.min(depth, palette.length - 1)];
}

// ─── Tree Node Component ─────────────────────────────────────────────────────
interface TreeNodeProps {
  node: RoleNode;
  depth: number;
  rootIndex: number;
  currentRoleId?: string;
}

const TreeNode: React.FC<TreeNodeProps> = ({ node, depth, rootIndex, currentRoleId }) => {
  const [expanded, setExpanded] = useState(true);
  const isCurrent = node.id === currentRoleId;
  const hasChildren = node.children && node.children.length > 0;
  const dotColor = getDotColor(rootIndex, depth);

  const toggle = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setExpanded((prev) => !prev);
  }, []);

  return (
    <div className="relative">
      <div
        className={[
          "flex items-center gap-3 px-3 py-[8px] my-[2px] rounded-lg group",
          "border transition-all duration-200",
          isCurrent
            ? "bg-blue-50/50 border-blue-200/40 shadow-none"
            : "border-transparent hover:bg-slate-50 hover:border-slate-200",
          "relative",
        ].join(" ")}
        onClick={hasChildren ? toggle : undefined}
      >
        {depth > 0 && (
          <span
            className="absolute left-[-24px] top-1/2 w-5 h-[1.5px] bg-slate-200 opacity-60"
            aria-hidden="true"
          />
        )}
        <div
          className={`flex items-center justify-center rounded-full flex-shrink-0 ${depth === 0 ? "w-3 h-3" : "w-2.5 h-2.5"}`}
          style={{ backgroundColor: `${dotColor}20`, border: `1.5px solid ${dotColor}` }}
        />
        <span
          className={[
            "flex-1 transition-colors",
            isCurrent ? "text-blue-600 font-semibold" : "text-slate-700",
            depth === 0 ? "text-sm font-medium" : "text-[13px]",
          ].join(" ")}
        >
          {node.name}
          {isCurrent && (
            <span className="ml-2 text-[10px] uppercase font-extrabold tracking-tight bg-blue-600 text-white px-2 py-0.5 rounded-md shadow-sm">
              CURRENT
            </span>
          )}
        </span>
        {hasChildren && (
          <button
            onClick={toggle}
            className={[
              "w-4 h-4 rounded-[4px] flex-shrink-0 ml-auto",
              "border border-slate-200",
              "bg-white",
              "flex items-center justify-center",
              "text-[10px] leading-none text-slate-500",
              "cursor-pointer transition-all duration-100",
              "hover:bg-slate-50 hover:border-slate-300",
            ].join(" ")}
            aria-label={expanded ? "Collapse" : "Expand"}
          >
            {expanded ? "−" : "+"}
          </button>
        )}
      </div>
      {hasChildren && expanded && (
        <div className="ml-6 border-l-[1.5px] border-slate-200 pl-0 mt-[-2px] mb-1">
          {node.children?.map((child: RoleNode) => (
            <TreeNode
              key={child.id}
              node={child}
              depth={depth + 1}
              rootIndex={rootIndex}
              currentRoleId={currentRoleId}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// ─── Main Integrated Component ───────────────────────────────────────────────
export interface RoleHierarchyIntegratedProps {
  roles: Role[];
  roots: RoleNode[];
  currentRoleName?: string;
  currentRoleId?: string;
  loading?: boolean;
  onHierarchyChange: (data: { parentRoleId: string | null; childRoleId: string | null; isValid: boolean }) => void;
  onSave?: () => void;
  onCancel?: () => void;
  isSaving?: boolean;
  showButtons?: boolean;
  disabled?: boolean;
}

function findRootIndex(roots: RoleNode[], targetId: string): number | null {
  const findNode = (nodes: RoleNode[], id: string): boolean => {
    for (const node of nodes) {
      if (node.id === id) return true;
      if (node.children && findNode(node.children, id)) return true;
    }
    return false;
  };

  for (let i = 0; i < roots.length; i++) {
    if (findNode([roots[i]], targetId)) return i;
  }
  return null;
}

function findParentId(nodes: RoleNode[], targetId: string): string | null {
  for (const node of nodes) {
    if (node.children?.some(child => child.id === targetId)) {
      return node.id;
    }
    const found = findParentId(node.children || [], targetId);
    if (found) return found;
  }
  return null;
}

function findChildId(nodes: RoleNode[], targetId: string): string | null {
  const findNode = (nodes: RoleNode[], id: string): RoleNode | null => {
    for (const node of nodes) {
      if (node.id === id) return node;
      const found = findNode(node.children || [], id);
      if (found) return found;
    }
    return null;
  };

  const targetNode = findNode(nodes, targetId);
  return (targetNode && targetNode.children && targetNode.children.length > 0) ? targetNode.children[0].id : null;
}

export const RoleHierarchyIntegrated: React.FC<RoleHierarchyIntegratedProps> = ({
  roles,
  roots,
  currentRoleName,
  currentRoleId,
  loading,
  onHierarchyChange,
  onSave,
  onCancel,
  isSaving = false,
  showButtons = true,
  disabled = false
}) => {
  const [activeTab, setActiveTab] = useState(0);
  const [parentRoleId, setParentRoleId] = useState<string | null>(null);
  const [childRoleId, setChildRoleId] = useState<string | null>(null);
  const [initialParentId, setInitialParentId] = useState<string | null>(null);
  const [initialChildId, setInitialChildId] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);
  const [isParentAutoSelected, setIsParentAutoSelected] = useState(false);
  const [isChildAutoSelected, setIsChildAutoSelected] = useState(false);

  useEffect(() => {
    if (!loading && roots.length > 0 && !initialized) {
      const parent = findParentId(roots, currentRoleId || '');
      const child = findChildId(roots, currentRoleId || '');
      setParentRoleId(parent);
      setChildRoleId(child);
      setInitialParentId(parent);
      setInitialChildId(child);
      setInitialized(true);
    }
  }, [loading, roots, currentRoleId, initialized]);



  // ─── Relationship Mapping ──────────────────────────────────────────────────
  const { parentMap, childrenMap } = useMemo(() => {
    const pMap = new Map<string, string | null>();
    const cMap = new Map<string, string[]>();

    const traverse = (node: RoleNode, pId: string | null) => {
      pMap.set(node.id, pId);
      const cIds = node.children?.map(c => c.id) || [];
      cMap.set(node.id, cIds);
      node.children?.forEach(c => traverse(c, node.id));
    };

    roots.forEach(r => traverse(r, null));
    return { parentMap: pMap, childrenMap: cMap };
  }, [roots]);

  useEffect(() => {
    onHierarchyChange({ parentRoleId, childRoleId, isValid: true });
  }, [parentRoleId, childRoleId, onHierarchyChange]);

  // ─── Hierarchy Insertion Validation ──────────────────────────────────────────
  

  const handleParentChange = (id: string) => {
    const finalId = id === "none" ? null : id;
    
    // Auto-select child role if the parent has only one child or no child is selected
    const currentChildren = finalId ? (childrenMap.get(finalId) || []) : [];
    if (finalId && currentChildren.length > 0) {
      if (currentChildren.length === 1 || !childRoleId || !currentChildren.includes(childRoleId)) {
        setChildRoleId(currentChildren[0]);
        setIsChildAutoSelected(true); // Lock child if auto-selected
      } else {
        setIsChildAutoSelected(false);
      }
    } else if (childRoleId && !currentChildren.includes(childRoleId)) {
      setChildRoleId(null);
      setIsChildAutoSelected(false);
    } else if (!finalId) {
      setChildRoleId(null);
      setIsChildAutoSelected(false);
    }
    
    setParentRoleId(finalId);
    setIsParentAutoSelected(false); // Manual change unlocks parent

    // Auto-switch tab to the hierarchy containing the new parent
    if (finalId) {
      const rootIdx = findRootIndex(roots, finalId);
      if (rootIdx !== null) {
        setActiveTab(rootIdx);
      }
    }
  };

  const handleChildChange = (id: string) => {
    const finalId = id === "none" ? null : id;
    
    // Auto-select parent if child is selected
    if (finalId) {
      const pId = parentMap.get(finalId);
      if (pId) {
        setParentRoleId(pId);
        setIsParentAutoSelected(true); // Lock parent if auto-selected
        
        // Auto-switch tab to the hierarchy containing the new parent
        const rootIdx = findRootIndex(roots, pId);
        if (rootIdx !== null) {
          setActiveTab(rootIdx);
        }
      } else {
        setParentRoleId(null);
        setIsParentAutoSelected(false);
      }
    } else {
      setParentRoleId(null);
      setIsParentAutoSelected(false);
    }

    setChildRoleId(finalId);
    setIsChildAutoSelected(false); // Manual change unlocks child
  };

  const parentOptions: Option[] = useMemo(() => {
    let filtered = roles.filter(r => r.id !== currentRoleId);

    if (childRoleId) {
      const pId = parentMap.get(childRoleId);
      if (pId) {
        filtered = filtered.filter(r => r.id === pId);
      } else {
        // Child is a root node, only None is valid for parent
        filtered = [];
      }
    }

    return [
      { value: "none", label: "None" },
      ...filtered.map(r => ({ value: r.id, label: r.name }))
    ];
  }, [roles, childRoleId, parentMap, currentRoleId]);

  const childOptions: Option[] = useMemo(() => {
    let filtered = roles.filter(r => r.id !== currentRoleId);

    if (parentRoleId) {
      const cIds = childrenMap.get(parentRoleId) || [];
      filtered = filtered.filter(r => cIds.includes(r.id));
    }

    return [
      { value: "none", label: "None" },
      ...filtered.map(r => ({ value: r.id, label: r.name }))
    ];
  }, [roles, parentRoleId, childrenMap, currentRoleId]);

  const parentHelperText = useMemo(() => {
    if (childRoleId) {
      const pId = parentMap.get(childRoleId);
      return pId ? `` : "no parent available";
    }
  }, [childRoleId, parentMap, roles]);

  const childHelperText = useMemo(() => {
    if (parentRoleId) {
      const cIds = childrenMap.get(parentRoleId) || [];
      return cIds.length > 0 ? `` : "no children available";
    }
  }, [parentRoleId, childrenMap, roles]);

  // ─── Preview Tree Logic ───────────────────────────────────────────────────
  const previewRoots = useMemo(() => {
    const isParentChanged = parentRoleId !== initialParentId;
    const isChildChanged = childRoleId !== initialChildId;
    const hasChange = isParentChanged || isChildChanged;

    const findNodeRecursive = (nodes: RoleNode[], id: string): RoleNode | null => {
      for (const node of nodes) {
        if (node.id === id) return node;
        const found = findNodeRecursive(node.children || [], id);
        if (found) return found;
      }
      return null;
    };

    // 1. If no change, try to just badge the existing role positions in ALL trees
    if (!hasChange && currentRoleId) {
      const existsInTree = findNodeRecursive(roots, currentRoleId);
      if (existsInTree) {
        const applyBadges = (nodes: RoleNode[]): RoleNode[] => {
          return nodes.map(n => ({
            ...n,
            badgeText: n.id === currentRoleId ? "New" : (n as any).badgeText,
            children: n.children ? applyBadges(n.children) : []
          })) as RoleNode[];
        };
        return applyBadges(roots);
      }
    }

    // Helper functions for rehoming
    const cloneAndFilter = (nodes: RoleNode[], excludeIds: (string | null | undefined)[]): RoleNode[] => {
      const validExcludeIds = excludeIds.filter(Boolean) as string[];
      return nodes
        .filter(n => !validExcludeIds.includes(n.id))
        .map(n => ({
          ...n,
          children: n.children ? cloneAndFilter(n.children, validExcludeIds) : []
        }));
    };

    const insertNodeEverywhere = (nodes: RoleNode[], parentId: string, nodeToInsert: RoleNode): boolean => {
      let inserted = false;
      for (const node of nodes) {
        if (node.id === parentId) {
          node.children = [...(node.children || []), { ...nodeToInsert }];
          inserted = true;
        }
        if (node.children && insertNodeEverywhere(node.children, parentId, nodeToInsert)) {
          inserted = true;
        }
      }
      return inserted;
    };

    // 2. Initial clone, removing current role and child role from their current spots
    const idsToRehome = [currentRoleId];
    if (childRoleId) idsToRehome.push(childRoleId);

    // Track the original index if the child was a root
    const rootIdxOfChild = childRoleId ? roots.findIndex(r => r.id === childRoleId) : -1;

    let newRoots = cloneAndFilter(roots, idsToRehome);

    // 3. Resolve the current role node
    let currentRoleNode: RoleNode | null = findNodeRecursive(roots, currentRoleId || '');

    if (!currentRoleNode) {
      // Handle "Add Role" Case
      currentRoleNode = {
        id: currentRoleId || "preview-new-role",
        name: currentRoleName || "New Role",
        children: []
      };
    } else {
      currentRoleNode = { ...currentRoleNode, children: [] };
    }

    // Distinguish the preview instance
    const previewCurrentNode = {
      ...currentRoleNode,
      name: currentRoleName,
      badgeText: hasChange ? "New Position" : "New"
    } as RoleNode & { badgeText: string };

    // 4. Resolve the child role node
    let childRoleNode: RoleNode | null = null;
    if (childRoleId) {
      const originalChildNode = findNodeRecursive(roots, childRoleId);
      if (originalChildNode) {
        childRoleNode = { ...originalChildNode } as RoleNode;
        previewCurrentNode.children = [childRoleNode];
      }
    }

    // 5. Insert current role into its new parent(s)
    if (parentRoleId) {
      const success = insertNodeEverywhere(newRoots, parentRoleId, previewCurrentNode);
      if (!success) {
        newRoots.push(previewCurrentNode);
      }
    } else {
      // Only show as a root if it was already one of the two main roots, or if it now has children
      const wasRoot = roots.some(r => r.id === currentRoleId);
      const hasChildrenNow = previewCurrentNode.children && previewCurrentNode.children.length > 0;
      if (wasRoot || hasChildrenNow) {
        if (rootIdxOfChild !== -1) {
          // Correct Principle: If the child was a root, the "new" node replaces it at the SAME index
          // This prevents the remaining roots from shifting and swapping labels.
          newRoots.splice(rootIdxOfChild, 0, previewCurrentNode);
        } else {
          newRoots.push(previewCurrentNode);
        }
      }
    }

    return newRoots;

  }, [roots, parentRoleId, childRoleId, currentRoleId, currentRoleName, initialParentId, initialChildId]);

  // Ensure activeTab is always within bounds of previewRoots
  useEffect(() => {
    if (activeTab >= previewRoots.length && previewRoots.length > 0) {
      setActiveTab(Math.max(0, previewRoots.length - 1));
    }
  }, [previewRoots.length, activeTab]);

  return (
    <Card className="border-slate-200 shadow-sm bg-white overflow-hidden">
      <CardHeader className="border-b bg-white py-4 px-6">
        <CardTitle className="text-lg font-bold text-slate-800 flex items-center justify-between">
          Role Hierarchy Details
        </CardTitle>
      </CardHeader>

      <CardContent className="p-0 divide-y divide-slate-100">
        {/* 1. Tree Structure Section (Top) */}
        <div className="p-6">
          <div className="mb-6">
            <h3 className="text-sm font-bold text-slate-800 tracking-tight">
              Hierarchy Tree
            </h3>
            <p className="text-[11px] text-slate-500 mt-1">
              Full organisational structure of roles across branches.
            </p>
          </div>

          {loading ? (
            <div className="py-12 text-center text-sm text-slate-400 italic">
              Loading hierarchy...
            </div>
          ) : (
            previewRoots.length > 0 && (
              <div className="space-y-6">
                {/* Tabs */}
                {previewRoots.length > 1 && (
                  <div className="inline-flex p-1 bg-slate-50 rounded-xl border border-slate-100">
                    {previewRoots.map((root, idx) => {
                      const titles = ["Credit hierarchy", "Collection hierarchy"];
                      const label = titles[idx] || root.name;

                      return (
                        <button
                          key={root.id}
                          onClick={() => setActiveTab(idx)}
                          className={[
                            "px-6 py-2 rounded-lg text-[12px] font-semibold transition-all duration-200",
                            activeTab === idx
                              ? "bg-white text-[#0052CC] shadow-sm"
                              : "text-slate-400 hover:text-slate-600 hover:bg-slate-100/50",
                          ].join(" ")}
                        >
                          {label}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Active tree */}
                <div className="max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                  {previewRoots[activeTab] ? (
                    <TreeNode
                      key={previewRoots[activeTab].id}
                      node={previewRoots[activeTab]}
                      depth={0}
                      rootIndex={activeTab}
                      currentRoleId={currentRoleId}
                    />
                  ) : (
                    <TreeNode
                      key={previewRoots[0]?.id}
                      node={previewRoots[0]}
                      depth={0}
                      rootIndex={0}
                      currentRoleId={currentRoleId}
                    />
                  )}
                </div>
              </div>
            )
          )}
        </div>

        {/* 2. Setup / Summary Section (Bottom) */}
        <div className="p-6 bg-slate-50/10">
          <div className="mb-6">
            <h3 className="text-sm font-bold text-slate-800 tracking-tight">
              Structural Summary & Setup
            </h3>
            <p className="text-[11px] text-slate-500 mt-1">
              Define the immediate relationship context for the new role: <span className="text-slate-900 font-semibold">{currentRoleName}</span>
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            {/* Parent Box */}
            <div className="space-y-2">
              <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Parent Role</Label>
              <div className="space-y-3">
                <SearchableSelect
                  options={parentOptions}
                  value={parentRoleId === null ? "none" : (parentRoleId || "")}
                  onValueChange={handleParentChange}
                  placeholder="Select parent..."
                  searchPlaceholder="Search roles..."
                  disabled={disabled || isParentAutoSelected || (parentOptions.length <= 1 && !!childRoleId)}
                />
                <p className="text-[10px] text-slate-400 italic px-1">{parentHelperText}</p>
              </div>
            </div>

            {/* Child Box */}
            <div className="space-y-2">
              <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Child Role</Label>
              <div className="space-y-3">
                <SearchableSelect
                  options={childOptions}
                  value={childRoleId === null ? "none" : (childRoleId || "")}
                  onValueChange={handleChildChange}
                  placeholder="Select child..."
                  searchPlaceholder="Search roles..."
                  disabled={disabled || isChildAutoSelected || (childOptions.length <= 1 && !!parentRoleId)}
                />
                <p className="text-[10px] text-slate-400 italic px-1">{childHelperText}</p>
              </div>
            </div>
          </div>


            {showButtons && (
              <div className="flex flex-col items-end gap-3 pt-6">
                <div className="flex items-center justify-end gap-3 w-full">
                  <Button
                    variant="outline"
                    onClick={onCancel}
                    disabled={isSaving}
                    className="text-slate-500 border-slate-200 hover:bg-rose-500 rounded-xl px-6"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={onSave}
                    disabled={isSaving}
                    className="bg-[#0052CC] hover:bg-[#0747A6] text-white px-8 h-10 rounded-lg text-sm font-semibold transition-all duration-200 shadow-sm"
                  >
                    {isSaving ? (
                      <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving Hierarchy...</>
                    ) : (
                      'Save Hierarchy'
                    )}
                  </Button>
                </div>
              </div>
            )}
        </div>
      </CardContent>
    </Card>
  );
};
