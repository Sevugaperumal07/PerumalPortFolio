import React, { useState, useCallback } from "react";
import { type RoleNode } from "../../hooks/use-role-hierarchy";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';

// ─── Depth colour palette ────────────────────────────────────────────────────
const ROOT_PALETTES = [
  ["#2b00ffff", "#402fffff", "#7a6dffff", "#8b83faff", "#b7b2faff"],
  ["#2b00ffff", "#402fffff", "#7a6dffff", "#8b83faff", "#b7b2faff"],
];
function getDotColor(rootIndex: number, depth: number): string {
  const palette = ROOT_PALETTES[rootIndex % ROOT_PALETTES.length];
  return palette[Math.min(depth, palette.length - 1)];
}

// ─── Single tree node ────────────────────────────────────────────────────────
interface TreeNodeProps {
  node: RoleNode;
  depth: number;
  rootIndex: number;
  currentRoleId?: string;
}

const TreeNode: React.FC<TreeNodeProps> = ({ node, depth, rootIndex, currentRoleId }) => {
  const [expanded, setExpanded] = useState(true);
  const isCurrent = node.id === currentRoleId;
  const hasChildren = node.children && node.children.length > 0;
  const dotColor = getDotColor(rootIndex, depth);

  const toggle = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setExpanded((prev) => !prev);
  }, []);

  return (
    <div className="relative">
      <div
        className={[
          "flex items-center gap-3 px-3 py-[8px] my-[2px] rounded-lg group",
          "border transition-all duration-200",
          isCurrent 
            ? "bg-blue-50/50 border-blue-200/40" 
            : "border-transparent hover:bg-slate-50 hover:border-slate-200",
          "relative",
        ].join(" ")}
        onClick={hasChildren ? toggle : undefined}
      >
        {depth > 0 && (
          <span
            className="absolute left-[-24px] top-1/2 w-5 h-[1.5px] bg-[var(--color-border-tertiary)] opacity-60"
            aria-hidden="true"
          />
        )}
        <div 
          className={`flex items-center justify-center rounded-full flex-shrink-0 ${depth === 0 ? "w-3 h-3" : "w-2.5 h-2.5"}`}
          style={{ backgroundColor: `${dotColor}20`, border: `1.5px solid ${dotColor}` }}
        />
        <span
          className={[
            "flex-1 transition-colors",
            isCurrent ? "text-blue-600 font-semibold" : "text-slate-700",
            depth === 0 ? "text-sm font-medium" : "text-[13px]",
          ].join(" ")}
        >
          {node.name}
          {isCurrent && (
             <span className="ml-2 text-[10px] uppercase font-extrabold tracking-tight bg-blue-600 text-white px-2 py-0.5 rounded-md shadow-sm">
              CURRENT
            </span>
          )}
        </span>
        {hasChildren && (
          <button
            onClick={toggle}
            className={[
              "w-3.5 h-3.5 rounded-[3px] flex-shrink-0 ml-auto",
              "border border-[var(--color-border-secondary)]",
              "bg-[var(--color-background-secondary)]",
              "flex items-center justify-center",
              "text-[10px] leading-none text-[var(--color-text-secondary)]",
              "cursor-pointer transition-all duration-100",
              "hover:bg-[var(--color-background-primary)] hover:border-[var(--color-border-primary)]",
            ].join(" ")}
            aria-label={expanded ? "Collapse" : "Expand"}
          >
            {expanded ? "−" : "+"}
          </button>
        )}
      </div>
      {hasChildren && expanded && (
        <div className="ml-6 border-l-[1.5px] border-slate-200 pl-0 mt-[-2px] mb-1">
          {node.children?.map((child: RoleNode) => (
            <TreeNode
              key={child.id}
              node={child}
              depth={depth + 1}
              rootIndex={rootIndex}
              currentRoleId={currentRoleId}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// ─── Combined Component ──────────────────────────────────────────────────────
interface RoleHierarchyBothProps {
  /** Array of root nodes coming from useRoleHierarchy() */
  roots: RoleNode[];
  /** Optional ID of the role to highlight as 'current' */
  currentRoleId?: string;
  /** Summary data from RoleHierarchyView */
  parentRoleName?: string;
  childRoleName?: string;
  /** Loading state for the tree */
  loading?: boolean;
}

const RoleHierarchyBoth: React.FC<RoleHierarchyBothProps> = ({ 
  roots, 
  currentRoleId, 
  parentRoleName, 
  childRoleName,
  loading 
}) => {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <Card className="border-slate-200 shadow-sm bg-white overflow-hidden">
      <CardHeader className="border-b bg-white">
        <CardTitle className="text-lg font-bold text-slate-800 flex items-center justify-between">
          Role Hierarchy Details    
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-0 divide-y divide-slate-100">
        {/* 1. Tree Structure Section (Top) */}
        <div className="">
          <div className="mb-3">
            <h3 className="text-sm font-bold text-slate-800">
              Hierarchy Tree
            </h3>
            <p className="text-[11px] text-slate-500 mt-1">
              Full organisational structure of roles across branches.
            </p>
          </div>
          
          {loading ? (
            <div className="py-12 text-center text-sm text-slate-400 italic">
              Loading hierarchy...
            </div>
          ) : (
            roots.length > 0 && (
              <div>
                {/* Tabs */}
                {roots.length > 1 && (
                  <div className="inline-flex p-1 mb-6 bg-slate-50 rounded-xl border border-slate-100">
                    {roots.map((root, idx) => {
                      const titles = ["Credit hierarchy", "Collection hierarchy"];
                      const label = titles[idx] || root.name;
                          
                      return (
                        <button
                          key={root.id}
                          onClick={() => setActiveTab(idx)}
                          className={[
                            "px-6 py-2 rounded-lg text-[12px] font-semibold transition-all duration-200",
                            activeTab === idx
                              ? "bg-white text-[var(--color-primary)] shadow-sm"
                              : "text-slate-400 hover:text-slate-600 hover:bg-slate-100/50",
                          ].join(" ")}
                        >
                          {label}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Active tree */}
                <div className="pr-2">
                  <TreeNode
                    key={roots[activeTab].id}
                    node={roots[activeTab]}
                    depth={0}
                    rootIndex={activeTab}
                    currentRoleId={currentRoleId}
                  />
                </div>
              </div>
            )
          )}
        </div>

        {/* 2. Summary Section (Bottom) */}
        <div className="p-6 bg-slate-50/10">
          <div className="mb-6">
            <h3 className="text-sm font-bold text-slate-800">
              Structural Summary
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Immediate relationship context within the hierarchy.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Parent Role</Label>
              <div className="text-sm font-semibold text-slate-900 bg-white px-4 py-3 rounded-xl border border-slate-200 shadow-sm transition-all hover:border-[var(--color-primary)]/30">
                {parentRoleName || 'No parent role assigned'}
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Child Role</Label>
              <div className="text-sm font-semibold text-slate-900 bg-white px-4 py-3 rounded-xl border border-slate-200 shadow-sm transition-all hover:border-[var(--color-primary)]/30">
                {childRoleName || 'No child role assigned'}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RoleHierarchyBoth;