import { useMemo } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface YearMonthFilterProps {
  year: number | undefined;
  month: number | undefined;
  onYearChange: (year: number | undefined) => void;
  onMonthChange: (month: number | undefined) => void;
  compact?: boolean;
}

const MONTHS = [
  { value: 1, label: "January" },
  { value: 2, label: "February" },
  { value: 3, label: "March" },
  { value: 4, label: "April" },
  { value: 5, label: "May" },
  { value: 6, label: "June" },
  { value: 7, label: "July" },
  { value: 8, label: "August" },
  { value: 9, label: "September" },
  { value: 10, label: "October" },
  { value: 11, label: "November" },
  { value: 12, label: "December" },
];

// Generate years from 2025 to current year
const currentYear = new Date().getFullYear();
const currentMonth = new Date().getMonth() + 1;
const YEARS = Array.from(
  { length: Math.max(0, currentYear - 2025 + 1) },
  (_, i) => 2025 + i
);
if (YEARS.length === 0) YEARS.push(2025);

export function YearMonthFilter({
  year,
  month,
  onYearChange,
  onMonthChange,
  compact,
}: YearMonthFilterProps) {

  const availableMonths = useMemo(() => {
    if (year === currentYear) {
      return MONTHS.filter(m => m.value <= currentMonth);
    }
    if (year === 2025) {
      // In case we ever need to block months before a specific one in 2025
      // For now, it's just Jan (1) onwards, which is all months anyway.
      return MONTHS;
    }
    return MONTHS;
  }, [year, currentYear, currentMonth]);

  return (
    <div className={`flex items-center gap-1.5 flex-nowrap ${compact ? '' : 'flex-wrap'}`}>
      <Select
        value={year?.toString() ?? ""}
        onValueChange={(value) =>
          onYearChange(value ? parseInt(value, 10) : undefined)
        }
      >
        <SelectTrigger className={`bg-white focus:ring-0 text-gray-900 font-medium border-none shadow-sm ${compact ? 'w-[80px] h-7 text-[10px]' : 'w-[120px] h-9'}`}>
          <SelectValue placeholder="Year" />
        </SelectTrigger>
        <SelectContent>
          {YEARS.map((y) => (
            <SelectItem key={y} value={y.toString()}>
              {y}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select
        value={month?.toString() ?? ""}
        onValueChange={(value) =>
          onMonthChange(value ? parseInt(value, 10) : undefined)
        }
      >
        <SelectTrigger className={`bg-white focus:ring-0 text-gray-900 font-medium border-none shadow-sm ${compact ? 'w-[110px] h-7 text-[10px]' : 'w-[140px] h-9'}`}>
          <SelectValue placeholder="Month" />
        </SelectTrigger>
        <SelectContent>
          {availableMonths.map((m) => (
            <SelectItem key={m.value} value={m.value.toString()}>
              {m.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

    </div>
  );
}
