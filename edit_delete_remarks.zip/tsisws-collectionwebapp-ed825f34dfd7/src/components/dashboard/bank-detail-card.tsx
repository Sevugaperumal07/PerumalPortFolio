import type { BankDetail } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Pencil, Trash2 } from "lucide-react"
import { Link } from "react-router-dom"
import { useUserRole } from "@/contexts/UserRoleContext"

interface BankDetailCardProps {
    bank: BankDetail;
    onDelete?: (id: string) => void;
}

export function BankDetailCard({ bank, onDelete }: BankDetailCardProps) {
    const { canAccessCategory } = useUserRole();
    return (
        <Card className="flex flex-col justify-between">
            <CardHeader className="pb-2">
                <CardTitle className="text-base font-semibold">{bank.bankName}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <p className="text-xs text-muted-foreground">Account Number</p>
                    <p className="text-sm font-medium">{bank.accountNumber}</p>
                </div>
                {bank.branchName && (
                    <div>
                        <p className="text-xs text-muted-foreground">Branch</p>
                        <p className="text-sm font-medium">{bank.branchName}</p>
                    </div>
                )}
                {bank.ifscCode && (
                    <div>
                        <p className="text-xs text-muted-foreground">IFSC Code</p>
                        <p className="text-sm font-medium">{bank.ifscCode}</p>
                    </div>
                )}
            </CardContent>
            <CardFooter className="flex justify-end gap-1 mt-auto">
                {canAccessCategory("BankDetailsWeb", "EDIT") && (
                    <Button variant="ghost" size="icon" asChild>
                        <Link to={`/dashboard/bank-details/${bank.id}/edit`}>
                            <Pencil className="h-4 w-4" />
                        </Link>
                    </Button>
                )}
                {onDelete && canAccessCategory("BankDetailsWeb", "DELETE") && (
                    <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:text-destructive"
                        onClick={() => onDelete(bank.id)}
                    >
                        <Trash2 className="h-4 w-4" />
                    </Button>
                )}
            </CardFooter>
        </Card>
    )
}

