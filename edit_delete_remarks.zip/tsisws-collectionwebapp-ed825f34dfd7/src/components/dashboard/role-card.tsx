import type { Role } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Pencil } from "lucide-react"
import { Link } from "react-router-dom"
import { useUserRole } from "@/contexts/UserRoleContext"

interface RoleCardProps {
    role: Role;
}

export function RoleCard({ role }: RoleCardProps) {
    const { canAccessCategory } = useUserRole();
    return (
        <Card className="flex flex-col justify-between">
            <CardHeader className="pb-2">
                <CardTitle className="text-base font-semibold">{role.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                {role.description && (
                    <div>
                        <p className="text-xs text-muted-foreground">Description</p>
                        <p className="text-sm font-medium">{role.description}</p>
                    </div>
                )}
                {role.dateEntered && (
                    <div>
                        <p className="text-xs text-muted-foreground">Created</p>
                        <p className="text-sm font-medium">
                            {new Date(role.dateEntered).toLocaleDateString()}
                        </p>
                    </div>
                )}
            </CardContent>
            <CardFooter className="flex justify-end gap-1 mt-auto">
                {canAccessCategory("RolesWeb", "EDIT") && (<Button variant="ghost" size="icon" asChild>
                    <Link to={`/dashboard/roles/${role.id}/edit`}>
                        <Pencil className="h-4 w-4" />
                    </Link>
                </Button>)}
            </CardFooter>
        </Card>
    )
}

