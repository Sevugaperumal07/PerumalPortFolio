import type { SecurityGroup } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Pencil } from "lucide-react"
import { Link } from "react-router-dom"
import { useUserRole } from "@/contexts/UserRoleContext"

interface SecurityGroupCardProps {
    group: SecurityGroup;
}

export function SecurityGroupCard({ group }: SecurityGroupCardProps) {
    const { canAccessCategory } = useUserRole();
    return (
        <Card className="flex flex-col justify-between">
            <CardHeader className="pb-2">
                <CardTitle className="text-base font-semibold">{group.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                {group.description && (
                    <div>
                        <p className="text-xs text-muted-foreground">Description</p>
                        <p className="text-sm font-medium">{group.description}</p>
                    </div>
                )}
                <div>
                    <p className="text-xs text-muted-foreground">Inheritable</p>
                    <p className="text-sm font-medium">{group.inheritable ? 'Yes' : 'No'}</p>
                </div>
                {group.dateEntered && (
                    <div>
                        <p className="text-xs text-muted-foreground">Created</p>
                        <p className="text-sm font-medium">
                            {new Date(group.dateEntered).toLocaleDateString()}
                        </p>
                    </div>
                )}
            </CardContent>
            <CardFooter className="flex justify-end gap-1 mt-auto">
                {canAccessCategory("SecurityGroups", "EDIT") && (
                    <Button variant="ghost" size="icon" asChild>
                        <Link to={`/dashboard/security-groups/${group.id}/edit`}>
                            <Pencil className="h-4 w-4" />
                        </Link>
                    </Button>
                )}
            </CardFooter>
        </Card>
    )
}

