import type { User } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Eye, Pencil } from "lucide-react"
import { Link } from "react-router-dom"
import { useUserRole} from "@/contexts/UserRoleContext"

interface UserCardProps {
    user: User;
}

export function UserCard({ user }: UserCardProps) {
    const status = user.status;
    const { canAccessCategory } = useUserRole();
    const variant: "outline" | "secondary" | "destructive" =
        status === "Active" ? "outline" : status === "Inactive" ? "destructive" : "secondary";

    return (
        <Card className="flex flex-col justify-between">
            <CardHeader className="pb-2">
                <CardTitle className="flex justify-between items-start">
                    <div className="flex flex-col gap-1">
                        <span className="text-base font-semibold">
                            {user.firstName || user.lastName
                                ? `${user.firstName || ''} ${user.lastName || ''}`.trim()
                                : user.userName || 'N/A'}
                        </span>
                        <span className="text-sm font-normal text-muted-foreground">{user.email || 'N/A'}</span>
                    </div>
                    {status && <Badge variant={variant}>{status}</Badge>}
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <p className="text-xs text-muted-foreground">Username</p>
                    <p className="text-sm font-medium">{user.userName || 'N/A'}</p>
                </div>
                <div>
                    <p className="text-xs text-muted-foreground">User Type</p>
                    <p className="text-sm font-medium">{user.userType || 'N/A'}</p>
                </div>
                {user.employeeCode && (
                    <div>
                        <p className="text-xs text-muted-foreground">Employee Code</p>
                        <p className="text-sm font-medium">{user.employeeCode}</p>
                    </div>
                )}
            </CardContent>
            <CardFooter className="flex justify-end gap-1 mt-auto">
                <Button variant="ghost" size="icon" asChild>
                    <Link to={`/dashboard/users/${user.id}`}>
                        <Eye className="h-4 w-4" />
                    </Link>
                </Button>
                {canAccessCategory("UsersWeb", "EDIT") && (<Button variant="ghost" size="icon" asChild>
                    <Link to={`/dashboard/users/${user.id}/edit`}>
                        <Pencil className="h-4 w-4" />
                    </Link>
                </Button>
                )}
            </CardFooter>
        </Card>
    )
}

