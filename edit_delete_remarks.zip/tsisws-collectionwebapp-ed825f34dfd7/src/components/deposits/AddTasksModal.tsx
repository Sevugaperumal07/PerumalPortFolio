import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Search, Loader2 } from "lucide-react";
import { Pagination } from "@/components/common/pagination";
import { useAddTasksModal } from "@/hooks/deposits/useAddTasksModal";
import type { Task } from "@/lib/types";
import { cn } from "@/lib/utils";

interface AddTasksModalProps {
    isOpen: boolean;
    onClose: () => void;
    branchName?: string;
    initialSelectedTasks?: Task[];
    baseTaskIds?: string[];
    onAddTasks: (tasks: Task[]) => void;
}

export function AddTasksModal({
    isOpen,
    onClose,
    branchName,
    initialSelectedTasks,
    baseTaskIds,
    onAddTasks
}: AddTasksModalProps) {
    const {
        tasks,
        selectedTasks,
        pageIndex,
        totalRecords,
        totalPages,
        hasNext,
        hasPrevious,
        loading,
        searchQuery,
        setSearchQuery,
        toggleTaskSelection,
        toggleAllTasks,
        clearSelection,
        isTaskSelected,
        allSelected,
        someSelected,
        newSelectedCount,
        setPageIndex,
    } = useAddTasksModal({
        isOpen,
        branchName,
        initialSelectedTasks,
        baseTaskIds
    });

    const handleAddTasks = () => {
        if (selectedTasks.length > 0) {
            onAddTasks(selectedTasks);
            onClose();
        }
    };

    // Create a dummy table object for Pagination component
    const dummyTable = {
        getRowModel: () => ({ rows: tasks })
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-4xl max-h-[90vh] p-0 flex flex-col">
                <DialogHeader className="px-6 pt-6 pb-4 border-b">
                    <DialogTitle className="text-xl font-bold">Add Tasks to Deposit</DialogTitle>
                    <DialogDescription className="text-sm text-gray-600 mt-1">
                        Select tasks to add to this cash deposit. Only tasks with status 'In-Hand Branch' from the{" "}
                        {branchName} branch are shown.
                    </DialogDescription>
                </DialogHeader>

                {/* Search Bar */}
                <div className="px-6 pt-4">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <Input
                            placeholder="Search by LAN, Task No, or Receipt No"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-10 h-11"
                        />
                    </div>
                </div>

                {/* Table */}
                <div className="flex-1 overflow-auto px-6">
                    <Table>
                        <TableHeader className="sticky top-0 bg-white z-10">
                            <TableRow>
                                <TableHead className="w-12">
                                    <Checkbox
                                        checked={allSelected}
                                        onCheckedChange={toggleAllTasks}
                                        aria-label="Select all"
                                        className={cn(someSelected && "data-[state=checked]:bg-gray-400")}
                                    />
                                </TableHead>
                                <TableHead className="font-bold">Task No</TableHead>
                                <TableHead className="font-bold">LAN</TableHead>
                                <TableHead className="font-bold">Receipt</TableHead>
                                <TableHead className="font-bold">Branch</TableHead>
                                <TableHead className="font-bold text-right">Amount</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {loading ? (
                                <TableRow>
                                    <TableCell colSpan={6} className="h-32 text-center">
                                        <div className="flex flex-col items-center justify-center gap-2">
                                            <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
                                            <p className="text-sm text-muted-foreground">Loading tasks...</p>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ) : tasks.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={6} className="h-32 text-center">
                                        <p className="text-sm text-muted-foreground">
                                            No tasks found{searchQuery ? " matching your search" : ""}.
                                        </p>
                                    </TableCell>
                                </TableRow>
                            ) : (
                                tasks.map((task) => (
                                    <TableRow
                                        key={task.id}
                                        className={cn(
                                            "cursor-pointer hover:bg-gray-50",
                                            isTaskSelected(task.id) && "bg-blue-50 hover:bg-blue-100"
                                        )}
                                        onClick={() => toggleTaskSelection(task)}
                                    >
                                        <TableCell>
                                            <Checkbox
                                                checked={isTaskSelected(task.id)}
                                                onCheckedChange={() => toggleTaskSelection(task)}
                                                onClick={(e) => e.stopPropagation()}
                                                aria-label={`Select task ${task.taskNumber}`}
                                            />
                                        </TableCell>
                                        <TableCell className="font-medium">{task.taskNumber || "-"}</TableCell>
                                        <TableCell>{task.lan || "-"}</TableCell>
                                        <TableCell>{task.receiptNo || "-"}</TableCell>
                                        <TableCell>{task.branch || "-"}</TableCell>
                                        <TableCell className="text-right font-semibold">
                                            ₹{(task.receivedAmount || 0).toLocaleString("en-IN", {
                                                minimumFractionDigits: 2
                                            })}
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                </div>

                {/* Pagination */}
                {!loading && tasks.length > 0 && (
                    <div className="px-6">
                        <Pagination
                            table={dummyTable}
                            totalRecords={totalRecords}
                            totalPages={totalPages}
                            pageIndex={pageIndex}
                            setPageIndex={setPageIndex}
                            hasNext={hasNext}
                            hasPrevious={hasPrevious}
                            loading={loading}
                            entityName="Tasks"
                            selectionCount={newSelectedCount}
                            onClearSelection={clearSelection}
                        />
                    </div>
                )}

                {/* Footer */}
                <div className="px-6 py-4 border-t bg-gray-50 flex justify-end items-center">
                    <div className="flex gap-3">
                        <Button
                            variant="outline"
                            onClick={onClose}
                            className="px-6"
                        >
                            Cancel
                        </Button>
                        <Button
                            onClick={handleAddTasks}
                            disabled={newSelectedCount === 0}
                            className="px-6 bg-blue-600 hover:bg-blue-700"
                        >
                            Add {newSelectedCount > 0 && `${newSelectedCount} `}Task{newSelectedCount !== 1 ? "s" : ""}
                        </Button>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}
