import { format } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetDescription,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SearchableSelect } from "@/components/ui/searchable-select";
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import type { DepositDateRange } from "@/hooks/deposits/useAdvancedDepositSearch";

interface AdvancedDepositSearchProps {
    isOpen: boolean;
    onOpenChange: (open: boolean) => void;
    activeTab: "Digital" | "Cash";
    showBankSearch?: boolean;

    // Values from hook
    tempDepositDateRange: DepositDateRange;
    depositSlipNo: string;
    selectedBank: string;
    dateRangePopoverOpen: boolean;
    bankNames: string[];
    loadingBankNames: boolean;

    // Handlers from hook
    setDepositSlipNo: (value: string) => void;
    setSelectedBank: (value: string) => void;
    setTempDepositDateRange: (range: DepositDateRange) => void;
    handleApplyFilters: () => void;
    handleResetFilters: () => void;
    handleApplyDateRange: () => void;
    handleCancelDateRange: () => void;
    handleDateRangeOpenChange: (open: boolean) => void;
}

export function AdvancedDepositSearch({
    isOpen,
    onOpenChange,
    activeTab,
    tempDepositDateRange,
    depositSlipNo,
    selectedBank,
    dateRangePopoverOpen,
    bankNames,
    loadingBankNames,
    setDepositSlipNo,
    setSelectedBank,
    setTempDepositDateRange,
    handleApplyFilters,
    handleResetFilters,
    handleApplyDateRange,
    handleCancelDateRange,
    handleDateRangeOpenChange,
    showBankSearch = true,
}: AdvancedDepositSearchProps) {
    return (
        <Sheet open={isOpen} onOpenChange={onOpenChange}>
            <SheetContent side="right" className="w-[500px] sm:w-[800px] bg-white p-6 overflow-y-auto flex flex-col justify-between">
                <div>
                    <div className="flex items-center justify-between mb-6">
                        <SheetHeader className="flex-1">
                            <SheetTitle className="text-xl font-semibold text-gray-900">
                                Advanced Deposit Search
                            </SheetTitle>
                            <SheetDescription className="text-sm text-gray-600 mt-2">
                                Filter deposits by multiple criteria.
                            </SheetDescription>
                        </SheetHeader>
                    </div>

                    <div className="space-y-6">
                        {/* Deposit Date */}
                        <div className="space-y-2">
                            <Label htmlFor="deposit-date" className="text-sm font-medium text-gray-900">
                                {(activeTab === "Digital") ? "Date Entered" : "Deposit Date"}
                            </Label>
                            <Popover open={dateRangePopoverOpen} onOpenChange={handleDateRangeOpenChange}>
                                <PopoverTrigger asChild>
                                    <Button
                                        variant="outline"
                                        className={cn(
                                            "w-full justify-start text-left font-normal",
                                            !tempDepositDateRange.from && "text-muted-foreground"
                                        )}
                                    >
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {tempDepositDateRange.from ? (
                                            tempDepositDateRange.to ? (
                                                <>
                                                    {format(tempDepositDateRange.from as Date, "yyyy MMM dd")} -{" "}
                                                    {format(tempDepositDateRange.to as Date, "yyyy MMM dd")}
                                                </>
                                            ) : (
                                                format(tempDepositDateRange.from as Date, "yyyy MMM dd")
                                            )
                                        ) : (
                                            <span>Pick a date range</span>
                                        )}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                    <Calendar
                                        mode="range"
                                        selected={{ from: tempDepositDateRange.from, to: tempDepositDateRange.to }}
                                        onSelect={(range) => {
                                            setTempDepositDateRange({
                                                from: range?.from,
                                                to: range?.to,
                                            });
                                        }}
                                        numberOfMonths={1}
                                        initialFocus
                                        disabled={{ after: new Date() }}
                                    />
                                    <div className="flex items-center justify-end gap-2 p-3 border-t bg-gray-50">
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={handleCancelDateRange}
                                            className="h-8 text-xs text-gray-600 hover:text-gray-900"
                                        >
                                            Cancel
                                        </Button>
                                        <Button
                                            size="sm"
                                            onClick={handleApplyDateRange}
                                            className="h-8 text-xs bg-blue-800 text-white hover:bg-blue-900 px-4"
                                        >
                                            Apply
                                        </Button>
                                    </div>
                                </PopoverContent>
                            </Popover>
                        </div>

                        {/* Deposit Slip No */}
                        <div className="space-y-2">
                            <Label htmlFor="deposit-slip-no" className="text-sm font-medium text-gray-900">
                                Deposit Slip No.
                            </Label>
                            <Input
                                id="deposit-slip-no"
                                value={depositSlipNo}
                                onChange={(e) => setDepositSlipNo(e.target.value)}
                                className="w-full"
                            />
                        </div>


                        {/* Bank */}
                        {showBankSearch && (
                            <div className="space-y-2">
                                <Label htmlFor="bank" className="text-sm font-medium text-gray-900">
                                    Bank
                                </Label>
                                <SearchableSelect
                                    id="bank"
                                    placeholder={loadingBankNames ? "Loading banks..." : "Select a bank"}
                                    value={selectedBank}
                                    onValueChange={setSelectedBank}
                                    disabled={loadingBankNames || !Array.isArray(bankNames) || bankNames.length === 0}
                                    options={Array.isArray(bankNames) ? bankNames.map((bank) => ({
                                        value: bank,
                                        label: bank
                                    })) : []}
                                />
                            </div>
                        )}
                    </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-3 mt-8 justify-end border-t pt-4">
                    <Button
                        variant="ghost"
                        className=" text-gray-700 hover:text-white"
                        onClick={handleResetFilters}
                    >
                        Reset
                    </Button>
                    <Button
                        className="bg-blue-800 hover:bg-blue-900 text-white"
                        onClick={handleApplyFilters}
                    >
                        Apply Filters
                    </Button>
                </div>
            </SheetContent>
        </Sheet>
    );
}
