import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetDescription
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import type { VerificationType } from "@/lib/types";

interface BankCollReceipt {
    lanNumber: string;
}

interface SelectedDeposit {
    id: string;
    depositSlipno: string;
    amount: number;
    bankCollReceipts: BankCollReceipt[];
}

interface ApproveRejectDepositsProps {
    isOpen: boolean;
    onOpenChange: (open: boolean) => void;
    selectedDeposits: SelectedDeposit[];
    decision: VerificationType | null;
    remarks: string;
    setRemarks: (remarks: string) => void;
    isSubmitting: boolean;
    onSubmit: (decision: VerificationType) => void;
    showApprove?: boolean;
    showReject?: boolean;
}

export function ApproveRejectDeposits({
    isOpen,
    onOpenChange,
    selectedDeposits,
    decision,
    remarks,
    setRemarks,
    isSubmitting,
    onSubmit,
    showApprove = true,
    showReject = true
}: ApproveRejectDepositsProps) {
    const count = selectedDeposits.length;
    const totalAmount = selectedDeposits.reduce((sum, d) => sum + d.amount, 0);

    return (
        <Sheet open={isOpen} onOpenChange={onOpenChange}>
            <SheetContent side="right" className="w-full sm:max-w-md flex flex-col h-full bg-white p-0">
                <SheetHeader className="p-6 border-b">
                    <SheetTitle className="text-xl font-bold">
                        Approve/Reject Deposits
                    </SheetTitle>
                    <SheetDescription className="text-gray-500">
                        Review the deposits for {count} item{count !== 1 ? 's' : ''}. Please provide remarks and choose an action.
                    </SheetDescription>
                </SheetHeader>

                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    {count === 0 ? (
                        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex gap-3">
                            <AlertCircle className="h-5 w-5 text-amber-600 shrink-0" />
                            <p className="text-sm text-amber-800">
                                No deposits selected. Please select at least one deposit to proceed.
                            </p>
                        </div>
                    ) : (
                        <div className="space-y-6">
                            {/* Selected Deposits Section */}
                            <div className="bg-blue-50/30 border border-blue-100/50 rounded-xl overflow-hidden">
                                <div className="px-4 py-3 border-b border-blue-100/50 flex justify-between items-center">
                                    <span className="text-sm font-semibold text-gray-900">Selected Deposits</span>
                                </div>
                                <div className="max-h-[300px] overflow-y-auto">
                                    {selectedDeposits.map((deposit) => (
                                        <div key={deposit.id} className="px-4 py-3 flex justify-between items-start border-b border-blue-100/30 last:border-0 hover:bg-white/50 transition-colors">
                                            <div className="space-y-1">
                                                <div className="text-sm font-bold text-gray-900">SlipNo: {deposit.depositSlipno}</div>
                                                <div className="text-xs text-gray-500">LAN: {deposit.bankCollReceipts?.map(r => r.lanNumber).filter(Boolean).join(", ") || "—"}</div>
                                            </div>
                                            <div className="text-sm font-bold text-gray-900">
                                                ₹{deposit.amount.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <div className="px-4 py-4 bg-white/40 border-t border-blue-100/50 flex justify-between items-center">
                                    <span className="text-sm font-bold text-gray-900">Total Amount:</span>
                                    <span className="text-base font-bold text-gray-900">
                                        ₹{totalAmount.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                    </span>
                                </div>
                            </div>

                            {/* Remarks Section */}
                            <div className="space-y-2">
                                <Label htmlFor="remarks" className="text-sm font-semibold text-gray-900">
                                    Remarks <span className="text-red-500 ml-0.5">*</span>
                                </Label>
                                <Textarea
                                    id="remarks"
                                    value={remarks}
                                    onChange={(e) => setRemarks(e.target.value)}
                                    placeholder="Enter remarks for approval or rejection..."
                                    className="min-h-[120px] resize-none border-gray-200 focus:ring-blue-500 text-sm rounded-xl placeholder:text-gray-400"
                                />
                            </div>
                        </div>
                    )}
                </div>

                <div className="p-6 border-t bg-white flex flex-col gap-3">
                    <div className={cn(
                        "grid gap-3",
                        (showApprove && showReject) ? "grid-cols-3" : "grid-cols-2"
                    )}>
                        <Button
                            variant="outline"
                            className="px-6 h-9 font-semibold text-gray-700 border-gray-300"
                            onClick={() => onOpenChange(false)}
                            disabled={isSubmitting}
                        >
                            Cancel
                        </Button>
                        {showReject && (
                            <Button
                                className="px-6 h-9 font-semibold bg-rose-600 hover:bg-rose-700 text-white"
                                disabled={count === 0 || isSubmitting || !remarks.trim()}
                                onClick={() => onSubmit("REJECT")}
                            >
                                {isSubmitting && decision === "REJECT" ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                    "Reject All"
                                )}
                            </Button>
                        )}
                        {showApprove && (
                            <Button
                                className="px-6 h-9 font-semibold bg-blue-800 hover:bg-blue-900 text-white"
                                disabled={count === 0 || isSubmitting || !remarks.trim()}
                                onClick={() => onSubmit("APPROVE")}
                            >
                                {isSubmitting && decision === "APPROVE" ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                    "Approve All"
                                )}
                            </Button>
                        )}
                    </div>
                </div>
            </SheetContent>
        </Sheet>
    );
}
