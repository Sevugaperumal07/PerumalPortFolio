import { useState, useEffect } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import depositStatus from "@/constants/DepositStatus";
import depositTypes from "@/constants/DepositTypes";
import {
    Download,
    Loader2
    // Pencil, 
    // Trash2 
} from "lucide-react";
import { PaymentTypes } from "@/constants/PaymentTypes";
import paymentTab from "@/constants/PaymentTab";
import type { Deposit, CollReceipt } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { getScreenShot } from "@/lib/services/screenShot";
import { downloadBlob, cn } from "@/lib/utils";
import { useUserRole } from "@/contexts/UserRoleContext";

interface DepositDetailsSheetProps {
    isOpen: boolean;
    onOpenChange: (open: boolean) => void;
    loading: boolean;
    selectedDeposit: Deposit | null;
    activeTab: string;
    isAcceptancePending?: boolean;
    onEditReceipt: (receipt: CollReceipt) => void;
    onDeleteReceipt: (receipt: CollReceipt) => void;
    onSuccess?: () => void;
    isSubmitting?: boolean;
    onSubmission?: (params: {
        deposit: Deposit | null;
        remarks: string;
        isAcceptancePending: boolean;
        decision: "ACCEPT" | "REJECT" | "APPROVE";
        onSuccess?: () => void;
        onClose: (open: boolean) => void;
    }) => Promise<void>;
}

export function DepositDetailsSheet({
    isOpen,
    onOpenChange,
    loading,
    selectedDeposit: deposit,
    activeTab,
    isAcceptancePending = false,
    // onEditReceipt,
    // onDeleteReceipt,
    onSuccess,
    isSubmitting: isSubmittingProp,
    onSubmission,
}: DepositDetailsSheetProps) {
    const { toast } = useToast();
    const [remarks, setRemarks] = useState("");
    const { canAccessCategory } = useUserRole();
    const isDepositVerificationPending = depositStatus.VERIFICATION_PENDING;
    const isBranchDeposit = depositTypes.BRANCH_DEPOSIT;



    const isSubmitting = isSubmittingProp ?? false;
    const showReject = activeTab === paymentTab.CASH;
    const showApprove = true;

    //Reset remarks when sheet closes/opens
    useEffect(() => {
        if (isOpen) {
            setRemarks("");
        }
    }, [isOpen]);

    return (
        <Sheet open={isOpen} onOpenChange={onOpenChange}>
            <SheetContent side="right" className="w-[650px] sm:max-w-[420px] bg-white p-6 overflow-y-auto">
                {loading ? (
                    <div className="flex items-center justify-center p-8">
                        <p className="text-muted-foreground">Loading deposit details...</p>
                    </div>
                ) : deposit ? (
                    <div className="h-full flex flex-col justify-between">
                        <div>
                            <SheetHeader className="mb-6">
                                <SheetTitle className="text-xl font-semibold text-gray-900">
                                    Deposit Details
                                </SheetTitle>
                                <SheetDescription className="text-sm text-gray-600 mt-2">
                                    Reviewing deposit slip #{deposit.depositSlipno || "-"}
                                </SheetDescription>
                            </SheetHeader>

                            <div className="space-y-5">
                                <div className="flex items-start justify-between gap-4 border-b border-gray-200 pb-3">
                                    <div className="flex-1">
                                        <Label className="text-xs text-gray-500 uppercase tracking-wide block mb-1">
                                            Deposit Date
                                        </Label>
                                        <p className="text-sm font-semibold text-gray-900">
                                            {(deposit.bankDepositDate || deposit.branchDepositionDate)
                                                ? (() => {
                                                    try {
                                                        const dateObj = new Date(deposit.bankDepositDate || deposit.branchDepositionDate as string);
                                                        return dateObj.toLocaleDateString("en-GB", {
                                                            day: "2-digit",
                                                            month: "2-digit",
                                                            year: "numeric",
                                                        });
                                                    } catch {
                                                        return deposit.bankDepositDate || deposit.branchDepositionDate;
                                                    }
                                                })()
                                                : "-"}
                                        </p>
                                    </div>
                                    <Badge
                                        variant="secondary"
                                        className="text-gray-800 hover:bg-gray-100 font-semibold shrink-0"
                                    >
                                        {deposit.status || "Pending"}
                                    </Badge>
                                </div>

                                <div className="grid grid-cols-2 gap-6">
                                    <div>
                                        <Label className="text-xs text-gray-500 uppercase tracking-wide block mb-1">
                                            Payment Type
                                        </Label>
                                        <p className="text-sm font-semibold text-gray-900">
                                            {deposit.bankCollReceipts?.[0]?.paymentType || activeTab}
                                        </p>
                                    </div>
                                    {!isAcceptancePending && (
                                        <div>
                                            <Label className="text-xs text-gray-500 uppercase tracking-wide block mb-1">
                                                Bank Name
                                            </Label>
                                            <p className="text-sm font-semibold text-gray-900">
                                                {deposit.bankName?.includes("&")
                                                    ? deposit.bankName.split("&")[0].trim()
                                                    : (deposit.bankName || "-")}
                                            </p>
                                        </div>
                                    )}
                                </div>

                                {!isAcceptancePending && (
                                    <div className="grid grid-cols-2 gap-6">
                                        <div>
                                            <Label className="text-xs text-gray-500 uppercase tracking-wide block mb-1">
                                                Branch Name
                                            </Label>
                                            <p className="text-sm font-semibold text-gray-900">
                                                {deposit.bankCollReceipts?.[0]?.branchName ||
                                                    (deposit.bankName?.includes("&")
                                                        ? deposit.bankName.split("&")[1].trim()
                                                        : "-")}
                                            </p>
                                        </div>
                                        <div>
                                            <Label className="text-xs text-gray-500 uppercase tracking-wide block mb-1">
                                                Account Number
                                            </Label>
                                            <p className="text-sm font-semibold text-gray-900">
                                                {deposit.bankAccountNumber || "-"}
                                            </p>
                                        </div>
                                    </div>
                                )}

                                <div className="grid grid-cols-2 gap-6">
                                    <div>
                                        <Label className="text-xs text-gray-500 uppercase tracking-wide block mb-1">
                                            Deposited By
                                        </Label>
                                        <p className="text-sm font-semibold text-gray-900">
                                            {deposit.bankDepositedBy || deposit.userName || "-"}
                                        </p>
                                    </div>
                                    <div>
                                        <Label className="text-xs text-gray-500 uppercase tracking-wide block mb-1">
                                            Deposit Remarks
                                        </Label>
                                        <p className="text-sm font-semibold text-gray-900">
                                            {isAcceptancePending
                                                ? (deposit.branchDepositRemarks || "-")
                                                : (deposit.bankDepositRemarks || "-")}
                                        </p>
                                    </div>
                                </div>

                                <div>
                                    {!isAcceptancePending && (<Button
                                        variant="outline"
                                        className="w-full justify-center items-center"
                                        onClick={async () => {
                                            if (!deposit?.id) return;
                                            try {
                                                toast({
                                                    title: "Download",
                                                    description: "Screenshot download initiated.",
                                                });
                                                const firstReceipt = isAcceptancePending ? deposit.collReceipts?.[0] : deposit.bankCollReceipts?.[0];
                                                if (firstReceipt?.paymentType === PaymentTypes.CASH) {
                                                    const { blob, filename } = await getScreenShot({
                                                        moduleName: "Deposit Slip",
                                                        refId: deposit.id
                                                    });
                                                    downloadBlob(blob, filename);
                                                } else if (firstReceipt?.hiveId) {
                                                    const { blob, filename } = await getScreenShot({
                                                        moduleName: "Payment Image",
                                                        refId: firstReceipt.hiveId
                                                    });
                                                    downloadBlob(blob, filename);
                                                } else {
                                                    throw new Error("Payment information unavailable.");
                                                }
                                                toast({
                                                    title: "Success",
                                                    description: "Screenshot downloaded successfully.",
                                                });
                                            } catch (error) {
                                                console.error("Download failed:", error);
                                                toast({
                                                    title: "Screenshot unavailable",
                                                    description: error instanceof Error ? error.message : "An error occurred while downloading the screenshot.",
                                                });
                                            }
                                        }}
                                    >
                                        <Download className="mr-2 h-4 w-4" />
                                        Download Screenshot
                                    </Button>)}
                                </div>

                                <div className="pt-3 border-t border-gray-200">
                                    <div className="flex items-center justify-between">
                                        <Label className="text-sm font-semibold text-gray-900">
                                            Total Amount
                                        </Label>
                                        <p className="text-base font-semibold text-gray-900">
                                            {(isAcceptancePending ? deposit.branchDepositAmount : deposit.bankDepositedAmount) != null
                                                ? (() => {
                                                    const amount = isAcceptancePending ? deposit.branchDepositAmount : deposit.bankDepositedAmount;
                                                    const numAmount = typeof amount === "string"
                                                        ? parseFloat(amount)
                                                        : amount;
                                                    return !isNaN(numAmount as number)
                                                        ? `₹${(numAmount as number).toLocaleString("en-IN", {
                                                            minimumFractionDigits: 2,
                                                            maximumFractionDigits: 2,
                                                        })}`
                                                        : "-";
                                                })()
                                                : "-"}
                                        </p>
                                    </div>
                                </div>

                                {((isAcceptancePending ? deposit.collReceipts : deposit.bankCollReceipts) || []).length > 0 && (
                                    <div className="pt-4 border-t border-gray-200">
                                        <Label className="text-sm font-semibold text-gray-900 block mb-3">
                                            Associated Receipts ({((isAcceptancePending ? deposit.collReceipts : deposit.bankCollReceipts) || []).length})
                                        </Label>
                                        <div className="space-y-3">
                                            {((isAcceptancePending ? deposit.collReceipts : deposit.bankCollReceipts) || []).map((receipt) => (
                                                <div
                                                    key={receipt.id}
                                                    className="p-3 bg-gray-50 rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow space-y-1.5"
                                                >
                                                    {/* Row 1: Receipt No and Amount */}
                                                    <div className="flex items-center justify-between">
                                                        <p className="text-xs font-bold text-gray-900">
                                                            Receipt - {receipt.receiptNo || "-"}
                                                        </p>
                                                        <p className="text-xs font-bold text-gray-900">
                                                            Collected Amount: {receipt.totalAmount != null
                                                                ? `₹${receipt.totalAmount.toLocaleString("en-IN")}`
                                                                : "-"}
                                                        </p>
                                                    </div>

                                                    {/* Row 2: Conditional Download Icons based on Data Presence */}
                                                    {(receipt.selfieImage || receipt.paymentImage) && (
                                                        <div className="flex items-center gap-10 py-1.5 border-y border-gray-100 overflow-x-auto no-scrollbar">
                                                            {receipt.selfieImage && (
                                                                <div className="flex items-center gap-2 shrink-0">
                                                                    <span className="text-[11px] font-medium text-gray-500 whitespace-nowrap">Selfie Image:</span>
                                                                    <Button
                                                                        variant="ghost"
                                                                        size="icon"
                                                                        className="ml-5 h-7 w-7 hover:bg-white"
                                                                        onClick={async () => {
                                                                            if (!receipt.hiveId) {
                                                                                toast({ description: "Screenshot unavailable" });
                                                                                return;
                                                                            }
                                                                            try {
                                                                                const { blob, filename } = await getScreenShot({
                                                                                    moduleName: "Selfie Image",
                                                                                    refId: receipt.hiveId
                                                                                });
                                                                                downloadBlob(blob, filename);
                                                                            } catch (error) {
                                                                                console.error("Download failed:", error);
                                                                                toast({ description: "Screenshot unavailable" });
                                                                            }
                                                                        }}
                                                                        title="Download Selfie Image"
                                                                    >
                                                                        <Download className="h-4 w-4 text-blue-600" />
                                                                    </Button>
                                                                </div>
                                                            )}

                                                            {receipt.paymentImage && (
                                                                <div className={`flex items-center gap-1.5 shrink-0 ${receipt.selfieImage ? 'border-l pl-3 border-gray-200' : ''}`}>
                                                                    <span className="text-[11px] font-medium text-gray-500 whitespace-nowrap">Payment Image:</span>
                                                                    <Button
                                                                        variant="ghost"
                                                                        size="icon"
                                                                        className="ml-5 h-7 w-7 hover:bg-white"
                                                                        onClick={async () => {
                                                                            if (!receipt.hiveId) {
                                                                                toast({ description: "Screenshot unavailable" });
                                                                                return;
                                                                            }
                                                                            try {
                                                                                const { blob, filename } = await getScreenShot({
                                                                                    moduleName: "Payment Image",
                                                                                    refId: receipt.hiveId
                                                                                });
                                                                                downloadBlob(blob, filename);
                                                                            } catch (error) {
                                                                                console.error("Download failed:", error);
                                                                                toast({ description: "Screenshot unavailable" });
                                                                            }
                                                                        }}
                                                                        title="Download Payment Image"
                                                                    >
                                                                        <Download className="h-4 w-4 text-blue-600" />
                                                                    </Button>
                                                                </div>
                                                            )}
                                                        </div>
                                                    )}

                                                    {/* Row 3: Customer Name */}
                                                    <div className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider py-0.5">
                                                        {receipt.customerName || "-"}
                                                    </div>

                                                    {/* Metadata Content - More Compact */}
                                                    <div className="grid grid-cols-2 gap-y-1 gap-x-4">
                                                        <div className="flex items-baseline gap-1 overflow-hidden">
                                                            <span className="text-[10px] text-gray-500 uppercase font-medium shrink-0">LAN:</span>
                                                            <span className="text-xs font-semibold text-gray-900 truncate">{receipt.lanNumber || "-"}</span>
                                                        </div>
                                                        <div className="flex items-baseline gap-1 overflow-hidden">
                                                            <span className="text-[10px] text-gray-500 uppercase font-medium shrink-0">Ref:</span>
                                                            <span className="text-xs font-semibold text-gray-900 truncate" title={receipt.transactionRefNo || "-"}>
                                                                {receipt.transactionRefNo || "-"}
                                                            </span>
                                                        </div>
                                                        <div className="flex items-baseline gap-1">
                                                            <span className="text-[10px] text-gray-500 uppercase font-medium shrink-0">Date:</span>
                                                            <span className="text-xs font-semibold text-gray-900">{receipt.receiptdate || "-"}</span>
                                                        </div>
                                                        <div className="flex items-baseline gap-1">
                                                            <span className="text-[10px] text-gray-500 uppercase font-medium shrink-0">Status:</span>
                                                            <span className="text-xs font-semibold text-gray-900">{receipt.status || "-"}</span>
                                                        </div>
                                                    </div>

                                                    {/* Row Last: Edit/Delete Buttons - Smaller and Tighter */}
                                                    {/* <div className="flex items-center justify-end gap-0.5 pt-1">
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            className="h-8 w-8 hover:bg-blue-50"
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                onEditReceipt(receipt);
                                                            }}
                                                            title="Edit Receipt"
                                                        >
                                                            <Pencil className="h-4 w-4 text-blue-600" />
                                                        </Button>
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            className="h-8 w-8 hover:bg-red-50"
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                onDeleteReceipt(receipt);
                                                            }}
                                                            title="Delete Receipt"
                                                        >
                                                            <Trash2 className="h-4 w-4 text-red-600" />
                                                        </Button>
                                                    </div> */}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Verification Action Section */}
                        {(deposit.status === isDepositVerificationPending && (
                            (deposit.typeOfDeposit === isBranchDeposit && canAccessCategory("ApproveRejectCashAP")) ||
                            (deposit.typeOfDeposit !== isBranchDeposit && canAccessCategory("ApproveRejectDepositsVP"))
                        )) && (
                            <div className="mt-8 pt-8 border-t border-gray-200 space-y-5 px-1 pb-8 ">
                                <div className="space-y-2">
                                    <Label className="text-sm font-bold text-gray-900 flex items-center gap-2 ">
                                        Remarks
                                        <span className="text-red-500">*</span>
                                    </Label>
                                    <Textarea
                                        placeholder="Enter remarks for approval or rejection..."
                                        className="min-h-[100px] bg-gray-50/50 border-gray-200 transition-all resize-none text-sm rounded-lg"
                                        value={remarks}
                                        onChange={(e) => setRemarks(e.target.value)}
                                    />
                                </div>
                                <div className={cn(
                                    "grid gap-3",
                                    (showApprove && showReject) ? "grid-cols-3" : "grid-cols-2"
                                )}>
                                    <Button
                                        variant="outline"
                                        className="px-6 h-9 font-semibold text-gray-700 border-gray-300"
                                        onClick={() => onOpenChange(false)}
                                        disabled={isSubmitting}
                                    >
                                        Cancel
                                    </Button>
                                    {showReject && (
                                        <Button
                                            className="px-6 h-9 font-semibold bg-rose-600 hover:bg-rose-700 text-white shadow-sm transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                                            disabled={!remarks.trim() || isSubmitting}
                                            onClick={async () => {
                                                if (onSubmission) {
                                                    await onSubmission({
                                                        deposit,
                                                        remarks,
                                                        isAcceptancePending,
                                                        decision: "REJECT" as const,
                                                        onSuccess: () => {
                                                            setRemarks("");
                                                            onSuccess?.();
                                                        },
                                                        onClose: onOpenChange
                                                    });
                                                }
                                            }}
                                        >
                                            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Reject All"}
                                        </Button>
                                    )}
                                    {showApprove && (
                                        <Button
                                            className="px-6 h-9 font-semibold bg-blue-800 hover:bg-blue-900 text-white shadow-sm transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                                            disabled={!remarks.trim() || isSubmitting}
                                            onClick={async () => {
                                                if (onSubmission) {
                                                    await onSubmission({
                                                        deposit,
                                                        remarks,
                                                        isAcceptancePending,
                                                        decision: isAcceptancePending ? "ACCEPT" as const : "APPROVE" as const,
                                                        onSuccess: () => {
                                                            setRemarks("");
                                                            onSuccess?.();
                                                        },
                                                        onClose: onOpenChange
                                                    });
                                                }
                                            }}
                                        >
                                            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Accept All"}
                                        </Button>
                                    )}
                                </div>
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="flex items-center justify-center p-8">
                        <p className="text-muted-foreground">No deposit details available.</p>
                    </div>
                )}
            </SheetContent>
        </Sheet>
    );
}