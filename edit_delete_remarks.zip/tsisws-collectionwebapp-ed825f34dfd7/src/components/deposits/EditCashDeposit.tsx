import { useState, useMemo } from "react";
import { format } from "date-fns";
import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetDescription
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
    Calendar as CalendarIcon,
    Loader2,
    PlusCircle,
    MinusCircle
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Deposit, CollReceipt, Task } from "@/lib/types";
import { AddTasksModal } from "@/components/deposits/AddTasksModal";

interface EditCashDepositProps {
    isOpen: boolean;
    onOpenChange: (open: boolean) => void;
    loading: boolean;
    isSaving: boolean;
    deposit: Deposit | null;
    editDate: Date | undefined;
    setEditDate: (date: Date | undefined) => void;
    editTime: string;
    setEditTime: (time: string) => void;
    editRemarks: string;
    setEditRemarks: (remarks: string) => void;
    editLinkedReceipts: CollReceipt[];
    removedReceipts: CollReceipt[];
    handleRemoveReceipt: (id: string) => void;
    handleAddReceipt: (id: string) => void;
    onAddTasks: (tasks: Task[]) => void;
    onSave: () => void;
    initialLockedReceiptIds: string[];
}

export function EditCashDeposit({
    isOpen,
    onOpenChange,
    loading,
    isSaving,
    deposit,
    editDate,
    setEditDate,
    editTime,
    setEditTime,
    editRemarks,
    setEditRemarks,
    editLinkedReceipts,
    removedReceipts,
    handleRemoveReceipt,
    handleAddReceipt,
    onAddTasks,
    onSave,
    initialLockedReceiptIds
}: EditCashDepositProps) {
    const [isAddTasksModalOpen, setIsAddTasksModalOpen] = useState(false);
    const [isDatePickerOpen, setIsDatePickerOpen] = useState(false);

    const handleAddTasks = (tasks: Task[]) => {
        onAddTasks(tasks);
        setIsAddTasksModalOpen(false);
    };

    // Get branch name from deposit
    const branchName = deposit?.bankCollReceipts?.[0]?.branchName;

    // Convert already linked receipts to Task objects for the modal
    const linkedTasks: Task[] = useMemo(() => editLinkedReceipts.map(receipt => ({
        id: receipt.id,
        taskNumber: receipt.receiptNo?.split('-').pop() || "",
        receiptNo: receipt.receiptNo || "",
        lan: receipt.lanNumber || "",
        receivedAmount: Number(receipt.totalAmount) || receipt.collectedEmiAmount || 0,
        branch: receipt.branchName || "",
        dateCreatedRaw: receipt.dateEntered || "",
        lastModifiedRaw: receipt.dateModified || "",
        receipt: receipt
    } as Task)), [editLinkedReceipts]);

    return (
        <Sheet open={isOpen} onOpenChange={onOpenChange}>
            <SheetContent side="right" className="w-[500px] sm:w-[500px] bg-white p-0 flex flex-col">
                {loading ? (
                    <div className="flex flex-col h-full">
                        <SheetHeader className="p-6 border-b">
                            <SheetTitle className="text-xl font-bold">Edit Cash Deposit</SheetTitle>
                            <SheetDescription>Loading deposit details...</SheetDescription>
                        </SheetHeader>
                        <div className="flex-1 flex items-center justify-center">
                            <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
                        </div>
                    </div>
                ) : deposit ? (
                    <>
                        <div className="p-6 overflow-y-auto flex-1">
                            <SheetHeader className="mb-6 relative">
                                <SheetTitle className="text-2xl font-bold text-gray-900">
                                    Edit Cash Deposit
                                </SheetTitle>
                                <SheetDescription className="text-sm text-gray-500 mt-1">
                                    Modify the date and linked tasks for slip #{deposit.depositSlipno || "-"}.
                                </SheetDescription>
                            </SheetHeader>

                            <div className="space-y-6">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label className="text-sm font-semibold text-gray-700">Deposit Date</Label>
                                        <Popover open={isDatePickerOpen} onOpenChange={setIsDatePickerOpen}>
                                            <PopoverTrigger asChild>
                                                <Button
                                                    variant="outline"
                                                    className={cn(
                                                        "w-full justify-start text-left font-normal border-gray-200 h-11 px-3",
                                                        !editDate && "text-muted-foreground"
                                                    )}
                                                >
                                                    <CalendarIcon className="mr-2 h-4 w-4 text-gray-400 shrink-0" />
                                                    <span className="truncate">
                                                        {editDate ? (
                                                            format(editDate as Date, "PP")
                                                        ) : (
                                                            "Pick a date"
                                                        )}
                                                    </span>
                                                </Button>
                                            </PopoverTrigger>
                                            <PopoverContent className="w-auto p-0" align="start">
                                                <Calendar
                                                    mode="single"
                                                    selected={editDate}
                                                    onSelect={(date) => {
                                                        setEditDate(date);
                                                        setIsDatePickerOpen(false);
                                                    }}
                                                    initialFocus
                                                    disabled={{ after: new Date() }}
                                                />
                                            </PopoverContent>
                                        </Popover>
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-sm font-semibold text-gray-700">Deposit Time</Label>
                                        <Input
                                            type="time"
                                            value={(() => {
                                                if (!editTime) return "";
                                                const match = editTime.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
                                                if (!match) return editTime.slice(0, 5);
                                                let hours = parseInt(match[1], 10);
                                                const minutes = match[2];
                                                const isPM = match[3].toUpperCase() === "PM";
                                                if (isPM && hours < 12) hours += 12;
                                                if (!isPM && hours === 12) hours = 0;
                                                return `${hours.toString().padStart(2, '0')}:${minutes}`;
                                            })()}
                                            onChange={(e) => {
                                                const val = e.target.value;
                                                if (!val) {
                                                    setEditTime("");
                                                    return;
                                                }
                                                const [h, m] = val.split(':');
                                                let hours = parseInt(h, 10);
                                                const ampm = hours >= 12 ? 'PM' : 'AM';
                                                hours = hours % 12;
                                                hours = hours ? hours : 12;
                                                setEditTime(`${hours.toString().padStart(2, '0')}:${m} ${ampm}`);
                                            }}
                                            className="border-gray-200 h-11 focus:ring-blue-500"
                                        />
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label className="text-sm font-semibold text-gray-700">Deposited By</Label>
                                        <div
                                            className="border border-gray-200 bg-gray-50 h-11 rounded-md px-3 flex items-center text-[12px] text-gray-900"
                                            title={deposit.bankDepositedBy || deposit.userName || ""}
                                        >
                                            {deposit.bankDepositedBy || deposit.userName || ""}
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-sm font-semibold text-gray-700">Bank & Branch Name</Label>
                                        <div
                                            className="border border-gray-200 bg-gray-50 h-11 rounded-md px-3 flex items-center text-[12px] text-gray-900"
                                            title={deposit.bankName?.toUpperCase()}
                                        >
                                            {deposit.bankName?.toUpperCase()}
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <Label className="text-sm font-semibold text-gray-700">Deposit Remarks</Label>
                                    <Textarea
                                        placeholder="Enter remarks for this deposit..."
                                        className="min-h-[100px] border-gray-200 resize-none"
                                        value={editRemarks}
                                        onChange={(e) => setEditRemarks(e.target.value)}
                                    />
                                </div>

                                {(() => {
                                    const activeReceipts = editLinkedReceipts.filter(r => r.deleted !== true);
                                    const deletedReceipts = editLinkedReceipts.filter(r => r.deleted === true);

                                    return (
                                        <>
                                            {/* Currently Linked Tasks - only non-deleted */}
                                            <div className="space-y-4 pt-2">
                                                <div className="flex items-center justify-between">
                                                    <h3 className="text-sm font-bold text-gray-900">
                                                        Currently Linked Tasks ({activeReceipts.length})
                                                    </h3>
                                                    <Button
                                                        variant="outline"
                                                        size="sm"
                                                        className="gap-2 border-gray-300 h-9 font-semibold"
                                                        onClick={() => setIsAddTasksModalOpen(true)}
                                                    >
                                                        <PlusCircle className="h-4 w-4" />
                                                        Add Tasks
                                                    </Button>
                                                </div>

                                                <div className="space-y-3 border rounded-lg p-3">
                                                    {activeReceipts.map((receipt, index) => (
                                                        <div key={receipt.id} className={cn("flex items-center justify-between py-2", index !== 0 && "border-t border-gray-100 mt-2 Pt-2")}>
                                                            <div className="space-y-1">
                                                                <div className="flex flex-col text-xs text-black-400 font-bold">
                                                                    <span>Receipt : {receipt.receiptNo || "N/A"}</span>
                                                                    <span>{receipt.lanNumber || "N/A"}</span>
                                                                </div>
                                                            </div>
                                                            <div className="flex items-center gap-4">
                                                                <p className="text-sm font-bold text-gray-900">
                                                                    ₹{((Number(receipt.totalAmount) || receipt.collectedEmiAmount || 0)).toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                                                                </p>
                                                                <button
                                                                    className="text-red-500 hover:text-red-600 transition-colors"
                                                                    onClick={() => handleRemoveReceipt(receipt.id)}
                                                                >
                                                                    <MinusCircle className="h-5 w-5" />
                                                                </button>
                                                            </div>
                                                        </div>
                                                    ))}
                                                    {activeReceipts.length === 0 && (
                                                        <p className="text-sm text-center text-muted-foreground py-4">No tasks linked</p>
                                                    )}
                                                </div>
                                            </div>

                                            {/* Removed Tasks (manually removed in this session) */}
                                            {removedReceipts.length > 0 && (
                                                <div className="space-y-4 pt-2">
                                                    <div className="flex items-center justify-between">
                                                        <h3 className="text-sm font-bold text-gray-900">
                                                            Removed Tasks ({removedReceipts.length})
                                                        </h3>
                                                    </div>

                                                    <div className="space-y-3 border rounded-lg p-3">
                                                        {removedReceipts.map((receipt, index) => (
                                                            <div key={receipt.id} className={cn("flex items-center justify-between py-2", index !== 0 && "border-t border-gray-100 mt-2 Pt-2")}>
                                                                <div className="space-y-1">

                                                                    <div className="flex flex-col text-xs text-black-400 font-bold">
                                                                        <span>Receipt : {receipt.receiptNo || "N/A"}</span>
                                                                        <span>{receipt.lanNumber || "N/A"}</span>
                                                                    </div>
                                                                </div>
                                                                <div className="flex items-center gap-4">
                                                                    <p className="text-sm font-bold text-gray-900">
                                                                        ₹{((Number(receipt.totalAmount) || receipt.collectedEmiAmount || 0)).toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                                                                    </p>
                                                                    <button
                                                                        className="text-green-500 hover:text-green-600 transition-colors"
                                                                        onClick={() => handleAddReceipt(receipt.id)}
                                                                    >
                                                                        <PlusCircle className="h-5 w-5" />
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            )}

                                            {/* Deleted Tasks (deleted===true from server) - read-only */}
                                            {deletedReceipts.length > 0 && (
                                                <div className="space-y-4 pt-2">
                                                    <div className="flex items-center justify-between">
                                                        <h3 className="text-sm font-bold text-gray-900">
                                                            Deleted Tasks ({deletedReceipts.length})
                                                        </h3>
                                                    </div>

                                                    <div className="space-y-3 border border-red-100 rounded-lg p-3 bg-red-50/40">
                                                        {deletedReceipts.map((receipt, index) => (
                                                            <div key={receipt.id} className={cn("flex items-center justify-between py-2", index !== 0 && "border-t border-red-100 mt-2")}>
                                                                <div className="space-y-1">
                                                                    <div className="flex flex-col text-xs text-gray-600 line-through font-bold">
                                                                        <span>Receipt : {receipt.receiptNo || "N/A"}</span>
                                                                        <span>{receipt.lanNumber || "N/A"}</span>
                                                                    </div>
                                                                </div>
                                                                <div className="flex items-center gap-4">
                                                                    <p className="text-sm font-bold text-gray-600">
                                                                        ₹{((Number(receipt.totalAmount) || receipt.collectedEmiAmount || 0)).toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                                                                    </p>
                                                                    <span className="text-xs text-red-400 font-medium px-2 py-0.5 bg-red-100 rounded-full">Deleted</span>
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            )}

                                        </>
                                    );
                                })()}
                            </div>
                        </div>

                        <div className="px-6 pt-4 pb-3 border-t border-gray-200 bg-white sticky bottom-0">
                            {(() => {
                                const activeReceipts = editLinkedReceipts.filter(r => r.deleted !== true);
                                return (
                                    <div className="flex items-center justify-between pb-3 border-b border-gray-100">
                                        <span className="text-sm font-bold text-gray-900">New Total Amount:</span>
                                        <span className="text-sm font-bold text-gray-900">
                                            ₹{(activeReceipts.reduce((total, receipt) => total + (Number(receipt.totalAmount) || receipt.collectedEmiAmount || 0), 0) || 0).toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                                        </span>
                                    </div>
                                );
                            })()}
                            <div className="flex justify-end gap-3 pt-3">
                                <Button
                                    variant="outline"
                                    className="px-6 h-11 font-semibold text-gray-700 border-gray-300"
                                    onClick={() => onOpenChange(false)}
                                    disabled={isSaving}
                                >
                                    Cancel
                                </Button>
                                <Button
                                    className="px-6 h-11 font-semibold bg-blue-600 hover:bg-blue-700 text-white gap-2"
                                    onClick={onSave}
                                    disabled={isSaving}
                                >
                                    {isSaving && <Loader2 className="h-4 w-4 animate-spin" />}
                                    Save Changes
                                </Button>
                            </div>
                        </div>
                    </>
                ) : (
                    <div className="flex flex-col h-full">
                        <SheetHeader className="p-6 border-b">
                            <SheetTitle className="text-xl font-bold">Edit Cash Deposit</SheetTitle>
                            <SheetDescription>No deposit details found.</SheetDescription>
                        </SheetHeader>
                        <div className="flex-1 flex items-center justify-center">
                            <p className="text-muted-foreground">No deposit details available.</p>
                        </div>
                    </div>
                )}
            </SheetContent>

            {/* Add Tasks Modal */}
            <AddTasksModal
                isOpen={isAddTasksModalOpen}
                onClose={() => setIsAddTasksModalOpen(false)}
                branchName={branchName}
                initialSelectedTasks={linkedTasks}
                baseTaskIds={initialLockedReceiptIds}
                onAddTasks={handleAddTasks}
            />
        </Sheet>
    );
}
