import type { Case } from "@/lib/types";
import { UnifiedHistorySheet } from "./UnifiedHistorySheet";

interface CaseHistorySheetProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  caseItem: Case | null;
}

export function CaseHistorySheet({
  isOpen,
  onOpenChange,
  caseItem,
}: CaseHistorySheetProps) {
  if (!caseItem) return null;

  return (
    <UnifiedHistorySheet
      isOpen={isOpen}
      onOpenChange={onOpenChange}
      target={{ caseItem }}
      customerName={caseItem.account?.name || "N/A"}
    />
  );
}
