interface HistoryInfoCardProps {
    lanLabel: string;
    customerName: string;
}

export function HistoryInfoCard({ lanLabel, customerName }: HistoryInfoCardProps) {
    return (
        <div className="bg-white rounded-xl p-2 mb-2 grid grid-cols-2 gap-4 shadow-sm border border-gray-100">
            <div className="text-center">
                <p className="text-[15px] font-bold text-gray-900 uppercase">LAN NO</p>
                <p className="text-[13px] text-gray-500 break-all leading-tight">{lanLabel || "N/A"}</p>
            </div>
            <div className="text-center">
                <p className="text-[15px] font-bold text-gray-900 uppercase">CUSTOMER NAME</p>
                <p className="text-[13px] text-gray-500 uppercase line-clamp-1 leading-tight">{customerName || "N/A"}</p>
            </div>
        </div>
    );
}
