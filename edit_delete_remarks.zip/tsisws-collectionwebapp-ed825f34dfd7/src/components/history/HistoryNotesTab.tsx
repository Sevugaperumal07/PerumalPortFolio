import { Loader2, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { NoteCard } from "../dashboard/NoteCard";
import type { NoteFromCriteriaAPI } from "@/lib/services/notes";

interface HistoryNotesTabProps {
    isLoading: boolean;
    error: string | null;
    isEmpty: boolean;
    notes: NoteFromCriteriaAPI[];
    fallbackLabel: string;
    hasMore: boolean;
    isLoadingMore: boolean;
    onLoadMore: () => void;
    onRetry: () => void;
}

export function HistoryNotesTab({
    isLoading,
    error,
    isEmpty,
    notes,
    fallbackLabel,
    hasMore,
    isLoadingMore,
    onLoadMore,
    onRetry,
}: HistoryNotesTabProps) {
    return (
        <div className="flex flex-col h-full bg-transparent">
            {isLoading ? (
                <div className="flex items-center justify-center py-10 bg-white rounded-lg border my-2">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                    <span className="ml-2 text-muted-foreground text-sm">
                        Loading notes...
                    </span>
                </div>
            ) : error ? (
                <div className="text-center py-10 text-red-500 bg-white rounded-lg border my-2">
                    <p className="text-sm">{error}</p>
                    <Button
                        variant="outline"
                        size="sm"
                        className="mt-2"
                        onClick={onRetry}
                    >
                        Retry
                    </Button>
                </div>
            ) : isEmpty ? (
                <div className="text-center py-10 text-muted-foreground bg-white rounded-lg border my-2">
                    <FileText className="h-10 w-10 mx-auto mb-2 text-gray-300" />
                    <p className="text-sm">No notes found for this LAN.</p>
                </div>

            ) : (
                <div className="flex-1 overflow-y-auto pr-1 space-y-3 pb-4">
                    {notes.map((note) => (
                        <NoteCard
                            key={note.id}
                            note={note}
                            fallbackLabel={fallbackLabel}
                        />
                    ))}

                    {hasMore && (
                        <div className="text-center pt-2">
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={onLoadMore}
                                disabled={isLoadingMore}
                            >
                                {isLoadingMore ? (
                                    <>
                                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                                        Loading...
                                    </>
                                ) : (
                                    "Load More"
                                )}
                            </Button>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
