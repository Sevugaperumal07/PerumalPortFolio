import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface MonthNavigationProps {
    onPrevious: () => void;
    onNext: () => void;
    isNextDisabled: boolean;
    isPreviousDisabled: boolean;
}

export function MonthNavigation({ onPrevious, onNext, isNextDisabled, isPreviousDisabled }: MonthNavigationProps) {
    return (
        <div className="flex justify-between items-center gap-4 py-4 mt-auto sticky bottom-0 bg-transparent">
            <Button
                onClick={onPrevious}
                disabled={isPreviousDisabled}
                variant="default"
                className="flex-1 bg-[#5c8aff] hover:bg-blue-600 text-white font-bold h-11 rounded-xl shadow-md border-0 text-[15px] disabled:opacity-50 disabled:bg-gray-400"
            >
                <ChevronLeft className="mr-2 h-5 w-5" />
                Previous
            </Button>
            <Button
                onClick={onNext}
                disabled={isNextDisabled}
                variant="default"
                className="flex-1 bg-[#5c8aff] hover:bg-blue-600 text-white font-bold h-11 rounded-xl shadow-md border-0 text-[15px] disabled:opacity-50 disabled:bg-gray-400"
            >
                Next
                <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
        </div>
    );
}
