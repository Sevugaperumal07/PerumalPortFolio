import { useState, useMemo, useEffect } from "react";
import { Loader2, AlertCircle, ChevronDown, Filter, Info, User, Settings, Database, Receipt, Landmark, ClipboardList, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { HistoryPagination } from "@/components/common/HistoryPagination";
import { cn } from "@/lib/utils";
import type { CaseAuditHistory } from "@/lib/types";

// Helper functions for parsing and formatting
const sp = (s: string) => { try { return JSON.parse(s); } catch { return {}; } };
const fmt = (v: any) => {
    if (v === null || v === undefined) return "—";
    if (typeof v === "boolean") return v ? "Yes" : "No";
    if (typeof v === "number" && !isNaN(v)) return v.toLocaleString("en-IN");
    return String(v);
};
const fmtAmt = (v: any) => v != null ? `₹${Number(v).toLocaleString("en-IN")}` : "—";
const fmtDT = (iso: string) => {
    try {
        const d = new Date(iso);
        return {
            date: d.toLocaleDateString("en-IN", { day: "2-digit", month: "2-digit", year: "numeric" }),
            time: d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: true }).toUpperCase(),
        };
    } catch { return { date: iso, time: "" }; }
};

const SKIP = new Set(["selfieImage", "bankDepositSlip", "depositSlip", "paymentImage", "receiptPdf", "serviceChargeTypeId", "serviceChargeType", "latitude", "longitude", "hiveId", "accountId", "caseNo", "id", "dateEntered", "receiptStoredDateTime", "receiptGenerationTime", "cases", "user", "currencyId", "pay_EMI_only", "receivedSumInWords", "receivedSumOfRupees", "userId"]);
const ENTITY_CONFIG: Record<string, { cls: string; icon: any; label: string }> = {
    RECEIPT: { cls: "bg-blue-50 text-blue-600 border-blue-200", icon: Receipt, label: "Receipt" },
    DEPOSIT_SLIP: { cls: "bg-purple-50 text-purple-600 border-purple-200", icon: Landmark, label: "Deposit Slip" },
    CASE: { cls: "bg-yellow-50 text-yellow-600 border-yellow-200", icon: ClipboardList, label: "Case" },
    CASE_DISPOSITION: { cls: "bg-amber-50 text-amber-600 border-amber-200", icon: ClipboardList, label: "Disposition" },
    ACCOUNT: { cls: "bg-green-50 text-green-600 border-green-200", icon: User, label: "Account" },
    USER_CASE: { cls: "bg-gray-50 text-gray-600 border-gray-200", icon: Settings, label: "User Case" },
};

const ACTION_STYLES: Record<string, string> = {
    CREATE: "bg-green-600",
    CREATED: "bg-green-600",
    UPDATE: "bg-amber-600",
    UPDATED: "bg-amber-600",
    DELETE: "bg-red-600",
    DELETED: "bg-red-600",
    APPROVE: "bg-green-600",
    REJECT: "bg-red-600",
    ASSIGN: "bg-sky-600",
    COLLECT: "bg-purple-600",
};

function getEntityCfg(type: string) {
    return ENTITY_CONFIG[type] || { cls: "bg-gray-100 text-gray-600 border-gray-200", icon: Database, label: type };
}

function getActionClass(action: string) {
    return ACTION_STYLES[action.toUpperCase()] || "bg-gray-500";
}

function DiffPanel({ 
    fieldChanges, 
    version, 
    entityType,
    onViewDepositDetails 
}: { 
    fieldChanges: string | null; 
    version: number;
    entityType: string;
    onViewDepositDetails?: (slipNo: string) => void;
}) {
    const diffs = useMemo(() => {
        if (!fieldChanges) return [];
        const fc = sp(fieldChanges);
        return Object.entries(fc).map(([key, value]: [string, any]) => {
            if (SKIP.has(key)) return null;
            const oldVal = fmt(value.oldValue);
            const newVal = fmt(value.newValue);
            if (oldVal === newVal) return null;
            return { key, old: oldVal, new: newVal };
        }).filter(Boolean);
    }, [fieldChanges]);

    if (version === 1 && diffs.length === 0) {
        return <div className="text-center p-6 text-gray-500 text-sm bg-white rounded-lg border border-dashed">This is a create event — full snapshot shown in Details.</div>;
    }

    if (diffs.length === 0) {
        return <div className="text-center p-6 text-gray-500 text-sm bg-white rounded-lg border">✓ No field differences recorded for this event.</div>;
    }

    return (
        <div className="space-y-3">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-gray-900">Field Changes</span>
                    <span className="bg-red-50 text-red-600 text-[10px] font-bold px-1.5 py-0.5 rounded-full border border-red-100">{diffs.length}</span>
                </div>
                <div className="flex gap-3 text-[9px] font-bold uppercase tracking-wider text-gray-700">
                    <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded bg-red-200" /> Before</span>
                    <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded bg-green-200" /> After</span>
                </div>
            </div>
            <div className="grid grid-cols-1 gap-1.5">
                {diffs.map((d: any) => (
                    <div key={d.key} className="bg-white rounded-lg overflow-hidden border border-gray-100/80 shadow-sm">
                        <div className="text-[9px] font-bold text-gray-700 uppercase tracking-widest px-2.5 py-1 bg-gray-50/50 border-b border-gray-100/50">
                            {d.key.replace(/([A-Z])/g, " $1").trim()}
                        </div>
                        <div className="grid grid-cols-2">
                            <div className="px-2.5 py-2 text-xs font-medium bg-red-50/20 text-red-700 border-r border-red-100/50 line-through decoration-red-400/50 break-all text-left flex flex-col items-start">
                                <span className="text-[8px] font-bold uppercase opacity-60 block mb-0.5 no-underline">Before</span>
                                {d.key === "bankDepositSlipno" && d.old !== "—" && entityType === "RECEIPT" && onViewDepositDetails ? (
                                    <button 
                                        onClick={() => onViewDepositDetails(d.old)}
                                        className="text-blue-600 hover:text-blue-800 underline decoration-blue-600 text-left"
                                    >
                                        {d.old}
                                    </button>
                                ) : d.old}
                            </div>
                            <div className="px-2.5 py-2 text-xs font-semibold bg-green-50/20 text-green-700 break-all text-left flex flex-col items-start">
                                <span className="text-[8px] font-bold uppercase opacity-60 block mb-0.5">After</span>
                                {d.key === "bankDepositSlipno" && d.new !== "—" && entityType === "RECEIPT" && onViewDepositDetails ? (
                                    <button 
                                        onClick={() => onViewDepositDetails(d.new)}
                                        className="text-blue-600 hover:text-blue-800 underline decoration-blue-600 text-left"
                                    >
                                        {d.new}
                                    </button>
                                ) : d.new}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

function DetailGrid({ entry, currentData }: { entry: CaseAuditHistory, currentData: any }) {
    const cells = useMemo(() => {
        const type = entry.entityType;
        const d = currentData;
        const base: any[] = [];

        if (type === "RECEIPT") {
            base.push(
                { key: "Receipt No", val: d.receiptNo, cls: "text-blue-600" },
                { key: "Amount", val: fmtAmt(d.totalAmount), cls: "text-blue-600" },
                { key: "Payment Type", val: d.paymentType },
                { key: "Status", val: d.status, cls: "text-green-600" },
                { key: "Acceptance", val: d.acceptanceStatus },
                { key: "Customer", val: d.customerName },
                { key: "Branch", val: d.branchName },
                { key: "Collected By", val: d.collectedBy },
                { key: "Receipt Date", val: d.receiptdate },
                { key: "Txn Ref", val: d.transactionRefNo || "N/A", wide: true, sm: true }
            );
        } else if (type === "CASE") {
            base.push(
                { key: "Loan No", val: d.loanNumber, cls: "text-blue-600", sm: true },
                { key: "Case No", val: String(d.caseNumber || ""), cls: "text-blue-600" },
                { key: "State / Status", val: `${d.state || "N/A"} / ${d.status || "N/A"}`, cls: "text-green-600" },
                { key: "Collected", val: fmtAmt(d.amountCollected), cls: "text-blue-600" },
                { key: "EMI Overdue", val: fmtAmt(d.emiOverdue), cls: "text-red-600" },
                { key: "Total Overdue", val: fmtAmt(d.totalOverdue), cls: "text-red-600" },
                { key: "DPD", val: String(d.dpd || "N/A") }
            );
        } else {
            // Generic fallback
            Object.keys(d).forEach(k => {
                if (!SKIP.has(k) && d[k] != null && d[k] !== "") {
                    base.push({ key: k.replace(/([A-Z])/g, " $1").trim(), val: fmt(d[k]) });
                }
            });
        }
        return base.filter((c: any) => c.val != null && c.val !== "—");
    }, [entry.entityType, currentData]);

    return (
        <div className="space-y-3">
            <div className="grid grid-cols-2 gap-1.5">
                {cells.slice(0, 12).map((c: any, i: number) => (
                    <div key={i} className={cn("bg-white border border-gray-100/80 rounded-lg p-2.5 shadow-sm", c.wide && "col-span-2")}>
                        <div className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-0.5">{c.key}</div>
                        <div className={cn("font-bold ", c.sm ? "text-[10px]" : "text-xs", c.cls)} title={String(c.val)}>{c.val}</div>
                    </div>
                ))}
            </div>
            {currentData.remarks && (
                <div className="text-[11px] text-gray-500 italic bg-gray-50/50 p-2.5 rounded-lg border border-gray-100/50">
                    <span className="font-bold text-gray-600 not-italic mr-1.5 uppercase tracking-tighter text-[9px]">Remarks:</span> "{currentData.remarks}"
                </div>
            )}
        </div>
    );
}

function EventItem({ 
    entry, 
    isOpen, 
    onToggle,
    onViewDepositDetails
}: { 
    entry: CaseAuditHistory; 
    isOpen: boolean; 
    onToggle: () => void; 
    onViewDepositDetails?: (slipNo: string) => void;
}) {
    const [activeTab, setActiveTab] = useState("changes");
    const currentData = useMemo(() => sp(entry.currentData), [entry.currentData]);
    const { date, time } = fmtDT(entry.changedAt);
    const cfg = getEntityCfg(entry.entityType);
    const amt = currentData.totalAmount || currentData.amountCollected;

    return (
        <div className={cn(
            "group border rounded-2xl mb-3 bg-gray-50 hover:bg-white transition-all duration-300 overflow-hidden w-[465px]",
            isOpen ? "border-blue-200 shadow-xl shadow-blue-500/5 ring-1 ring-blue-500/5" : "border-blue-200 hover:border-blue-200 hover:shadow-lg hover:shadow-gray-200/50"
        )}>
            {/* Header Row */}
            <div 
                onClick={onToggle} 
                className="flex flex-nowrap items-center p-3 gap-2 cursor-pointer select-none"
            >
                <div className={cn("flex items-center justify-center gap-1 px-2.5 py-0.5 rounded-full border text-[9px] font-bold uppercase tracking-wider whitespace-nowrap w-[90px] flex-none", cfg.cls)}>
                    <cfg.icon className="w-3 h-3 stroke-[2]" />
                    {cfg.label}
                </div>
                
                <span className={cn("text-[9px] font-black text-white px-2 py-0.5 rounded uppercase tracking-[0.02em] min-w-[70px] text-center shadow-sm ml-2 flex-none", getActionClass(entry.action))}>
                    {entry.action.replace("CREATED", "CREATE").replace("UPDATED", "UPDATE").replace("DELETED", "DELETE")}
                </span>

                <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1.5 overflow-hidden w-full pr-4">
                        <span className="text-xs font-black text-blue-600 truncate">{amt != null ? fmtAmt(amt) : "N/A"}</span>
                        <span className="text-[9px] font-bold text-gray-400 bg-gray-50 px-1.5 py-0.2 rounded border border-gray-100 uppercase tracking-tighter whitespace-nowrap">v{entry.version}</span>
                    </div>
                </div>

                <div className="flex items-center gap-3 ml-auto">


                    <div className="text-right border-l border-gray-100 pl-3 hidden sm:block">
                        <div className="text-xs font-black text-blue-500 leading-none">{time}</div>
                        <div className="text-[9px] font-bold text-gray-400 mt-0.5 uppercase leading-none tracking-tighter">{date}</div>
                    </div>

                    <ChevronDown className={cn("w-4 h-4 text-gray-300 transition-transform duration-500 ease-out sm:ml-1", isOpen && "rotate-180 text-blue-400")} />
                </div>
            </div>

            {/* Expanded Content */}
            {isOpen && (
                <>
                    <div className="bg-gray-50/50 border-t border-gray-100 p-5 space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
                        <div className="flex items-center justify-between gap-4">
                            <div className="flex p-1 bg-gray-100/80 rounded-xl w-fit border border-gray-200/50">
                                {[
                                    { id: "changes", label: "Changes", icon: Filter, count: sp(entry.fieldChanges || "{}") ? Object.keys(sp(entry.fieldChanges || "{}")).length : 0 },
                                    { id: "details", label: "Details", icon: Info },
                                ].map((t) => (
                                    <button
                                        key={t.id}
                                        onClick={() => setActiveTab(t.id)}
                                        className={cn(
                                            "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all duration-200 whitespace-nowrap",
                                            activeTab === t.id 
                                                ? "bg-white text-blue-600 shadow-sm ring-1 ring-gray-200" 
                                                : "text-gray-500 hover:text-gray-700 hover:bg-white/50"
                                        )}
                                    >
                                        <t.icon className="w-3 h-3" />
                                        {t.label}
                                        {t.id === "changes" && (t.count ?? 0) > 0 && (
                                            <span className={cn(
                                                "ml-1 w-1.5 h-1.5 rounded-full bg-red-500 ring-2",
                                                activeTab === t.id ? "ring-white" : "ring-gray-100"
                                            )} />
                                        )}
                                    </button>
                                ))}
                            </div>

                            <div className="flex items-center gap-1.5 text-gray-500 py-1">
                                <span className="text-[9px] font-bold text-gray-700 uppercase tracking-tighter">Modified By :</span>
                                {entry.isSystem ? (
                                    <div className="flex items-center gap-1 px-0.5">
                                        <Settings className="w-2.5 h-2.5 text-gray-400" />
                                        <span className="text-[9px] font-bold text-gray-500 uppercase">System</span>
                                    </div>
                                ) : (
                                    <div className="flex items-center gap-1 px-0.5 max-w-[100px]">
                                        <User className="w-2.5 h-2.5 text-blue-600" />
                                        <span className="text-[10px] font-bold text-gray-800 truncate uppercase tracking-tight"
                                            title={entry.modifiedUserName || "—"}
                                        >{entry.modifiedUserName || "—"}</span>
                                    </div>
                                )}
                            </div>
                        </div>

                        {activeTab === "details" && <DetailGrid entry={entry} currentData={currentData} />}
                        {activeTab === "changes" && (
                            <DiffPanel 
                                fieldChanges={entry.fieldChanges} 
                                version={entry.version} 
                                entityType={entry.entityType}
                                onViewDepositDetails={onViewDepositDetails}
                            />
                        )}
                    </div>
                </>
            )}
        </div>
    );
}

interface ReceiptAuditHistoryProps {
    history: CaseAuditHistory[];
    isLoading: boolean;
    error: string | null;
    onRetry: () => void;
    // Pagination props
    currentPage: number;
    totalPages: number;
    totalRecords: number;
    hasNext: boolean;
    hasPrevious: boolean;
    onPageChange?: (page: number) => void;
    showSystem: boolean;
    setShowSystem: (show: boolean) => void;
    entityType: string;
    setEntityType: (type: string) => void;
    onViewDepositDetails?: (slipNo: string) => void;
}

export function ReceiptAuditHistory({
    history,
    isLoading,
    error,
    onRetry,
    currentPage,
    totalPages,
    totalRecords,
    hasNext,
    hasPrevious,
    showSystem,
    setShowSystem,
    entityType,
    setEntityType,
    onPageChange,
    onViewDepositDetails
}: ReceiptAuditHistoryProps) {
    const [expandedId, setExpandedId] = useState<string | null>(null);

    // Reset expanded row when history changes
    useEffect(() => {
        setExpandedId(null);
    }, [history]);

    const filters = useMemo(() => [
        { id: "ALL", label: "All", icon: Database },
        ...Object.entries(ENTITY_CONFIG).map(([id, cfg]) => ({
            id,
            label: cfg.label,
            icon: cfg.icon,
            cls: cfg.cls
        }))
    ], []);


    return (
        <div className="flex flex-col h-full max-w-[630px] bg-slate-50/50">
            {/* Toolbar */}
            <div className="sticky top-0 z-20 backdrop-blur-md border-b border-gray-100 px-4 py-1 space-y-3 shadow-sm rounded-t-2xl">
                <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap gap-2 items-center">
                        {filters.map((f: any) => (
                            <button
                                key={f.id}
                                onClick={() => setEntityType(f.id)}
                                className={cn(
                                    "flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold transition-all border",
                                    entityType === f.id
                                        ? "bg-blue-600 text-white border-blue-600"
                                        : "bg-white text-gray-500 border-gray-100 hover:border-gray-200"
                                )}
                            >
                                <f.icon className={cn("w-3 h-3 stroke-[2]", entityType === f.id ? "text-white" : (f.id === "ALL" ? "text-gray-400" : (f.cls?.split(" ")[1] || "text-gray-400")))} />
                                {f.label}
                            </button>
                        ))}
                    </div>

                    <label className="flex items-center gap-2 cursor-pointer group ml-auto">
                        <span className="text-[11px] font-bold text-gray-700 group-hover:text-gray-600 transition-colors uppercase tracking-wider">Show System Actions</span>
                        <div className="relative">
                            <input
                                type="checkbox"
                                className="sr-only"
                                checked={showSystem}
                                onChange={() => setShowSystem(!showSystem)}
                            />
                            <div className={cn("block w-10 h-6 rounded-full transition-colors", showSystem ? "bg-blue-600" : "bg-gray-200")} />
                            <div className={cn("absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform shadow-sm", showSystem && "translate-x-4")} />
                        </div>
                    </label>
                </div>
            </div>

            {/* List Body */}
            <div className="flex-1 overflow-y-auto overflow-x-hidden pl-0 pr-4 py-4 scrollbar-thin">
                {isLoading ? (
                    <div className="flex flex-col items-center justify-center py-20 animate-pulse">
                        <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center mb-4">
                            <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
                        </div>
                        <span className="text-sm font-bold text-gray-400 uppercase tracking-widest">Loading History...</span>
                    </div>
                ) : error ? (
                    <div className="bg-white p-10 rounded-3xl border border-red-50 text-center shadow-xl shadow-red-500/5">
                        <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
                            <AlertCircle className="h-8 w-8 text-red-500" />
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 mb-2">Oops! Something went wrong</h3>
                        <p className="text-sm text-gray-500 mb-6">{error}</p>
                        <Button
                            onClick={onRetry}
                            className="bg-gray-900 hover:bg-black text-white px-8 py-6 rounded-2xl font-bold shadow-xl shadow-gray-900/20 transition-all border-0 ring-offset-2 focus:ring-2 focus:ring-gray-900"
                        >
                            Retry Request
                        </Button>
                    </div>
                ) : history.length === 0 ? (
                    <div className="flex-1 flex flex-col items-center justify-center py-10 text-muted-foreground bg-white rounded-lg border my-2">
                        <Clock className="h-10 w-10 mx-auto mb-2 text-gray-300" />
                        <p className="text-sm">No Audit History found for this search.</p>
                    </div>
                ) : (
                    <div className="space-y-4 w-[500px]">
                        {history.map((item) => {
                            const itemKey = `${item.id}-${item.version}`;
                            return (
                                <EventItem 
                                    key={itemKey} 
                                    entry={item} 
                                    isOpen={expandedId === itemKey}
                                    onToggle={() => setExpandedId(expandedId === itemKey ? null : itemKey)}
                                    onViewDepositDetails={onViewDepositDetails}
                                />
                            );
                        })}
                    </div>
                )}
            </div>

            {/* Pagination */}
            {onPageChange && (
                <div className="px-5 border-t border-gray-100 rounded-b-2xl">
                    <HistoryPagination
                        currentPage={currentPage}
                        totalPages={totalPages}
                        totalRecords={totalRecords}
                        hasNext={hasNext}
                        hasPrevious={hasPrevious}
                        onPageChange={onPageChange}
                        isLoading={isLoading}
                    />
                </div>
            )}
        </div>
    );
}

