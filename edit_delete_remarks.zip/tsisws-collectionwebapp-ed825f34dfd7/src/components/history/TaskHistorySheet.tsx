import type { Task } from "@/lib/types";
import { UnifiedHistorySheet } from "./UnifiedHistorySheet";

interface TaskHistorySheetProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  task: Task | null;
}

export function TaskHistorySheet({
  isOpen,
  onOpenChange,
  task,
}: TaskHistorySheetProps) {
  if (!task) return null;

  return (
    <UnifiedHistorySheet
      isOpen={isOpen}
      onOpenChange={onOpenChange}
      target={{ task }}
      customerName={task.customerName || "N/A"}
    />
  );
}
