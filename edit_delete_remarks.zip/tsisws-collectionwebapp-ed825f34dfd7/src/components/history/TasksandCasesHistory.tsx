import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Loader2, Clock, MapPin, X, Image as ImageIcon } from "lucide-react";
import type { CaseActivityHistory, DispositionHistory, ReceiptHistory, Case } from "@/lib/types";
import { getScreenShot } from "@/lib/services/screenShot";
import { getCollReceiptById } from "@/lib/services/tasks";
import { ReceiptPdfGenerator } from "@/lib/utils/receiptPdfGenerator";
import { useToast } from "@/hooks/use-toast";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AddAddress } from "@/components/Cases/AddAddress";

interface TasksandCasesHistoryProps {
    history: CaseActivityHistory[];
    isLoading: boolean;
    error: string | null;
    onRetry: () => void;
    lanNumber?: string;
    customerName?: string;
    caseData: Case | null;
}

const DetailItem = ({
    label,
    value,
    valueClassName = "text-gray-800",
    isBlue = false,
    onClick,
    isLoading = false,
}: {
    label: string;
    value?: string | number | null;
    valueClassName?: string;
    isBlue?: boolean;
    onClick?: () => void;
    isLoading?: boolean;
}) => (
    <div
        className={`flex flex-col items-center justify-center text-center ${onClick ? "cursor-pointer transition-colors" : ""}`}
        onClick={onClick}
    >
        <div className="w-full py-2 px-1">
            <p className="text-[12px] font-bold text-gray-900 uppercase">{label}</p>
        </div>
        <div className="w-full border-t-[5px] border-white py-2 px-1 flex items-center justify-center">
            {isLoading ? (
                <Loader2 className="h-3 w-3 animate-spin text-[#3b82f6]" />
            ) : (
                <p className={`text-[11px] font-semibold ${isBlue ? "text-[#3b82f6]" : valueClassName}`}>
                    {value || "-"}
                </p>
            )}
        </div>
    </div>
);

const ImagePreview = ({
    isOpen,
    onClose,
    images,
    isLoading
}: {
    isOpen: boolean;
    onClose: () => void;
    images: { title: string, url: string }[];
    isLoading: boolean;
}) => {
    const [currentIndex, setCurrentIndex] = useState(0);

    // Reset index when opening
    useEffect(() => {
        if (isOpen) {
            setCurrentIndex(0);
        }
    }, [isOpen]);

    const currentImage = images[currentIndex];

    const handlePrevious = (e: React.MouseEvent) => {
        e.stopPropagation();
        setCurrentIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
    };

    const handleNext = (e: React.MouseEvent) => {
        e.stopPropagation();
        setCurrentIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-4xl bg-white p-0 overflow-hidden border-none shadow-2xl">
                <DialogHeader className="p-4 border-b bg-white/80 backdrop-blur-md sticky top-0 z-10">
                    <div className="flex items-center justify-between w-full">
                        <DialogTitle className="text-lg font-bold text-gray-900">
                            {currentImage?.title || "Image Preview"}
                        </DialogTitle>
                        <div className="flex items-center gap-4">
                            {images.length > 1 && (
                                <span className="text-sm font-semibold bg-gray-100 px-3 py-1 rounded-full text-gray-600">
                                    {currentIndex + 1} / {images.length}
                                </span>
                            )}
                            <button
                                onClick={onClose}
                                className="p-1 rounded-md hover:bg-gray-100 transition-colors text-gray-500 hover:text-gray-900"
                            >
                                <X className="h-5 w-5" />
                                <span className="sr-only">Close</span>
                            </button>
                        </div>
                    </div>
                </DialogHeader>

                <div className="relative group flex items-center justify-center bg-zinc-950 min-h-[450px] max-h-[85vh]">
                    {isLoading ? (
                        <div className="flex flex-col items-center gap-3 text-white">
                            <Loader2 className="h-10 w-10 animate-spin text-blue-500" />
                            <p className="font-medium animate-pulse">Loading secure image...</p>
                        </div>
                    ) : (
                        <>
                            {currentImage?.url ? (
                                <img
                                    src={currentImage.url}
                                    alt={currentImage.title}
                                    className="max-w-full max-h-[80vh] object-contain transition-all duration-500 ease-in-out"
                                />
                            ) : (
                                <div className="text-zinc-500 flex flex-col items-center gap-2">
                                    <ImageIcon className="opacity-20" />
                                    <p>Image not available</p>
                                </div>
                            )}

                            {/* Navigation Arrows */}
                            {images.length > 1 && !isLoading && (
                                <>
                                    <button
                                        onClick={handlePrevious}
                                        className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-black/40 hover:bg-black/60 text-white transition-all transform hover:scale-110 active:scale-95 z-20"
                                    >
                                        <ChevronLeft className="h-8 w-8" />
                                    </button>
                                    <button
                                        onClick={handleNext}
                                        className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-black/40 hover:bg-black/60 text-white transition-all transform hover:scale-110 active:scale-95 z-20"
                                    >
                                        <ChevronRight className="h-8 w-8" />
                                    </button>
                                </>
                            )}
                        </>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
};

const HistoryCard = ({
    historyItem,
    onMapPinClick
}: {
    historyItem: CaseActivityHistory;
    onMapPinClick: (historyItem: CaseActivityHistory) => void;
}) => {
    const isReceipt = historyItem.type === "RECEIPT";
    const isDisposition = historyItem.type === "DISPOSITION";
    const { toast } = useToast();
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImages, setPreviewImages] = useState<{ title: string, url: string }[]>([]);
    const [isImageLoading, setIsImageLoading] = useState(false);
    const [isPdfLoading, setIsPdfLoading] = useState(false);

    const handleReceiptClick = async () => {
        if (!historyItem.id || isPdfLoading) return;

        setIsPdfLoading(true);
        try {
            const receiptDetail = await getCollReceiptById(historyItem.id);
            if (receiptDetail) {
                const generator = new ReceiptPdfGenerator(receiptDetail);
                await generator.generateAndPreview();
            } else {
                toast({
                    title: "Error",
                    description: "Failed to fetch receipt details.",
                    variant: "destructive"
                });
            }
        } catch (error) {
            console.error("PDF generation failed:", error);
            toast({
                title: "Error",
                description: "An error occurred while generating the PDF.",
                variant: "destructive"
            });
        } finally {
            setIsPdfLoading(false);
        }
    };

    const handlePreview = async () => {
        const isReceipt = historyItem.type === "RECEIPT";
        const refId = isReceipt ? historyItem.hiveId : historyItem.id;

        if (!refId) {
            toast({
                title: "Unavailable",
                description: `${isReceipt ? "Image ID (hiveId)" : "Activity ID"} is missing for this record.`,
                variant: "destructive"
            });
            return;
        }

        setIsImageLoading(true);
        setPreviewImages([]);
        setPreviewOpen(true);

        const loadedImages: { title: string, url: string }[] = [];
        const dispositionId = isReceipt ? "" : historyItem.hiveId;

        try {
            // Fetch Selfie if available
            if (historyItem.hasSelfieImagePath) {
                const { blob } = await getScreenShot({
                    moduleName: "Selfie Image",
                    refId: isDisposition ? "" : refId,
                    dispositionId: isReceipt ? "" : dispositionId
                });
                loadedImages.push({ title: "Selfie Image", url: URL.createObjectURL(blob) });
            }
            // Fetch Payment if available
            if (historyItem.hasPaymentImagePath) {
                const { blob } = await getScreenShot({
                    moduleName: "Payment Image",
                    refId: isDisposition ? "" : refId,
                    dispositionId: isReceipt ? "" : dispositionId
                });
                loadedImages.push({ title: "Payment Image", url: URL.createObjectURL(blob) });
            }
            setPreviewImages(loadedImages);
        } catch (error) {
            console.error("Preview failed:", error);
            toast({
                title: "Error",
                description: "Failed to load image preview.",
                variant: "destructive"
            });
            setPreviewOpen(false);
        } finally {
            setIsImageLoading(false);
        }
    };

    const formatDate = (dateString: string) => {
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString("en-GB", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric"
            });
        } catch (e) {
            return dateString;
        }
    };

    const formatTime = (dateString: string) => {
        try {
            const date = new Date(dateString);
            return date.toLocaleTimeString("en-US", {
                hour: "2-digit",
                minute: "2-digit",
                hour12: true
            });
        } catch (e) {
            return "";
        }
    };


    return (
        <div className="space-y-2 mb-3">
            {/* 1. Header Row */}
            <div className="bg-white rounded-lg p-3 grid grid-cols-[110px_1fr_150px_50px] gap-2 items-center shadow-sm">
                <span className="text-[11px] text-gray-600 font-medium">{formatDate(historyItem.date)}</span>
                <span className="text-[11px] text-gray-500 font-medium truncate">
                    {isReceipt ? (historyItem as ReceiptHistory).status : (historyItem as DispositionHistory).activityName}
                </span>
                <span className="text-[11px] text-gray-600 font-medium whitespace-nowrap justify-start">
                    {historyItem.activityBy}
                </span>
                <div className="flex justify-end">
                    {historyItem.latitude && historyItem.longitude && (
                        <button
                            onClick={() => onMapPinClick(historyItem)}
                            className="text-[#3b82f6] hover:opacity-80 transition-opacity"
                        >
                            <MapPin className="h-5 w-5" />
                        </button>
                    )}
                </div>
            </div>

            {/* 2. Info Table */}
            <div className="bg-[#d1d5db] rounded-lg overflow-hidden grid grid-cols-4 divide-x-[6px] divide-white">
                {isReceipt ? (
                    <>
                        <DetailItem
                            label="Receipt"
                            value={(historyItem as ReceiptHistory).receiptNo}
                            isBlue={true}
                            onClick={handleReceiptClick}
                            isLoading={isPdfLoading}
                        />
                        <DetailItem label="Collected" value={(historyItem as ReceiptHistory).collectedAmount} />
                        <DetailItem label="Due" value={(historyItem as ReceiptHistory).due} />
                        <DetailItem label="Mode" value={(historyItem as ReceiptHistory).paymentMode} />
                    </>
                ) : (
                    <>
                        <DetailItem label="Field" value={(historyItem as DispositionHistory).activityName} />
                        <DetailItem label="Due Date" value={formatDate((historyItem as DispositionHistory).nextActionDate || "")} />
                        <DetailItem label="Due Time" value={(historyItem as DispositionHistory).nextActionTime?.split(":").slice(0, 2).join(":")} />
                        <DetailItem label="Counter" value={(historyItem as DispositionHistory).counter} />
                    </>
                )}
            </div>

            {/* 3. Remarks Footer */}
            <div className="bg-[#d1d5db] rounded-lg p-3 flex justify-between items-center gap-4">
                <p className="text-[14px] text-gray-800">
                    <span className="font-medium">Remarks:</span> {historyItem.remarks || "No remarks available"}
                </p>
                <div className="flex items-center gap-2 shrink-0">
                    {isReceipt && (historyItem.hasSelfieImagePath || historyItem.hasPaymentImagePath) && (
                        <button
                            onClick={handlePreview}
                            className="text-[#3b82f6]"
                        >
                            <ImageIcon className="h-6 w-6" />
                        </button>
                    )}
                    {isDisposition && (historyItem.hasSelfieImagePath || historyItem.hasPaymentImagePath) && (
                        <button
                            onClick={handlePreview}
                            className="text-[#3b82f6]"
                        >
                            <ImageIcon className="h-6 w-6" />
                        </button>
                    )}
                    <span className="text-[12px] font-bold text-[#22c55e]">
                        {isReceipt ? (historyItem as ReceiptHistory).receiptGenerationTime : formatTime(historyItem.date)}
                    </span>
                </div>
            </div>

            <ImagePreview
                isOpen={previewOpen}
                onClose={() => {
                    setPreviewOpen(false);
                    previewImages.forEach(img => URL.revokeObjectURL(img.url));
                }}
                images={previewImages}
                isLoading={isImageLoading}
            />
        </div>
    );
};

export function TasksandCasesHistory({
    history,
    isLoading,
    error,
    onRetry,
    caseData,
}: TasksandCasesHistoryProps) {
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const [isAddAddressOpen, setIsAddAddressOpen] = useState(false);
    const [historyItemForAction, setHistoryItemForAction] = useState<CaseActivityHistory | null>(null);


    const handleMapPinClick = (item: CaseActivityHistory) => {
        setHistoryItemForAction(item);
        setIsConfirmOpen(true);
    };

    const handleConfirmYes = () => {
        setIsConfirmOpen(false);
        setIsAddAddressOpen(true);
    };

    const handleConfirmNo = () => {
        setIsConfirmOpen(false);
        if (historyItemForAction?.latitude && historyItemForAction?.longitude) {
            const mapLink = `https://www.google.com/maps?q=${historyItemForAction.latitude},${historyItemForAction.longitude}`;
            window.open(mapLink, "_blank");
        }
    };

    return (
        <div className="flex flex-col h-full bg-transparent">
            {/* ... other components ... */}

            {/* Column Headers */}
            <div className="px-3 py-2 mb-2 grid grid-cols-[110px_1fr_150px_50px] gap-2 text-[12px] font-bold text-gray-900 border-b-0 bg-white rounded-xl shadow-sm">
                <span className="text-left">Date</span>
                <span className="text-left font-bold">Status</span>
                <span className="text-left">Activity By</span>
                <span className="text-right pr-1">Map</span>
            </div>

            <div className="flex-1 flex flex-col min-h-0">
                {isLoading ? (
                    <div className="flex-1 flex items-center justify-center py-10 bg-white rounded-lg border my-2">
                        <div className="flex items-center">
                            <Loader2 className="h-6 w-6 animate-spin text-primary" />
                            <span className="ml-2 text-muted-foreground text-sm">
                                Loading history...
                            </span>
                        </div>
                    </div>
                ) : error ? (
                    <div className="flex-1 flex flex-col items-center justify-center py-10 text-red-500 bg-white rounded-lg border my-2">
                        <p className="text-sm">{error}</p>
                        <Button
                            variant="outline"
                            size="sm"
                            className="mt-2"
                            onClick={onRetry}
                        >
                            Retry
                        </Button>
                    </div>
                ) : history.length === 0 ? (
                    <div className="flex-1 flex flex-col items-center justify-center py-10 text-muted-foreground bg-white rounded-lg border my-2">
                        <Clock className="h-10 w-10 mx-auto mb-2 text-gray-300" />
                        <p className="text-sm">No activity history found for this period.</p>
                    </div>
                ) : (
                    <div className="flex-1 overflow-y-auto pb-4 scrollbar-thin pr-1">
                        {history.map((item) => (
                            <HistoryCard
                                key={item.id}
                                historyItem={item}
                                onMapPinClick={handleMapPinClick}
                            />
                        ))}
                    </div>
                )}
            </div>

            {/* Tag Location Confirmation Dialog */}
            <AlertDialog open={isConfirmOpen} onOpenChange={setIsConfirmOpen}>
                <AlertDialogContent className="bg-white">
                    <AlertDialogHeader>
                        <AlertDialogTitle>Tag Location</AlertDialogTitle>
                        <AlertDialogDescription>
                            Do you want to tag your current location?
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter className="bg-white">
                        <AlertDialogCancel onClick={handleConfirmNo}>No</AlertDialogCancel>
                        <AlertDialogAction
                            onClick={handleConfirmYes}
                            className="bg-[#5c8aff] hover:bg-blue-600 text-white"
                        >
                            Yes
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            {/* Add Address Sheet */}
            <AddAddress
                isOpen={isAddAddressOpen}
                onOpenChange={setIsAddAddressOpen}
                caseData={caseData}
                initialCoords={
                    historyItemForAction?.latitude && historyItemForAction?.longitude
                        ? {
                            latitude: historyItemForAction.latitude,
                            longitude: historyItemForAction.longitude,
                        }
                        : null
                }
            />
        </div>
    );
}
