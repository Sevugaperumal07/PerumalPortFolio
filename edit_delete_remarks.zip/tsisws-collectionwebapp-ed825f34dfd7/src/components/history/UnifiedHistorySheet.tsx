import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
} from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { YearMonthFilter } from "../dashboard/YearMonthFilter";
import { HistoryInfoCard } from "./HistoryInfoCard";
import { HistoryNotesTab } from "./HistoryNotesTab";
import { MonthNavigation } from "./MonthNavigation";
import { ReceiptAuditHistory } from "@/components/history/ReceiptAuditHistory";
import { TasksandCasesHistory } from "@/components/history/TasksandCasesHistory";
import { useHistoryTabs } from "@/hooks/history/useHistoryTabs";
import { useAuditHistory } from "@/hooks/history/useAuditHistory";
import { useDepositDetails } from "@/hooks/use-deposit-details";
import { DepositDetailsSheet } from "@/components/deposits/DepositDetailsSheet";
import { useState } from "react";
import type { Task, Case } from "@/lib/types";

interface UnifiedHistorySheetProps {
    isOpen: boolean;
    onOpenChange: (isOpen: boolean) => void;
    target: {
        task?: Task | null;
        caseItem?: Case | null;
    };
    customerName: string;
}

export function UnifiedHistorySheet({
    isOpen,
    onOpenChange,
    target,
    customerName,
}: UnifiedHistorySheetProps) {
    const {
        notes,
        history,
        lanLabel,
        handleYearChange,
        handleMonthChange,
        handlePreviousMonth,
        handleNextMonth,
        isNextDisabled,
        isPreviousDisabled,
    } = useHistoryTabs({
        isOpen,
        task: target.task,
        caseItem: target.caseItem,
    });

    const [showSystem, setShowSystem] = useState(false);

    const auditHistory = useAuditHistory({
        caseId: target.caseItem?.id || target.task?.account?.id || null,
        year: history.filterYear,
        month: history.filterMonth,
        isOpen,
        showSystem,
    });

    const {
        selectedDeposit,
        isOpen: isDepositSheetOpen,
        setIsOpen: setIsDepositSheetOpen,
        loading: isDepositLoading,
        isSubmitting: isDepositSubmitting,
        openDetails: openDepositDetails,
        handleDepositSubmission
    } = useDepositDetails();

    const { task, caseItem } = target;

    const handleYearChangeProxy = (year: number | undefined) => {
        if (year !== undefined) handleYearChange(year);
    };

    const handleMonthChangeProxy = (month: number | undefined) => {
        if (month !== undefined) handleMonthChange(month);
    };

    // Map task to caseData format if needed for TasksandCasesHistory
    const caseData = caseItem
        ? caseItem
        : task
            ? ({
                id: task.id,
                caseNumber: task.taskNumber,
                account: { lanNumber: task.lan },
            } as any)
            : null;

    return (
        <Sheet open={isOpen} onOpenChange={onOpenChange}>
            <SheetContent className="sm:max-w-lg w-full bg-gray-100 flex flex-col h-full p-0">
                <div className="flex-1 flex flex-col min-h-0 p-6 w-[525px]">
                    <SheetHeader className="flex-row items-center justify-between bg-white p-3 -m-6 mb-4 border-b">
                        <div className="text-left">
                            <SheetTitle>History</SheetTitle>
                        </div>
                    </SheetHeader>
                    <Tabs defaultValue="history" className="flex-1 flex flex-col min-h-0 mt-1">
                        <TabsList className="flex items-center justify-start w-full mb-4 h-auto p-1 bg-gray-200/50">
                            <TabsTrigger value="notes" className="px-4 py-2 text-xs">
                                Notes
                            </TabsTrigger>
                            <TabsTrigger value="history" className="px-4 py-2 text-xs">
                                History
                            </TabsTrigger>
                            <TabsTrigger value="call" className="px-4 py-2 text-xs">
                                Call
                            </TabsTrigger>
                            <TabsTrigger value="audit" className="px-4 py-2 text-xs">
                                Audit
                            </TabsTrigger>
                            <div className="ml-auto flex items-center">
                                <YearMonthFilter
                                    year={history.filterYear}
                                    month={history.filterMonth}
                                    onYearChange={handleYearChangeProxy}
                                    onMonthChange={handleMonthChangeProxy}
                                    compact={true}
                                />
                            </div>
                        </TabsList>

                        <HistoryInfoCard lanLabel={lanLabel} customerName={customerName} />

                        <TabsContent
                            value="notes"
                            className="flex-1 data-[state=active]:flex data-[state=inactive]:hidden flex-col min-h-0 overflow-hidden outline-none"
                        >
                            <HistoryNotesTab
                                notes={notes.notes}
                                isLoading={notes.isLoading}
                                isLoadingMore={notes.isLoadingMore}
                                error={notes.error}
                                isEmpty={notes.isEmpty}
                                hasMore={notes.hasMore}
                                fallbackLabel={lanLabel}
                                onLoadMore={notes.handleLoadMore}
                                onRetry={notes.handleRetry}
                            />
                        </TabsContent>

                        <TabsContent
                            value="history"
                            className="flex-1 data-[state=active]:flex data-[state=inactive]:hidden flex-col min-h-0 overflow-hidden outline-none"
                        >
                            <TasksandCasesHistory
                                history={history.history}
                                isLoading={history.isLoading}
                                error={history.error}
                                onRetry={history.handleRetry}
                                caseData={caseData}
                            />
                        </TabsContent>

                        <TabsContent value="call" className="flex-1 data-[state=active]:flex data-[state=inactive]:hidden flex-col min-h-0 overflow-hidden outline-none">
                        </TabsContent>

                        <TabsContent
                            value="audit"
                            className="flex-1 data-[state=active]:flex data-[state=inactive]:hidden flex-col min-h-0 overflow-hidden outline-none"
                        >
                            <ReceiptAuditHistory
                                history={auditHistory.history}
                                isLoading={auditHistory.isLoading}
                                error={auditHistory.error}
                                onRetry={auditHistory.handleRetry}
                                currentPage={auditHistory.paginationMetadata.currentPage}
                                totalPages={auditHistory.paginationMetadata.totalPages}
                                totalRecords={auditHistory.paginationMetadata.totalRecords}
                                hasNext={auditHistory.paginationMetadata.hasNext}
                                hasPrevious={auditHistory.paginationMetadata.hasPrevious}
                                showSystem={showSystem}
                                setShowSystem={setShowSystem}
                                entityType={auditHistory.entityType}
                                setEntityType={auditHistory.setEntityType}
                                onPageChange={auditHistory.setPage}
                                onViewDepositDetails={openDepositDetails}
                            />
                        </TabsContent>
                    </Tabs>

                    <MonthNavigation
                        onPrevious={handlePreviousMonth}
                        onNext={handleNextMonth}
                        isNextDisabled={isNextDisabled}
                        isPreviousDisabled={isPreviousDisabled}
                    />
                </div>
            </SheetContent>

            <DepositDetailsSheet
                isOpen={isDepositSheetOpen}
                onOpenChange={setIsDepositSheetOpen}
                loading={isDepositLoading}
                selectedDeposit={selectedDeposit}
                activeTab="History Link"
                onEditReceipt={() => {}}
                onDeleteReceipt={() => {}}
                isSubmitting={isDepositSubmitting}
                onSubmission={handleDepositSubmission}
            />
        </Sheet>
    );
}