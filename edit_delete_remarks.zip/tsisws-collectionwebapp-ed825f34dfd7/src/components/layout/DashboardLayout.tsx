import { Outlet, Link, useLocation } from 'react-router-dom';
import { Users, ShieldCheck, Shield, Landmark, Briefcase, ListTodo, StickyNote, Settings, RailSymbol, PanelRight, ChevronDown, ChevronRight, LayoutDashboard, CircleX, CircleCheck, ClipboardCheck, 
  Hourglass
 } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import UserNav from '@/components/nav/UserNav';
import { Breadcrumbs } from '@/components/nav/Breadcrumbs';
import { useState } from 'react';
import {
  TooltipProvider,
  Tooltip,
  TooltipTrigger,
  TooltipContent,
} from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useUserRole } from '@/contexts/UserRoleContext';

type SidebarItem = {
  label: string;
  icon: LucideIcon;
  href?: string;
  category?: string;
  children?: { href: string; label: string; icon: LucideIcon; category?: string }[];
};

const sidebarItems: SidebarItem[] = [
  {
    href: '/dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
    category: 'Dashboard',
  },
  {
    href: '/dashboard/cases',
    label: 'Cases',
    icon: Briefcase,
    category: 'Account',
  },
  {
    href: '/dashboard/tasks',
    label: 'Tasks',
    icon: ListTodo,
    category: 'Case',
  },
  {
    label: 'Deposits',
    icon: Landmark,
    children: [
      {
        href: '/dashboard/deposits/acceptance-pending',
        label: 'Acceptance Pending',
        icon: Hourglass,
        category: 'AcceptancePending',
      },
       {
        href: '/dashboard/deposits/in-hand-branch',
        label: 'In-Hand Branch',
        icon: Landmark,
        category: 'InHandBranch',
      },
      {
        href: '/dashboard/deposits/verify',
        label: 'Verification Pending',
        icon: ClipboardCheck,
        category: 'VerificationPending',
      },
      {
        href: '/dashboard/deposits/verified',
        label: 'Verification Completed',
        icon: CircleCheck,
        category: 'VerificationCompleted',
      },
      {
        href: '/dashboard/deposits/rejected',
        label: 'Rejected',
        icon: CircleX,
        category: 'Rejected'
      },
    ],
  },
  {
    href: '/dashboard/maps',
    label: 'Agent Tracker',
    icon: RailSymbol,
    category: 'MapScreen',
  },
  {
    href: '/dashboard/notes',
    label: 'Notes',
    icon: StickyNote,
  },
  {
    href: '/dashboard/users',
    label: 'Users',
    icon: Users,
    category: 'UsersWeb',
  },
  {
    href: '/dashboard/roles',
    label: 'Roles',
    icon: ShieldCheck,
    category: 'RolesWeb',
  },
  {
    label: 'Masters',
    icon: Settings,
    children: [
      {
        href: '/dashboard/bank-details',
        label: 'Bank Details',
        icon: Landmark,
        category: 'BankDetailsWeb',
      },
      {
        href: '/dashboard/security-groups',
        label: 'Security Groups',
        icon: Shield,
        category: 'SecurityGroups',
      },
    ],
  },
];

export function DashboardLayout() {
  const location = useLocation();
  const { canAccessCategory: contextCanAccessCategory } = useUserRole();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(false);
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set(['Deposits', 'Masters']));

  const canAccessCategory = (category?: string, action?: string): boolean => {
    // Default to visible if no category specified
    if (!category) return true;
    return contextCanAccessCategory(category, action);
  };

  const filteredSidebarItems = sidebarItems
    .map(item => {
      if (item.children) {
        return {
          ...item,
          children: item.children.filter(child => canAccessCategory(child.category))
        };
      }
      return item;
    })
    .filter(item => {
      if (item.children) {
        return item.children.length > 0;
      }
      return canAccessCategory(item.category);
    });

  const toggleItem = (label: string) => {
    setExpandedItems((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(label)) {
        newSet.delete(label);
      } else {
        newSet.add(label);
      }
      return newSet;
    });
  };

  return (
    <TooltipProvider delayDuration={100}>
      <div className="flex min-h-screen w-full bg-muted/40">
        {/* Sidebar */}
        <aside
          className={`hidden md:flex md:flex-col md:fixed md:inset-y-0 border-r bg-background transition-all duration-200 z-50 ${isSidebarExpanded ? 'md:w-56' : 'md:w-20'
            }`}
        >
          <div
            className={`flex h-16 items-center ${isSidebarExpanded ? 'px-4 justify-between' : 'px-2 justify-center'}`}
          >
            <Link to="/dashboard" className="flex justify-center items-center gap-3 my-4">
              <img
                src="https://www.infinityfincorp.com/images/logo_dark.png"
                alt="Company Logo"
                className={`${isSidebarExpanded ? 'h-32 w-32 ml-10 mt-7' : 'h-96 w-96'} object-contain object-center`}
              />

            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="hidden md:inline-flex h-9 w-9 ml-auto"
              aria-label={isSidebarExpanded ? 'Collapse sidebar' : 'Expand sidebar'}
              onClick={() => setIsSidebarExpanded((prev) => !prev)}
            >
            </Button>
          </div>
          <nav
            className={`flex-1 flex flex-col gap-1 py-6 overflow-y-auto ${isSidebarExpanded ? 'px-3' : 'items-center px-2'
              }`}
          >
            {filteredSidebarItems.map((item) => {
              const Icon = item.icon;
              const childActive = item.children?.some((child) =>
                location.pathname.startsWith(child.href),
              );
              // For dashboard, only highlight if pathname is exactly /dashboard
              const isActive =
                (!item.children && item.href
                  ? item.href === '/dashboard'
                    ? location.pathname === '/dashboard'
                    : location.pathname.startsWith(item.href)
                  : false) || childActive;

              if (isSidebarExpanded) {
                if (item.children && item.children.length > 0) {
                  const isExpanded = expandedItems.has(item.label);
                  return (
                    <div key={item.label} className="space-y-2">
                      <button
                        onClick={() => toggleItem(item.label)}
                        className={`group flex items-center gap-1 rounded-lg px-3 text-sm transition-colors w-full ${isActive ? 'bg-rose-500 text-white' : 'text-neutral-800 hover:bg-rose-500 hover:text-white'
                          }`}
                      >
                        <span className={`flex h-9 w-9 items-center justify-center rounded-lg ${isActive ? 'bg-rose-500 text-white' : 'text-neutral-800 group-hover:text-white'
                          }`}>
                          <Icon className="h-4 w-4" />
                        </span>
                        <span className="flex-1 text-left truncate">{item.label}</span>
                        <span className={`flex items-center justify-center ${isActive ? 'text-white' : 'text-neutral-800 group-hover:text-white'}`}>
                          {isExpanded ? (
                            <ChevronDown className="h-4 w-4" />
                          ) : (
                            <ChevronRight className="h-4 w-4" />
                          )}
                        </span>
                      </button>
                      {isExpanded && (
                        <div className="space-y-1 pl-12">
                          {item.children.map((child) => (
                            <Link
                              key={child.href}
                              to={child.href}
                              className={`flex items-center gap-1 rounded-lg px-3 py-2 text-xs transition-colors ${location.pathname.startsWith(child.href)
                                ? 'text-white bg-rose-500'
                                : 'text-neutral-800 hover:bg-rose-500 hover:text-white'
                                }`}
                            >
                              <child.icon className="h-4 w-4" />
                              {child.label}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                }

                if (!item.href) return null;
                const href = item.href as string;
                return (
                  <Link
                    key={href}
                    to={href}
                    className={`flex items-center gap-1 rounded-lg px-3 text-sm transition-colors ${isActive
                      ? 'bg-rose-500 text-white'
                      : 'text-neutral-800 hover:bg-rose-500 hover:text-white'
                      }`}
                  >
                    <span className="flex h-9 w-9 items-center justify-center rounded-lg">
                      <Icon className="h-4 w-4" />
                    </span>
                    <span className="flex-1 truncate">{item.label}</span>
                  </Link>
                );
              }

              if (item.children && item.children.length > 0) {
                return (
                  <DropdownMenu key={item.label}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <DropdownMenuTrigger asChild>
                          <button
                            className={`group flex h-8 w-8 items-center justify-center rounded-lg transition-colors text-neutral-800 ${isActive
                              ? 'bg-rose-500 text-white border-rose-500 shadow-sm'
                              : 'text-neutral-800 hover:border-rose-500 hover:bg-rose-500 hover:text-white'
                              }`}
                          >
                            <Icon className="h-4 w-4 stroke-2" />
                          </button>
                        </DropdownMenuTrigger>
                      </TooltipTrigger>
                      <TooltipContent side="right" className="px-3 py-1.5 text-xs font-medium">
                        {item.label}
                      </TooltipContent>
                    </Tooltip>
                    <DropdownMenuContent side="right" align="center" className="ml-2">
                      {item.children.map((child) => (
                        <DropdownMenuItem key={child.href} asChild>
                          <Link to={child.href} className="flex items-center gap-2 text-sm">
                            <child.icon className="h-4 w-4" />
                            {child.label}
                          </Link>
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                );
              }

              if (!item.href) return null;
              const href = item.href as string;
              return (
                <Tooltip key={href}>
                  <TooltipTrigger asChild>
                    <Link
                      to={href}
                      className={`group flex h-8 w-8 items-center justify-center rounded-lg transition-colors text-neutral-800 ${isActive
                        ? 'bg-rose-500 text-white border-rose-500 shadow-sm'
                        : 'text-muted-foreground hover:border-rose-500 hover:bg-rose-500 hover:text-white'
                        }`}
                    >
                      <Icon className="h-4 w-4 stroke-2" />
                    </Link>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="px-3 py-1.5 text-xs font-medium">
                    {item.label}
                  </TooltipContent>
                </Tooltip>
              );
            })}
          </nav>
        </aside>

        {/* Mobile Sidebar */}
        {sidebarOpen && (
          <div className="fixed inset-0 z-50 md:hidden">
            <div className="fixed inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
            <aside className="fixed left-0 top-0 h-full w-64 bg-background border-r z-50">
              <div className="flex items-center justify-center border-b px-4 py-3">
                <Link to="/dashboard" className="flex justify-center items-center" onClick={() => setSidebarOpen(false)}>
                  <img
                    src="https://technospaceis.com/wp-content/uploads/2021/04/TiS_Logo_200.png"
                    alt="Company Logo"
                    className="h-24 w-24 object-contain object-center"
                  />
                </Link>
              </div>
              <nav className="flex-1 space-y-1 px-2 py-4 overflow-y-auto">
                {filteredSidebarItems.map((item) => {
                  const Icon = item.icon;
                  const childActive = item.children?.some((child) =>
                    location.pathname.startsWith(child.href),
                  );
                  // For dashboard, only highlight if pathname is exactly /dashboard
                  const isActive =
                    (!item.children && item.href
                      ? item.href === '/dashboard'
                        ? location.pathname === '/dashboard'
                        : location.pathname.startsWith(item.href)
                      : false) || childActive;

                  if (item.children && item.children.length > 0) {
                    const isExpanded = expandedItems.has(item.label);
                    return (
                      <div key={item.label} className="space-y-1">
                        <button
                          onClick={() => toggleItem(item.label)}
                          className={`group flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm w-full transition-colors ${isActive
                            ? 'bg-rose-500 text-white'
                            : 'text-neutral-800 hover:bg-rose-500 hover:text-white'
                            }`}
                        >
                          <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${isActive
                            ? 'bg-rose-500 text-white border-rose-500'
                            : 'text-neutral-800 group-hover:text-white'
                            }`}>
                            <Icon className="h-4 w-4" />
                          </span>
                          <span className="flex-1 text-left">{item.label}</span>
                          <span className={`flex items-center justify-center ${isActive ? 'text-white' : 'text-neutral-800 group-hover:text-white'}`}>
                            {isExpanded ? (
                              <ChevronDown className="h-4 w-4" />
                            ) : (
                              <ChevronRight className="h-4 w-4" />
                            )}
                          </span>
                        </button>
                        {isExpanded && (
                          <div className="space-y-0.5 pl-10">
                            {item.children.map((child) => (
                              <Link
                                key={child.href}
                                to={child.href}
                                onClick={() => setSidebarOpen(false)}
                                className={`flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm transition-colors ${location.pathname.startsWith(child.href)
                                  ? 'bg-rose-500 text-white'
                                  : 'text-neutral-800 hover:bg-rose-500 hover:text-white'
                                  }`}
                              >
                                <child.icon className="h-4 w-4" />
                                {child.label}
                              </Link>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  }

                  if (!item.href) return null;
                  const href = item.href as string;
                  return (
                    <Link
                      key={href}
                      to={href}
                      onClick={() => setSidebarOpen(false)}
                      className={`flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm transition-colors ${isActive
                        ? 'bg-rose-500 text-white'
                        : 'text-neutral-800 hover:bg-rose-500 hover:text-white'
                        }`}
                    >
                      <span className="flex h-8 w-8 items-center justify-center rounded-lg">
                        <Icon className="h-4 w-4" />
                      </span>
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </nav>
            </aside>
          </div>
        )}

        {/* Main Content */}
        <div
          className={`flex flex-1 flex-col min-w-0 transition-all duration-200 ${isSidebarExpanded ? 'md:ml-56' : 'md:ml-16'
            }`}
        >
          <header className="sticky top-0 z-40 flex h-14 items-center gap-4 px-4 sm:px-6 bg-background border-b">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden h-9 w-9"
              onClick={() => setSidebarOpen(true)}
            >
              <PanelRight className="h-11 w-11 stroke-2" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="hidden md:inline-flex h-9 w-9"
              aria-label={isSidebarExpanded ? 'Collapse sidebar' : 'Expand sidebar'}
              onClick={() => setIsSidebarExpanded((prev) => !prev)}
            >
              <PanelRight className="h-11 w-11 stroke-2" />
            </Button>
            <div className="sm:flex hidden">
              <Breadcrumbs />
            </div>
            <div className="ml-auto flex items-center"><UserNav /></div>
          </header>
          <main className="flex-1 p-3 sm:p-4 md:p-6" style={{ overflowX: 'scroll', overflowY: 'auto', minWidth: 0 }}>
            <Outlet />
          </main>
        </div>
      </div>
    </TooltipProvider>
  );
}










