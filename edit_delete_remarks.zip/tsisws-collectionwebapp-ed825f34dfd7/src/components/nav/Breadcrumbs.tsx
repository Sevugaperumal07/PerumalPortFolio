import { useMemo } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  href?: string;
}

const getBreadcrumbItems = (pathname: string): BreadcrumbItem[] => {
  const pathParts = pathname.split('/').filter(part => part);
  const items: BreadcrumbItem[] = [{ label: 'Dashboard', href: '/dashboard' }];

  if (pathParts.includes('cases')) {
    items.push({ label: 'Cases', href: '/dashboard/cases' });
    if (pathParts.includes('new')) {
      items.push({ label: 'Create' });
    }
  } else if (pathParts.includes('tasks')) {
    items.push({ label: 'Tasks', href: '/dashboard/tasks' });
  } else if (pathParts.includes('deposits')) {
    items.push({ label: 'Deposits' });
    if (pathParts.includes('verify')) {
      items.push({ label: 'Verify', href: '/dashboard/deposits/verify' });
    } else if (pathParts.includes('verified')) {
      items.push({ label: 'Verified', href: '/dashboard/deposits/verified' });
    }
  } else if (pathParts.includes('maps')) {
    items.push({ label: 'Agent Tracker', href: '/dashboard/maps' });
  } else if (pathParts.includes('notes')) {
    items.push({ label: 'Notes', href: '/dashboard/notes' });
  } else if (pathParts.includes('users')) {
    items.push({ label: 'Users', href: '/dashboard/users' });
    if (pathParts.includes('new')) {
      items.push({ label: 'Create' });
    } else if (pathParts.length > 2) {
      if (pathParts.includes('edit')) {
        items.push({ label: 'Edit' });
      } else {
        items.push({ label: 'Details' });
      }
    }
  } else if (pathParts.includes('roles')) {
    items.push({ label: 'Roles', href: '/dashboard/roles' });
    if (pathParts.includes('new') || pathParts.includes('clone')) {
      items.push({ label: 'Create' });
    } else if (pathParts.includes('edit')) {
      items.push({ label: 'Edit' });
    }
  } else if (pathParts.includes('bank-details') || pathParts.includes('security-groups')) {
    items.push({ label: 'Masters' });
    if (pathParts.includes('bank-details')) {
      items.push({ label: 'Bank Details', href: '/dashboard/bank-details' });
      if (pathParts.includes('new')) {
        items.push({ label: 'Create' });
      } else if (pathParts.includes('edit')) {
        items.push({ label: 'Edit' });
      }
    }
    if (pathParts.includes('security-groups')) {
      items.push({ label: 'Security Groups', href: '/dashboard/security-groups' });
      if (pathParts.includes('new')) {
        items.push({ label: 'Create' });
      } else if (pathParts.includes('edit')) {
        items.push({ label: 'Edit' });
      }
    }
  }

  if (items.length === 1 && (pathname === '/dashboard' || pathname === '/dashboard/')) {
    items.push({ label: 'Home' });
  }

  if (items.length > 0) {
    const lastItem = items[items.length - 1];
    if (lastItem) {
      delete lastItem.href;
    }
  }

  return items;
};

export function Breadcrumbs() {
  const { pathname } = useLocation();

  const items = useMemo(() => getBreadcrumbItems(pathname), [pathname]);

  return (
    <nav aria-label="Breadcrumb" className="flex items-center text-xs sm:text-sm">
      {items.map((item, idx) => {
        const isLast = idx === items.length - 1;
        return (
          <span key={idx} className="flex items-center text-sm">
            <span className={isLast ? 'text-foreground font-medium' : 'text-muted-foreground flex items-center gap-1'}>
              {item.href ? (
                <Link to={item.href} className="hover:underline">
                  {item.label}
                </Link>
              ) : (
                item.label
              )}
            </span>
            {!isLast && <ChevronRight className="mx-2 h-3.5 w-3.5 text-muted-foreground" />}
          </span>
        );
      })}
    </nav>
  );
}

export default Breadcrumbs;