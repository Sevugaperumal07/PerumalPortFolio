"use client";

import { useEffect, useMemo, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import { Bell, Briefcase, ListTodo, User, Loader2, AlertTriangle, Megaphone, Users } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { ThemeToggle } from "@/components/theme-toggle";
import { getUserByEmail, getUserRoles } from "@/lib/services/users";
import {
  getUserNotifications,
  getNotificationNavigationLink,
  type Notification,
} from "@/lib/services/notifications";

const LAST_SEEN_NOTIFICATIONS_COUNT_KEY = "lastSeenNotificationsCount";

function getLastSeenCount(userId: string): number {
  try {
    const stored = localStorage.getItem(`${LAST_SEEN_NOTIFICATIONS_COUNT_KEY}_${userId}`);
    return stored ? parseInt(stored, 10) : 0;
  } catch {
    return 0;
  }
}

function saveLastSeenCount(userId: string, count: number): void {
  try {
    localStorage.setItem(`${LAST_SEEN_NOTIFICATIONS_COUNT_KEY}_${userId}`, count.toString());
  } catch (error) {
    console.error("Error saving last seen count:", error);
  }
}

export function UserNav() {
  const { user, logout } = useAuth();
  const [userData, setUserData] = useState(() => {
    const stored = localStorage.getItem("userData");
    return stored ? JSON.parse(stored) : null;
  });

  const [userRoles, setUserRoles] = useState<Array<{ name: string }>>([]);
  const [lastLoginTime, setLastLoginTime] = useState("");
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoadingNotifications, setIsLoadingNotifications] = useState(false);
  const [lastSeenCount, setLastSeenCount] = useState(0);

  useEffect(() => {
    async function fetchUser() {
      try {
        const email = user?.email || userData?.email;
        if (!email) return;

        const fetchedUser = await getUserByEmail(email);

        if (fetchedUser) {
          setUserData(fetchedUser);
          localStorage.setItem("userData", JSON.stringify(fetchedUser));

          if (fetchedUser.id) {
            try {
              const roles = await getUserRoles(fetchedUser.id);
              setUserRoles(roles);
            } catch (error) {
              console.error("Error fetching user roles:", error);
            }
          }
        }
      } catch (error) {
        console.error("Error fetching user:", error);
      }
    }

    fetchUser();
  }, [user?.email]);

  useEffect(() => {
    if (userData?.id) {
      const count = getLastSeenCount(userData.id);
      setLastSeenCount(count);
    }
  }, [userData?.id]);

  const fetchNotifications = useCallback(async () => {
    if (!userData?.id) return;

    setIsLoadingNotifications(true);
    try {
      const fetchedNotifications = await getUserNotifications(userData.id);
      setNotifications(fetchedNotifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
    } finally {
      setIsLoadingNotifications(false);
    }
  }, [userData?.id]);

  useEffect(() => {
    if (userData?.id) {
      fetchNotifications();
      const interval = setInterval(fetchNotifications, 30000);
      return () => clearInterval(interval);
    }
  }, [userData?.id, fetchNotifications]);

  useEffect(() => {
    const lastLogin = new Date();
    lastLogin.setDate(lastLogin.getDate() - 1);
    setLastLoginTime(lastLogin.toLocaleString());
  }, []);

  const userName = useMemo(() => {
    const u = userData || user || {};
    const nameParts = [
      u.firstName,
      u.lastName,
      u.given_name,
      u.family_name,
    ].filter(Boolean);

    if (nameParts.length) return nameParts.join(" ");
    if (u.userName) return u.userName;
    if (u.name) return u.name;
    if (u.email) return u.email.split("@")[0];
    return "User";
  }, [userData, user]);

  const roleName = useMemo(() => {
    if (userRoles.length > 0) {
      return userRoles[0].name;
    }
    return null;
  }, [userRoles]);

  const unreadCount = useMemo(() => {
    return Math.max(0, notifications.length - lastSeenCount);
  }, [notifications.length, lastSeenCount]);

  const handleDropdownOpenChange = (open: boolean) => {
    if (open && userData?.id && notifications.length > 0) {
      setTimeout(() => {
        saveLastSeenCount(userData.id, notifications.length);
        setLastSeenCount(notifications.length);
      }, 2000);
    }
  };

  // Get icon based on event type or note type
  const getNotificationIcon = (notification: Notification) => {
    const eventType = notification.eventType?.toUpperCase() || "";
    const noteType = notification.noteType ||
      (notification.noteTypeId === 1 ? "CASE" : notification.noteTypeId === 2 ? "TASK" : "");

    // Check for specific event types
    if (eventType.includes("HIGH_CASH") || eventType.includes("CASH")) {
      return <AlertTriangle className="w-4 h-4 text-amber-500" />;
    }
    if (eventType.includes("BROADCAST")) {
      return <Megaphone className="w-4 h-4 text-purple-500" />;
    }
    if (noteType === "CASE") {
      return <Briefcase className="w-4 h-4 text-primary" />;
    }
    if (noteType === "TASK") {
      return <ListTodo className="w-4 h-4 text-primary" />;
    }
    if (noteType === "USER" || eventType.includes("USER")) {
      return <Users className="w-4 h-4 text-blue-500" />;
    }

    return <Bell className="w-4 h-4 text-primary" />;
  };

  // Get message from notification (prefer payload title/body)
  const getNotificationMessage = (notification: Notification) => {
    const payload = notification.parsedPayload;

    // If we have parsed payload with title, use it
    if (payload?.title) {
      return payload.title;
    }

    // Fall back to content or message
    return notification.content || notification.message || "New notification";
  };

  // Get description/body from notification
  const getNotificationDescription = (notification: Notification) => {
    const payload = notification.parsedPayload;

    // If we have parsed payload with body, use it
    if (payload?.body) {
      return payload.body;
    }

    // If title was used as message, show content as description
    if (payload?.title && notification.content) {
      return notification.content;
    }

    return null;
  };

  // Get link for notification
  const getNotificationLink = (notification: Notification) => {
    const payloadLink = getNotificationNavigationLink(notification);
    if (payloadLink) {
      return payloadLink;
    }

    const eventType = notification.eventType?.toUpperCase() || "";
    const noteType = notification.noteType ||
      (notification.noteTypeId === 1 ? "CASE" : notification.noteTypeId === 2 ? "TASK" : "");
    const isCaseNote = eventType === "CASE_NOTE_NOTIFICATION" || noteType === "CASE";
    const isTaskNote = eventType === "TASK_NOTE_NOTIFICATION" || noteType === "TASK";
    const recordId = notification.caseId?.trim() || "";
    const referenceId = notification.loanNumber || notification.referenceId || "";

    if (isCaseNote) {
      if (recordId) {
        return `/dashboard/cases?caseId=${encodeURIComponent(recordId)}`;
      }
      if (referenceId) {
        return `/dashboard/cases?lan=${encodeURIComponent(referenceId)}`;
      }
      return "/dashboard/cases";
    }
    if (isTaskNote) {
      if (recordId) {
        return `/dashboard/tasks?caseId=${encodeURIComponent(recordId)}`;
      }
      if (referenceId) {
        return `/dashboard/tasks?lan=${encodeURIComponent(referenceId)}`;
      }
      return "/dashboard/tasks";
    }

    return "/dashboard/notes";
  };

  // Format time
  const formatTime = (dateString: string) => {
    try {
      const date = new Date(dateString);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMs / 3600000);
      const diffDays = Math.floor(diffMs / 86400000);

      if (diffMins < 1) return "Just now";
      if (diffMins < 60) return `${diffMins}m ago`;
      if (diffHours < 24) return `${diffHours}h ago`;
      if (diffDays < 7) return `${diffDays}d ago`;
      return date.toLocaleDateString();
    } catch {
      return "";
    }
  };

  return (
    <div className="flex items-center gap-4">
      <div className="hidden md:flex flex-col items-end">
        <p className="text-sm font-medium">
          Welcome {roleName ? `${roleName} ` : ""}{userName}
        </p>
        {lastLoginTime && (
          <p className="text-xs text-muted-foreground">Last login: {lastLoginTime}</p>
        )}
      </div>
      <ThemeToggle />
      <DropdownMenu onOpenChange={handleDropdownOpenChange}>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-10 w-10 rounded-full">
            <Bell className="h-5 w-5" />
            {unreadCount > 0 && (
              <Badge
                variant="destructive"
                className="absolute top-1 right-1 h-4 w-4 justify-center p-0 text-[10px]"
              >
                {unreadCount > 9 ? "9+" : unreadCount}
              </Badge>
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-80" align="end">
          <DropdownMenuLabel>
            <p className="font-semibold">Notifications</p>
            <p className="text-xs text-muted-foreground">
              {unreadCount > 0
                ? `You have ${unreadCount} unread message${unreadCount > 1 ? "s" : ""}.`
                : "No new notifications."}
            </p>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuGroup className="overflow-y-auto max-h-80">
            {isLoadingNotifications ? (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                <span className="ml-2 text-sm text-muted-foreground">Loading...</span>
              </div>
            ) : notifications.length === 0 ? (
              <div className="text-center py-4 text-sm text-muted-foreground">
                No notifications yet.
              </div>
            ) : (
              notifications.slice(0, 10).map((notification, index) => {
                const isNew = index < unreadCount;
                const message = getNotificationMessage(notification);
                const description = getNotificationDescription(notification);

                const eventType = notification.eventType?.toUpperCase() || "";
                const isHighCashAlert = eventType.includes("HIGH_CASH");

                // Senior dev rule: High cash alerts navigate to Tasks -> Branch Ops In Hand
                const navigationLink = isHighCashAlert ? "/dashboard/tasks" : getNotificationLink(notification);
                const navigationState = isHighCashAlert ? { tab: "Pending" } : undefined;

                return (
                  <DropdownMenuItem
                    key={notification.id || notification.messageId || index}
                    className={cn(
                      "gap-2 items-start cursor-pointer",
                      isNew && "bg-accent/50"
                    )}
                    asChild
                  >
                    <Link to={navigationLink} state={navigationState}>
                      <div className="flex-shrink-0 mt-1">
                        {getNotificationIcon(notification)}
                      </div>
                      <div className="flex flex-col flex-1 min-w-0">
                        <p className="text-sm leading-snug whitespace-normal font-medium">
                          {message}
                        </p>
                        {description && (
                          <p className="text-xs text-muted-foreground whitespace-normal mt-0.5 line-clamp-2">
                            {description}
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground mt-1">
                          {formatTime(notification.createdAt)}
                        </p>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                );
              })
            )}
          </DropdownMenuGroup>
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild className="justify-center text-sm text-primary hover:underline">
            <Link to="/dashboard/notes">View all notifications</Link>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-8 w-8 rounded-full">
            <User />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56" align="end" forceMount>
          <DropdownMenuLabel className="font-normal">
            <div className="flex flex-col space-y-1">
              <p className="text-sm font-medium leading-none">{roleName ? `${roleName} ` : ""} {userName}</p>
              {(userData?.email || user?.email) && (
                <p className="text-xs leading-none text-muted-foreground break-words">{userData?.email || user?.email}</p>
              )}
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuGroup>
            <DropdownMenuItem>Profile</DropdownMenuItem>
            <DropdownMenuItem>Settings</DropdownMenuItem>
          </DropdownMenuGroup>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            className="text-destructive focus:text-white focus:bg-destructive cursor-pointer"
            onSelect={() => logout({ skipApiCall: false })}
          >
            Log out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

export default UserNav;
