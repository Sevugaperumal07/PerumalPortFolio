import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useIdleTimer } from '@/hooks/useIdleTimer';
import { SESSION_EXPIRED_EVENT } from '@/lib/utils/NavigateService';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Loader2 } from 'lucide-react';

/**
 * SessionTimeoutHandler manages the idle session lifecycle and renders the warning dialog.
 * Warning shows at 14 minutes (60 seconds before logout).
 * Automatic logout occurs at 15 minutes.
 */
export function SessionTimeoutHandler() {
    const { logout, isAuthenticated, sessionTimeout } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const [expiryMessage, setExpiryMessage] = useState<string | null>(null);

    useEffect(() => {
        const handleSessionExpired = (event: Event) => {
            const customEvent = event as CustomEvent<{ message?: string }>;
            if (customEvent.detail?.message) {
                setExpiryMessage(customEvent.detail.message);
            }
        };

        window.addEventListener(SESSION_EXPIRED_EVENT, handleSessionExpired);
        return () => window.removeEventListener(SESSION_EXPIRED_EVENT, handleSessionExpired);
    }, []);

    // Dynamically calculate thresholds from the backend-provided timeout
    // sessionTimeout is in seconds
    // 5 seconds are subtracted for safety before backend timeout occurs frontend timeout will be 5 seconds less than backend timeout
    const ACTIVE_IDLE_TIMEOUT = sessionTimeout - 5;
    const BACKGROUND_TIMEOUT = sessionTimeout - 5;

    // Show warning 30 seconds before timeout, or 50% of the time if session is very short
    const WARNING_THRESHOLD = sessionTimeout > 60 ? 30 : Math.floor(sessionTimeout / 2);

    const { isWarning, isExpired, timeLeft } = useIdleTimer({
        activeIdleTimeout: ACTIVE_IDLE_TIMEOUT,
        backgroundTimeout: BACKGROUND_TIMEOUT,
        warningThreshold: WARNING_THRESHOLD,
        onIdle: () => {
            console.warn('Session timeout reached. logging out...');
            logout();
        },
    });

    const handleLoginAgain = async () => {
        await logout({ skipApiCall: true });
        navigate('/login', { replace: true });
    };

    // Don't show the modal if we are on the login page
    if (location.pathname === '/login') return null;
    if (location.pathname === '/login/verify-otp') return null;
    if (location.pathname === '/login/reset-password') return null;

    if (!isAuthenticated && !isExpired) return null;

    return (
        <AlertDialog open={(isAuthenticated && isWarning) || isExpired}>
            <AlertDialogContent className="max-w-[400px]">
                <AlertDialogHeader>
                    <AlertDialogTitle className="flex items-center gap-2">
                        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-amber-100 text-amber-600">
                            <Loader2 className="h-4 w-4 animate-spin" />
                        </span>
                        {isExpired ? 'Session Expired' : 'Session Expiring'}
                    </AlertDialogTitle>
                    <AlertDialogDescription className="text-base text-neutral-600 text-center">
                        {isExpired ? (
                            <>{expiryMessage || 'Your session expired due to inactivity.'}</>
                        ) : (
                            <>
                                You have been idle for a while. For your security, you will be logged out in
                                <span className="block mt-2 font-bold text-rose-600 underline decoration-2 underline-offset-2">
                                    {timeLeft} seconds
                                </span>
                            </>
                        )}
                    </AlertDialogDescription>
                </AlertDialogHeader>
                {isExpired && (
                    <AlertDialogFooter className="flex-col sm:flex-row gap-2 mt-4">
                        <AlertDialogAction
                            onClick={handleLoginAgain}
                            className="bg-rose-600 hover:bg-rose-700 w-full"
                        >
                            Login Again
                        </AlertDialogAction>
                    </AlertDialogFooter>
                )}
            </AlertDialogContent>
        </AlertDialog>
    );
}
