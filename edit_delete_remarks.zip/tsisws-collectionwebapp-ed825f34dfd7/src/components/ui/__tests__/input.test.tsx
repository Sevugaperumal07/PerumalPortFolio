import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { Input } from '../input'

describe('Input', () => {
  it('should render input element', () => {
    render(<Input placeholder="Enter text" />)
    expect(screen.getByPlaceholderText('Enter text')).toBeInTheDocument()
  })

  it('should handle text input', async () => {
    const user = userEvent.setup()
    render(<Input placeholder="Enter text" />)
    
    const input = screen.getByPlaceholderText('Enter text')
    await user.type(input, 'Hello World')
    
    expect(input).toHaveValue('Hello World')
  })

  it('should handle onChange event', async () => {
    const handleChange = vi.fn()
    const user = userEvent.setup()
    
    render(<Input onChange={handleChange} placeholder="Enter text" />)
    
    const input = screen.getByPlaceholderText('Enter text')
    await user.type(input, 'Test')
    
    expect(handleChange).toHaveBeenCalled()
  })

  it('should be disabled when disabled prop is true', () => {
    render(<Input disabled placeholder="Disabled input" />)
    expect(screen.getByPlaceholderText('Disabled input')).toBeDisabled()
  })

  it('should render with different types', () => {
    const { rerender } = render(<Input type="email" data-testid="input" />)
    expect(screen.getByTestId('input')).toHaveAttribute('type', 'email')
    
    rerender(<Input type="password" data-testid="input" />)
    expect(screen.getByTestId('input')).toHaveAttribute('type', 'password')
    
    rerender(<Input type="number" data-testid="input" />)
    expect(screen.getByTestId('input')).toHaveAttribute('type', 'number')
  })

  it('should apply custom className', () => {
    render(<Input className="custom-class" data-testid="input" />)
    expect(screen.getByTestId('input')).toHaveClass('custom-class')
  })

  it('should support defaultValue', () => {
    render(<Input defaultValue="Default text" data-testid="input" />)
    expect(screen.getByTestId('input')).toHaveValue('Default text')
  })

  it('should support value prop (controlled)', () => {
    const { rerender } = render(<Input value="Initial" onChange={() => {}} data-testid="input" />)
    expect(screen.getByTestId('input')).toHaveValue('Initial')
    
    rerender(<Input value="Updated" onChange={() => {}} data-testid="input" />)
    expect(screen.getByTestId('input')).toHaveValue('Updated')
  })

  it('should support required attribute', () => {
    render(<Input required data-testid="input" />)
    expect(screen.getByTestId('input')).toBeRequired()
  })

  it('should support maxLength attribute', () => {
    render(<Input maxLength={10} data-testid="input" />)
    expect(screen.getByTestId('input')).toHaveAttribute('maxLength', '10')
  })

  it('should support readOnly attribute', () => {
    render(<Input readOnly value="Read only" data-testid="input" />)
    const input = screen.getByTestId('input')
    expect(input).toHaveAttribute('readOnly')
    expect(input).toHaveValue('Read only')
  })

  it('should support aria-label', () => {
    render(<Input aria-label="Username input" data-testid="input" />)
    expect(screen.getByTestId('input')).toHaveAttribute('aria-label', 'Username input')
  })

  it('should support name attribute', () => {
    render(<Input name="username" data-testid="input" />)
    expect(screen.getByTestId('input')).toHaveAttribute('name', 'username')
  })
})

