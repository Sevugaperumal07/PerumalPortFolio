/**
 * Centralized configuration for the application.
 * All environment variables should be accessed through this object.
 */
export const config = {
  api: {
    baseUrl: import.meta.env.VITE_API_BASE_URL || '',
    notificationsUrl: import.meta.env.VITE_NOTIFICATIONS_API_BASE_URL || '',
    notesUrl: import.meta.env.VITE_NOTES_API_BASE_URL || '',
    screenshotUrl: import.meta.env.VITE_API_SCREENSHOT_URL || '',
    dashboardUrl: import.meta.env.VITE_DASHBOARD_API_BASE_URL || '',
  },
  google: {
    mapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '',
  },
  isDev: import.meta.env.DEV,
  isProd: import.meta.env.PROD,
};

export default config;
