const acceptanceStatusTabs = {
    CASE_PENDING: "Case Pending",
    PENDING: "Pending",
    ACCEPTANCE_PENDING: "Acceptance Pending",
    BRANCH_OPS_IN_HAND: "Branch Ops In Hand",
    VERIFICATION_PENDING: "Verification Pending",
    VERIFICATION_COMPLETED: "Verification Completed",
    VERIFIED_BY_HO: "Verified By HO",
}

export default acceptanceStatusTabs;
