const depositStatus = {
    VERIFICATION_PENDING: "Verification Pending",
    VERIFICATION_COMPLETED: "Verification Completed",
    REJECTED: "rejected",
}

export default depositStatus;