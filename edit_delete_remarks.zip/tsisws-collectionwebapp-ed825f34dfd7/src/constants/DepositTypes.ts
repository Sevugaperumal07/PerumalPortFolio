const depositTypes = {
    BRANCH_DEPOSIT: "Branch Deposit",
    BANK_DEPOSIT: "Bank Deposit",
}

export default depositTypes;