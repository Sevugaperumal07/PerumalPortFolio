const ErrorStatusCode = {
    INVALID_OR_EXPIRED_TOKEN: "AUTH-003",
    SESSION_EXPIRED: "AUTH-005",
    NO_ACTIVE_SESSIONS_FOUND: "AUTH-007",
}

export default ErrorStatusCode;
