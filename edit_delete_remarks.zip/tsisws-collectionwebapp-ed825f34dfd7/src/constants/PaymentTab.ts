const paymentTab = {
    UPI: "UPI",
    CASH: "Cash",
}

export default paymentTab;