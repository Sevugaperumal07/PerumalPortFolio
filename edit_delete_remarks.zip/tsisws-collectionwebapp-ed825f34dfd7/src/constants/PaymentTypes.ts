export const PaymentTypes = {
    CASH: "Cash",
    CHEQUE: "Cheque",
    NEFT: "NEFT",
    RTGS: "RTGS",
    UPI: "UPI",
    IMPS: "IMPS",
}