import { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import { login as loginApi, logout as logoutApi, getToken, refreshAccessToken } from '@/lib/api/auth';
import type { LoginRequest, LoginResponse } from '@/lib/types';
import { TokenService } from '@/lib/api/token-service';

type AuthUser = {
  firstName?: string;
  lastName?: string;
  given_name?: string;
  family_name?: string;
  userName?: string;
  name?: string;
  email?: string;
  id?: string;
};

interface AuthContextType {
  isAuthenticated: boolean;
  token: string | null;
  user: AuthUser | null;
  login: (credentials: LoginRequest) => Promise<LoginResponse>;
  logout: (options?: { skipApiCall?: boolean }) => Promise<void>;
  loading: boolean;
  sessionTimeout: number; // in seconds
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const USER_STORAGE_KEY = 'auth:user';
const SESSION_TIMEOUT_KEY = 'auth:idle_timeout';
const DEFAULT_IDLE_TIMEOUT = 15 * 60; // 15 minutes default

function asString(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined;
}

function asEmail(value: unknown): string | undefined {
  const maybe = asString(value)?.trim();
  if (!maybe) return undefined;
  return maybe.includes('@') ? maybe : undefined;
}

function decodeJwt<T>(token: string): T | null {
  try {
    const payload = token.split('.')?.[1];
    if (!payload) return null;
    const normalized = payload.replace(/-/g, '+').replace(/_/g, '/');
    const decoded = atob(normalized);
    const utf8 = decodeURIComponent(
      decoded
        .split('')
        .map((char) => `%${char.charCodeAt(0).toString(16).padStart(2, '0')}`)
        .join('')
    );
    return JSON.parse(utf8) as T;
  } catch {
    return null;
  }
}

function getUserFromToken(token: string | null): AuthUser | null {
  if (!token) return null;
  const payload = decodeJwt<Record<string, unknown>>(token);
  if (!payload) return null;
  const firstName =
    asString(payload.firstName) ?? asString(payload.given_name) ?? asString(payload.first_name);
  const lastName =
    asString(payload.lastName) ?? asString(payload.family_name) ?? asString(payload.last_name);
  const email =
    asEmail(payload.email) ??
    asEmail(payload.userEmail) ??
    asEmail(payload.user_email) ??
    asEmail(payload.mail) ??
    asEmail(payload.preferred_username) ??
    asEmail(payload.upn) ??
    asEmail(payload.sub);
  const id = asString(payload.id) ?? asString(payload.userId) ?? asString(payload.sub);
  const userName =
    asString(payload.userName) ??
    asString(payload.name) ??
    asString(payload.preferred_username) ??
    asString(payload.username) ??
    asString(payload.sub);

  return { firstName, lastName, email, userName, id };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [sessionTimeout, setSessionTimeout] = useState<number>(() => {
    const stored = sessionStorage.getItem(SESSION_TIMEOUT_KEY);
    return stored ? parseInt(stored, 10) : DEFAULT_IDLE_TIMEOUT;
  });

  const USER_METADATA_COOKIE = 'auth_metadata';

  const saveMetadata = (user: AuthUser | null) => {
    if (user?.email) {
      // Store non-sensitive metadata for cross-tab sync (1 day expiry)
      const metadata = JSON.stringify({ email: user.email, name: user.name || user.userName });
      document.cookie = `${USER_METADATA_COOKIE}=${encodeURIComponent(metadata)}; path=/; max-age=86400; SameSite=Lax`;
    }
  };

  const getMetadata = (): AuthUser | null => {
    const match = document.cookie.match(new RegExp('(^| )' + USER_METADATA_COOKIE + '=([^;]+)'));
    if (match) {
      try {
        return JSON.parse(decodeURIComponent(match[2])) as AuthUser;
      } catch {
        return null;
      }
    }
    return null;
  };

  useEffect(() => {
    const initializeAuth = async () => {
      const storedToken = getToken();
      const storedUserRaw = sessionStorage.getItem(USER_STORAGE_KEY);
      let restoredUser: AuthUser | null = null;

      if (storedUserRaw) {
        try {
          restoredUser = JSON.parse(storedUserRaw) as AuthUser;
          setUser(restoredUser);
        } catch {
          sessionStorage.removeItem(USER_STORAGE_KEY);
        }
      } else {
        // New Tab: try to recover from metadata cookie
        restoredUser = getMetadata();
        if (restoredUser) {
          setUser(restoredUser);
          sessionStorage.setItem(USER_STORAGE_KEY, JSON.stringify(restoredUser));
        }
      }

      if (storedToken) {
        setToken(storedToken);
      }

      // Always attempt to re-validate session via HttpOnly cookie
      try {
        const refreshResult = await refreshAccessToken();
        if (refreshResult && 'accessToken' in refreshResult) {
          setToken(refreshResult.accessToken);

          if (refreshResult.sessionIdleTimeoutMs) {
            const timeoutSeconds = Math.floor(refreshResult.sessionIdleTimeoutMs / 1000);
            setSessionTimeout(timeoutSeconds);
            sessionStorage.setItem(SESSION_TIMEOUT_KEY, timeoutSeconds.toString());
          }

          const parsedUser = getUserFromToken(refreshResult.accessToken);
          if (parsedUser) {
            setUser(prev => {
              const merged = {
                ...prev,
                ...parsedUser,
                email: parsedUser.email || prev?.email || restoredUser?.email
              };
              saveMetadata(merged);
              sessionStorage.setItem(USER_STORAGE_KEY, JSON.stringify(merged));
              return merged;
            });
          }
        }
      } catch (error) {
        // We don't re-throw here to allow unauthenticated users to see login
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();
  }, []);

  const login = async (credentials: LoginRequest): Promise<LoginResponse> => {
    try {
      const response = await loginApi(credentials);
      const parsedUser = getUserFromToken(response.accessToken);
      const emailFromToken = asEmail(parsedUser?.email);
      setToken(response.accessToken);

      if (response.sessionIdleTimeoutMs) {
        const timeoutSeconds = Math.floor(response.sessionIdleTimeoutMs / 1000);
        setSessionTimeout(timeoutSeconds);
        sessionStorage.setItem(SESSION_TIMEOUT_KEY, timeoutSeconds.toString());
      }

      const nextUser: AuthUser = {
        email: emailFromToken ?? credentials.email,
        firstName: parsedUser?.firstName,
        lastName: parsedUser?.lastName,
        userName: parsedUser?.userName,
        id: parsedUser?.id,
      };
      setUser(nextUser);
      saveMetadata(nextUser);
      sessionStorage.setItem(USER_STORAGE_KEY, JSON.stringify(nextUser));
      return response; 
    } catch (error) {
      throw error;
    }
  };

  const logout = async (options?: { skipApiCall?: boolean }) => {
    const userId = user?.id;
    try {
      if (!options?.skipApiCall) {
        console.log('Logging out...');
        await logoutApi();
      }
    } catch (error) {
      console.error('Logout failed', error);
    } finally {
      setToken(null);
      setUser(null);
      sessionStorage.removeItem(USER_STORAGE_KEY);
      sessionStorage.removeItem(SESSION_TIMEOUT_KEY);
      localStorage.removeItem('userData');
      TokenService.clearAllTokens();

      // Clear metadata cookie
      document.cookie = `${USER_METADATA_COOKIE}=; path=/; max-age=0; SameSite=Lax`;

      if (userId) {
        localStorage.removeItem(`unread_notifications_${userId}`);
        localStorage.removeItem(`lastSeenNotificationsCount_${userId}`);
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated: !!token,
        token,
        user,
        login,
        logout,
        loading,
        sessionTimeout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
