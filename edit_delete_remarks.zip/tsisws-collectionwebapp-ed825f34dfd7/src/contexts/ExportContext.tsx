import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

interface ExportContextType {
    isExporting: boolean;
    setIsExporting: (status: boolean) => void;
}

const ExportContext = createContext<ExportContextType | undefined>(undefined);

export const ExportProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [isExporting, setIsExporting] = useState(false);
    const { token } = useAuth();

    // Automatically reset export state when user logs out
    useEffect(() => {
        if (!token) {
            setIsExporting(false);
        }
    }, [token]);

    return (
        <ExportContext.Provider value={{ isExporting, setIsExporting }}>
            {children}
        </ExportContext.Provider>
    );
};

export const useExport = () => {
    const context = useContext(ExportContext);
    if (context === undefined) {
        throw new Error('useExport must be used within an ExportProvider');
    }
    return context;
};
