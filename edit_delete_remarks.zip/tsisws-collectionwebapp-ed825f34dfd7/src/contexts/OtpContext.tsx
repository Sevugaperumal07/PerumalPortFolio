import { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import type { ReactNode } from 'react';

const OTP_EXPIRY_KEY = 'otp_session_expiry';
const OTP_SESSION_KEY = 'otp_overall_session';

const OTP_CONFIG = {
  RESEND_COOLDOWN: 60, // seconds
  SESSION_DURATION: 180, // 3 minutes in seconds
};

interface OtpContextType {
  otpSent: boolean;
  timerSeconds: number;
  resendEnabled: boolean;
  setOtpSent: (val: boolean) => void;
  startCooldown: (seconds?: number) => void;
  resetOtpFlow: () => void;
}

const OtpContext = createContext<OtpContextType | undefined>(undefined);

export function OtpProvider({ children }: { children: ReactNode }) {
  const [otpSent, setOtpSent] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [resendEnabled, setResendEnabled] = useState(true);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const resetOtpFlow = useCallback(() => {
    setOtpSent(false);
    setTimerSeconds(0);
    setResendEnabled(true);
    if (timerRef.current) clearInterval(timerRef.current);
    sessionStorage.removeItem(OTP_EXPIRY_KEY);
    sessionStorage.removeItem(OTP_SESSION_KEY);
  }, []);

  const startCooldown = useCallback((seconds: number = OTP_CONFIG.RESEND_COOLDOWN) => {
    setTimerSeconds(seconds);
    setResendEnabled(false);

    // 1. Resend Cooldown (45s by default)
    const resendExpiry = Date.now() + seconds * 1000;
    sessionStorage.setItem(OTP_EXPIRY_KEY, resendExpiry.toString());

    // 2. Overall Session Window (3m) — Only set if not already active
    if (!sessionStorage.getItem(OTP_SESSION_KEY)) {
      const sessionExpiry = Date.now() + OTP_CONFIG.SESSION_DURATION * 1000;
      sessionStorage.setItem(OTP_SESSION_KEY, sessionExpiry.toString());
    }
  }, []);

  // Timer Tick Logic (Reactive)
  useEffect(() => {
    if (timerSeconds > 0) {
      setResendEnabled(false);
      timerRef.current = setInterval(() => {
        setTimerSeconds((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setResendEnabled(true);
            sessionStorage.removeItem(OTP_EXPIRY_KEY);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      setResendEnabled(true);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [timerSeconds > 0]); // Only re-run when we start/stop

  // Sync state on mount & monitor session expiry
  useEffect(() => {
    const storedSession = sessionStorage.getItem(OTP_SESSION_KEY);
    const storedResend = sessionStorage.getItem(OTP_EXPIRY_KEY);
    let sessionTimeout: ReturnType<typeof setTimeout> | null = null;

    if (storedSession) {
      const sessionExpiry = parseInt(storedSession, 10);
      const remainingSession = sessionExpiry - Date.now();

      if (remainingSession <= 0) {
        resetOtpFlow();
      } else {
        setOtpSent(true);
        sessionTimeout = setTimeout(resetOtpFlow, remainingSession);

        // Resume resend timer if still active
        if (storedResend) {
          const resendExpiry = parseInt(storedResend, 10);
          const remainingResend = Math.floor((resendExpiry - Date.now()) / 1000);
          if (remainingResend > 0) {
            setTimerSeconds(remainingResend);
          } else {
            sessionStorage.removeItem(OTP_EXPIRY_KEY);
            setResendEnabled(true);
          }
        }
      }
    } else {
      setOtpSent(false);
    }

    return () => {
      if (sessionTimeout) clearTimeout(sessionTimeout);
    };
  }, [resetOtpFlow]); // startCooldown removed from deps to prevent re-runs

  return (
    <OtpContext.Provider
      value={{
        otpSent,
        timerSeconds,
        resendEnabled,
        setOtpSent,
        startCooldown,
        resetOtpFlow,
      }}
    >
      {children}
    </OtpContext.Provider>
  );
}

export function useOtp() {
  const context = useContext(OtpContext);
  if (context === undefined) {
    throw new Error('useOtp must be used within an OtpProvider');
  }
  return context;
}
