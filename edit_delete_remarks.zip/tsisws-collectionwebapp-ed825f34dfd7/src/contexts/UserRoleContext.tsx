import { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { graphqlRequest } from '@/lib/graphql/client';
import { GET_USER_BY_EMAIL, GET_ROLES_BY_USER_ID } from '@/lib/graphql/queries/users';
import { getRoleMatrix } from '@/lib/services/roles';
import { SessionExpiredError } from '@/lib/utils/errors';
import type { User, Role } from '@/lib/types';
import type { RoleMatrixResponse } from '@/components/dashboard/RoleAccessSetup';

interface StoredAuthUser {
    email?: string | null;
    userName?: string | null;
}

interface UserRoleContextType {
    currentUserId: string | null;
    currentUserRoleId: string | null;
    roleMatrixData: RoleMatrixResponse | null;
    loading: boolean;
    isInitialized: boolean;
    refreshRoleData: () => Promise<void>;
    canAccessCategory: (category: string, action?: string) => boolean;
}

const UserRoleContext = createContext<UserRoleContextType | undefined>(undefined);

export function UserRoleProvider({ children }: { children: ReactNode }) {
    const { user, isAuthenticated, loading: authLoading, token } = useAuth();
    const [storedUser, setStoredUser] = useState<StoredAuthUser | null>(null);
    const [currentUserId, setCurrentUserId] = useState<string | null>(null);
    const [currentUserRoleId, setCurrentUserRoleId] = useState<string | null>(null);
    const [roleMatrixData, setRoleMatrixData] = useState<RoleMatrixResponse | null>(null);
    const [loading, setLoading] = useState(true);
    const [isInitialized, setIsInitialized] = useState(false);
    const [lastUserId, setLastUserId] = useState<string | null>(null);
    const [lastToken, setLastToken] = useState<string | null>(null);

    // Get stored user from sessionStorage
    useEffect(() => {
        if (user?.email) {
            setStoredUser(null);
            return;
        }
        if (typeof window === "undefined") {
            return;
        }
        try {
            const raw = sessionStorage.getItem("auth:user");
            if (raw) {
                setStoredUser(JSON.parse(raw));
            }
        } catch {
            setStoredUser(null);
        }
    }, [user?.email]);

    const userEmail = user?.email ?? storedUser?.email ?? undefined;

    /**
     * Fetch all role-related data for the given email.
     * This is a complete refresh of the user's permissions.
     */
    const fetchData = async (email: string) => {
        if (!email) {
            setLoading(false);
            return;
        }

        setLoading(true);
        // but clear it if it's a new user or a new token/session to avoid stale data.
        if (email !== lastUserId || (token && token !== lastToken)) {
            setCurrentUserId(null);
            setCurrentUserRoleId(null);
            setRoleMatrixData(null);
        }
        
        setLastUserId(email);
        if (token) setLastToken(token);
        
        try {
            // 1. Fetch User ID
            const userResponse = await graphqlRequest<{ getUserByEmail: User | null }>(
                GET_USER_BY_EMAIL,
                { email }
            );
            const fetchedId = userResponse?.getUserByEmail?.id ?? null;
            setCurrentUserId(fetchedId);

            if (!fetchedId) {
                setCurrentUserRoleId(null);
                setRoleMatrixData(null);
                return;
            }

            // 2. Fetch User Role
            const rolesData = await graphqlRequest<{ getRolesByUserId: Role[] }>(
                GET_ROLES_BY_USER_ID,
                { userId: fetchedId }
            );
            const roles = rolesData?.getRolesByUserId || [];
            const roleId = roles.length > 0 ? roles[0].id : null;
            setCurrentUserRoleId(roleId);

            if (!roleId) {
                setRoleMatrixData(null);
                return;
            }

            // 3. Fetch Role Matrix
            const matrixData = await getRoleMatrix(roleId);
            setRoleMatrixData(matrixData);
        } catch (err) {
            if (err instanceof SessionExpiredError) {
                // Stop execution immediately on session expiry.
                // Do NOT reset state to null to avoid "Unauthorized" redirects in the UI.
                return;
            }
            console.error("[UserRoleContext] Error fetching user role data:", err);
        } finally {
            setLoading(false);
            setIsInitialized(true);
        }
    };

    const refreshRoleData = async () => {
        if (userEmail) {
            setCurrentUserId(null);
            setCurrentUserRoleId(null);
            setLastUserId(null); 
            await fetchData(userEmail);
        } else {
            setLoading(false);
        }
    };

    const canAccessCategory = (
        category: string,
        action?: string
    ): boolean => {
        if (!roleMatrixData?.matrix) return false;

        const categoryMatrix = roleMatrixData.matrix.find(
            (cat: { category: string; actions: { action: string; effectiveLevel: number }[] }) =>
                cat.category === category
        );

        if (!categoryMatrix) return false;

        // If specific action is provided → check only that action
        if (action) {
            const targetAction = categoryMatrix.actions.find(
                (a: { action: string; effectiveLevel: number }) =>
                    a.action === action
            );

            return targetAction ? targetAction.effectiveLevel > 0 : false;
        }

        // If no action provided → default to ACCESS only
        const accessAction = categoryMatrix.actions.find(
            (a: { action: string; effectiveLevel: number }) =>
                a.action === 'ACCESS'
        );

        return accessAction ? accessAction.effectiveLevel > 0 : false;
    };

    // Effect to handle initialization and session restoration
    useEffect(() => {
        // Wait for AuthContext to resolve initial state
        if (authLoading) return;

        // Reset if not authenticated
        if (!isAuthenticated) {
            setCurrentUserId(null);
            setCurrentUserRoleId(null);
            setRoleMatrixData(null);
            setLastUserId(null);
            setLoading(false);
            setIsInitialized(false);
            return;
        }

        // Fetch if authenticated and we have the email
        if (userEmail) {
            // Fetch if user changed OR if token changed (new login)
            if (userEmail !== lastUserId || (token && token !== lastToken)) {
                fetchData(userEmail);
            }
        }
    }, [userEmail, authLoading, isAuthenticated, lastUserId, token, lastToken]);

    return (
        <UserRoleContext.Provider 
            value={{ 
                currentUserId, 
                currentUserRoleId, 
                roleMatrixData, 
                loading, 
                isInitialized,
                refreshRoleData, 
                canAccessCategory 
            }}
        >
            {children}
        </UserRoleContext.Provider>
    );
}

export function useUserRole() {
    const context = useContext(UserRoleContext);
    if (context === undefined) {
        throw new Error('useUserRole must be used within a UserRoleProvider');
    }
    return context;
}

