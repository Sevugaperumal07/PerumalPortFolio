import { useState, useEffect } from 'react';
import { graphqlRequest } from '@/lib/graphql/client';
import { GET_SECURITY_GROUPS_BY_USER_ID } from '@/lib/graphql/queries/users';
import type { SecurityGroup } from '@/lib/types';
import { useAuth } from '@/contexts/AuthContext';

export function useSecurityGroups() {
    const { user } = useAuth();
    const [securityGroups, setSecurityGroups] = useState<SecurityGroup[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (!user?.id) return;

        let isCancelled = false;

        const fetchSecurityGroups = async () => {
            setLoading(true);
            setError(null);
            try {
                const response = await graphqlRequest<{ getSecurityGroupsByUserId: { securityGroups: SecurityGroup[] } }>(
                    GET_SECURITY_GROUPS_BY_USER_ID,
                    { userId: user.id }
                );

                if (!isCancelled) {
                    setSecurityGroups(response?.getSecurityGroupsByUserId?.securityGroups ?? []);
                }
            } catch (err) {
                if (!isCancelled) {
                    setError(err instanceof Error ? err.message : 'Failed to fetch security groups');
                }
            } finally {
                if (!isCancelled) {
                    setLoading(false);
                }
            }
        };

        fetchSecurityGroups();

        return () => {
            isCancelled = true;
        };
    }, [user?.id]);

    return { securityGroups, loading, error };
}
