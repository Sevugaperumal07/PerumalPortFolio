import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { createAccountAddressManagement } from "@/lib/services/cases";
import type { AccountAddressManagementInput, Case } from "@/lib/types";

export function useAddAddress() {
    const [isLoading, setIsLoading] = useState(false);
    const { toast } = useToast();

    const addAddress = async (
        caseData: Case,
        data: { address: string; locname: string; latitude?: number; longitude?: number }
    ) => {
        setIsLoading(true);
        try {
            const input: AccountAddressManagementInput = {
                accountId: caseData.id || "",
                userId: caseData.userId || "",
                address: data.address,
                locname: data.locname,
                latitude: data.latitude,
                longitude: data.longitude,
                accountAddressDateTime: new Date().toISOString().replace('Z', ''),
                deleted: false,
            };

            const result = await createAccountAddressManagement(input);

            if (result) {
                toast({
                    title: "Success",
                    description: "Address added successfully.",
                });
                return result;
            }
            throw new Error("Failed to create address");
        } catch (error: any) {
            console.error("Add Address Error:", error);
            toast({
                title: "Error",
                description: error.message || "Failed to add address. Please try again.",
                variant: "destructive",
            });
            return null;
        } finally {
            setIsLoading(false);
        }
    };

    return {
        addAddress,
        isLoading,
    };
}
