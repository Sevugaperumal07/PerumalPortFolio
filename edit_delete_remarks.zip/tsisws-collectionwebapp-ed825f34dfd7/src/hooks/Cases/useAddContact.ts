import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { createAccountContact } from "@/lib/services/cases";
import type { AccountContactInput, Case } from "@/lib/types";

export function useAddContact() {
    const [isLoading, setIsLoading] = useState(false);
    const { toast } = useToast();

    const addContact = async (
        caseData: Case,
        data: { name: string; phone: string; latitude: number; longitude: number }
    ) => {
        setIsLoading(true);
        try {
            const input: AccountContactInput = {
                accountId: caseData.id || "",
                userId: caseData.userId || "",
                hiveId: crypto.randomUUID(),
                contactName: data.name,
                contactNumber: data.phone,
                latitude: data.latitude,
                longitude: data.longitude,
                accountContactdateEntered: new Date().toISOString().replace('Z', ''),
                deleted: false,
            };

            const result = await createAccountContact(input);

            if (result) {
                toast({
                    title: "Success",
                    description: "Contact added successfully.",
                });
                return result;
            }
            throw new Error("Failed to create contact");
        } catch (error: any) {
            console.error("Add Contact Error:", error);
            toast({
                title: "Error",
                description: error.message || "Failed to add contact. Please try again.",
                variant: "destructive",
            });
            return null;
        } finally {
            setIsLoading(false);
        }
    };

    return {
        addContact,
        isLoading,
    };
}
