import { useState, useMemo, useEffect } from "react";
import type { AdvancedFilterParamsCases, StateSecurityGroup, BranchRecord } from "@/lib/types";
import { getUsersBySecurityGroupId } from "@/lib/services/tasks";

export const INITIAL_FILTERS: AdvancedFilterParamsCases = {
    branch: "",
    state: "",
    agent: "",
    lan: "",
};

interface UseAdvancedSearchTasksProps {
    states: StateSecurityGroup[];
    pageIndex: number;
    pageSize: number;
}

interface Agent {
    id: string;
    userName: string;
}

export function useAdvancedSearchCases({
    states,
}: UseAdvancedSearchTasksProps) {
    // Advanced Search filter states
    const [isAdvancedSearchOpen, setIsAdvancedSearchOpen] = useState(false);
    const [filters, setFilters] = useState<AdvancedFilterParamsCases>(INITIAL_FILTERS);
    const [appliedFilters, setAppliedFilters] = useState<AdvancedFilterParamsCases>(INITIAL_FILTERS);
    const [agents, setAgents] = useState<Agent[]>([]);
    const [isLoadingAgents, setIsLoadingAgents] = useState(false);

    // Get branches for selected state
    const branches = useMemo<BranchRecord[]>(() => {
        if (!filters.state) return [];
        const selectedState = states.find(s => s.stateName === filters.state);
        return selectedState?.branches || [];
    }, [states, filters.state]);

    // Get security group ID for selected branch (for fetching agents)
    const selectedSecurityGroupId = useMemo(() => {
        if (!filters.branch) return null;
        const selectedBranch = branches.find(b => b.name === filters.branch);
        return selectedBranch?.id || null;
    }, [branches, filters.branch]);

    // Fetch agents when branch is selected
    useEffect(() => {
        const fetchAgents = async () => {
            if (!selectedSecurityGroupId) {
                setAgents([]);
                return;
            }

            setIsLoadingAgents(true);
            try {
                const response = await getUsersBySecurityGroupId(selectedSecurityGroupId, undefined, 100, 0);
                setAgents(response.records || []);
            } catch (error) {
                console.error('Error fetching agents:', error);
                setAgents([]);
            } finally {
                setIsLoadingAgents(false);
            }
        };

        fetchAgents();
    }, [selectedSecurityGroupId]);


    // Check if filters are applied (based on appliedFilters, not current filters)
    const isFilterApplied = useMemo(() => {
        return (
            !!appliedFilters.state || !!appliedFilters.branch || !!appliedFilters.agent ||
            !!appliedFilters.lan.trim()
        );
    }, [appliedFilters]);

    const resetFilters = () => {
        setFilters(INITIAL_FILTERS);
        setAppliedFilters(INITIAL_FILTERS);
        setAgents([]);
    };

    const updateFilter = (newFilters: Partial<AdvancedFilterParamsCases>) => {
        setFilters(prev => {
            const updated = { ...prev, ...newFilters };
            // Reset branch and agent if state changes
            if (newFilters.state !== undefined && newFilters.state !== prev.state) {
                updated.branch = "";
                updated.agent = "";
            }
            // Reset agent if branch changes
            if (newFilters.branch !== undefined && newFilters.branch !== prev.branch) {
                updated.agent = "";
            }
            return updated;
        });
    };

    // Apply filters - this is called when user clicks "Apply Filters" button
    const applyFilters = () => {
        setAppliedFilters(filters);
    };

    return {
        // State
        isAdvancedSearchOpen,
        setIsAdvancedSearchOpen,
        filters,
        appliedFilters,
        isFilterApplied,

        // Computed values
        states,
        branches,
        agents,
        isLoadingAgents,
        selectedSecurityGroupId,

        // Functions
        updateFilter,
        resetFilters,
        applyFilters,
        setAppliedFilters,
    };
}
