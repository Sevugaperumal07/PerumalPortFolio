import { useState, useMemo, useEffect } from "react";
import { format } from "date-fns";
import type { AdvancedFilterParams, StateSecurityGroup, BranchRecord, EmiPendingBucket } from "@/lib/types";
import { getUsersBySecurityGroupId, getAllEmiPendings } from "@/lib/services/tasks";

export const INITIAL_FILTERS: AdvancedFilterParams = {
    dateType: "ACTIVITY_DATE",
    dateRange: {},
    branch: "",
    state: "",
    agent: "",
    disposition: "",
    status: "",
    lan: "",
    receipt: "",
    emiPendingBucket: "",
};

interface UseAdvancedSearchTasksProps {
    states: StateSecurityGroup[];
    pageIndex: number;
    pageSize: number;
}

interface Agent {
    id: string;
    userName: string;
}

export function useAdvancedSearchTasks({
    states,
}: UseAdvancedSearchTasksProps) {
    // Advanced Search filter states
    const [isAdvancedSearchOpen, setIsAdvancedSearchOpen] = useState(false);
    const [filters, setFilters] = useState<AdvancedFilterParams>(INITIAL_FILTERS);
    const [appliedFilters, setAppliedFilters] = useState<AdvancedFilterParams>(INITIAL_FILTERS);
    const [agents, setAgents] = useState<Agent[]>([]);
    const [isLoadingAgents, setIsLoadingAgents] = useState(false);
    const [emiPendings, setEmiPendings] = useState<EmiPendingBucket[]>([]);
    const [isLoadingEmiPendings, setIsLoadingEmiPendings] = useState(false);

    // Helper function to format date range labels
    const formatDateRangeLabel = (range: { from?: Date; to?: Date }) => {
        if (!range.from && !range.to) return "";
        if (range.from && range.to) {
            return `${format(range.from, "dd/MM/yyyy")} - ${format(range.to, "dd/MM/yyyy")} `;
        }
        if (range.from) {
            return `${format(range.from, "dd/MM/yyyy")} - ...`;
        }
        if (range.to) {
            return `... - ${format(range.to, "dd/MM/yyyy")} `;
        }
        return "";
    };

    // Get branches for selected state
    const branches = useMemo<BranchRecord[]>(() => {
        if (!filters.state) return [];
        const selectedState = states.find(s => s.stateName === filters.state);
        return selectedState?.branches || [];
    }, [states, filters.state]);

    // Get security group ID for selected branch (for fetching agents)
    const selectedSecurityGroupId = useMemo(() => {
        if (!filters.branch) return null;
        const selectedBranch = branches.find(b => b.name === filters.branch);
        return selectedBranch?.id || null;
    }, [branches, filters.branch]);

    // Fetch agents when branch is selected
    useEffect(() => {
        const fetchAgents = async () => {
            if (!selectedSecurityGroupId) {
                setAgents([]);
                return;
            }

            setIsLoadingAgents(true);
            try {
                const response = await getUsersBySecurityGroupId(selectedSecurityGroupId, undefined, 100, 0);
                setAgents(response.records || []);
            } catch (error) {
                console.error('Error fetching agents:', error);
                setAgents([]);
            } finally {
                setIsLoadingAgents(false);
            }
        };

        fetchAgents();
    }, [selectedSecurityGroupId]);

    // Fetch EMI Pendings when Advanced Search opens (only if not already loaded)
    const [hasLoadedEmiPendings, setHasLoadedEmiPendings] = useState(false);

    useEffect(() => {
        if (isAdvancedSearchOpen && !hasLoadedEmiPendings && emiPendings.length === 0) {
            const fetchEmiPendings = async () => {
                setIsLoadingEmiPendings(true);
                try {
                    const data = await getAllEmiPendings();
                    setEmiPendings(data);
                    setHasLoadedEmiPendings(true);
                } catch (error) {
                    console.error('Error fetching EMI pendings:', error);
                } finally {
                    setIsLoadingEmiPendings(false);
                }
            };
            fetchEmiPendings();
        }
    }, [isAdvancedSearchOpen, hasLoadedEmiPendings, emiPendings.length]);

    // Check if filters are applied (based on appliedFilters, not current filters)
    const isFilterApplied = useMemo(() => {
        return (
            !!appliedFilters.dateRange.from || !!appliedFilters.dateRange.to ||
            !!appliedFilters.state || !!appliedFilters.branch || !!appliedFilters.agent ||
            !!appliedFilters.disposition || !!appliedFilters.status ||
            !!appliedFilters.lan.trim() || !!appliedFilters.receipt.trim() ||
            !!appliedFilters.emiPendingBucket
        );
    }, [appliedFilters]);

    const resetFilters = () => {
        setFilters(INITIAL_FILTERS);
        setAppliedFilters(INITIAL_FILTERS);
        setAgents([]);
    };

    const updateFilter = (newFilters: Partial<AdvancedFilterParams>) => {
        setFilters(prev => {
            const updated = { ...prev, ...newFilters };
            // Reset branch and agent if state changes
            if (newFilters.state !== undefined && newFilters.state !== prev.state) {
                updated.branch = "";
                updated.agent = "";
            }
            // Reset agent if branch changes
            if (newFilters.branch !== undefined && newFilters.branch !== prev.branch) {
                updated.agent = "";
            }
            return updated;
        });
    };

    // Apply filters - this is called when user clicks "Apply Filters" button
    const applyFilters = () => {
        setAppliedFilters(filters);
    };

    return {
        // State
        isAdvancedSearchOpen,
        setIsAdvancedSearchOpen,
        filters,
        appliedFilters,
        isFilterApplied,

        // Computed values
        states,
        branches,
        agents,
        isLoadingAgents,
        selectedSecurityGroupId,
        emiPendings,
        isLoadingEmiPendings,

        // Functions
        updateFilter,
        resetFilters,
        applyFilters,
        setAppliedFilters,
        formatDateRangeLabel,
    };
}
