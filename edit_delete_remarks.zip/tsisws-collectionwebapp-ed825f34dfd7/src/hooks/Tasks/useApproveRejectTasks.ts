import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { consolidateReceiptAcceptanceRejection } from "@/lib/services/tasks";
import type { VerificationType } from "@/lib/types";

interface UseApproveRejectTasksProps {
    onSuccess?: () => void;
}

export function useApproveRejectTasks({ onSuccess }: UseApproveRejectTasksProps = {}) {
    const [isOpen, setIsOpen] = useState(false);
    const [selectedReceiptIds, setSelectedReceiptIds] = useState<string[]>([]);
    const [decision, setDecision] = useState<VerificationType | null>(null);
    const [remarks, setRemarks] = useState("");
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { toast } = useToast();

    const openApproveReject = useCallback((ids: string[]) => {
        setSelectedReceiptIds(ids);
        setIsOpen(true);
        setDecision(null);
        setRemarks("");
    }, []);

    const closeApproveReject = useCallback(() => {
        setIsOpen(false);
        setSelectedReceiptIds([]);
    }, []);

    const handleSubmit = useCallback(async (newDecision: VerificationType) => {
        if (selectedReceiptIds.length === 0) return;

        setDecision(newDecision);
        setIsSubmitting(true);

        try {
            const now = new Date();
            const date = now.toISOString().split('T')[0]; // yyyy-MM-dd
            const time = now.toTimeString().split(' ')[0]; // HH:mm:ss

            const result = await consolidateReceiptAcceptanceRejection({
                receiptIds: selectedReceiptIds,
                action: newDecision as "ACCEPT" | "REJECT",
                remarks,
                date,
                time,
            });

            if (!result.success || (result.totalFailed && result.totalFailed > 0)) {
                toast({
                    title: "Processing Completed with Errors",
                    description: result.message || `${result.totalFailed} tasks failed to process`,
                    variant: "destructive",
                });
            } else {
                toast({
                    title: "Success",
                    description: result.message || `${result.totalProcessed} tasks processed successfully`,
                });
                onSuccess?.();
                closeApproveReject();
            }
        } catch (error) {
            console.error("Acceptance/Rejection failed:", error);
            toast({
                title: "Error",
                description: error instanceof Error ? error.message : "Failed to process acceptance/rejection",
                variant: "destructive",
            });
        } finally {
            setIsSubmitting(false);
        }
    }, [selectedReceiptIds, remarks, toast, onSuccess, closeApproveReject]);

    return {
        isOpen,
        setIsOpen,
        selectedReceiptIds,
        decision,
        setDecision,
        remarks,
        setRemarks,
        isSubmitting,
        openApproveReject,
        closeApproveReject,
        handleSubmit,
    };
}
