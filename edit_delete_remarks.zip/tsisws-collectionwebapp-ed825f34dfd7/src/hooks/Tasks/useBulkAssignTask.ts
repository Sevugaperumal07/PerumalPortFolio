import { useToast } from "@/hooks/use-toast";
import type { BulkAssignResponse, BulkAssignType } from "@/lib/services/tasks";
import { bulkAssignTasksAndCases, getUsersBySecurityGroupId } from "@/lib/services/tasks";
import { getUsers } from "@/lib/services/users";
import type { AgentRecord, Task } from "@/lib/types";
import { useCallback, useEffect,useState } from "react";

const AGENT_LIMIT = 10;
let GLOBAL_INACTIVE_USER_IDS: Set<string> | null = null;

export type AssignStep = 'loading' | 'agent_selection' | 'success';

interface UseBulkAssignTaskProps {
    isOpen: boolean;
    selectedTasks: Task[];
    onOpenChange: (open: boolean) => void;
    onSuccess: () => void;
    securityGroupId: string | null;
}

export function useBulkAssignTask({
    isOpen,
    selectedTasks,
    onOpenChange,
    onSuccess,
    securityGroupId
}: UseBulkAssignTaskProps) {
    const { toast } = useToast();

    const [step, setStep] = useState<AssignStep>('loading');
    const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [assignmentType, setAssignmentType] = useState<BulkAssignType>('ASSIGN_BOTH');
    const [inactiveUserIds, setInactiveUserIds] = useState<Set<string>>(new Set());

    // Agent selection state
    const [agents, setAgents] = useState<AgentRecord[]>([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [loadingAgents, setLoadingAgents] = useState(false);
    const [hasFetchedInitial, setHasFetchedInitial] = useState(false);
    const [hasNext, setHasNext] = useState(false);
    const [offset, setOffset] = useState(0);

    const fetchInactiveUsers = useCallback(async () => {
        if (!securityGroupId) return;

        // Use global cache if available to save time and reduce API calls
        if (GLOBAL_INACTIVE_USER_IDS) {
            setInactiveUserIds(GLOBAL_INACTIVE_USER_IDS);
            return;
        }

        try {
            const allUsers = await getUsers();
            const inactive = new Set<string>();
            allUsers.forEach(u => {
                if (u.deleted || u.status === 'Inactive') {
                    inactive.add(u.id);
                }
            });
            GLOBAL_INACTIVE_USER_IDS = inactive;
            setInactiveUserIds(inactive);
        } catch (error) {
            console.error("Error fetching inactive users:", error);
        }
    }, [securityGroupId]);

    const performCheck = useCallback(() => {
        if (selectedTasks.length === 0) return;
        setStep('agent_selection');
    }, [selectedTasks]);

    useEffect(() => {
        if (isOpen && securityGroupId) {
            performCheck();
            fetchInactiveUsers();
        }
    }, [isOpen, securityGroupId, performCheck, fetchInactiveUsers]);

    const fetchAgents = useCallback(async (currentOffset: number, name: string, append: boolean = false) => {
        if (!securityGroupId) return;

        setLoadingAgents(true);
        try {
            const response = await getUsersBySecurityGroupId(securityGroupId, name, AGENT_LIMIT, currentOffset);
            const activeAgents = response.records.filter(agent => !inactiveUserIds.has(agent.id));

            if (append) {
                setAgents(prev => [...prev, ...activeAgents]);
            } else {
                setAgents(activeAgents);
            }
            setHasNext(response.hasNext);
            setOffset(currentOffset + AGENT_LIMIT);
            setHasFetchedInitial(true);
        } catch (error) {
            console.error("Error fetching agents:", error);
            toast({
                title: "Error",
                description: "Failed to fetch agents list.",
                variant: "destructive"
            });
        } finally {
            setLoadingAgents(false);
        }
    }, [securityGroupId, toast, inactiveUserIds]);

    const handleLoadMore = useCallback(() => {
        if (!loadingAgents && hasNext) {
            fetchAgents(offset, searchTerm, true);
        }
    }, [loadingAgents, hasNext, offset, searchTerm, fetchAgents]);

    const handleAssign = async () => {
        if (!selectedAgentId || selectedTasks.length === 0) return;

        setIsSubmitting(true);
        try {
            const loanNumbers = selectedTasks.map(t => t.lan).filter((lan): lan is string => !!lan && lan !== 'N/A');

            if (loanNumbers.length === 0) {
                toast({
                    title: "Invalid Selection",
                    description: "Selected tasks do not have valid LAN numbers.",
                    variant: "destructive"
                });
                return;
            }

            const response: BulkAssignResponse = await bulkAssignTasksAndCases({
                loanNumbers,
                userId: selectedAgentId,
                type: assignmentType
            });

            if (response.success) {
                const hasFailures = response.failedIds && response.failedIds.length > 0;

                if (hasFailures) {
                    toast({
                        title: "Partial Success",
                        description: `${loanNumbers.length - response.failedIds!.length} tasks assigned, but ${response.failedIds!.length} failed.`,
                        variant: "warning"
                    });
                } else {
                    toast({
                        title: "Success",
                        description: response.message || "Bulk assignment completed successfully.",
                    });
                }

                setStep('success');
                setTimeout(() => {
                    onSuccess();
                    onOpenChange(false);
                }, 2000);
            } else {
                toast({
                    title: "Assignment Failed",
                    description: response.message || "Failed to assign tasks.",
                    variant: "destructive"
                });
            }
        } catch (error) {
            console.error("Bulk assign error:", error);
            toast({
                title: "Error",
                description: error instanceof Error ? error.message : "An unexpected error occurred during assignment.",
                variant: "destructive"
            });
        } finally {
            setIsSubmitting(false);
        }
    };

    const reset = useCallback(() => {
        setStep('loading');
        setSelectedAgentId(null);
        setSearchTerm("");
        setOffset(0);
        setAgents([]);
        setAssignmentType('ASSIGN_BOTH');
        setInactiveUserIds(new Set());
        setHasFetchedInitial(false);
    }, []);

    // // Build complete sets of already assigned agent IDs and names to exclude them
    // const assignedAgentData = useMemo(() => {
    //     const names = new Set<string>();
    //     const ids = new Set<string>();

    //     selectedTasks.forEach(task => {
    //         if (task.agentName && task.agentName !== 'N/A') {
    //             names.add(task.agentName.trim().toLowerCase());
    //         }
    //         task.UserCases?.forEach(uc => {
    //             if (uc.userId?.userName) {
    //                 names.add(uc.userId.userName.trim().toLowerCase());
    //             }
    //             if (uc.userId?.id) {
    //                 ids.add(uc.userId.id);
    //             }
    //         });
    //     });
    //     return { names, ids };
    // }, [selectedTasks]);

    return {
        step,
        selectedAgentId,
        setSelectedAgentId,
        isSubmitting,
        assignmentType,
        setAssignmentType,
        // agents: agents.filter(agent => {
        //     const isInactive = inactiveUserIds.has(agent.id);
        //     const isAlreadyAssignedById = assignedAgentData.ids.has(agent.id);
        //     const isAlreadyAssignedByName = assignedAgentData.names.has(agent.userName.trim().toLowerCase());
        //     return !isInactive && !isAlreadyAssignedById && !isAlreadyAssignedByName;
        // }),
        agents: agents.filter(agent => !inactiveUserIds.has(agent.id)),
        searchTerm,
        setSearchTerm,
        loadingAgents,
        hasNext,
        handleLoadMore,
        handleAssign,
        fetchAgents,
        reset,
        setStep,
        hasFetchedInitial
    };
}
