import { useState } from "react";
import { createDeposit } from "@/lib/services/tasks";
import { uploadImage } from "@/lib/services/screenShot";
import { useToast } from "@/hooks/use-toast";
import type { CreateDepositInput, Task } from "@/lib/types";
import { format } from "date-fns";

interface UseDepositCashProps {
    onSuccess?: () => void;
    onOpenChange: (open: boolean) => void;
}

export function useDepositCash({ onSuccess, onOpenChange }: UseDepositCashProps) {
    const { toast } = useToast();
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleDeposit = async (data: {
        tasks: Task[];
        bankName: string;
        accountNo: string;
        depositDate: Date;
        remarks: string;
        depositSlip?: File | null;
    }) => {
        if (data.tasks.length === 0) return;

        setIsSubmitting(true);
        try {
            // Fetch geolocation
            let latitude = 0;
            let longitude = 0;

            if ("geolocation" in navigator) {
                try {
                    const position = await new Promise<GeolocationPosition>((resolve, reject) => {
                        navigator.geolocation.getCurrentPosition(resolve, reject, {
                            enableHighAccuracy: true,
                            timeout: 10000, // Increased timeout to 10s
                            maximumAge: 0,
                        });
                    });
                    latitude = position.coords.latitude;
                    longitude = position.coords.longitude;
                } catch (geoError: any) {
                    console.error("Geolocation failed or denied:", geoError);
                    let errorMessage = "Location permission is required to deposit cash. Please enable location services and try again.";
                    if (geoError.code === geoError.TIMEOUT) {
                        errorMessage = "Location fetching timed out. Please ensure you have a good signal and try again.";
                    }
                    throw new Error(errorMessage);
                }
            } else {
                throw new Error("Geolocation is not supported by your browser. Location is mandatory for deposits.");
            }

            const receiptIds = data.tasks
                .map(t => t.receipt?.id)
                .filter((id): id is string => !!id);

            if (receiptIds.length === 0) {
                throw new Error("No valid receipts found for the selected tasks.");
            }

            const totalAmount = data.tasks.reduce((sum, t) => sum + (t.receivedAmount || 0), 0).toString();

            const input: CreateDepositInput = {
                depositSlipType: "BANK",
                receiptIds,
                date: format(data.depositDate, "yyyy-MM-dd"),
                time: format(new Date(), "HH:mm:ss"),
                remarks: data.remarks,
                latitude,
                longitude,
                bankName: data.bankName,
                accountNo: data.accountNo,
                depositSlipImagePath: "", // Will be updated via separate upload
                totalAmount,
            };

            const response = await createDeposit(input);

            if (response && response.createDeposit) {
                const depositSlipid = response.createDeposit.id;

                // If image is provided, upload it as a follow-up step
                if (data.depositSlip) {
                    try {
                        await uploadImage(data.depositSlip, "Deposit Slip", depositSlipid);
                    } catch (uploadError) {
                        console.error("Image upload failed:", uploadError);
                        toast({
                            title: "Deposit Created, but Image Upload Failed",
                            description: "The deposit record was created successfully, but there was an error uploading the deposit slip image. Please check your connection.",
                            variant: "destructive",
                        });
                    }
                }

                toast({
                    title: "Success",
                    description: response.createDeposit.message || "Deposit created successfully.",
                });

                if (onSuccess) {
                    onSuccess();
                }
                onOpenChange(false);
            }
        } catch (error) {
            console.error("Error creating deposit:", error);
            toast({
                title: "Error",
                description: error instanceof Error ? error.message : "Failed to create deposit.",
                variant: "destructive",
            });
        } finally {
            setIsSubmitting(false);
        }
    };

    return {
        isSubmitting,
        handleDeposit,
    };
}

