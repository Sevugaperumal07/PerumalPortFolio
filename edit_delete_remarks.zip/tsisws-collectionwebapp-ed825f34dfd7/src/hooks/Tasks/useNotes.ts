import { useState, useEffect, useCallback } from "react";
import {
    searchNotesByCriteria,
    type NoteFromCriteriaAPI,
} from "@/lib/services/notes";
import type { Task, Case } from "@/lib/types";

const PAGE_SIZE = 10;

interface UseNotesProps {
    task?: Task | null;
    caseItem?: Case | null;
    isOpen: boolean;
    lan?: string;
}

export function useNotes({ task, caseItem, isOpen, lan }: UseNotesProps) {
    const [notes, setNotes] = useState<NoteFromCriteriaAPI[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isLoadingMore, setIsLoadingMore] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [page, setPage] = useState(0);
    const [hasMore, setHasMore] = useState(false);
    const [isEmpty, setIsEmpty] = useState(false);

    // Filter state
    const [filterYear, setFilterYear] = useState<number>(new Date().getFullYear());
    const [filterMonth, setFilterMonth] = useState<number | undefined>(new Date().getMonth() + 1);

    const getUserId = () => {
        try {
            const stored = localStorage.getItem("userData");
            if (stored) {
                const userData = JSON.parse(stored);
                return userData?.id;
            }
        } catch (error) {
            console.error("[useNotes] Error reading userData:", error);
        }
        return null;
    };

    const loanNumber = lan || task?.lan || caseItem?.account?.lanNumber || caseItem?.loanNumber || "";

    const fetchNotes = useCallback(
        async (
            pageNum: number,
            append: boolean = false,
            year?: number,
            month?: number
        ) => {
            const userId = getUserId();
            if (!userId) {
                setError("User not found");
                return;
            }

            if (!loanNumber) {
                setError("No LAN number found.");
                return;
            }

            if (append) {
                setIsLoadingMore(true);
            } else {
                setIsLoading(true);
                setNotes([]);
            }
            setError(null);

            try {
                let currentPage = pageNum;
                let allFilteredNotes: NoteFromCriteriaAPI[] = [];
                let isLastPage = false;
                let isEmptyResult = false;

                do {
                    const result = await searchNotesByCriteria(
                        {
                            loanNumber,
                            page: currentPage,
                            size: PAGE_SIZE,
                            year,
                            month,
                        },
                        userId
                    );

                    isLastPage = result.last;
                    isEmptyResult = result.empty;

                    const pageNotes = result.content;
                    allFilteredNotes = [...allFilteredNotes, ...pageNotes];

                    if (pageNotes.length === 0 && !isLastPage) {
                        currentPage++;
                    } else {
                        break;
                    }
                } while (!isLastPage && allFilteredNotes.length === 0);

                if (append) {
                    setNotes((prev) => [...prev, ...allFilteredNotes]);
                } else {
                    setNotes(allFilteredNotes);
                    setIsEmpty(isEmptyResult || allFilteredNotes.length === 0);
                }

                setHasMore(!isLastPage);
                setPage(currentPage);
            } catch (err) {
                console.error("[useNotes] Error fetching notes:", err);
                setError(err instanceof Error ? err.message : "Failed to fetch notes");
            } finally {
                setIsLoading(false);
                setIsLoadingMore(false);
            }
        },
        [loanNumber]
    );

    useEffect(() => {
        if (isOpen && (task || caseItem || lan)) {
            setPage(0);
            fetchNotes(0, false, filterYear, filterMonth);
        } else if (!isOpen) {
            // Reset filters when closed so they're fresh for next open
            setFilterYear(new Date().getFullYear());
            setFilterMonth(new Date().getMonth() + 1);
        }
    }, [isOpen, task, caseItem, lan, filterYear, filterMonth, fetchNotes]);

    const handleLoadMore = () => {
        fetchNotes(page + 1, true, filterYear, filterMonth);
    };

    const handleClearFilters = () => {
        setFilterYear(new Date().getFullYear());
        setFilterMonth(undefined);
    };

    const handleYearChange = (year: number | undefined) => {
        setFilterYear(year ?? new Date().getFullYear());
    };

    const handleRetry = () => {
        fetchNotes(0, false, filterYear, filterMonth);
    };

    return {
        notes,
        isLoading,
        isLoadingMore,
        error,
        hasMore,
        isEmpty,
        filterYear,
        filterMonth,
        setFilterMonth,
        handleLoadMore,
        handleClearFilters,
        handleYearChange,
        handleRetry,
        loanNumber,
    };
}
