import { useState, useEffect } from "react";
import type { Task, AgentRecord } from "@/lib/types";
import { getUsersBySecurityGroupId, linkUserToCase, linkUserToAccount, searchCasesPaginated } from "@/lib/services/tasks";
import { getUsers } from "@/lib/services/users";
import { useToast } from "@/hooks/use-toast";

const AGENT_LIMIT = 10;

export type SingleAssignStep = 'agent_selection' | 'saving' | 'success';
interface UseSingleAssignTaskProps {
    isOpen: boolean;
    task: Task | null;
    onOpenChange: (open: boolean) => void;
    onSuccess: (agentName?: string) => void;
    securityGroupId: string | null;
}

export function useSingleAssignTask({
    isOpen,
    task,
    onOpenChange,
    onSuccess,
    securityGroupId
}: UseSingleAssignTaskProps) {
    const { toast } = useToast();

    const [step, setStep] = useState<SingleAssignStep>('agent_selection');
    const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Agent selection state
    const [agents, setAgents] = useState<AgentRecord[]>([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [loadingAgents, setLoadingAgents] = useState(false);
    const [hasNext, setHasNext] = useState(false);
    const [offset, setOffset] = useState(0);

    // Holds agent names fetched from the real Case entity (for Cases page / isAccountOnly)
    const [caseAssignedNames, setCaseAssignedNames] = useState<Set<string>>(new Set());

    // Holds IDs of users who are deleted or inactive
    const [inactiveUserIds, setInactiveUserIds] = useState<Set<string>>(new Set());

    // Fetch all users to identify inactive ones (client-side filter)
    const fetchInactiveUsers = async () => {
        try {
            const allUsers = await getUsers();
            const inactive = new Set<string>();
            allUsers.forEach(u => {
                if (u.deleted || u.status === 'Inactive') {
                    inactive.add(u.id);
                }
            });
            setInactiveUserIds(inactive);
        } catch (err) {
            console.error("Error fetching users for filtering:", err);
        }
    };

    // Fetch the real Case entity by LAN to get its UserCases (used for Cases page filtering)
    const fetchCaseAssignedAgents = async (lan: string) => {
        try {
            const result = await searchCasesPaginated({ lanNumber: lan, limit: 1 });
            if (result.tasks && result.tasks.length > 0) {
                const caseTask = result.tasks[0];
                const names = new Set<string>();
                // agentName = UserCases[0].userId.userName
                if (caseTask.agentName && caseTask.agentName !== 'N/A') {
                    names.add(caseTask.agentName);
                }
                // All UserCases entries
                caseTask.UserCases?.forEach(uc => {
                    if (uc.userId?.userName) names.add(uc.userId.userName);
                });
                setCaseAssignedNames(names);
            }
        } catch (err) {
            console.error("Error fetching case assigned agents:", err);
        }
    };

    // Reset state when sheet opens
    useEffect(() => {
        if (isOpen) {
            setStep('agent_selection');
            setSelectedAgentId(null);
            setAgents([]);
            setOffset(0);
            setSearchTerm("");
            setCaseAssignedNames(new Set());
            setInactiveUserIds(new Set());
            fetchInactiveUsers();
            if (securityGroupId) {
                fetchAgents(0, "");
            }
            // Cases page: task.isAccountOnly=true → fetch the real Case to get UserCases
            if (task?.isAccountOnly && task?.lan) {
                fetchCaseAssignedAgents(task.lan);
            }
        }
    }, [isOpen, securityGroupId]);

    const fetchAgents = async (currentOffset: number, name: string, append: boolean = false) => {
        if (!securityGroupId) {
            console.warn("No security group ID provided for agent fetching");
            return;
        }
        setLoadingAgents(true);
        try {
            const response = await getUsersBySecurityGroupId(securityGroupId, name, AGENT_LIMIT, currentOffset);
            if (append) {
                setAgents(prev => [...prev, ...response.records]);
            } else {
                setAgents(response.records);
            }
            setHasNext(response.hasNext);
            setOffset(currentOffset + AGENT_LIMIT);
        } catch (error) {
            console.error("Error fetching agents:", error);
            toast({
                title: "Error",
                description: "Failed to fetch agents.",
                variant: "destructive"
            });
        } finally {
            setLoadingAgents(false);
        }
    };

    // Debounced search
    useEffect(() => {
        if (!isOpen || step !== 'agent_selection') return;

        const timer = setTimeout(() => {
            setOffset(0);
            fetchAgents(0, searchTerm);
        }, 500);

        return () => clearTimeout(timer);
    }, [searchTerm, step, isOpen]);

    const handleLoadMore = () => {
        if (!loadingAgents && hasNext) {
            fetchAgents(offset, searchTerm, true);
        }
    };

    const handleAssign = async (options: { assignCase: boolean; assignTask: boolean }) => {
        if (!selectedAgentId || !task) return;

        setIsSubmitting(true);
        try {
            const promises = [];

            // Assign Task -> linkUserToCase
            if (options.assignTask) {
                let caseIdToUse = task.id;

                // If this is an Account record (from Cases page), we need to find the real Case ID first
                if (task.isAccountOnly) {
                    try {
                        const searchResult = await searchCasesPaginated({ lanNumber: task.lan, limit: 1 });
                        if (searchResult.tasks && searchResult.tasks.length > 0) {
                            caseIdToUse = searchResult.tasks[0].id;
                        }
                    } catch (err) {
                        console.error("Error resolving case ID:", err);
                    }
                }

                promises.push(linkUserToCase(caseIdToUse, selectedAgentId));
            }

            // Assign Case -> linkUserToAccount
            if (options.assignCase && task.accountId) {
                promises.push(linkUserToAccount(task.accountId, selectedAgentId));
            } else if (options.assignCase && !task.accountId) {
                console.warn("No accountId found for task, skipping account assignment");
            }

            if (promises.length === 0) {
                setIsSubmitting(false);
                return;
            }

            const results = await Promise.allSettled(promises);
            const allSucceeded = results.every(r => r.status === 'fulfilled');
            const someSucceeded = results.some(r => r.status === 'fulfilled');

            if (allSucceeded) {
                toast({
                    title: "Success",
                    description: `Assigned successfully.`,
                });
                setStep('success');
                setTimeout(() => {
                    const agentName = agents.find(a => a.id === selectedAgentId)?.userName;
                    onSuccess(agentName);
                    onOpenChange(false);
                }, 2000);
            } else if (someSucceeded) {
                toast({
                    title: "Partial Success",
                    description: "Some assignments failed, please check history.",
                    variant: "default"
                });
                setStep('success');
                setTimeout(() => {
                    const agentName = agents.find(a => a.id === selectedAgentId)?.userName;
                    onSuccess(agentName);
                    onOpenChange(false);
                }, 2000);
            } else {
                toast({
                    title: "Error",
                    description: "Failed to assign.",
                    variant: "destructive"
                });
            }
        } catch (error) {
            toast({
                title: "Error",
                description: "An unexpected error occurred during assignment.",
                variant: "destructive"
            });
        } finally {
            setIsSubmitting(false);
        }
    };

    // Build complete set of excluded agent names:
    // 1. task.agentName + task.UserCases → for Task page (Case entity data)
    // 2. caseAssignedNames              → for Cases page (fetched from real Case via LAN)
    const assignedAgentNames = new Set<string>();
    if (task?.agentName) assignedAgentNames.add(task.agentName);
    task?.UserCases?.forEach(uc => {
        if (uc.userId?.userName) assignedAgentNames.add(uc.userId.userName);
    });
    caseAssignedNames.forEach(name => assignedAgentNames.add(name));

    return {
        step,
        selectedAgentId,
        setSelectedAgentId,
        isSubmitting,
        agents: agents.filter(agent => {
            const isInactive = inactiveUserIds.has(agent.id);
            return !assignedAgentNames.has(agent.userName) && !isInactive;
        }),
        searchTerm,
        setSearchTerm,
        loadingAgents,
        hasNext,
        handleLoadMore,
        handleAssign,
    };
}