import { useState, useEffect, useCallback, useMemo } from "react";
import { searchCasesPaginated } from "@/lib/services/tasks";
import type { Task } from "@/lib/types";
import { useDebounce } from "@/hooks/use-debounce";
import { usePagination } from "@/hooks/use-pagination";

interface UseAddTasksModalProps {
    isOpen: boolean;
    branchName?: string;
    initialSelectedTasks?: Task[];
    baseTaskIds?: string[];
}

interface UseAddTasksModalReturn {
    // Data
    tasks: Task[];
    selectedTasks: Task[];

    // Pagination
    pageIndex: number;
    pageSize: number;
    totalRecords: number;
    totalPages: number;
    hasNext: boolean;
    hasPrevious: boolean;

    // Loading states
    loading: boolean;

    // Search
    searchQuery: string;
    setSearchQuery: (query: string) => void;

    // Selection
    toggleTaskSelection: (task: Task) => void;
    toggleAllTasks: () => void;
    clearSelection: () => void;
    isTaskSelected: (taskId: string) => boolean;
    allSelected: boolean;
    someSelected: boolean;
    newSelectedCount: number;

    // Pagination actions
    setPageIndex: (index: number) => void;

    // Reset
    resetModal: () => void;
}

export function useAddTasksModal({
    isOpen,
    branchName,
    initialSelectedTasks = [],
    baseTaskIds = []
}: UseAddTasksModalProps): UseAddTasksModalReturn {
    // State
    const [tasks, setTasks] = useState<Task[]>([]);
    const [selectedTasks, setSelectedTasks] = useState<Task[]>([]);
    const [loading, setLoading] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");

    // Use pagination hook
    const {
        pageIndex,
        setPageIndex,
        pageSize,
        totalRecords,
        totalPages,
        hasNext,
        hasPrevious,
        updatePagination,
        resetPagination,
    } = usePagination(10);

    // Debounce search query
    const debouncedSearchQuery = useDebounce(searchQuery, 300);

    // Fetch tasks
    const fetchTasks = useCallback(async () => {
        if (!isOpen) return;

        setLoading(true);
        try {
            const offset = pageIndex * pageSize;
            const response = await searchCasesPaginated({
                limit: pageSize,
                offset,
                query: debouncedSearchQuery,
                branchName,
                forDeposit: true,
            });

            setTasks(response.tasks);
            updatePagination({
                totalRecords: response.totalRecords,
                totalPages: response.totalPages,
                hasNext: response.hasNext,
                hasPrevious: response.hasPrevious
            });
        } catch (error) {
            console.error("Error fetching tasks:", error);
            setTasks([]);
            updatePagination({
                totalRecords: 0,
                totalPages: 0,
                hasNext: false,
                hasPrevious: false
            });
        } finally {
            setLoading(false);
        }
    }, [isOpen, pageIndex, pageSize, debouncedSearchQuery, branchName, updatePagination]);

    // Fetch tasks when dependencies change
    useEffect(() => {
        fetchTasks();
    }, [fetchTasks]);

    // Initialize selection when modal opens
    useEffect(() => {
        if (isOpen) {
            // Ensure uniqueness when initializing
            const uniqueInitial = Array.from(new Map(initialSelectedTasks.map(t => [t.id, t])).values());
            setSelectedTasks(uniqueInitial);
        }
    }, [isOpen, initialSelectedTasks]);

    // Reset to first page when search changes
    useEffect(() => {
        if (pageIndex !== 0) {
            setPageIndex(0);
        }
    }, [debouncedSearchQuery]);

    // Selection handlers
    const isTaskSelected = useCallback((taskId: string) => {
        return selectedTasks.some(t => t.id === taskId);
    }, [selectedTasks]);

    const toggleTaskSelection = useCallback((task: Task) => {
        setSelectedTasks(prev => {
            const isSelected = prev.some(t => t.id === task.id);
            if (isSelected) {
                return prev.filter(t => t.id !== task.id);
            } else {
                // Ensure uniqueness
                if (prev.find(t => t.id === task.id)) return prev;
                return [...prev, task];
            }
        });
    }, []);

    // Check if all current page tasks are selected
    const allSelected = tasks.length > 0 && tasks.every(task => isTaskSelected(task.id));
    const someSelected = tasks.some(task => isTaskSelected(task.id)) && !allSelected;

    const toggleAllTasks = useCallback(() => {
        if (allSelected) {
            // Deselect all current page tasks
            setSelectedTasks(prev =>
                prev.filter(selected => !tasks.some(task => task.id === selected.id))
            );
        } else {
            // Select all current page tasks, ensuring uniqueness
            setSelectedTasks(prev => {
                const newSelections = tasks.filter(
                    task => !prev.some(selected => selected.id === task.id)
                );
                return [...prev, ...newSelections];
            });
        }
    }, [tasks, allSelected]);

    const clearSelection = useCallback(() => {
        setSelectedTasks([]);
    }, []);

    // Count only tasks that weren't initially in the DB (baseTaskIds)
    // If baseTaskIds is provided, we compare against it. 
    // Otherwise we fallback to comparing against IDs of initialSelectedTasks.
    const newSelectedCount = useMemo(() => {
        const baseIds = baseTaskIds || initialSelectedTasks.map(it => it.id);
        return selectedTasks.filter(st => !baseIds.includes(st.id)).length;
    }, [selectedTasks, baseTaskIds, initialSelectedTasks]);

    // Reset modal state
    const resetModal = useCallback(() => {
        setSearchQuery("");
        setTasks([]);
        resetPagination();
    }, [resetPagination]);

    // Reset when modal closes
    useEffect(() => {
        if (!isOpen) {
            resetModal();
        }
    }, [isOpen, resetModal]);

    return {
        // Data
        tasks,
        selectedTasks,

        // Pagination
        pageIndex,
        pageSize,
        totalRecords,
        totalPages,
        hasNext,
        hasPrevious,

        // Loading
        loading,

        // Search
        searchQuery,
        setSearchQuery,

        // Selection
        toggleTaskSelection,
        toggleAllTasks,
        clearSelection,
        isTaskSelected,
        allSelected,
        someSelected,
        newSelectedCount,
        // Pagination actions
        setPageIndex,
        // Reset
        resetModal
    };
}
