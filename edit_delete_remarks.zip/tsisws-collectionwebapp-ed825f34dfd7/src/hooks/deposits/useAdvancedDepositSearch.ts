import { useState, useEffect, useCallback, useMemo } from "react";
import { format } from "date-fns";
import { getBankNames } from "@/lib/services/deposits";

export interface DepositDateRange {
    from?: Date;
    to?: Date;
}

export interface AdvancedSearchFilters {
    depositDateRange: DepositDateRange;
    depositSlipNo: string;
    selectedBank: string;
}

export const useAdvancedDepositSearch = (onFiltersApplied?: () => void) => {
    // Draft states (inside the sidebar)
    const [depositDateRange, setDepositDateRange] = useState<DepositDateRange>({});
    const [depositSlipNo, setDepositSlipNo] = useState("");
    const [selectedBank, setSelectedBank] = useState<string>("");

    // Applied states (used for API calls)
    const [appliedDepositDateRange, setAppliedDepositDateRange] = useState<DepositDateRange>({});
    const [appliedDepositSlipNo, setAppliedDepositSlipNo] = useState("");
    const [appliedSelectedBank, setAppliedSelectedBank] = useState<string>("");

    // Temporary states for the date picker "Apply/Cancel" pattern
    const [tempDepositDateRange, setTempDepositDateRange] = useState<DepositDateRange>({});
    const [dateRangePopoverOpen, setDateRangePopoverOpen] = useState(false);

    // Bank names state
    const [bankNames, setBankNames] = useState<string[]>([]);
    const [loadingBankNames, setLoadingBankNames] = useState(false);

    const loadBankNames = useCallback(async () => {
        try {
            setLoadingBankNames(true);
            const data = await getBankNames();
            setBankNames(data);
        } catch (error) {
            console.error("Failed to load bank names", error);
        } finally {
            setLoadingBankNames(false);
        }
    }, []);

    useEffect(() => {
        loadBankNames();
    }, [loadBankNames]);

    // Handlers for the sidebar
    const handleApplyFilters = useCallback(() => {
        setAppliedDepositDateRange(depositDateRange);
        setAppliedDepositSlipNo(depositSlipNo);
        setAppliedSelectedBank(selectedBank);
        onFiltersApplied?.();
    }, [depositDateRange, depositSlipNo, selectedBank, onFiltersApplied]);

    const handleResetFilters = useCallback(() => {
        setDepositDateRange({});
        setTempDepositDateRange({});
        setDepositSlipNo("");
        setSelectedBank("");
        setAppliedDepositDateRange({});
        setAppliedDepositSlipNo("");
        setAppliedSelectedBank("");
        onFiltersApplied?.();
    }, [onFiltersApplied]);

    // Handlers for the date range picker (Inside the sidebar)
    const handleApplyDateRange = useCallback(() => {
        setDepositDateRange(tempDepositDateRange);
        setDateRangePopoverOpen(false);
    }, [tempDepositDateRange]);

    const handleCancelDateRange = useCallback(() => {
        setTempDepositDateRange(depositDateRange);
        setDateRangePopoverOpen(false);
    }, [depositDateRange]);

    const handleDateRangeOpenChange = useCallback((open: boolean) => {
        if (open) {
            setTempDepositDateRange(depositDateRange);
        }
        setDateRangePopoverOpen(open);
    }, [depositDateRange]);

    // Applied filters summary for the display bar
    const activeFilters = useMemo(() => {
        const filters: Array<{ key: string; label: string; value: string }> = [];

        if (appliedDepositSlipNo.trim()) {
            filters.push({ key: "depositSlipNo", label: "Slip No", value: appliedDepositSlipNo });
        }
        if (appliedSelectedBank) {
            filters.push({ key: "bank", label: "Bank", value: appliedSelectedBank });
        }
        if (appliedDepositDateRange.from || appliedDepositDateRange.to) {
            const dateStr = appliedDepositDateRange.from && appliedDepositDateRange.to
                ? `${format(appliedDepositDateRange.from, "yyyy-MM-dd")} - ${format(appliedDepositDateRange.to, "yyyy-MM-dd")}`
                : appliedDepositDateRange.from
                    ? format(appliedDepositDateRange.from, "yyyy-MM-dd")
                    : format(appliedDepositDateRange.to!, "yyyy-MM-dd");
            filters.push({ key: "dateRange", label: "Date Range", value: dateStr });
        }

        return filters;
    }, [appliedDepositSlipNo, appliedSelectedBank, appliedDepositDateRange]);

    const removeFilter = useCallback((filterKey: string) => {
        switch (filterKey) {
            case "depositSlipNo":
                setAppliedDepositSlipNo("");
                setDepositSlipNo("");
                break;
            case "bank":
                setAppliedSelectedBank("");
                setSelectedBank("");
                break;
            case "dateRange":
                setAppliedDepositDateRange({});
                setDepositDateRange({});
                setTempDepositDateRange({});
                break;
        }
    }, []);

    const clearAllFilters = useCallback(() => {
        setAppliedDepositDateRange({});
        setAppliedDepositSlipNo("");
        setAppliedSelectedBank("");
        setDepositDateRange({});
        setTempDepositDateRange({});
        setDepositSlipNo("");
        setSelectedBank("");
    }, []);

    // Memoized filters to prevent unstable references
    const filters = useMemo(() => ({
        depositDateRange,
        depositSlipNo,
        selectedBank,
    }), [depositDateRange, depositSlipNo, selectedBank]);

    const appliedFilters = useMemo(() => ({
        depositDateRange: appliedDepositDateRange,
        depositSlipNo: appliedDepositSlipNo,
        selectedBank: appliedSelectedBank,
    }), [appliedDepositDateRange, appliedDepositSlipNo, appliedSelectedBank]);

    return {
        // State
        filters,
        appliedFilters,
        tempDepositDateRange,
        dateRangePopoverOpen,
        bankNames,
        loadingBankNames,
        activeFilters,

        // Setters for controlled inputs
        setDepositDateRange,
        setDepositSlipNo,
        setSelectedBank,
        setTempDepositDateRange,

        // Handlers
        handleApplyFilters,
        handleResetFilters,
        handleApplyDateRange,
        handleCancelDateRange,
        handleDateRangeOpenChange,
        removeFilter,
        clearAllFilters,
    };
};
