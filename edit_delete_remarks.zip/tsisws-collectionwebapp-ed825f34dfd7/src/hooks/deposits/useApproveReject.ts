import { useState, useCallback } from "react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { processBankDepositSlipVerification } from "@/lib/services/deposits";
import type { VerificationType } from "@/lib/types";

interface UseApproveRejectProps {
    onSuccess?: () => void;
}

export function useApproveReject({ onSuccess }: UseApproveRejectProps = {}) {
    const [isOpen, setIsOpen] = useState(false);
    const [selectedDepositIds, setSelectedDepositIds] = useState<string[]>([]);
    const [decision, setDecision] = useState<VerificationType | null>(null);
    const [remarks, setRemarks] = useState("");
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { toast } = useToast();

    const openApproveReject = useCallback((ids: string[]) => {
        setSelectedDepositIds(ids);
        setIsOpen(true);
        setDecision(null);
        setRemarks("");
    }, []);

    const closeApproveReject = useCallback(() => {
        setIsOpen(false);
        setSelectedDepositIds([]);
    }, []);

    const handleSubmit = useCallback(async (newDecision: VerificationType) => {
        if (selectedDepositIds.length === 0) return;

        setDecision(newDecision);
        try {
            const currentDate = new Date();
            const date = format(currentDate, "yyyy-MM-dd");
            const time = format(currentDate, "HH:mm:ss");

            const result = await processBankDepositSlipVerification(
                selectedDepositIds,
                newDecision,
                remarks,
                date,
                time
            );


            if (result.failureBankDepositSlipIds.length > 0) {
                toast({
                    title: "Verification Processed with Errors",
                    description: result.message,
                    variant: "destructive",
                });
            } else {
                toast({
                    title: "Success",
                    description: result.message,
                });
                onSuccess?.();
                closeApproveReject();
            }
        } catch (error) {
            console.error("Verification failed:", error);
            toast({
                title: "Error",
                description: error instanceof Error ? error.message : "Failed to process verification",
                variant: "destructive",
            });
        } finally {
            setIsSubmitting(false);
        }
    }, [selectedDepositIds, decision, remarks, toast, onSuccess, closeApproveReject]);

    return {
        isOpen,
        setIsOpen,
        selectedDepositIds,
        decision,
        setDecision,
        remarks,
        setRemarks,
        isSubmitting,
        openApproveReject,
        closeApproveReject,
        handleSubmit,
    };
}
