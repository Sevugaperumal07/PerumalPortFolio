import { useState, useEffect, useCallback } from "react";
import { getCaseActivityHistory } from "@/lib/services/activity-history";
import type { CaseActivityHistory, Task, Case } from "@/lib/types";

interface UseActivityHistoryProps {
    task?: Task | null;
    caseItem?: Case | null;
    isOpen: boolean;
    lan?: string;
}

export function useActivityHistory({ task, caseItem, isOpen, lan }: UseActivityHistoryProps) {
    const [history, setHistory] = useState<CaseActivityHistory[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    // Filter state - default to current year/month
    const [filterYear, setFilterYear] = useState<number>(new Date().getFullYear());
    const [filterMonth, setFilterMonth] = useState<number | undefined>(new Date().getMonth() + 1);

    const loanNumber = lan || task?.lan || caseItem?.account?.lanNumber || caseItem?.loanNumber || "";

    const fetchHistory = useCallback(async (year: number, month?: number) => {
        if (!loanNumber) {
            setError("No LAN number found.");
            return;
        }

        setIsLoading(true);
        setError(null);

        try {
            const data = await getCaseActivityHistory(loanNumber, year, month);
            setHistory(data);
        } catch (err) {
            console.error("[useActivityHistory] Error fetching history:", err);
            setError("Failed to fetch activity history");
        } finally {
            setIsLoading(false);
        }
    }, [loanNumber]);

    useEffect(() => {
        if (isOpen && (task || caseItem || lan)) {
            fetchHistory(filterYear, filterMonth);
        } else if (!isOpen) {
            // Reset filters when closed so they're fresh for next open
            setFilterYear(new Date().getFullYear());
            setFilterMonth(new Date().getMonth() + 1);
        }
    }, [isOpen, task, caseItem, lan, filterYear, filterMonth, fetchHistory]);

    const handleRetry = () => {
        fetchHistory(filterYear, filterMonth);
    };

    const handleClearFilters = () => {
        setFilterYear(new Date().getFullYear());
        setFilterMonth(new Date().getMonth() + 1);
    };

    const handleYearChange = (year: number | undefined) => {
        setFilterYear(year ?? new Date().getFullYear());
    };

    const handlePreviousMonth = () => {
        if (!filterMonth) return;
        if (filterMonth === 1) {
            setFilterYear(prev => prev - 1);
            setFilterMonth(12);
        } else {
            setFilterMonth(prev => (prev as number) - 1);
        }
    };

    const handleNextMonth = () => {
        if (!filterMonth) return;
        const now = new Date();
        const currentYear = now.getFullYear();
        const currentMonth = now.getMonth() + 1;

        if (filterYear === currentYear && filterMonth >= currentMonth) return;

        if (filterMonth === 12) {
            setFilterYear(prev => prev + 1);
            setFilterMonth(1);
        } else {
            setFilterMonth(prev => (prev as number) + 1);
        }
    };

    return {
        history,
        isLoading,
        error,
        filterYear,
        filterMonth,
        setFilterMonth,
        handleYearChange,
        handleClearFilters,
        handleRetry,
        handlePreviousMonth,
        handleNextMonth,
        loanNumber,
    };
}
