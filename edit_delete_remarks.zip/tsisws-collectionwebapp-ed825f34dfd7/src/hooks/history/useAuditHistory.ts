import { useState, useCallback, useEffect } from "react";
import { getCaseAuditReceiptHistory } from "@/lib/services/activity-history";
import type { CaseAuditHistory } from "@/lib/types";


interface UseAuditHistoryProps {
    caseId: string | null;
    year: number;
    month: number | undefined;
    isOpen: boolean;
    limit?: number;
    showSystem?: boolean;
    initialEntityType?: string;
}

export function useAuditHistory({ 
    caseId, 
    year, 
    month, 
    isOpen, 
    limit = 20,
    showSystem = false,
    initialEntityType = "ALL"
}: UseAuditHistoryProps) {
    const [history, setHistory] = useState<CaseAuditHistory[]>([]);
    const [entityType, setEntityType] = useState<string>(initialEntityType);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [page, setPage] = useState(0);
    const [paginationMetadata, setPaginationMetadata] = useState({
        totalRecords: 0,
        totalPages: 1,
        hasNext: false,
        hasPrevious: false,
        currentPage: 0
    });

    const fetchHistory = useCallback(async () => {
        if (!caseId || !isOpen || month === undefined) return;

        setIsLoading(true);
        setError(null);
        try {
            const apiEntityType = entityType === "ALL" ? undefined : entityType;
            const result = await getCaseAuditReceiptHistory(caseId, year, month, limit, page * limit, showSystem, apiEntityType);
            if (result) {
                setHistory(result.content);
                setPaginationMetadata({
                    totalRecords: result.totalRecords,
                    totalPages: result.totalPages,
                    hasNext: result.hasNext,
                    hasPrevious: result.hasPrevious,
                    currentPage: result.currentPage
                });
            } else {
                setHistory([]);
            }
        } catch (err) {
            setError("Failed to fetch audit history");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, [caseId, year, month, isOpen, limit, page, showSystem, entityType]);

    useEffect(() => {
        if (isOpen) {
            fetchHistory();
        }
    }, [fetchHistory, isOpen]);

    // Reset page when showSystem or entityType changes
    useEffect(() => {
        setPage(0);
    }, [showSystem, entityType]);

    return {
        history,
        isLoading,
        error,
        page,
        setPage,
        entityType,
        setEntityType,
        paginationMetadata,
        handleRetry: fetchHistory,
    };
}
