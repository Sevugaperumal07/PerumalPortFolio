import { useMemo } from "react";
import { useNotes } from "../Tasks/useNotes";
import { useActivityHistory } from "./useActivityHistory";
import type { Task, Case } from "@/lib/types";

interface UseHistoryTabsProps {
    isOpen: boolean;
    task?: Task | null;
    caseItem?: Case | null;
}

export function useHistoryTabs({ isOpen, task, caseItem }: UseHistoryTabsProps) {
    const notesResult = useNotes({ task, caseItem, isOpen });
    const historyResult = useActivityHistory({ task, caseItem, isOpen });

    // Synchronize filters
    const handleYearChange = (year: number) => {
        notesResult.handleYearChange(year);
        historyResult.handleYearChange(year);
    };

    const handleMonthChange = (month: number) => {
        notesResult.setFilterMonth(month);
        historyResult.setFilterMonth(month);
    };

    // Derived values
    const lanLabel = notesResult.loanNumber || historyResult.loanNumber || "";

    const isNextDisabled = useMemo(() => {
        const now = new Date();
        const currentYear = now.getFullYear();
        const currentMonth = now.getMonth() + 1;
        const year = historyResult.filterYear;
        const month = historyResult.filterMonth ?? 0;
        return year >= currentYear && month >= currentMonth;
    }, [historyResult.filterYear, historyResult.filterMonth]);

    const isPreviousDisabled = useMemo(() => {
        return historyResult.filterYear === 2025 && historyResult.filterMonth === 1;
    }, [historyResult.filterYear, historyResult.filterMonth]);

    const handlePreviousMonth = () => {
        const currentMonth = historyResult.filterMonth;
        const currentYear = historyResult.filterYear;
        if (!currentMonth) return;

        if (currentMonth === 1) {
            handleYearChange(currentYear - 1);
            handleMonthChange(12);
        } else {
            handleMonthChange(currentMonth - 1);
        }
    };

    const handleNextMonth = () => {
        const currentMonth = historyResult.filterMonth;
        const currentYear = historyResult.filterYear;
        if (!currentMonth) return;

        const now = new Date();
        const nowYear = now.getFullYear();
        const nowMonth = now.getMonth() + 1;

        if (currentYear === nowYear && currentMonth >= nowMonth) return;

        if (currentMonth === 12) {
            handleYearChange(currentYear + 1);
            handleMonthChange(1);
        } else {
            handleMonthChange(currentMonth + 1);
        }
    };

    return {
        notes: notesResult,
        history: historyResult,
        lanLabel,
        handleYearChange,
        handleMonthChange,
        handlePreviousMonth,
        handleNextMonth,
        isNextDisabled,
        isPreviousDisabled,
    };

}
