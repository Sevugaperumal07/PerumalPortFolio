import { useState, useCallback } from 'react';
import { useOtp } from '@/contexts/OtpContext';
import { sendOtp, verifyOtp } from '@/lib/api/auth';
import {type OtpType } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { validateEmail } from '@/lib/utils/validation';

export interface UseOtpVerificationReturn {
  // States
  email: string;
  setEmail: (val: string) => void;
  emailError: string;
  handleEmailBlur: () => void;
  otpSent: boolean;
  sending: boolean;
  confirming: boolean;
  otp: string;
  timerSeconds: number;
  resendEnabled: boolean;

  // Handlers
  handleSendOTP: (inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>) => void;
  handleOtpChange: (value: string, idx: number, inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>) => void;
  handleOtpKeyDown: (e: React.KeyboardEvent, idx: number, inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>) => void;
  handleOtpPaste: (e: React.ClipboardEvent<HTMLInputElement>, inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>) => void;
  handleConfirm: (onSuccess?: () => void) => void;
  handleResend: (inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>) => void;
  setOtpSent: (val: boolean) => void;
  setOtp: (val: string) => void;

  // Helpers
  formatTimer: () => string;
  otpComplete: boolean;
}

export function useOtpVerification(initialEmail: string, otpType: OtpType): UseOtpVerificationReturn {
  const [email, setEmail] = useState(initialEmail);
  const [emailError, setEmailError] = useState('');
  const [emailTouched, setEmailTouched] = useState(false);
  const { 
    otpSent, 
    timerSeconds, 
    resendEnabled, 
    setOtpSent, 
    startCooldown,
    resetOtpFlow 
  } = useOtp();

  const { toast } = useToast();

  const [sending, setSending] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [otp, setOtp] = useState('');

  const formatTimer = useCallback(() => {
    const m = String(Math.floor(timerSeconds / 60)).padStart(2, '0');
    const s = String(timerSeconds % 60).padStart(2, '0');
    return `${m}:${s}`;
  }, [timerSeconds]);

  const handleEmailBlur = useCallback(() => {
    setEmailTouched(true);
    setEmailError(validateEmail(email));
  }, [email]);

  const handleSendOTP = useCallback(async (inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>) => {
    if (sending || !resendEnabled) return;

    const emailErr = validateEmail(email);
    if (emailErr) {
      setEmailTouched(true);
      setEmailError(emailErr);
      return;
    }
    
    setSending(true);
    try {
      await sendOtp({ email, otpType });
      setOtpSent(true);
      toast({
        title: 'Success',
        description: 'OTP sent to your registered email',
      });
      startCooldown();
      setTimeout(() => inputRefs.current[0]?.focus(), 100);
    } catch (err: any) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: err.message || 'Failed to send OTP. Please try again.',
      });
    } finally {
      setSending(false);
    }
  }, [sending, resendEnabled, setOtpSent, toast, startCooldown, email, otpType]);

  const handleOtpChange = useCallback((value: string, idx: number, inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>) => {
    const cleaned = value.replace(/[^0-9]/g, '').slice(-1);
    if (!cleaned && value !== '') return; // Block non-numeric

    const nextOtp = otp.split('');
    nextOtp[idx] = cleaned;
    const finalOtp = nextOtp.join('').slice(0, 6);
    setOtp(finalOtp);

    if (cleaned && idx < 5) {
      inputRefs.current[idx + 1]?.focus();
    }
  }, [otp]);

  const handleOtpKeyDown = useCallback((e: React.KeyboardEvent, idx: number, inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>) => {
    if (e.key === 'Backspace' && !otp[idx] && idx > 0) {
      inputRefs.current[idx - 1]?.focus();
    }
  }, [otp]);

  const handleOtpPaste = useCallback((e: React.ClipboardEvent<HTMLInputElement>, inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/[^0-9]/g, '').slice(0, 6);
    if (!pasted) return;

    setOtp(pasted);
    const targetIdx = pasted.length === 6 ? 5 : pasted.length;
    inputRefs.current[targetIdx]?.focus();
  }, []);

  const otpComplete = otp.length === 6;

  const handleConfirm = useCallback(async (onSuccess?: () => void) => {
    if (confirming || !otpComplete) return;

    setConfirming(true);
    try {
      const response = await verifyOtp({ email, otp, otpType });
      
      // Store temp token for the next step (Reset Password)
      if (response.tempToken) {
        sessionStorage.setItem('tempToken', response.tempToken);
      }
      
      resetOtpFlow();
      toast({
        title: 'Success',
        description: 'OTP verified successfully!',
      });
      if (onSuccess) onSuccess();
    } catch (err: any) {
       console.error("Verification error:", err);
       toast({
         variant: 'destructive',
         title: 'Error',
         description: err.message || 'Invalid OTP. Please check and try again.',
       });
    } finally {
      setConfirming(false);
    }
  }, [confirming, otpComplete, resetOtpFlow, toast, email, otp, otpType]);

  const handleResend = useCallback(async (inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>) => {
    if (sending || !resendEnabled) return;

    setOtp('');
    setSending(true);
    try {
      await sendOtp({ email, otpType });
      toast({
        title: 'Success',
        description: 'OTP resent to your email',
      });
      startCooldown();
      inputRefs.current[0]?.focus();
    } catch (err: any) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: err.message || 'Failed to resend. Please try again.',
      });
    } finally {
      setSending(false);
    }
  }, [sending, resendEnabled, startCooldown, toast, email, otpType]);

  return {
    email,
    setEmail,
    emailError: emailTouched ? emailError : '',
    handleEmailBlur,
    otpSent,
    sending,
    confirming,
    otp,
    timerSeconds,
    resendEnabled,
    handleSendOTP,
    handleOtpChange,
    handleOtpKeyDown,
    handleOtpPaste,
    handleConfirm,
    handleResend,
    setOtpSent,
    setOtp,
    formatTimer,
    otpComplete,
  };
}



