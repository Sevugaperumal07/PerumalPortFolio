import { useState, useCallback } from 'react';
import { resetPassword as resetPasswordApi } from '@/lib/api/auth';

// ─── Password rule definitions ────────────────────────────────────────────────
export interface PasswordRule {
  id: string;
  label: string;
  test: (pw: string) => boolean;
}

export const PASSWORD_RULES: PasswordRule[] = [
  { id: 'length',    label: 'At least 8 characters',    test: (pw) => pw.length >= 8 },
  { id: 'uppercase', label: '1 uppercase letter (A–Z)',  test: (pw) => /[A-Z]/.test(pw) },
  { id: 'lowercase', label: '1 lowercase letter (a–z)',  test: (pw) => /[a-z]/.test(pw) },
  { id: 'number',    label: '1 number (0–9)',            test: (pw) => /[0-9]/.test(pw) },
  { id: 'special',   label: '1 special character (!@#…)',test: (pw) => /[^A-Za-z0-9]/.test(pw) },
];

// ─── Pure validation functions (exported for unit testing) ────────────────────

/** Validates the new password against all PASSWORD_RULES. */
export function validateNewPassword(value: string): string {
  if (!value) return 'New password is required.';
  const failing = PASSWORD_RULES.filter((r) => !r.test(value));
  if (failing.length > 0) return 'Password must meet all requirements below.';
  return '';
}

/**
 * Validates confirm password.
 * Only checks that the value is non-empty and matches the new password.
 * Strength rules are NOT applied here.
 */
export function validateConfirmPassword(newPw: string, confirmPw: string): string {
  if (!confirmPw) return 'Please confirm your password.';
  if (newPw !== confirmPw) return 'Passwords do not match.';
  return '';
}

// ─── Hook return type ─────────────────────────────────────────────────────────
export interface UsePasswordFormReturn {
  // Field values
  newPassword: string;
  confirmPassword: string;

  // Visibility toggles
  showNew: boolean;
  showConfirm: boolean;
  toggleShowNew: () => void;
  toggleShowConfirm: () => void;

  // Errors
  newError: string;
  confirmError: string;

  // Async state
  loading: boolean;
  success: boolean;

  // Derived
  ruleResults: (PasswordRule & { passed: boolean })[];
  isNewPasswordValid: boolean;
  isConfirmValid: boolean;

  // Handlers
  handleNewPasswordChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleNewPasswordBlur: () => void;
  handleConfirmPasswordChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleConfirmPasswordBlur: () => void;

  /**
   * Call inside your form's onSubmit. Runs full validation and, if valid,
   * invokes the provided `onSubmit` callback with the new password.
   * Accepts the native form event so you can also use it directly as the handler.
   */
  handleSubmit: (
    e?: React.FormEvent,
  ) => Promise<void>;
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

/**
 * Encapsulates all state, validation, and handlers for a "create / reset password"
 * form that has a New Password field (with strength rules) and a Confirm Password
 * field (match-only check).
 *
 * Reusable across: Reset Password page, Change Password page, First-time setup, etc.
 */
export function usePasswordForm(): UsePasswordFormReturn {
  const [newPassword, setNewPassword]         = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNew, setShowNew]                 = useState(false);
  const [showConfirm, setShowConfirm]         = useState(false);
  const [loading, setLoading]                 = useState(false);
  const [success, setSuccess]                 = useState(false);

  // Track whether the user has ever interacted with each field
  const [newTouched, setNewTouched]         = useState(false);
  const [confirmTouched, setConfirmTouched] = useState(false);

  const [newError, setNewError]         = useState('');
  const [confirmError, setConfirmError] = useState('');

  // ── Derived ────────────────────────────────────────────────────────────────
  const ruleResults = PASSWORD_RULES.map((rule) => ({
    ...rule,
    passed: rule.test(newPassword),
  }));
  const isNewPasswordValid = ruleResults.every((r) => r.passed) && newPassword.length > 0;
  const isConfirmValid = confirmPassword.length > 0 && newPassword === confirmPassword;

  // ── Stable callbacks ───────────────────────────────────────────────────────
  const toggleShowNew     = useCallback(() => setShowNew((p) => !p), []);
  const toggleShowConfirm = useCallback(() => setShowConfirm((p) => !p), []);

  const handleNewPasswordChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setNewPassword(val);
      if (newTouched)     setNewError(validateNewPassword(val));
      // Re-check confirm match whenever the reference value changes
      if (confirmTouched) setConfirmError(validateConfirmPassword(val, confirmPassword));
    },
    [newTouched, confirmTouched, confirmPassword],
  );

  const handleNewPasswordBlur = useCallback(() => {
    setNewTouched(true);
    setNewError(validateNewPassword(newPassword));
  }, [newPassword]);

  const handleConfirmPasswordChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setConfirmPassword(val);
      if (confirmTouched) setConfirmError(validateConfirmPassword(newPassword, val));
    },
    [confirmTouched, newPassword],
  );

  const handleConfirmPasswordBlur = useCallback(() => {
    setConfirmTouched(true);
    setConfirmError(validateConfirmPassword(newPassword, confirmPassword));
  }, [newPassword, confirmPassword]);

  const handleSubmit = useCallback(
    async (
      e?: React.FormEvent,
    ) => {
      e?.preventDefault();

      const newErr     = validateNewPassword(newPassword);
      const confirmErr = validateConfirmPassword(newPassword, confirmPassword);
      
      setNewError(newErr);
      setConfirmError(confirmErr);
      setNewTouched(true);
      setConfirmTouched(true);

      if (newErr || confirmErr) return;

      const tempToken = sessionStorage.getItem('tempToken');
      if (!tempToken) {
        setNewError('Session expired. Please verify OTP again.');
        return;
      }

      setLoading(true);
      try {
        await resetPasswordApi({ 
          newPassword, 
          confirmNewPassword: confirmPassword 
        }, tempToken);

        setSuccess(true);
        sessionStorage.removeItem('tempToken');
      } catch (err: any) {
        setNewError(err.message || 'Failed to reset password. Please try again.');
        console.error('Reset password error:', err);
      } finally {
        setLoading(false);
      }
    },
    [newPassword, confirmPassword],
  );

  return {
    newPassword,
    confirmPassword,
    showNew,
    showConfirm,
    toggleShowNew,
    toggleShowConfirm,
    newError,
    confirmError,
    loading,
    success,
    ruleResults,
    isNewPasswordValid,
    isConfirmValid,
    handleNewPasswordChange,
    handleNewPasswordBlur,
    handleConfirmPasswordChange,
    handleConfirmPasswordBlur,
    handleSubmit,
  };
}
