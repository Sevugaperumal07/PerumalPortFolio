import { useState, useCallback } from "react";
import { getCollDepositById, processBankDepositSlipVerification } from "@/lib/services/deposits";
import { consolidateReceiptAcceptanceRejection } from "@/lib/services/tasks";
import { format } from "date-fns";
import type { Deposit } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export function useDepositDetails() {
    const [selectedDeposit, setSelectedDeposit] = useState<Deposit | null>(null);
    const [isOpen, setIsOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { toast } = useToast();

    const openDetails = useCallback(async (depositId: string) => {
        try {
            setLoading(true);
            setIsOpen(true);
            const data = await getCollDepositById(depositId);
            if (data) {
                setSelectedDeposit(data);
            } else {
                toast({
                    title: "Not Found",
                    description: `Deposit with ID ${depositId} could not be found or loaded.`,
                    variant: "destructive",
                });
                setIsOpen(false);
            }
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to load deposit details";
            toast({
                title: "Error",
                description: errorMessage,
                variant: "destructive",
            });
            setIsOpen(false);
        } finally {
            setLoading(false);
        }
    }, [toast]);

    const closeDetails = useCallback(() => {
        setIsOpen(false);
        setSelectedDeposit(null);
    }, []);

    const refreshDetails = useCallback(async () => {
        if (selectedDeposit?.id) {
            const data = await getCollDepositById(selectedDeposit.id);
            if (data) {
                setSelectedDeposit(data);
            }
        }
    }, [selectedDeposit]);

    const handleDepositSubmission = useCallback(async ({
        deposit,
        remarks,
        isAcceptancePending,
        decision,
        onSuccess,
        onClose
    }: {
        deposit: Deposit | null;
        remarks: string;
        isAcceptancePending: boolean;
        decision: "ACCEPT" | "REJECT" | "APPROVE";
        onSuccess?: () => void;
        onClose: (open: boolean) => void;
    }) => {
        if (!deposit?.id) return;
        setIsSubmitting(true);
        try {
            const now = new Date();
            const dateStr = format(now, "yyyy-MM-dd");
            const timeStr = format(now, "HH:mm:ss");

            if (isAcceptancePending) {
                const receiptIds = (deposit.collReceipts || []).map(r => r.id).filter(Boolean) as string[];
                if (receiptIds.length === 0) {
                    throw new Error("No valid receipts found for this deposit.");
                }
                const result = await consolidateReceiptAcceptanceRejection({
                    receiptIds,
                    action: decision === "APPROVE" ? "ACCEPT" : decision,
                    remarks,
                    date: dateStr,
                    time: timeStr,
                });
                if (!result.success || (result.totalFailed && result.totalFailed > 0)) {
                    throw new Error(result.message || `Failed to ${decision.toLowerCase()} deposit`);
                }
            } else {
                const result = await processBankDepositSlipVerification(
                    [deposit.id],
                    decision,
                    remarks,
                    dateStr,
                    timeStr
                );
                if (result.failureBankDepositSlipIds.length > 0) {
                    throw new Error(result.message || `Failed to ${decision.toLowerCase()} deposit`);
                }
            }

            toast({
                title: "Success",
                description: `Deposit ${decision === "REJECT" ? "rejected" : "accepted"} successfully.`,
            });
            onSuccess?.();
            onClose(false);
        } catch (error) {
            console.error("Submission failed:", error);
            toast({
                title: "Error",
                description: error instanceof Error ? error.message : "Failed to process request",
                variant: "destructive",
            });
        } finally {
            setIsSubmitting(false);
        }
    }, [toast]);

    return {
        selectedDeposit,
        isOpen,
        setIsOpen,
        loading,
        isSubmitting,
        openDetails,
        closeDetails,
        refreshDetails,
        handleDepositSubmission,
        setSelectedDeposit
    };
}
