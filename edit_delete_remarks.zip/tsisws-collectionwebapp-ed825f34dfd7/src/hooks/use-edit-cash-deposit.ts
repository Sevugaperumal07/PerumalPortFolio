import { useState, useCallback } from "react";
import { format } from "date-fns";
import {
    getCollDepositById,
    updateCollDepositField
} from "@/lib/services/deposits";
import type {
    Deposit,
    CollReceipt,
    DepositSearchResult,
    Task
} from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export function useEditCashDeposit(onSuccess?: () => void) {
    const [selectedDeposit, setSelectedDeposit] = useState<Deposit | null>(null);
    const [isOpen, setIsOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [isSaving, setIsSaving] = useState(false);

    // Form state
    const [editDate, setEditDate] = useState<Date | undefined>(undefined);
    const [editTime, setEditTime] = useState("");
    const [editRemarks, setEditRemarks] = useState("");
    const [editLinkedReceipts, setEditLinkedReceipts] = useState<CollReceipt[]>([]);
    const [removedReceipts, setRemovedReceipts] = useState<CollReceipt[]>([]);
    const [initialLockedReceiptIds, setInitialLockedReceiptIds] = useState<string[]>([]);

    const { toast } = useToast();

    const openEdit = useCallback(async (deposit: DepositSearchResult) => {
        if (!deposit.id) {
            toast({
                title: "Error",
                description: "Deposit ID is missing.",
                variant: "destructive",
            });
            return;
        }

        try {
            setLoading(true);
            const depositDetails = await getCollDepositById(deposit.id);
            if (depositDetails) {
                setSelectedDeposit(depositDetails);
                setEditDate(depositDetails.bankDepositDate ? new Date(depositDetails.bankDepositDate) : undefined);
                setEditTime(depositDetails.bankDepositTime || "");
                setEditRemarks(depositDetails.bankDepositRemarks || "");
                const linked = depositDetails.bankCollReceipts || [];
                setEditLinkedReceipts(linked);
                setRemovedReceipts([]);
                setInitialLockedReceiptIds(linked.map(r => r.id));
                setIsOpen(true);
            } else {
                toast({
                    title: "Error",
                    description: "Failed to load deposit details.",
                    variant: "destructive",
                });
            }
        } catch (error) {
            toast({
                title: "Error",
                description: error instanceof Error ? error.message : "Failed to load deposit details.",
                variant: "destructive",
            });
        } finally {
            setLoading(false);
        }
    }, [toast]);

    const closeEdit = useCallback(() => {
        setIsOpen(false);
        setSelectedDeposit(null);
    }, []);

    const handleRemoveReceipt = useCallback((receiptId: string) => {
        const receiptToRemove = editLinkedReceipts.find(r => r.id === receiptId);
        if (receiptToRemove) {
            setEditLinkedReceipts(prev => prev.filter(r => r.id !== receiptId));
            setRemovedReceipts(prev => [...prev, receiptToRemove]);
        }
    }, [editLinkedReceipts]);

    const handleAddReceipt = useCallback((receiptId: string) => {
        const receiptToAdd = removedReceipts.find(r => r.id === receiptId);
        if (receiptToAdd) {
            setRemovedReceipts(prev => prev.filter(r => r.id !== receiptId));
            setEditLinkedReceipts(prev => [...prev, receiptToAdd]);
        }
    }, [removedReceipts]);

    const handleAddTasks = useCallback((tasks: Task[]) => {
        const newReceipts: CollReceipt[] = tasks.map(task => {
            if (task.receipt) return task.receipt;
            return {
                id: task.id,
                receiptNo: task.receiptNo,
                lanNumber: task.lan,
                totalAmount: task.receivedAmount,
                collectedEmiAmount: task.receivedAmount,
                branchName: task.branch,
                deleted: false,
                dateEntered: task.dateCreatedRaw,
                dateModified: task.lastModifiedRaw,
            } as unknown as CollReceipt;
        });

        // Ensure unique IDs for linked list
        const uniqueReceipts = Array.from(new Map(newReceipts.map(r => [r.id, r])).values());
        setEditLinkedReceipts(uniqueReceipts);

        // Sync removedReceipts: 
        // 1. Keep items that were initially linked but are not in the new selection
        // 2. Keep items that were added in this session and then removed, but are still not in the new selection
        // 3. Ensure no items present in both linked and removed lists (checked by ID and Receipt No)
        const newIds = new Set(uniqueReceipts.map(r => r.id));
        const newReceiptNos = new Set(uniqueReceipts.map(r => r.receiptNo).filter(Boolean));

        setRemovedReceipts(prev => {
            const initiallyLinked = selectedDeposit?.bankCollReceipts || [];

            // Combine items that were originally in DB with items currently in the "Removed" list
            // (The "prev" items might include newly added tasks that were subsequently removed)
            const allPotentialRemoved = [...initiallyLinked, ...prev];

            // Ensure uniqueness by ID
            const uniquePossible = Array.from(new Map(allPotentialRemoved.map(r => [r.id, r])).values());

            // Filter out anything that is now in the linked list (by ID or Receipt No)
            return uniquePossible.filter(r =>
                !newIds.has(r.id) &&
                !(r.receiptNo && newReceiptNos.has(r.receiptNo))
            );
        });
    }, [selectedDeposit]);

    const saveEdit = useCallback(async () => {
        if (!selectedDeposit?.id) return;

        try {
            setIsSaving(true);

            const removedReceiptIds = initialLockedReceiptIds.filter(
                id => !editLinkedReceipts.find(r => r.id === id)
            );

            const newReceiptIds = editLinkedReceipts.filter(
                r => !initialLockedReceiptIds.includes(r.id)
            ).map(r => r.id);

            const collDeposit = {
                bankDepositDate: editDate ? format(editDate, "yyyy-MM-dd") : null,
                bankDepositTime: editTime,
                bankDepositRemarks: editRemarks,
            };

            const hasNewReceipts = newReceiptIds.length > 0;
            const hasRemovedReceipts = removedReceiptIds.length > 0;

            let adjustDepositSlip: any = undefined;

            if (hasNewReceipts || hasRemovedReceipts) {
                adjustDepositSlip = {
                    changeReason: editRemarks || "Administrative update via Edit Cash Deposit"
                };

                if (hasNewReceipts) {
                    adjustDepositSlip.newReceiptIds = newReceiptIds;
                }

                if (hasRemovedReceipts) {
                    adjustDepositSlip.removedReceiptIds = removedReceiptIds;
                }
            }

            const result = await updateCollDepositField(
                selectedDeposit.id,
                collDeposit,
                adjustDepositSlip
            );

            if (result) {
                toast({
                    title: "Success",
                    description: "Deposit updated successfully.",
                });
                setIsOpen(false);
                if (onSuccess) onSuccess();
            } else {
                toast({
                    title: "Error",
                    description: "Failed to update deposit.",
                    variant: "destructive",
                });
            }
        } catch (error) {
            console.error("Error saving deposit:", error);
            const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred while saving.";
            toast({
                title: "Error",
                description: errorMessage,
                variant: "destructive",
            });
        } finally {
            setIsSaving(false);
        }
    }, [selectedDeposit, initialLockedReceiptIds, editLinkedReceipts, editDate, editTime, editRemarks, toast, onSuccess]);

    const refreshEditDetails = useCallback(async () => {
        if (selectedDeposit?.id) {
            const depositDetails = await getCollDepositById(selectedDeposit.id);
            if (depositDetails) {
                setSelectedDeposit(depositDetails);
                setEditDate(depositDetails.bankDepositDate ? new Date(depositDetails.bankDepositDate) : undefined);
                setEditTime(depositDetails.bankDepositTime || "");
                setEditRemarks(depositDetails.bankDepositRemarks || "");
                const linked = depositDetails.bankCollReceipts || [];
                setEditLinkedReceipts(linked);
                setRemovedReceipts([]);
                setInitialLockedReceiptIds(linked.map(r => r.id));
            }
        }
    }, [selectedDeposit]);

    return {
        isOpen,
        setIsOpen,
        loading,
        isSaving,
        selectedDeposit,
        editDate,
        setEditDate,
        editTime,
        setEditTime,
        editRemarks,
        setEditRemarks,
        editLinkedReceipts,
        removedReceipts,
        openEdit,
        closeEdit,
        handleRemoveReceipt,
        handleAddReceipt,
        handleAddTasks,
        saveEdit,
        refreshEditDetails,
        initialLockedReceiptIds
    };
}
