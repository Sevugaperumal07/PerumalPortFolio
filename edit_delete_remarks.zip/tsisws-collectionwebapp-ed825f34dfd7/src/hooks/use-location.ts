import { useState, useCallback } from 'react';
import { useToast } from './use-toast';

/**
 * useLocation hook provides a reusable way to verify 
 * geolocation permission before performing sensitive actions.
 * This is an optimized permission-only check that does not fetch 
 * or wait for actual GPS coordinates.
 */
export function useGeoLocation() {
    const [isChecking, setIsChecking] = useState(false);
    const { toast } = useToast();

    /**
     * Verifies if geolocation access is allowed.
     */
    const checkPermission = useCallback(async (): Promise<boolean> => {
        if (!("geolocation" in navigator)) {
            return false;
        }

        try {
            // Check current permission state if supported
            if (navigator.permissions && navigator.permissions.query) {
                const result = await navigator.permissions.query({ name: 'geolocation' as PermissionName });
                if (result.state === 'granted') {
                    return true;
                }
                if (result.state === 'denied') {
                    return false;
                }
            }

            return await new Promise<boolean>((resolve) => {
                navigator.geolocation.getCurrentPosition(
                    () => resolve(true),
                    () => resolve(false),
                    {
                        enableHighAccuracy: false,
                        timeout: 3000,
                        maximumAge: Infinity,
                    }
                );
            });
        } catch (error) {
            return false;
        }
    }, []);

    /**
     * Executes a callback only if location access is granted.
     * Shows a toast warning if permission is denied.
     */
    const withLocation = useCallback(async <T>(action: () => T | Promise<T>): Promise<T | null> => {
        setIsChecking(true);
        try {
            const isAllowed = await checkPermission();
            if (isAllowed) {
                return await action();
            } else {
                toast({
                    title: "Location Access Required",
                    description: "Please enable location services in your browser settings to proceed.",
                    variant: "warning",
                });
                return null;
            }
        } finally {
            setIsChecking(false);
        }
    }, [checkPermission, toast]);

    return {
        isChecking,
        withLocation,
        checkPermission
    };
}
