import { useState, useCallback } from "react";

export interface PaginationState {
    pageIndex: number;
    pageSize: number;
    totalRecords: number;
    totalPages: number;
    hasNext: boolean;
    hasPrevious: boolean;
}

export function usePagination(initialPageSize = 20) {
    const [pageIndex, setPageIndex] = useState(0);
    const [pageSize] = useState(initialPageSize);
    const [totalRecords, setTotalRecords] = useState(0);
    const [totalPages, setTotalPages] = useState(0);
    const [hasNext, setHasNext] = useState(false);
    const [hasPrevious, setHasPrevious] = useState(false);

    const updatePagination = useCallback((data: {
        totalRecords: number;
        totalPages: number;
        hasNext: boolean;
        hasPrevious: boolean;
    }) => {
        setTotalRecords(data.totalRecords);
        setTotalPages(data.totalPages);
        setHasNext(data.hasNext);
        setHasPrevious(data.hasPrevious);
    }, []);

    const resetPagination = useCallback(() => {
        setPageIndex(0);
        setTotalRecords(0);
        setTotalPages(0);
        setHasNext(false);
        setHasPrevious(false);
    }, []);

    return {
        pageIndex,
        setPageIndex,
        pageSize,
        totalRecords,
        totalPages,
        hasNext,
        hasPrevious,
        updatePagination,
        resetPagination,
        // Helpers for UI
        isFirstPage: pageIndex === 0,
        isLastPage: pageIndex === totalPages - 1 || totalPages === 0
    };
}
