import { useState, useEffect } from "react";
import { getRoleHierarchy, type RoleHierarchyNode } from "@/lib/services/roles";

export type RoleNode = RoleHierarchyNode;

interface UseRoleHierarchyReturn {
  data: RoleNode[];
  loading: boolean;
  error: string | null;
  refetch: () => void;
}

export function useRoleHierarchy(): UseRoleHierarchyReturn {
  const [data, setData] = useState<RoleNode[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [trigger, setTrigger] = useState(0);

  useEffect(() => {
    let cancelled = false;

    const fetchHierarchy = async () => {
      setLoading(true);
      setError(null);
      try {
        const json = await getRoleHierarchy();
        if (!cancelled) setData(json || []);
      } catch (err) {
        if (!cancelled)
          setError(err instanceof Error ? err.message : "Unknown error");
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    fetchHierarchy();
    return () => {
      cancelled = true;
    };
  }, [trigger]);

  const refetch = () => setTrigger((t) => t + 1);

  return { data, loading, error, refetch };
}