import { useCallback, useState } from "react";

export function useGeolocation() {
    const [isFetching, setIsFetching] = useState(false);

    const getCurrentLocation = useCallback(async () => {
        setIsFetching(true);
        try {
            if (!("geolocation" in navigator)) {
                throw new Error("Geolocation is not supported by your browser.");
            }

            const position = await new Promise<GeolocationPosition>((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(resolve, reject, {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0,
                });
            });

            return {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude,
            };
        } catch (error: any) {
            console.error("Geolocation failed:", error);
            let errorMessage = "Location permission is required. Please enable location services.";
            if (error.code === error.TIMEOUT) {
                errorMessage = "Location fetching timed out. Please try again.";
            } else if (error.message) {
                errorMessage = error.message;
            }
            throw new Error(errorMessage);
        } finally {
            setIsFetching(false);
        }
    }, []);

    return {
        isFetching,
        getCurrentLocation,
    };
}
