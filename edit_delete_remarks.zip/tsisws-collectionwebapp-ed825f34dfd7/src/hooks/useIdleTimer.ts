import { useEffect, useCallback, useRef, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { sendHeartbeat } from '@/lib/services/session';
import { SESSION_EXPIRED_EVENT } from '@/lib/utils/NavigateService';

const HEARTBEAT_INTERVAL = 30000; // 30 seconds

interface IdleTimerOptions {
    activeIdleTimeout: number; // Total time in seconds before logout (active tab)
    backgroundTimeout: number; // Total time in seconds before logout (hidden tab)
    warningThreshold: number; // Time in seconds before logout to show warning
    onIdle: () => void; // Callback when any timeout is reached
}

type SessionStatus = 'active' | 'warning' | 'expired';

/**
 * useIdleTimer tracks user activity and manages distinct session states.
 * It strictly separates logic for the active tab and background visibility.
 */
export function useIdleTimer({
    activeIdleTimeout,
    backgroundTimeout,
    warningThreshold,
    onIdle,
}: IdleTimerOptions) {
    const { isAuthenticated } = useAuth();
    const [status, setStatus] = useState<SessionStatus>('active');
    const [timeLeft, setTimeLeft] = useState(warningThreshold);

    // Use refs for tracking to avoid stale closures in listeners/intervals
    const statusRef = useRef<SessionStatus>('active');
    const lastActivityRef = useRef<number>(Date.now());
    const hiddenAtRef = useRef<number | null>(null);
    const timeLeftRef = useRef(warningThreshold);
    const timeoutRef = useRef<ReturnType<typeof setInterval> | null>(null);
    const lastHeartbeatRef = useRef<number>(0);

    const onIdleRef = useRef(onIdle);
    useEffect(() => { onIdleRef.current = onIdle; }, [onIdle]);

    const resetToActive = useCallback(() => {
        // CRITICAL: If session is already expired, do NOT reset unless re-authenticated
        if (statusRef.current === 'expired') return;

        const now = Date.now();
        lastActivityRef.current = now;

        if (statusRef.current !== 'active') {
            statusRef.current = 'active';
            setStatus('active');
            setTimeLeft(warningThreshold);
            timeLeftRef.current = warningThreshold;
        }
    }, [warningThreshold]);

    const resetRef = useRef(resetToActive);
    useEffect(() => { resetRef.current = resetToActive; }, [resetToActive]);

    useEffect(() => {
        if (!isAuthenticated) {
            if (timeoutRef.current) clearInterval(timeoutRef.current);
            return;
        }

        lastActivityRef.current = Date.now();
        statusRef.current = 'active';
        setStatus('active');
        hiddenAtRef.current = null;

        const activityEvents = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart'];

        let lastMove = 0;
        const handleActivity = (e: Event) => {
            if (document.visibilityState === 'hidden' || statusRef.current === 'expired') return;

            if (e.type === 'mousemove') {
                const now = Date.now();
                if (now - lastMove < 2000) return;
                lastMove = now;
            }
            resetRef.current();

            // Heartbeat only on real activity (throttled)
            const now = Date.now();
            if (now - lastHeartbeatRef.current > HEARTBEAT_INTERVAL) {
                sendHeartbeat();
                lastHeartbeatRef.current = now;
            }
        };

        const checkIdle = () => {
            if (statusRef.current === 'expired' || document.visibilityState === 'hidden') return;

            const now = Date.now();
            const elapsed = Math.floor((now - lastActivityRef.current) / 1000);

            if (elapsed >= activeIdleTimeout) {
                statusRef.current = 'expired';
                setStatus('expired');
                if (timeoutRef.current) clearInterval(timeoutRef.current);
            } else if (elapsed >= activeIdleTimeout - warningThreshold) {
                if (statusRef.current !== 'warning') {
                    statusRef.current = 'warning';
                    setStatus('warning');
                }
                const remaining = activeIdleTimeout - elapsed;
                if (remaining !== timeLeftRef.current) {
                    timeLeftRef.current = remaining;
                    setTimeLeft(remaining);
                }
            } else {
                if (statusRef.current === 'warning') {
                    resetRef.current();
                }
            }
        };

        const handleVisibility = () => {
            const now = Date.now();
            if (document.visibilityState === 'hidden') {
                hiddenAtRef.current = now;
                if (timeoutRef.current) clearInterval(timeoutRef.current);
            } else {
                // Return transition: Check if background timeout was exceeded while away
                const startHidden = hiddenAtRef.current || lastActivityRef.current;
                const timeHidden = Math.floor((now - startHidden) / 1000);

                if (timeHidden >= backgroundTimeout) {
                    statusRef.current = 'expired';
                    setStatus('expired');
                    if (timeoutRef.current) clearInterval(timeoutRef.current);
                } else {
                    // Safe return: resume the internal ticker without resetting the idle clock.
                    // Tab visibility change is NOT considered user activity.
                    if (statusRef.current !== 'expired') {
                        if (timeoutRef.current) clearInterval(timeoutRef.current);
                        timeoutRef.current = setInterval(checkIdle, 1000);
                    }
                }
            }
        };

        /**
         * Responds to global session revocation events (e.g. from API 401 AUTH-005)
         */
        const handleForceExpiry = () => {
            if (statusRef.current !== 'expired') {
                statusRef.current = 'expired';
                setStatus('expired');
                if (timeoutRef.current) clearInterval(timeoutRef.current);
            }
        };

        // Initialize event listeners
        activityEvents.forEach((event) =>
            window.addEventListener(event, handleActivity, { passive: true })
        );
        document.addEventListener('visibilitychange', handleVisibility);
        window.addEventListener(SESSION_EXPIRED_EVENT, handleForceExpiry);

        // Start internal status check ticker
        if (timeoutRef.current) clearInterval(timeoutRef.current);
        timeoutRef.current = setInterval(checkIdle, 1000);

        return () => {
            activityEvents.forEach((event) => window.removeEventListener(event, handleActivity));
            document.removeEventListener('visibilitychange', handleVisibility);
            window.removeEventListener(SESSION_EXPIRED_EVENT, handleForceExpiry);
            if (timeoutRef.current) clearInterval(timeoutRef.current);
        };
    }, [isAuthenticated, activeIdleTimeout, backgroundTimeout, warningThreshold]);

    return {
        isWarning: status === 'warning',
        isExpired: status === 'expired',
        timeLeft,
        resetTimer: resetToActive
    };
}
