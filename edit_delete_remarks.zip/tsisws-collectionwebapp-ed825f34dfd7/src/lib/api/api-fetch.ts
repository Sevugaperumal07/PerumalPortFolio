import { config } from '@/config';
import { TokenService } from './token-service';
import { refreshAccessToken } from './auth';
import { NavigateService } from '../utils/NavigateService';
import ErrorStatusCode from '@/constants/ErrorStatusCode';
import { SessionExpiredError, ApiError } from '../utils/errors';

export interface ApiFetchOptions extends RequestInit {
  baseUrl?: string;
  responseType?: 'json' | 'blob' | 'text';
}


/**
 * Reusable fetch wrapper for API calls.
 * Handles base URL, authorization headers, and error handling.
 * Includes automatic 401 retry with token refresh.
 */
export async function apiFetch<T>(
  endpoint: string,
  options: ApiFetchOptions = {}
): Promise<T> {
  const {
    baseUrl = config.api.baseUrl,
    responseType = 'json',
    headers: customHeaders = {},
    ...rest
  } = options;

  // Use base URL if endpoint is relative
  const url = endpoint.startsWith('http') ? endpoint : `${baseUrl}${endpoint}`;

  const getHeaders = () => {
    const headers: Record<string, string> = {
      ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
      ...(customHeaders as Record<string, string>),
    };

    const token = TokenService.getAccessToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  };

  const executeRequest = async (): Promise<Response> => {
    return fetch(url, {
      ...rest,
      headers: getHeaders(),
      credentials: 'include',
    });
  };

  let response = await executeRequest();

  // If 401, attempt to refresh token and retry once
  if (response.status === 401) {
    try {
      // Clone response to read body for error code without consuming the original response
      const responseClone = response.clone();
      let errorCode = '';
      let errorMessage = '';
      const errorText = await responseClone.text();
      let errorData: any = null;
      if (errorText) {
        errorData = JSON.parse(errorText);
        errorCode = errorData?.errorCode || '';
        errorMessage = errorData?.message || errorData?.error || errorMessage;
      }

      // Handle specific session expiry code (AUTH-005) immediately
      if (errorCode === ErrorStatusCode.SESSION_EXPIRED) {
        NavigateService.triggerSessionExpiry(errorMessage);
        throw new SessionExpiredError(errorMessage || 'Session expired');
      }

      // Handle token expiration (AUTH-003) or generic 401 by attempting refresh
      if (errorCode === ErrorStatusCode.INVALID_OR_EXPIRED_TOKEN) {
        const refreshResult = await refreshAccessToken();

        if (refreshResult && 'accessToken' in refreshResult) {
          response = await executeRequest();
        } else {
          // If refresh failed, we must assume the session is dead
          const refreshError = (refreshResult as any)?.error || errorMessage;
          NavigateService.triggerSessionExpiry(refreshError);
        }
      } else if (errorCode === ErrorStatusCode.NO_ACTIVE_SESSIONS_FOUND) {
        // Special case: Do not trigger session expiry for "No active sessions found".
        // Return the error data directly so the caller can handle it in the try block.
        return errorData as T;
      } else {
        // For any other 401 error code, trigger expiry as a safety measure
        NavigateService.triggerSessionExpiry(errorMessage);
        throw new SessionExpiredError(`${errorMessage}`);
      }

    } catch (refreshError) {
      throw refreshError;
    }
  }

  if (!response.ok) {
    let errorMessage = `HTTP error! status: ${response.status}`;
    let errorCode = '';
    try {
      const errorContent = await response.text();
      try {
        const errorJson = JSON.parse(errorContent);
        errorMessage = errorJson.message || errorJson.error || errorMessage;
        errorCode = errorJson.errorCode || '';
      } catch {
        errorMessage = errorContent || errorMessage;
      }
    } catch {
      // Fallback
    }
    throw new ApiError(errorMessage, response.status, errorCode);
  }

  if (responseType === 'blob') {
    return response.blob() as unknown as Promise<T>;
  }

  const text = await response.text();
  if (responseType === 'text') {
    return text as unknown as T;
  }

  // Handle potentially empty JSON responses (e.g. 204 No Content)
  if (!text) {
    return {} as T;
  }

  try {
    return JSON.parse(text);
  } catch (err) {
    console.error(`[apiFetch] Failed to parse JSON response from ${url}:`, err);
    return text as unknown as T;
  }
}

export default apiFetch;
