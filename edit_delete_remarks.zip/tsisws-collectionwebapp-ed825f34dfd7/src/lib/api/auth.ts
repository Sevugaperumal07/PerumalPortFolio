import { restClient } from './client';
import { TokenService } from './token-service';
import { config } from '@/config';
import type {
  LoginRequest,
  LoginResponse,
  TokenRefreshResponse,
  SendOtpRequest,
  VerifyOtpRequest,
  VerifyOtpResponse,
  ResetPasswordRequest
} from '../types';

export async function login(credentials: LoginRequest): Promise<LoginResponse> {
  const response = await restClient<LoginResponse>('/api/v1/auth/authenticate', {
    method: 'POST',
    body: JSON.stringify(credentials),
  });

  if (response.accessToken) {
    TokenService.setAccessToken(response.accessToken);
  }

  return response;
}

export async function sendOtp(data: SendOtpRequest): Promise<void> {
  await restClient<void>('/api/v1/auth/send-otp', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function verifyOtp(data: VerifyOtpRequest): Promise<VerifyOtpResponse> {
  return await restClient<VerifyOtpResponse>('/api/v1/auth/verify-otp', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function resetPassword(data: ResetPasswordRequest, tempToken: string): Promise<void> {
  await restClient<void>('/api/v1/auth/reset-password', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${tempToken}`,
    },
    body: JSON.stringify(data),
  });
}


// Variable to track current refresh promise to avoid multiple simultaneous refreshes
let refreshPromise: Promise<TokenRefreshResponse | null> | null = null;

/**
 * Calls the refresh token API to get a new access token.
 */
export async function refreshAccessToken(): Promise<TokenRefreshResponse & { error?: string } | null> {
  if (refreshPromise) {
    return refreshPromise as any;
  }

  refreshPromise = (async () => {
    try {
      const response = await fetch(`${config.api.baseUrl}/api/auth/refresh`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
      });

      if (!response.ok) {
        let errorMessage = 'Refresh failed';
        try {
          const errorData = await response.json();
          errorMessage = errorData.message || errorData.error || errorMessage;
        } catch {
        }
        throw new Error(errorMessage);
      }

      const data: TokenRefreshResponse = await response.json();
      TokenService.setAccessToken(data.accessToken);

      return data;
    } catch (error: any) {
      TokenService.clearAllTokens();
      return { error: error.message } as any;
    } finally {
      refreshPromise = null;
    }
  })();

  return refreshPromise as any;
}

export async function logout(): Promise<void> {
  try {
    await restClient('/api/v1/auth/logout', {
      method: 'POST',
      credentials: 'include',
    });
  } catch (error) {
    console.error('Logout API call failed', error);
  } finally {
    TokenService.clearAllTokens();
  }
}

export function isAuthenticated(): boolean {
  return TokenService.isAuthenticated();
}

export function getToken(): string | null {
  return TokenService.getAccessToken();
}
