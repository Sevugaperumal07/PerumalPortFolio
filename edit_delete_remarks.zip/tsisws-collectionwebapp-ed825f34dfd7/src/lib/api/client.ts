import { apiFetch, type ApiFetchOptions } from './api-fetch';

export interface RestClientOptions extends ApiFetchOptions {}

export async function restClient<T>(
  endpoint: string,
  options: RestClientOptions = {}
): Promise<T> {
  return apiFetch<T>(endpoint, options);
}

