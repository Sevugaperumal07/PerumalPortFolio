/**
 * TokenService handles the secure storage of access and refresh tokens.
 * Access Token: Stored in sessionStorage to prevent XSS theft.
 * Refresh Token: Stored in a cookie for persistence and security.
 * Session ID: Stored in sessionStorage.
 */

const SESSION_ID_KEY = 'sessionId';

export const TokenService = {
    setAccessToken(token: string): void {
        sessionStorage.setItem('accessToken', token);
    },

    getAccessToken(): string | null {
        return sessionStorage.getItem('accessToken');
    },

    setSessionId(sessionId: string): void {
        sessionStorage.setItem(SESSION_ID_KEY, sessionId);
    },

    getSessionId(): string | null {
        return sessionStorage.getItem(SESSION_ID_KEY);
    },

    clearAllTokens(): void {
        sessionStorage.removeItem(SESSION_ID_KEY);
        sessionStorage.removeItem('accessToken');
        sessionStorage.removeItem('auth:user');
    },

    isAuthenticated(): boolean {
        return !!this.getAccessToken();
    }
};

export default TokenService;
