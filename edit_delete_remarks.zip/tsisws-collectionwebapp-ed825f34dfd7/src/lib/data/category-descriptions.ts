
/**
 * Dynamic mapping for category descriptions in the Role Access Setup.
 * Add new categories and their descriptions here to automatically 
 * update the UI modals/popovers.
 */

export interface CategoryDescription {
  about: string;
}

export const CATEGORY_DESCRIPTIONS: Record<string, CategoryDescription> = {
  "AcceptRejectCash": {
    about: "",
  },
  "AcceptancePending": {
    about: "",
  },
  "Account": {
    about: "",
  },
  "AccountHistory":{
    about : ""
  },

};

/**
 * Helper to get description for a category with safe fallback coverage.
 */
export const getCategoryInfo = (category: string): CategoryDescription => {
  return CATEGORY_DESCRIPTIONS[category] || {
    about: `Detailed description for ${category} will be updated shortly. This module defines the core functional logic and data access rules for this business area.`
  };
};