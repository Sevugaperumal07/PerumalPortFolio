export type Notification = {
  id: string;
  type: 'case' | 'task';
  message: string;
  time: string;
  referenceId: string | number;
  read: boolean;
};

export const sampleNotifications: Notification[] = [
  {
    id: '1',
    type: 'case',
    message: 'New case assigned: LA-10234',
    time: '5 min ago',
    referenceId: 'LA-10234',
    read: false,
  },
  {
    id: '2',
    type: 'task',
    message: 'Follow-up task due tomorrow',
    time: '1 hr ago',
    referenceId: 'T-9842',
    read: false,
  },
  {
    id: '3',
    type: 'task',
    message: 'Monthly report available for review',
    time: 'Yesterday',
    referenceId: 'R-2025-10',
    read: true,
  },
];
