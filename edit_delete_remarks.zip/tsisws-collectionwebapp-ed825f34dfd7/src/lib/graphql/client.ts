import { GraphQLClient } from "graphql-request";
import { config } from "@/config";
import { TokenService } from "../api/token-service";
import { refreshAccessToken } from "../api/auth";
import { NavigateService } from "../utils/NavigateService";
import ErrorStatusCode from "../../constants/ErrorStatusCode";
import { SessionExpiredError } from "../utils/errors";

const GRAPHQL_ENDPOINT = `${config.api.baseUrl}/graphql`;


// Create GraphQL client with authentication
function createClient(token: string | null) {
  return new GraphQLClient(GRAPHQL_ENDPOINT, {
    headers: {
      "Content-Type": "application/json",
      ...(token && { Authorization: `Bearer ${token}` }),
    },
  });
}

// GraphQL request wrapper
export async function graphqlRequest<T>(
  query: string,
  variables?: Record<string, unknown>,
): Promise<T> {
  const execute = async () => {
    const token = TokenService.getAccessToken();
    const client = createClient(token);
    return client.request<any>(query, variables);
  };

  try {
    const response = await execute();
    return formatResponse<T>(response);
  } catch (error: any) {
    const statusCode = error?.response?.status || error?.status;

    // If 401, attempt to refresh token and retry
    if (statusCode === 401) {
      try {
        const errors = error?.response?.data?.errors;
        const errorCode = errors?.[0]?.errorCode || error?.response?.data?.errorCode || '';

        // 1. Handle specific session expiry code (AUTH-005) immediately
        if (errorCode === ErrorStatusCode.SESSION_EXPIRED) {
          handleAuthFailure();
        }

        // 2. Handle token expiration (AUTH-003) or generic 401 by attempting refresh
        if (errorCode === ErrorStatusCode.INVALID_OR_EXPIRED_TOKEN || !errorCode) {
          const refreshResult = await refreshAccessToken();

          if (refreshResult && 'accessToken' in refreshResult) {
            const retryResponse = await execute();
            return formatResponse<T>(retryResponse);
          } else {
            const refreshError = (refreshResult as any)?.error;
            handleAuthFailure(refreshError);
          }
        } else {
          // For any other 401 error code
          handleAuthFailure();
        }
      } catch (refreshError) {
        if (refreshError instanceof SessionExpiredError) {
          throw refreshError;
        }
        handleAuthFailure();
        throw refreshError;
      }
    }

    // Handle other errors
    return handleError(error);
  }
}

function formatResponse<T>(response: any): T {
  if (response && typeof response === "object") {
    if ("errors" in response && response.errors && Array.isArray(response.errors) && response.errors.length > 0) {
      const errorMessage = response.errors[0]?.message || "GraphQL error occurred";
      throw new Error(errorMessage);
    }

    if ("data" in response && response.data && typeof response.data === "object" && "errors" in response.data) {
      const errors = response.data.errors;
      if (Array.isArray(errors) && errors.length > 0) {
        const errorMessage = errors[0]?.message || "GraphQL error occurred";
        throw new Error(errorMessage);
      }
    }
  }

  if (response && typeof response === "object" && "data" in response) {
    return response.data as T;
  }

  return response as T;
}

function handleError(error: any): any {
  if (error?.message?.includes('serialize') || error?.message?.includes('Boolean')) {
    if (error?.response?.data) {
      return error.response.data;
    }
    if (error?.response && typeof error.response === 'object' && 'deleteBankDetails' in error.response) {
      return error.response;
    }
  }

  const statusCode = error?.response?.status || error?.status;

  if (statusCode === 401) {
    handleAuthFailure();
  }

  if (error?.response?.errors && error.response.errors.length > 0) {
    throw new Error(
      error.response.errors[0].message || "GraphQL error occurred",
    );
  }

  if (error?.message) {
    throw new Error(error.message);
  }

  if (error instanceof Error) {
    throw error;
  }
  throw new Error("Unknown error occurred");
}

function handleAuthFailure(message?: string) {
  NavigateService.triggerSessionExpiry(message);
  throw new SessionExpiredError(message || 'Session expired');
}
