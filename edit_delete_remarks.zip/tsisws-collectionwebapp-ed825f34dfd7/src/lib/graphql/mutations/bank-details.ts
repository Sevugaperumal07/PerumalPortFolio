export const CREATE_BANK_DETAIL = `
  mutation CreateBankDetails($bankDetails: BankDetailsInput!) {
    createBankDetails(bankDetails: $bankDetails) {
      id
      bankName
      accountNumber
      branchName
      ifscCode
      hiveId
      dateEntered
      dateModified
      deleted
    }
  }
`;

export const UPDATE_BANK_DETAIL = `
  mutation updateBankDetailsFieldById($id: String!, $bankDetails: BankDetailsInput!) {
    updateBankDetailsFieldById(id: $id, bankDetails: $bankDetails) {
      id
      bankName
      accountNumber
      branchName
      ifscCode
      hiveId
      dateModified
      dateEntered
      deleted
    }
  }
`;

export const DELETE_BANK_DETAIL = `
  mutation deleteBankDetails($id: String!) {
    deleteBankDetails(id: $id)
  }
`;

