export const CREATE_ACCOUNT_CONTACT = `
  mutation CreateAccountContact($accountContact: AccountContactInput!) {
    createAccountContact(accountContact: $accountContact) {
      id
      contactNumber
      contactName
      latitude
      longitude
      dateEntered
      deleted
      dateModified
      accountId
      userId
      accountContactdateEntered
      hiveId
    }
  }
`;

export const CREATE_ACCOUNT_ADDRESS_MANAGEMENT = `
  mutation CreateAccountAddressManagement($accountAddressManagement: AccountAddressManagementInput!) {
    createAccountAddressManagement(accountAddressManagement: $accountAddressManagement) {
      id
      latitude
      longitude
      dateEntered
      dateModified
      deleted
      address
      accountId
      accountAddressDateTime
      collAgentId
      hiveId
      locname
      userId
    }
  }
`;
