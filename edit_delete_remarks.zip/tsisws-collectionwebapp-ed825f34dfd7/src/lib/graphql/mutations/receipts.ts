// Check if a receipt is editable or deletable
export const CHECK_COLL_RECEIPT_EDITABLE = `
  mutation CheckCollReceiptEditable($oldReceiptNo: String!) {
    checkCollReceiptEditable(oldReceiptNo: $oldReceiptNo) {
      editable
      reasons
    }
  }
`;

// Delete a collection receipt
export const DELETE_COLLECTION_RECEIPT = `
  mutation DeleteCollectionReceipt($receiptId: ID!, $remarks: String!) {
    deleteCollectionReceipt(receiptId: $receiptId, remarks: $remarks) {
      status
      message
    }
  }
`;

// Recreate (edit) a collection receipt
export const RECREATE_COLL_RECEIPT = `
  mutation RecreateCollReceipt($input: RecreateCollReceiptInput!) {
    recreateCollReceipt(input: $input) {
      success
      message
      newReceipt {
        id
        dateEntered
        dateModified
        deleted
        receiptNo
        receiptdate
        currencyId
        collectedEmiAmount
        status
        latitude
        longitude
        receiptPdf
        transactionRefNo
        branchName
        receiptGenerationTime
        receiptStoredDateTime
        caseNo
        userId
        branchDepositSlipno
        bankDepositSlipno
        receivedSumOfRupees
        receivedSumInWords
        collectedBy
        remarks
        totalAmount
        collectedBounceAmount
        emiOverdueAmount
        hiveId
        collectedPenaltyAmount
        lanNumber
        serviceChargeTypeId
        paymentImage
        selfieImage
        customerName
        acceptanceStatus
        rejectedBy
        rejectedUserId
        rejectedTime
        rejectedDate
        rejectedRemarks
        branchOpsUserId
        pay_EMI_only
        paymentType
        accountId
      }
      oldReceipt {
        id
        dateEntered
        dateModified
        deleted
        receiptNo
        receiptdate
        currencyId
        collectedEmiAmount
        status
        latitude
        longitude
        receiptPdf
        transactionRefNo
        branchName
        receiptGenerationTime
        receiptStoredDateTime
        caseNo
        userId
        branchDepositSlipno
        bankDepositSlipno
        receivedSumOfRupees
        receivedSumInWords
        collectedBy
        remarks
        totalAmount
        collectedBounceAmount
        emiOverdueAmount
        hiveId
        collectedPenaltyAmount
        lanNumber
        serviceChargeTypeId
        paymentImage
        selfieImage
        customerName
        acceptanceStatus
        rejectedBy
        rejectedUserId
        rejectedTime
        rejectedDate
        rejectedRemarks
        branchOpsUserId
        pay_EMI_only
        paymentType
        accountId
      }
    }
  }
`;
