export const CREATE_ROLE = `
  mutation CreateRole($aclRole: AclRoleInput) {
    createRole(aclRole: $aclRole) {
      id
      name
      description
      dateEntered
      dateModified
      deleted
    }
  }
`;

export const UPDATE_ROLE_BY_ID = `
  mutation UpdateRoleById($id: ID!, $aclRole: AclRoleInput) {
    updateRoleById(id: $id, aclRole: $aclRole) {
      id
      name
      description
      dateModified
      deleted
    }
  }
`;

