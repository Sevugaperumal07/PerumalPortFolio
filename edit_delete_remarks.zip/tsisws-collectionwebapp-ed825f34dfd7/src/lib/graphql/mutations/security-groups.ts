export const CREATE_SECURITY_GROUP = `
  mutation CreateSecurityGroups($securityGroups: SecurityGroupsInput) {
    createSecurityGroups(securityGroups: $securityGroups) {
      id
      name
      description
      inheritable
      dateEntered
      dateModified
      deleted
    }
  }
`;

export const UPDATE_SECURITY_GROUP_BY_ID = `
  mutation updateSecurityGroupsFieldById($id: String!, $securityGroups: SecurityGroupsInput!) {
    updateSecurityGroupsFieldById(id: $id, securityGroups: $securityGroups) {
      id
      name
      description
      inheritable
      dateModified
    }
  }
`;

export const LINK_ROLE_TO_SECURITY_GROUP = `
  mutation LinkRoleToSecurityGroup($roleId: String!, $securityId: String!) {
    linkRoleToSecurityGroup(roleId: $roleId, securityId: $securityId) {
      id
      name
      description
    }
  }
`;

export const LINK_BANK_DETAILS_TO_SECURITY_GROUP = `
  mutation LinkBankDetailsToSecurityGroup($bankDetailsId: String!, $securityGroupId: String!) {
    linkBankDetailsToSecurityGroup(bankDetailsId: $bankDetailsId, securityGroupId: $securityGroupId) {
      id
      bankName
      accountNumber
    }
  }
`;

