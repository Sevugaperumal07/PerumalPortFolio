export const CREATE_USER = `
  mutation CreateUser($user: UserInput!) {
    createUser(user: $user) {
      id
      userName
      email
      userType
      userHash
      firstName
      lastName
      status
      department
      title
      employeeCode
      phoneMobile
      phoneOther
      phoneWork
      reportsToId
      supervisor
      supervisorEmail
      dateModified
    }
  }
`;

export const UPDATE_USER_FIELD_BY_ID = `
  mutation UpdateUserFieldById($id: ID!, $user: UserInput) {
    updateUserFieldById(id: $id, user: $user) {
      id
      userName
      email
      firstName
      lastName
      status
      userType
      employeeCode
      phoneMobile
      phoneWork
      department
      title
      dateModified
      reportsToId
      supervisor
      supervisorEmail
    }
  }
`;

export const DELETE_USER = `
  mutation DeleteUser($id: ID!) {
    deleteUser(id: $id)
  }
`;

export const LINK_USER_TO_ROLE = `
  mutation LinkUserToRole($userId: String!, $roleId: String!) {
    linkUserToRole(userId: $userId, roleId: $roleId) {
      id
      userName
      email
    }
  }
`;

export const UNLINK_USER_FROM_ROLE = `
  mutation UnlinkUserFromRole($userId: String!, $roleId: String!) {
    unlinkUserFromRole(userId: $userId, roleId: $roleId) {
      id
      userName
      email
    }
  }
`;

export const LINK_EXISTING_SECURITY_TO_USER = `
  mutation LinkExistingSecurityToUser($userId: String!, $securityId: String!) {
    linkExistingSecurityToUser(userId: $userId, securityId: $securityId) {
      id
      name
    }
  }
`;

export const UNLINK_SECURITY_FROM_USER = `
  mutation UnlinkSecurityFromUser($userId: String!, $securityId: String!) {
    unlinkSecurityFromUser(userId: $userId, securityId: $securityId) {
      id
      name
    }
  }
`;

