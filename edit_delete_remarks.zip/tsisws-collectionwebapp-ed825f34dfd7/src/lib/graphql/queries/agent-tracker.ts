export const GET_CHECK_IN_OUT_BY_USER_ID = `
  query GetCheckInOutByUserId($userId: String!) {
    getCheckInOutByUserId(userId: $userId) {
      id
      checkInDateTime
      checkOutDateTime
      userId
      deleted
      dateEntered
      dateModified
      durationInSeconds
      hiveId
      checkInLatitude
      checkInLongitude
      checkInBatteryPercentage
      checkoutLatitude
      checkoutLongitude
      checkoutBatteryPercentage
    }
  }
`

export const GET_CASES_DISPOSITION_BY_USER_ID = `
  query GetCasesDispositionByUserId($userId: String!) {
    getCasesDispositionByUserId(userId: $userId) {
      id
      activityDate
      activityName
      remarks
      hiveId
      amountCollected
      ptpAmount
      contactName
      contactNumber
      paymentType
      paymentAttachment
      latitude
      longitude
      batteryPercentage
      userId
      casesId
      dateEntered
      dateModified
      deleted
    }
  }
`

export const GET_CASE_BY_ID = `
  query GetCaseById($id: ID!) {
    getCaseById(id: $id) {
      id
      caseNumber
    }
  }
`

export const GET_ACCOUNTS_BY_CASE_ID = `
  query GetAccountsByCaseId($id: ID!) {
    getAccountsByCaseId(id: $id) {
      id
      name
      lanNumber
      applicationNumber
      customerId
      coapplicantPhoneNumber
      emailAddress
      dateEntered
      dateModified
      createdBy
      deleted
      rmName
      product
      customerGender
      loanAmount
      customerAddress
      billingAddressPostalcode
      customerPhoneNumber
      propertyAddress
      coapplicantAddress
      propertyValue
      coapplicantGender
      buyOutOwn
      latitude
      longitude
      branch
      bdmName
      dataBy
      location
      disbursementStatus
      nextDueDate
      propertyType
      userId
      coApplicantName
      customerLatitude
      customerLongitude
      coapplicantLatitude
      coapplicantLongitude
      propertyLatitude
      propertyLongitude
      emiOverdue
      bounceCharge
      penalCharges
      emiAmount
      dpd
      previousUserId
      reassignedOn
    }
  }
`

