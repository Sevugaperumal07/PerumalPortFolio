export const GET_BANK_DETAILS_LIST = `
  query GetBankDetailsList {
    getBankDetailsList {
      id
      bankName
      accountNumber
      branchName
      ifscCode
      hiveId
      dateEntered
      dateModified
      deleted
    }
  }
`;

