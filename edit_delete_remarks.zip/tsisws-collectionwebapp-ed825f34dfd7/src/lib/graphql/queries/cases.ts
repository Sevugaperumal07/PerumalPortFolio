export const GET_ACCOUNTS = `
  query GetAccounts {
    getAccounts {
      id
      name
      lanNumber
      applicationNumber
      customerId
      coapplicantPhoneNumber
      emailAddress
      dateEntered
      dateModified
      createdBy
      deleted
      rmName
      product
      customerGender
      loanAmount
      customerAddress
      billingAddressPostalcode
      customerPhoneNumber
      propertyAddress
      coapplicantAddress
      propertyValue
      coapplicantGender
      buyOutOwn
      latitude
      longitude
      branch
      bdmName
      dataBy
      location
      disbursementStatus
      nextDueDate
      propertyType
      userId
      coApplicantName
      customerLatitude
      customerLongitude
      coapplicantLatitude
      coapplicantLongitude
      propertyLatitude
      propertyLongitude
      emiOverdue
      bounceCharge
      penalCharges
      emiAmount
      dpd
      previousUserId
      reassignedOn
    }
  }
`;

export const GET_ACCOUNTS_PAGINATED = `
  query GetAccountsByReportingManagerPaginated($limit: Int, $offset: Int, $searchFilter: String, $lanNumber: String, $state: String, $branch: String, $agentName: String) {
    getAccountsByReportingManagerPaginated(clientType: "web", limit: $limit, offset: $offset, searchFilter: $searchFilter, lanNumber: $lanNumber, state: $state, branch: $branch, agentName: $agentName) {
      pageNumber
      pageSize
      totalElements
      totalPages
      first
      last
      empty
      content {
        id
        name
        lanNumber
        applicationNumber
        customerId
        coapplicantPhoneNumber
        emailAddress
        dateEntered
        dateModified
        createdBy
        deleted
        rmName
        product
        customerGender
        loanAmount
        customerAddress
        billingAddressPostalcode
        customerPhoneNumber
        propertyAddress
        coapplicantAddress
        propertyValue
        coapplicantGender
        buyOutOwn
        latitude
        longitude
        branch
        bdmName
        dataBy
        location
        disbursementStatus
        nextDueDate
        propertyType
        userId
        coApplicantName
        customerLatitude
        customerLongitude
        coapplicantLatitude
        coapplicantLongitude
        propertyLatitude
        propertyLongitude
        emiOverdue
        bounceCharge
        penalCharges
        emiAmount
        dpd
        previousUserId
        reassignedOn
        securityGroups {
          id,
          name
        }
      }
    }
  }
`;

export const GET_ACCOUNT_BY_ID = `
  query GetAccountById($id: ID!) {
    getAccountById(id: $id) {
      id
      name
      lanNumber
      applicationNumber
      customerId
      coapplicantPhoneNumber
      emailAddress
      dateEntered
      dateModified
      createdBy
      deleted
      rmName
      product
      customerGender
      loanAmount
      customerAddress
      billingAddressPostalcode
      customerPhoneNumber
      propertyAddress
      coapplicantAddress
      propertyValue
      coapplicantGender
      buyOutOwn
      latitude
      longitude
      branch
      bdmName
      dataBy
      location
      disbursementStatus
      nextDueDate
      propertyType
      userId
      coApplicantName
      customerLatitude
      customerLongitude
      coapplicantLatitude
      coapplicantLongitude
      propertyLatitude
      propertyLongitude
      emiOverdue
      bounceCharge
      penalCharges
      emiAmount
      dpd
      previousUserId
      reassignedOn
    }
  }
`;

export const GET_CASE_ACTIVITY_HISTORY = `
  query GetCaseActivityHistory($lanNumber: String!, $year: Int!, $month: Int) {
    getCaseActivityHistory(
        lanNumber: $lanNumber
        year: $year
        month: $month
    ) {
        id
        type
        date
        caseId
        caseNumber
        hiveId
        latitude
        longitude
        hasPaymentImagePath
        hasSelfieImagePath
        remarks
        activityBy
        ... on DispositionHistory {
            activityName
            nextActionDate
            nextActionTime
            counter
        }
        ... on ReceiptHistory {
            status
            receiptNo
            collectedAmount
            receiptGenerationTime
            due
            paymentMode
        }
    }
  }
`;

export const GET_ACCOUNT_CONTACTS_BY_ACCOUNT_ID = `
  query GetAccountContactsByAccountId($accountId: String!) {
    getAccountContactsByAccountId(accountId: $accountId) {
      contactNumber
      contactName
      latitude
      longitude
      dateEntered
      deleted
      dateModified
      accountId
      userId
      accountContactdateEntered
      hiveId
    }
  }
`;

export const GET_ACCOUNT_ADDRESSES_BY_ACCOUNT_ID = `
  query GetAccountAddressManagementByAccountId($id: String!) {
    getAccountAddressManagementByAccountId(id: $id) {
      id
      latitude
      longitude
      dateEntered
      dateModified
      deleted
      address
      accountId
      accountAddressDateTime
      collAgentId
      userId
      hiveId
      locname
    }
  }
`;

export const GET_CASE_AUDIT_RECEIPT_HISTORY = `
  query GetAuditHistory($parentId: ID!, $year: Int!, $month: Int!, $limit: Int, $offset: Int, $showSystem: Boolean, $entityType: EntityType) {
    getAuditHistory(
        parentId: $parentId
        year: $year
        month: $month
        limit: $limit
        offset: $offset
        showSystem: $showSystem
        entityType: $entityType
    ) {
        content {
            action
            changedAt
            currentData
            entityId
            entityType
            fieldChanges
            id
            isSystem
            modifiedUserId
            modifiedUserName
            parentId
            version
        }
        currentPage
        hasNext
        hasPrevious
        size
        totalPages
        totalRecords
    }
  }
`;

