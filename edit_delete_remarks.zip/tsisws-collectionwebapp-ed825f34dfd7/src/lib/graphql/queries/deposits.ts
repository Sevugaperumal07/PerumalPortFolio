//New Query for deposit with Pagination Metadata
export const DEPOSIT_SEARCH_QUERY_DYNAMIC = (queryArgs: string, inputFields: string) => `
    query Search($typeOfDeposit: String!, $receiptPaymentType: String!, $sortBy: DepositSortField!, $sortDir: SortDir!, $depositStatus: String!, $query: String, $limit: Int!, $offset: Int!${queryArgs}){
      search(input: {
        typeOfDeposit: $typeOfDeposit,
        receiptPaymentType: $receiptPaymentType,
        sortBy: $sortBy,
        sortDir: $sortDir,
        depositStatus: $depositStatus,
        query: $query,
        limit: $limit,
        offset: $offset${inputFields}
      }){
        totalRecords
        totalPages
        currentPage
        size
        numberOfRecords
        hasNext
        hasPrevious
        content{
          id
          depositSlipno
          bankDepositDate
          branchDepositionDate
          branchDepositAmount
          bankDepositedAmount
          status
          bankName
          bankDepositedBy
          userName
          typeOfDeposit
          bankCollReceipts{
            id
            lanNumber
            transactionRefNo
            customerName
            receiptStoredDateTime
            collectedBy
            branchName
            receiptNo
            totalAmount
            status
            hiveId
            paymentType
          }
          collReceipts{
            id
            lanNumber
            transactionRefNo
            customerName
            receiptStoredDateTime
            collectedBy
            branchName
            receiptNo
            totalAmount
            status
            hiveId
            deleted
          }
        }
      }
    }
`;

export const GET_COLL_DEPOSIT_BY_ID = `
  query GetCollDepositById($id: ID!) {
    getCollDepositById(id: $id) {
      id
      dateEntered
      dateModified
      deleted
      depositSlipno
      branchDepositionDate
      branchDepositAmount
      branchDepositTime
      userId
      typeOfDeposit
      branchDepositRemarks
      branchOpsName
      hiveId
      userName
      status
      branchOpsUserId
      verifiedBy
      verifiedUserId
      verifiedTime
      verifiedDate
      verificationRemarks
      depositSlipImage
      acceptancePendingRemarks
      acceptancePendingTime
      acceptancePendingDate
      bankDepositDate
      bankDepositTime
      bankDepositRemarks
      bankDepositedBy
      bankDepositedUserId
      bankName
      bankAccountNumber
      bankDepositedAmount
      rejectedDate
      rejectedTime
      rejectedUserId
      rejectedRemarks
      rejectedBy
      branchDepositedLongitude
      branchDepositedLatitude
      bankDepositedLongitude
      bankDepositedLatitude
      depositTypeId
      bankCollReceipts{
        id
        lanNumber
        transactionRefNo
        branchName
        receiptNo
        totalAmount
        customerName
        collectedEmiAmount
        status
        receiptdate
        hiveId
        selfieImage
        paymentImage
        paymentType
        deleted
      }
      collReceipts {
        id
        dateEntered
        dateModified
        deleted
        branchName
        receiptNo
        receiptdate
        currencyId
        collectedEmiAmount
        status
        latitude
        longitude
        receiptPdf
        transactionRefNo
        branchName
        receiptGenerationTime
        receiptStoredDateTime
        caseNo
        userId
        branchDepositSlipno
        bankDepositSlipno
        receivedSumOfRupees
        receivedSumInWords
        collectedBy
        remarks
        totalAmount
        collectedBounceAmount
        emiOverdueAmount
        hiveId
        collectedPenaltyAmount
        lanNumber
        serviceChargeTypeId
        paymentImage
        selfieImage
        customerName
        acceptanceStatus
        rejectedBy
        rejectedUserId
        rejectedTime
        rejectedDate
        rejectedRemarks
        branchOpsUserId
        pay_EMI_only
        paymentType
        accountId
      }
      user {
        id
        userName
        userHash
        email
        systemGeneratedPassword
        pwdLastChanged
        authenticateId
        sugarLogin
        firstName
        lastName
        isAdmin
        externalAuthOnly
        receiveNotifications
        description
        dateEntered
        dateModified
        modifiedUserId
        createdBy
        title
        photo
        department
        phoneHome
        phoneMobile
        phoneWork
        phoneOther
        phoneFax
        status
        addressStreet
        addressCity
        addressState
        addressCountry
        addressPostalcode
        deleted
        portalOnly
        showOnEmployees
        employeeStatus
        messengerId
        messengerType
        reportsToId
        isGroup
        factorAuth
        factorAuthInterface
        supervisor
        supervisorEmail
        draCertificationDate
        draTrainingDate
        draUrn
        udid
        mpin
        userType
        deviceId
        asId
        isdevicelockedinactivity
        ismpinlocked
        isdeviceregistered
        lastsuccessfullogintimestamp
        failedloginattemptscount
        isjailbrokenorrooted
        lastpasswordchangetimestamp
        logingeolocationflag
        devicefingerprint
        isaccountlocked
        isrecentdevicechange
        isbiometricauthenabled
        noOfWarningsIssued
        cessationOfServices
        deviceMobileHash
        collAgencyId
        agentType
        pincodeID
        mpinHash
        employeeCode
        reportingManager
        reportingManagerEmployeeCode
        appVersion
      }
      depositType {
        id
        name
        dateEntered
        dateModified
        deleted
        hiveId
      }
    }
  }
`;

export const GET_BANK_NAMES = `
  query GetBankNames {
    getBankNames
  }
`;

export const UPDATE_COLL_DEPOSIT_FIELD_BY_ID = (mutationArgs: string, inputFields: string) => `
  mutation UpdateCollDepositFieldById($id: ID!${mutationArgs}) {
    updateCollDepositFieldById(
      id: $id${inputFields}
    ) {
      id
      status
      bankDepositedAmount
    }
  }
`;

export const PROCESS_BANK_DEPOSIT_SLIP_VERIFICATION = `
  mutation ProcessBankDepositSlipVerification($collDepositSlipIds: [ID!]!, $decision: VerificationType!, $remarks: String!, $date: String!, $time: String!) {
    processBankDepositSlipVerification(
      collDepositSlipIds: $collDepositSlipIds
      decision: $decision
      remarks: $remarks
      date: $date
      time: $time
    ) {
      message
      failureBankDepositSlipIds
      successBankDepositSlipIds
      failureMessages
    }
  }
`;