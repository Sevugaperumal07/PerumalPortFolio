export const GET_ROLES = `
  query GetRoles {
    getRoles {
      id
      name
      description
      dateEntered
      dateModified
      deleted
    }
  }
`;

export const GET_CONSOLIDATED_DATA = `
  query GetConsolidatedData {
    getConsolidatedData {
      permissionLevels {
        code
        value
        label
        description
      }
    }
  }
`;

