export const GET_SECURITY_GROUPS = `
  query GetSecurityGroups {
    getSecurityGroups {
      id
      name
      description
      inheritable
      dateEntered
      dateModified
      deleted
    }
  }
`;

export const GET_USERS_BY_SECURITY_GROUP_ID = `
  query GetUsersBySecurityGroupId($securityGroupId: ID!) {
    getUsersBySecurityGroupId(securityGroupId: $securityGroupId) {
      id
    }
  }
`;

export const GET_CASES_BY_SECURITY_GROUP_ID = `
  query GetCasesBySecurityGroupId($securityGroupId: ID!) {
    getCasesBySecurityGroupId(securityGroupId: $securityGroupId) {
      id
    }
  }
`;

export const GET_ROLES_BY_SECURITY_GROUP_ID = `
  query GetRoleBySecurityGroupId($securityGroupId: ID!) {
    getRoleBySecurityGroupId(securityGroupId: $securityGroupId) {
      id
    }
  }
`;