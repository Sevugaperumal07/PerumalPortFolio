export const SEARCH_CASES_DYNAMIC = (queryArgs: string, inputFields: string) => `
query SearchCases($limit: Int, $offset: Int${queryArgs}) {
  searchCases(
    limit: $limit 
    offset: $offset
    searchRequest: {
      ${inputFields}
    }
  ) {
    totalRecords
    totalPages
    currentPage
    size
    numberOfRecords
    hasNext
    hasPrevious
    casePendingCount
    pendingCount
    acceptancePendingCount
    branchOpsInHandCount
    verificationPendingCount
    verificationCompletedCount
    verifiedByHOCount
    content {
      id
      name
      dateEntered
      dateModified
      caseNumber
      createdBy
      totalOverdue
      amountCollected
      deleted
      status
      state
      accountId
      lastVisitDate
      nextActionDate
      creationDate
      latitude
      longitude
      category
      emi
      reasonForNonPayment
      emiOverdue
      bounceCharge
      penalCharges
      pendingInstallmentOverdue
      pendingBounceCharge
      pendingPenaltyCharge
      collectedInstallmentOverdue
      collectedBounceCharge
      collectedPenaltyCharge
      ptpDateDay
      ptpCounter
      nextActionTime
      loanNumber
      dpd
      ptpAttemptCount
      serviceChargeTypeId
      parentCaseId
      emiAmount

      account {
        id
        name
        lanNumber
        applicationNumber
        customerId
        coapplicantPhoneNumber
        emailAddress
        customerPhoneNumber
        branch
        loanAmount
        emiAmount
        dpd
        product
        propertyType
        location
        user {
          id
          userName
        }
      }
      UserCases{
        id
        userId{
          id
          userName
        }
      }
      caseDispositions {
        activityDate
        deleted
        userName
      }
      securityGroups {
        id
        name
        description
        deleted
      }
      collReceipts {
        id
        dateEntered
        dateModified
        deleted
        receiptNo
        receiptdate
        currencyId
        collectedEmiAmount
        status
        latitude
        longitude
        receiptPdf
        transactionRefNo
        branchName
        receiptGenerationTime
        receiptStoredDateTime
        caseNo
        userId
        branchDepositSlipno
        bankDepositSlipno
        receivedSumOfRupees
        receivedSumInWords
        collectedBy
        remarks
        totalAmount
        collectedBounceAmount
        emiOverdueAmount
        hiveId
        collectedPenaltyAmount
        lanNumber
        serviceChargeTypeId
        paymentImage
        selfieImage
        customerName
        acceptanceStatus
        rejectedBy
        rejectedUserId
        rejectedTime
        rejectedDate
        rejectedRemarks
        branchOpsUserId
        pay_EMI_only
        paymentType
        accountId
        }
    }
  }
}
`;

export const LINK_USER_TO_CASE = `
mutation LinkUserToCase($caseId: String!, $userId: String!) {
  linkUserToCase(caseId: $caseId, userId: $userId) {
    id
    name
    dateEntered
    dateModified
    caseNumber
    createdBy
    emiAmount
    amountCollected
    deleted
    status
    state
    accountId
    lastVisitDate
    nextActionDate
    creationDate
    latitude
    longitude
    category
    emi
    reasonForNonPayment
    emiOverdue
    bounceCharge
    penalCharges
    pendingInstallmentOverdue
    pendingBounceCharge
    pendingPenaltyCharge
    collectedInstallmentOverdue
    collectedBounceCharge
    collectedPenaltyCharge
    ptpDateDay
    ptpCounter
    nextActionTime
    parentCaseId
    dpd      
    securityGroups {
      id
      name
    }
    account {
      name
      lanNumber
      applicationNumber
      customerId
      coapplicantPhoneNumber
      emailAddress
      customerAddress
      billingAddressPostalcode
      customerPhoneNumber
      branch
      latitude
      longitude
      propertyType
      product
      propertyValue
      coapplicantAddress
      coapplicantGender
      propertyAddress
      customerGender
      coApplicantName
      customerLatitude
      customerLongitude
      coapplicantLatitude
      coapplicantLongitude
      propertyLatitude
      propertyLongitude
      emiOverdue
      bounceCharge
      penalCharges
      emiAmount
      dpd
      loanAmount
      user {
        id
        userName
        reportingManagerEmployeeCode
        employeeCode
      }
    }
  }
}
`;


export const GET_CASE_BY_ID = `
  query GetCaseById($id: ID!) {
  getCaseById(id: $id) {
    id
    name
    dateEntered
    dateModified
    caseNumber
    createdBy
    totalOverdue
    amountCollected
    deleted
    status
    state
    accountId
    lastVisitDate
    nextActionDate
    creationDate
    latitude
    longitude
    category
    emi
    reasonForNonPayment
    emiOverdue
    bounceCharge
    penalCharges
    pendingInstallmentOverdue
    pendingBounceCharge
    pendingPenaltyCharge
    collectedInstallmentOverdue
    collectedBounceCharge
    collectedPenaltyCharge
    ptpDateDay
    ptpCounter
    nextActionTime
    loanNumber
    dpd
    ptpAttemptCount
    serviceChargeTypeId
    parentCaseId
    emiAmount
      securityGroups {
      id
      name
    }
      collReceipts {
      id
      dateEntered
      dateModified
      deleted
      receiptNo
      receiptdate
      currencyId
      collectedEmiAmount
      status
      latitude
      longitude
      receiptPdf
      transactionRefNo
      branchName
      receiptGenerationTime
      receiptStoredDateTime
      caseNo
      userId
      branchDepositSlipno
      bankDepositSlipno
      receivedSumOfRupees
      receivedSumInWords
      collectedBy
      remarks
      totalAmount
      collectedBounceAmount
      emiOverdueAmount
      hiveId
      collectedPenaltyAmount
      lanNumber
      serviceChargeTypeId
      paymentImage
      selfieImage
      customerName
      acceptanceStatus
      rejectedBy
      rejectedUserId
      rejectedTime
      rejectedDate
      rejectedRemarks
      branchOpsUserId
      pay_EMI_only
      paymentType
      accountId
    }
      account {
      name
      lanNumber
      applicationNumber
      customerId
      coapplicantPhoneNumber
      emailAddress
      customerAddress
      billingAddressPostalcode
      customerPhoneNumber
      branch
      latitude
      longitude
      propertyType
      product
      propertyValue
      coapplicantAddress
      coapplicantGender
      propertyAddress
      loanAmount
      customerGender
      coApplicantName
      customerLatitude
      customerLongitude
      coapplicantLatitude
      coapplicantLongitude
      propertyLatitude
      propertyLongitude
      emiOverdue
      bounceCharge
      penalCharges
      emiAmount
      dpd
        user {
        id
        userName
        reportingManagerEmployeeCode
        employeeCode
      }
    }
      UserCases {
      id
        userId {
        id
        userName
        collAgencyId
        deleted
      }
    }
  }
}
`;

export const GET_STATE_SECURITY_GROUPS = `
  query GetStateSecurityGroups {
    getStateSecurityGroups {
    stateId
    stateName
      branches {
      id
      name
    }
  }
}
`;

export const GET_USERS_BY_SECURITY_GROUP_ID = `
  query GetUsersBySecurityGroupId($securityGroupId: ID!, $name: String, $limit: Int, $offset: Int) {
  getUsersBySecurityGroupId(
    securityGroupId: $securityGroupId
      name: $name
      limit: $limit
      offset: $offset
  ) {
      records {
      id
      userName
    }
    hasNext
    hasPrev
  }
}
`;

export const ASSIGN_CASES_TO_USER = `
  mutation AssignCasesToUser($caseIds: [ID!]!, $userId: ID!) {
  assignCasesToUser(caseIds: $caseIds, userId: $userId) {
    message
    failedIds
    successCount
  }
}
`;


export const GET_ALL_EMI_PENDINGS = `
  query GetAllEmiPendings {
    getAllEmiPendings {
    id
    fromRange
    toRange
    bucketCode
  }
}
`;

export const CONSOLIDATE_RECEIPT_ACCEPTANCE_REJECTION = `
  mutation ConsolidateReceiptAcceptanceRejection($receiptIds: [ID!]!, $action: String!, $remarks: String, $date: String!, $time: String!) {
  consolidateReceiptAcceptanceRejection(input: {
    receiptIds: $receiptIds
      action: $action
      remarks: $remarks
      date: $date
      time: $time
  }) {
    success
    message
    totalProcessed
    totalFailed
    errors
    action
    acceptanceStatus
    date
    time
    remarks
    receiptIds
    branchDepositSlipnos
    rejectedBy
    rejectedUserId
    branchDepositAmount
    depositStatus
    depositDeleted
      processedReceipts {
      id
      acceptanceStatus
      rejectedBy
      rejectedUserId
      rejectedDate
      rejectedTime
      rejectedRemarks
      branchDepositSlipno
      totalAmount
    }
  }
}
`;

export const CREATE_DEPOSIT = `
  mutation CreateDeposit($input: CreateDepositInput!) {
    createDeposit(input: $input) {
      id
      depositSlipNo
      message
    }
  }
`;






export const GET_COLL_RECEIPT_BY_ID = `
  query GetCollReceiptById($id: ID!) {
    getCollReceiptById(id: $id) {
      lanNumber
      receivedSumInWords
      collectedBounceAmount
      branchName
      totalAmount
      customerName
      collectedEmiAmount
      emiOverdueAmount
      paymentType
      collectedPenaltyAmount
      receiptdate
      receiptNo
      receiptGenerationTime
      remarks
      transactionRefNo
      collectedBy
      serviceChargeType {
        name
      }
    }
  }
`;

export const LINK_USER_TO_ACCOUNT = `
mutation LinkUserToAccount($accountId: String!, $userId: String!) {
  linkUserToAccount(accountId: $accountId, userId: $userId) {
    id
    name
    lanNumber
    applicationNumber
    customerId
    coapplicantPhoneNumber
    emailAddress
    dateEntered
    dateModified
    createdBy
    deleted
    rmName
    product
    customerGender
    loanAmount
    customerAddress
    billingAddressPostalcode
    customerPhoneNumber
    propertyAddress
    coapplicantAddress
    propertyValue
    coapplicantGender
    buyOutOwn
    latitude
    longitude
    branch
    bdmName
    dataBy
    location
    disbursementStatus
    nextDueDate
    propertyType
    userId
    coApplicantName
    customerLatitude
    customerLongitude
    coapplicantLatitude
    coapplicantLongitude
    propertyLatitude
    propertyLongitude
    emiOverdue
    bounceCharge
    penalCharges
    emiAmount
    dpd
    previousUserId
    reassignedOn

    securityGroups {
      id
      dateEntered
      dateModified
      modifiedUserId
      createdBy
      name
      description
      deleted
      inheritable
      stateMaster {
        id
        stateName
        dateEntered
        dateModified
        deleted
      }
    }
  }
}
`;
