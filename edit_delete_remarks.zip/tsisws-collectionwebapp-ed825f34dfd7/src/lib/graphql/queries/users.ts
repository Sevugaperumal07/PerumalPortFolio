export const GET_USERS = `
  query GetUsers {
    getUsers {
      id
      userName
      email
      firstName
      lastName
      status
      userType
      employeeCode
      phoneMobile
      phoneWork
      department
      title
      dateEntered
      dateModified
      deleted
    }
  }
`;

// Query to get roles for a user
// Note: getRolesByUserId expects ID! type
export const GET_ROLES_BY_USER_ID = `
  query GetRolesByUserId($userId: ID!) {
    getRolesByUserId(userId: $userId) {
      id
      name
      description
    }
  }
`;

// Query to get security groups for a user
export const GET_SECURITY_GROUPS_BY_USER_ID = `
  query GetSecurityGroupsByUserId($userId: String!) {
    getSecurityGroupsByUserId(userId: $userId) {
      securityGroups {
        id
        name
        description
        stateMaster {
          stateName
        }
        user {
          id
          userName
          firstName
          lastName
          userType
        }
      }
    }
  }
`;

export const GET_USER_BY_ID = `
  query GetUserById($id: ID!) {
    getUserById(id: $id) {
      id
      userName
      userHash
      email
      firstName
      lastName
      isAdmin
      externalAuthOnly
      receiveNotifications
      description
      dateEntered
      dateModified
      modifiedUserId
      createdBy
      title
      photo
      department
      phoneHome
      phoneMobile
      phoneWork
      phoneOther
      phoneFax
      status
      addressStreet
      addressCity
      addressState
      addressCountry
      addressPostalcode
      deleted
      portalOnly
      showOnEmployees
      employeeStatus
      reportsToId
      userType
      agentType
      employeeCode
      reportingManager
      reportingManagerEmployeeCode
      supervisor
      supervisorEmail
    }
  }
`;

export const GET_USER_BY_EMAIL = `
  query GetUserByEmail($email: String!) {
    getUserByEmail(email: $email) {
      id
      userName
      userHash
      email
      firstName
      lastName
      isAdmin
      externalAuthOnly
      receiveNotifications
      description
      dateEntered
      dateModified
      modifiedUserId
      createdBy
      title
      photo
      department
      phoneHome
      phoneMobile
      phoneWork
      phoneOther
      phoneFax
      status
      addressStreet
      addressCity
      addressState
      addressCountry
      addressPostalcode
      deleted
      portalOnly
      showOnEmployees
      employeeStatus
      reportsToId
      userType
      agentType
      employeeCode
      reportingManager
      reportingManagerEmployeeCode
      supervisor
      supervisorEmail
    }
  }
`;

export const GET_CASES_BY_USER_ID = `
  query GetCasesByUserId($id: ID!) {
    getCasesByUserId(id: $id) {
      id
    }
  }
`;

