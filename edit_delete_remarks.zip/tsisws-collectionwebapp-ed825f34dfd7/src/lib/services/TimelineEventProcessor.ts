import { format } from "date-fns"
import { fetchAgentLocationRecords } from "./agent-tracker"
import { graphqlRequest } from "@/lib/graphql/client"
import { GET_CASE_BY_ID, GET_CHECK_IN_OUT_BY_USER_ID, GET_CASES_DISPOSITION_BY_USER_ID, GET_ACCOUNTS_BY_CASE_ID } from "@/lib/graphql/queries/agent-tracker"

export type TimelineEvent = {
    type: "checkin" | "checkout" | "halt" | "collection" | "movement"
    startTime: string
    endTime?: string
    duration?: number
    lat: number
    lon: number
    meta?: any
    collectionMarkerColor?: "green" | "red"
}

type CheckInOutRecord = {
    id?: string | null
    checkInDateTime?: string | null
    checkOutDateTime?: string | null
    durationInSeconds?: number | string | null
    hiveId?: string | null
    checkInLatitude?: number | string | null
    checkInLongitude?: number | string | null
    checkInBatteryPercentage?: number | string | null
    checkoutLatitude?: number | string | null
    checkoutLongitude?: number | string | null
    checkoutBatteryPercentage?: number | string | null
    dateEntered?: string | null
    dateModified?: string | null
}

type CasesDispositionRecord = {
    id?: string | null
    activityDate?: string | null
    activityName?: string | null
    remarks?: string | null
    hiveId?: string | null
    amountCollected?: number | string | null
    ptpAmount?: number | string | null
    contactName?: string | null
    contactNumber?: string | null
    paymentType?: string | null
    paymentAttachment?: string | null
    latitude?: number | string | null
    longitude?: number | string | null
    batteryPercentage?: number | string | null
    userId?: string | null
    casesId?: string | null
    dateEntered?: string | null
    dateModified?: string | null
    deleted?: boolean | null
}

// Calculate distance between two coordinates in meters
export function calculateDistanceMeters(
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
): number {
    const R = 6371000 // Earth radius in meters
    const dLat = toRadians(lat2 - lat1)
    const dLon = toRadians(lon2 - lon1)
    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(toRadians(lat1)) *
            Math.cos(toRadians(lat2)) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
}

const toRadians = (degrees: number): number => (degrees * Math.PI) / 180

// Calculate duration in seconds between two dates
export function calculateDurationSeconds(start: Date, end: Date): number {
    return Math.floor((end.getTime() - start.getTime()) / 1000)
}

// Format timestamp to HH:mm AM/PM
export function formatTime(date: Date): string {
    return format(date, "hh:mm a")
}

// Check if two dates are on the same day
function isSameDay(date1: Date, date2: Date): boolean {
    return (
        date1.getFullYear() === date2.getFullYear() &&
        date1.getMonth() === date2.getMonth() &&
        date1.getDate() === date2.getDate()
    )
}

// Parse date string (yyyy-MM-dd) to Date object
function parseDateString(dateStr: string): Date | null {
    const parsed = new Date(dateStr + "T00:00:00")
    if (isNaN(parsed.getTime())) return null
    return parsed
}

// Parse date string to Date object
function parseDate(value: unknown): Date | null {
    if (!value) return null
    if (value instanceof Date) return value
    if (typeof value === "string") {
        const parsed = new Date(value)
        if (!isNaN(parsed.getTime())) return parsed
    }
    if (typeof value === "number") {
        const parsed = new Date(value)
        if (!isNaN(parsed.getTime())) return parsed
    }
    return null
}

// Convert to number
function toNumber(value: unknown): number | null {
    if (typeof value === "number" && !isNaN(value)) return value
    if (typeof value === "string") {
        const parsed = parseFloat(value)
        if (!isNaN(parsed)) return parsed
    }
    return null
}

async function fetchCaseNumberMap(caseIds: Array<string | null | undefined>): Promise<Map<string, string>> {
    const map = new Map<string, string>()
    const uniqueIds = Array.from(new Set(caseIds.filter((id): id is string => Boolean(id))))

    if (uniqueIds.length === 0) return map

    const results = await Promise.allSettled(
        uniqueIds.map((id) =>
            graphqlRequest<{ getCaseById: { caseNumber?: string | null } }>(GET_CASE_BY_ID, { id })
        )
    )

    results.forEach((result, index) => {
        const id = uniqueIds[index]
        if (result.status === "fulfilled") {
            const response = result.value as any
            const caseData = response?.data?.getCaseById || response?.getCaseById
            const caseNumber = caseData?.caseNumber
            if (caseNumber) {
                map.set(id, caseNumber)
            }
        } else {
            console.error(`Failed to fetch case ${id}:`, result.reason)
        }
    })

    return map
}

type AccountData = {
    propertyLatitude?: number | string | null
    propertyLongitude?: number | string | null
    customerLatitude?: number | string | null
    customerLongitude?: number | string | null
}

async function fetchAccountByCaseId(caseId: string | null | undefined): Promise<AccountData | null> {
    if (!caseId) return null

    try {
        const response = await graphqlRequest<{ getAccountsByCaseId: AccountData | null }>(
            GET_ACCOUNTS_BY_CASE_ID,
            { id: caseId }
        )
        const accountData = response?.getAccountsByCaseId || (response as any)?.getAccountsByCaseId
        return accountData || null
    } catch (error) {
        console.error(`Failed to fetch account for case ${caseId}:`, error)
        return null
    }
}

// Calculate marker color for collection event based on distance validation logic
async function calculateCollectionMarkerColor(
    activityLat: number,
    activityLon: number,
    caseId: string | null | undefined
): Promise<"green" | "red"> {
    const THRESHOLD_DISTANCE_KM = 1.5
    const THRESHOLD_DISTANCE_METERS = THRESHOLD_DISTANCE_KM * 1000

    if (!caseId) {
        return "red" 
    }

    const accountData = await fetchAccountByCaseId(caseId)
    if (!accountData) {
        return "red" 
    }

    const propertyLat = toNumber(accountData.propertyLatitude)
    const propertyLon = toNumber(accountData.propertyLongitude)

    if (propertyLat !== null && propertyLon !== null) {
        const distanceToProperty = calculateDistanceMeters(
            activityLat,
            activityLon,
            propertyLat,
            propertyLon
        )

        if (distanceToProperty <= THRESHOLD_DISTANCE_METERS) {
            return "green" 
        }
    }

    const customerLat = toNumber(accountData.customerLatitude)
    const customerLon = toNumber(accountData.customerLongitude)

    if (customerLat !== null && customerLon !== null) {
        const distanceToCustomer = calculateDistanceMeters(
            activityLat,
            activityLon,
            customerLat,
            customerLon
        )

        if (distanceToCustomer <= THRESHOLD_DISTANCE_METERS) {
            return "green" 
        }
    }

    return "red"
}

// Detect halt events: GPS points that stay within 40m for ≥ 20 minutes
function detectHalts(gpsPoints: Array<{ lat: number; lon: number; timestamp: Date; batteryPercentage?: number | null }>): TimelineEvent[] {
    const halts: TimelineEvent[] = []
    const HALT_RADIUS_METERS = 40
    const HALT_MIN_DURATION_SECONDS = 20 * 60 // 20 minutes

    let i = 0
    while (i < gpsPoints.length) {
        const startPoint = gpsPoints[i]
        const startTime = startPoint.timestamp
        let endTime = startTime
        let j = i + 1
        const haltPoints: Array<{ batteryPercentage?: number | null }> = [startPoint]

        // Find consecutive points within the halt radius
        while (j < gpsPoints.length) {
            const currentPoint = gpsPoints[j]
            const distance = calculateDistanceMeters(
                startPoint.lat,
                startPoint.lon,
                currentPoint.lat,
                currentPoint.lon
            )

            if (distance <= HALT_RADIUS_METERS) {
                endTime = currentPoint.timestamp
                haltPoints.push(currentPoint)
                j++
            } else {
                break
            }
        }

        // Check if duration meets minimum requirement
        const duration = calculateDurationSeconds(startTime, endTime)
        if (duration >= HALT_MIN_DURATION_SECONDS) {
            // Calculate average battery percentage from all points in the halt
            const batteryValues = haltPoints
                .map(p => p.batteryPercentage)
                .filter((b): b is number => typeof b === "number" && !isNaN(b))
            const avgBattery = batteryValues.length > 0
                ? Math.round(batteryValues.reduce((sum, b) => sum + b, 0) / batteryValues.length)
                : null

            halts.push({
                type: "halt",
                startTime: formatTime(startTime),
                endTime: formatTime(endTime),
                duration,
                lat: startPoint.lat,
                lon: startPoint.lon,
                meta: {
                    originalStart: startTime,
                    originalEnd: endTime,
                    batteryPercentage: avgBattery,
                },
            })
            i = j // Skip points that were part of this halt
        } else {
            i++
        }
    }

    return halts
}

// Group GPS points during a Collection into one event
function groupCollectionPoints(
    gpsPoints: Array<{ lat: number; lon: number; timestamp: Date; caseId?: string | null; batteryPercentage?: number | null }>,
    collections: Array<{
        casesId?: string | null
        timestamp: Date
        lat: number
        lon: number
        meta?: any
    }>
): TimelineEvent[] {
    const collectionEvents: TimelineEvent[] = []

    for (const collection of collections) {
        // Find GPS points that match this collection (by caseId or time proximity)
        const matchingPoints = gpsPoints.filter((point) => {
            if (collection.casesId && point.caseId === collection.casesId) {
                return true
            }
            // If no caseId match, check if point is within 5 minutes of collection time
            const timeDiff = Math.abs(point.timestamp.getTime() - collection.timestamp.getTime())
            const distance = calculateDistanceMeters(collection.lat, collection.lon, point.lat, point.lon)
            return timeDiff <= 5 * 60 * 1000 && distance <= 100 // 5 minutes and 100m
        })

        if (matchingPoints.length > 0) {
            const startTime = matchingPoints[0].timestamp
            const endTime = matchingPoints[matchingPoints.length - 1].timestamp
            const duration = calculateDurationSeconds(startTime, endTime)

            // Use collection coordinates or average of GPS points
            const avgLat =
                matchingPoints.reduce((sum, p) => sum + p.lat, 0) / matchingPoints.length
            const avgLon =
                matchingPoints.reduce((sum, p) => sum + p.lon, 0) / matchingPoints.length

            collectionEvents.push({
                type: "collection",
                startTime: formatTime(startTime),
                endTime: formatTime(endTime),
                duration,
                lat: collection.lat || avgLat,
                lon: collection.lon || avgLon,
                meta: {
                    ...collection.meta,
                    originalStart: startTime,
                    originalEnd: endTime,
                    gpsPointsCount: matchingPoints.length,
                },
            })
        } else {
            // If no matching GPS points, add collection as standalone event
            collectionEvents.push({
                type: "collection",
                startTime: formatTime(collection.timestamp),
                lat: collection.lat,
                lon: collection.lon,
                meta: {
                    ...collection.meta,
                    originalTimestamp: collection.timestamp,
                },
            })
        }
    }

    return collectionEvents
}

// Fetch all data in parallel and process
export async function processTimelineEvents(
    agentId: string,
    date: string
): Promise<TimelineEvent[]> {
    try {
        // Fetch all 3 APIs in parallel
        const [gpsRecords, checkInOutResult, collectionsResult] = await Promise.allSettled([
            fetchAgentLocationRecords(agentId, date),
            graphqlRequest<{ getCheckInOutByUserId: CheckInOutRecord[] }>(
                GET_CHECK_IN_OUT_BY_USER_ID,
                { userId: agentId }
            ),
            graphqlRequest<{ getCasesDispositionByUserId: CasesDispositionRecord[] }>(
                GET_CASES_DISPOSITION_BY_USER_ID,
                { userId: agentId }
            ),
        ])

        const events: TimelineEvent[] = []

        // Process GPS Records
        const gpsPoints: Array<{ lat: number; lon: number; timestamp: Date; caseId?: string | null; batteryPercentage?: number | null }> = []
        if (gpsRecords.status === "fulfilled") {
            const records = gpsRecords.value || []
            for (const record of records) {
                const lat = toNumber(record.latitude)
                const lon = toNumber(record.longitude)
                const timestamp = parseDate(record.timestamp || record.localCaptureTimestamp)
                const batteryPercentage = toNumber(record.batteryPercentage)

                if (lat !== null && lon !== null && timestamp) {
                    gpsPoints.push({
                        lat,
                        lon,
                        timestamp,
                        caseId: record.caseId || null,
                        batteryPercentage: batteryPercentage,
                    })
                }
            }

            // Sort GPS points by timestamp
            gpsPoints.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())

            // Detect halt events
            const halts = detectHalts(gpsPoints)
            events.push(...halts)

            // Add movement points (for map path, will be filtered in UI)
            for (const point of gpsPoints) {
                // Skip if this point is part of a halt
                const isPartOfHalt = halts.some((halt) => {
                    const haltStart = halt.meta?.originalStart as Date
                    const haltEnd = halt.meta?.originalEnd as Date
                    return point.timestamp >= haltStart && point.timestamp <= haltEnd
                })

                if (!isPartOfHalt) {
                    events.push({
                        type: "movement",
                        startTime: formatTime(point.timestamp),
                        lat: point.lat,
                        lon: point.lon,
                        meta: {
                            originalTimestamp: point.timestamp,
                            caseId: point.caseId,
                            batteryPercentage: point.batteryPercentage,
                        },
                    })
                }
            }
        }

        // Parse the target date for filtering
        const targetDate = parseDateString(date)

        // Process Check-In/Check-Out Records
        if (checkInOutResult.status === "fulfilled") {
            const records = checkInOutResult.value?.getCheckInOutByUserId || []
            for (const record of records) {
                // Check-In event
                const checkInTime = parseDate(record.checkInDateTime || record.dateEntered)
                const checkInLat = toNumber(record.checkInLatitude)
                const checkInLon = toNumber(record.checkInLongitude)

                if (
                    checkInTime &&
                    checkInLat !== null &&
                    checkInLon !== null &&
                    (!targetDate || isSameDay(checkInTime, targetDate))
                ) {
                    events.push({
                        type: "checkin",
                        startTime: formatTime(checkInTime),
                        lat: checkInLat,
                        lon: checkInLon,
                        meta: {
                            id: record.id,
                            hiveId: record.hiveId,
                            batteryPercentage: toNumber(record.checkInBatteryPercentage),
                            originalTimestamp: checkInTime,
                        },
                    })
                }

                // Check-Out event
                const checkOutTime = parseDate(record.checkOutDateTime || record.dateModified)
                const checkOutLat = toNumber(record.checkoutLatitude)
                const checkOutLon = toNumber(record.checkoutLongitude)

                if (
                    checkOutTime &&
                    checkOutLat !== null &&
                    checkOutLon !== null &&
                    (!targetDate || isSameDay(checkOutTime, targetDate))
                ) {
                    const duration = record.durationInSeconds
                        ? toNumber(record.durationInSeconds)
                        : undefined

                    events.push({
                        type: "checkout",
                        startTime: formatTime(checkOutTime),
                        duration: duration || undefined,
                        lat: checkOutLat,
                        lon: checkOutLon,
                        meta: {
                            id: record.id,
                            hiveId: record.hiveId,
                            batteryPercentage: toNumber(record.checkoutBatteryPercentage),
                            originalTimestamp: checkOutTime,
                        },
                    })
                }
            }
        }

        // Process Collection Records
        const collections: Array<{
            casesId?: string | null
            timestamp: Date
            lat: number
            lon: number
            meta?: any
        }> = []
        if (collectionsResult.status === "fulfilled") {
            const records = collectionsResult.value?.getCasesDispositionByUserId || []
            for (const record of records) {
                if (record.deleted) continue

                const timestamp = parseDate(record.activityDate || record.dateEntered || record.dateModified)
                const lat = toNumber(record.latitude)
                const lon = toNumber(record.longitude)

                if (
                    timestamp &&
                    lat !== null &&
                    lon !== null &&
                    (!targetDate || isSameDay(timestamp, targetDate))
                ) {
                    collections.push({
                        casesId: record.casesId || null,
                        timestamp,
                        lat,
                        lon,
                        meta: {
                            id: record.id,
                            casesId: record.casesId,
                            hiveId: record.hiveId,
                            activityName: record.activityName,
                            remarks: record.remarks,
                            amountCollected: toNumber(record.amountCollected),
                            ptpAmount: toNumber(record.ptpAmount),
                            contactName: record.contactName,
                            contactNumber: record.contactNumber,
                            paymentType: record.paymentType,
                            batteryPercentage: toNumber(record.batteryPercentage),
                        },
                    })
                }
            }
        }

        const caseNumberMap = await fetchCaseNumberMap(collections.map((collection) => collection.casesId))
        if (caseNumberMap.size > 0) {
            for (const collection of collections) {
                if (!collection.casesId) continue
                const caseNumber = caseNumberMap.get(collection.casesId)
                if (caseNumber) {
                    collection.meta = {
                        ...collection.meta,
                        caseNumber,
                    }
                }
            }
        }

        // Group GPS points during collections
        if (collections.length > 0) {
            const collectionEvents = groupCollectionPoints(gpsPoints, collections)
            
            // Calculate marker colors for collection events
            const collectionEventsWithColors = await Promise.all(
                collectionEvents.map(async (event) => {
                    if (event.type === "collection") {
                        const markerColor = await calculateCollectionMarkerColor(
                            event.lat,
                            event.lon,
                            event.meta?.casesId
                        )
                        return {
                            ...event,
                            collectionMarkerColor: markerColor,
                        }
                    }
                    return event
                })
            )
            
            events.push(...collectionEventsWithColors)
        }

        // Sort all events by timestamp
        events.sort((a, b) => {
            const timeA = (a.meta?.originalStart as Date) || (a.meta?.originalTimestamp as Date)
            const timeB = (b.meta?.originalStart as Date) || (b.meta?.originalTimestamp as Date)

            if (timeA && timeB) {
                return timeA.getTime() - timeB.getTime()
            }
            if (timeA) return -1
            if (timeB) return 1
            return 0
        })
        return events
    } catch (error) {
        console.error("Error processing timeline events:", error)
        throw error
    }
}
