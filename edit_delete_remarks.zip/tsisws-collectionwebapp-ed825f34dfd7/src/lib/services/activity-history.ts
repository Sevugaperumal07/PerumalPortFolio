import { graphqlRequest } from "../graphql/client";
import { GET_CASE_ACTIVITY_HISTORY, GET_CASE_AUDIT_RECEIPT_HISTORY } from "../graphql/queries/cases";
import type { CaseActivityHistory, GetCaseActivityHistoryResponse, GetAuditHistoryResponse, GetCaseAuditReceiptHistoryResponse } from "../types";

export async function getCaseActivityHistory(
    lanNumber: string,
    year: number,
    month?: number
): Promise<CaseActivityHistory[]> {
    try {
        const response = await graphqlRequest<GetCaseActivityHistoryResponse>(
            GET_CASE_ACTIVITY_HISTORY,
            { lanNumber, year, month }
        );

        if (response && response.getCaseActivityHistory) {
            return response.getCaseActivityHistory;
        }
        return [];
    } catch (error) {
        console.error("Error fetching case activity history:", error);
        return [];
    }
}


export async function getCaseAuditReceiptHistory(
    parentId: string,
    year: number,
    month: number,
    limit: number,
    offset: number,
    showSystem: boolean = false,
    entityType?: string
): Promise<GetAuditHistoryResponse['getAuditHistory'] | null> {
    try {
        const response = await graphqlRequest<GetCaseAuditReceiptHistoryResponse>(
            GET_CASE_AUDIT_RECEIPT_HISTORY,
            { parentId, year, month, limit, offset, showSystem, entityType }
        );

        if (response && response.getAuditHistory) {
            return response.getAuditHistory;
        }
        return null;
    } catch (error) {
        console.error("Error fetching case audit receipt history from mock/API:", error);
        return null;
    }
}