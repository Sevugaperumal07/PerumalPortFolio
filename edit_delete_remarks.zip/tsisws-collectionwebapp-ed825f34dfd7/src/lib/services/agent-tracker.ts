export type AgentDistanceResponse = Record<string, number>

export type AgentLocationRecord = {
  agentId?: string
  userId?: string
  latitude?: number
  longitude?: number
  timestamp?: string
  localCaptureTimestamp?: string
  batteryPercentage?: number
  caseId?: string | null
  id?: string
  version?: number
  [key: string]: unknown
}

import { apiFetch } from '../api/api-fetch';

// ========== API FUNCTIONS ==========
export async function fetchAgentDistanceRecords(
  agentId: string,
  date: string
): Promise<AgentDistanceResponse> {
  try {
    return await apiFetch<AgentDistanceResponse>('/api/locations/distance/by-date', {
      method: 'POST',
      body: JSON.stringify({ agentIds: [agentId], date }),
    });
  } catch (err) {
    console.error('Network error fetching distance:', err);
    return {};
  }
}

export async function fetchAgentLocationRecords(
  agentId: string,
  date: string
): Promise<AgentLocationRecord[]> {
  try {
    const data = await apiFetch<AgentLocationRecord[]>('/api/locations/records/by-date', {
      method: 'POST',
      body: JSON.stringify({ agentId, date }),
    });
    return Array.isArray(data) ? data : [];
  } catch (err) {
    console.error('Network error fetching locations:', err);
    return [];
  }
}
