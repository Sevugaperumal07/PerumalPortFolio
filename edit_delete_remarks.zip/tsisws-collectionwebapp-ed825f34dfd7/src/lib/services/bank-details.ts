import { graphqlRequest } from '../graphql/client';
import { GET_BANK_DETAILS_LIST } from '../graphql/queries/bank-details';
import { CREATE_BANK_DETAIL, UPDATE_BANK_DETAIL, DELETE_BANK_DETAIL } from '../graphql/mutations/bank-details';
import { LINK_BANK_DETAILS_TO_SECURITY_GROUP } from '../graphql/mutations/security-groups';
import type { BankDetail } from '../types';

export async function getBankDetails(): Promise<BankDetail[]> {
  const response = await graphqlRequest<{ getBankDetailsList: BankDetail[] }>(GET_BANK_DETAILS_LIST);

  if (response && typeof response === 'object' && 'getBankDetailsList' in response) {
    const banks = response.getBankDetailsList;

    if (Array.isArray(banks)) {
      return banks.filter(bank => !bank.deleted);
    }
  }

  throw new Error('Unexpected response format from getBankDetailsList query');
}

export async function createBankDetail(input: {
  bankName: string;
  accountNumber: string;
  branchName: string;
  ifscCode: string;
  hiveId: string;
  deleted?: boolean;
}): Promise<BankDetail> {
  try {
    const payload = {
      ...input,
      deleted: input.deleted ?? false,
    };
    const response = await graphqlRequest<{ createBankDetails: BankDetail | null }>(CREATE_BANK_DETAIL, { bankDetails: payload });

    if (response && typeof response === 'object' && 'createBankDetails' in response) {
      const bank = response.createBankDetails;

      if (bank === null || bank === undefined) {
        throw new Error('Failed to create bank detail. The backend returned null.');
      }

      if (bank && typeof bank === 'object') {
        if (!bank.id) {
          throw new Error('Failed to create bank detail. Server did not return a valid ID.');
        }

        if (!bank.bankName || !bank.accountNumber) {
          throw new Error('Failed to create bank detail. Server returned incomplete data.');
        }

        return bank;
      }
    }

    throw new Error('Server returned unexpected response format.');
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('required') || error.message.includes('non-null')) {
        throw new Error('All fields are required. Please fill in Branch Name, IFSC Code, and Hive ID.');
      }
      if (error.message.includes('fetch') || error.message.includes('network')) {
        throw new Error('Network error. Please check your connection and try again.');
      }
      throw error;
    }
    throw new Error('Failed to create bank detail. Please try again.');
  }
}

export async function updateBankDetail(id: string, input: {
  bankName: string;
  accountNumber: string;
  branchName: string;
  ifscCode: string;
  hiveId: string;
}): Promise<BankDetail> {
  try {
    const response = await graphqlRequest<{ updateBankDetailsFieldById: BankDetail | null }>(UPDATE_BANK_DETAIL, { id, bankDetails: input });

    if (response && typeof response === 'object' && 'updateBankDetailsFieldById' in response) {
      const bank = response.updateBankDetailsFieldById;

      if (bank === null || bank === undefined) {
        throw new Error(`Failed to update bank detail. The record with ID "${id}" may not exist or you don't have permission to update it.`);
      }

      if (bank && typeof bank === 'object') {
        if (!bank.id) {
          throw new Error('Update succeeded but server did not return a valid ID.');
        }
        return bank;
      }
    }

    throw new Error('Unexpected response format from updateBankDetailsFieldById mutation');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to update bank detail. Please try again.');
  }
}

export async function deleteBankDetail(id: string): Promise<string> {
  try {
    const response = await graphqlRequest<{ deleteBankDetails: string | null }>(DELETE_BANK_DETAIL, { id });

    if (response && typeof response === 'object' && 'deleteBankDetails' in response) {
      const result = response.deleteBankDetails;

      if (result === null || result === undefined) {
        throw new Error(`Failed to delete bank detail. The record with ID "${id}" may not exist or you don't have permission to delete it.`);
      }
      return result;
    }

    throw new Error('Unexpected response format from deleteBankDetails mutation');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to delete bank detail. Please try again.');
  }
}


export async function linkBankDetailsToSecurityGroup(bankDetailsId: string, securityGroupId: string): Promise<any> {
  try {
    const response = await graphqlRequest(LINK_BANK_DETAILS_TO_SECURITY_GROUP, {
      bankDetailsId,
      securityGroupId,
    });
    return response;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to link bank detail to security group.');
  }
}
