import { graphqlRequest } from "../graphql/client";
import {
  GET_ACCOUNTS, GET_ACCOUNTS_PAGINATED, GET_ACCOUNT_BY_ID,
  GET_ACCOUNT_CONTACTS_BY_ACCOUNT_ID,
  GET_ACCOUNT_ADDRESSES_BY_ACCOUNT_ID
} from "../graphql/queries/cases";
import { CREATE_ACCOUNT_CONTACT, CREATE_ACCOUNT_ADDRESS_MANAGEMENT } from "../graphql/mutations/cases";
import type {
  Account, Case, PaginatedResponse,
  AccountContact,
  AccountContactInput,
  AccountAddressManagement,
  AccountAddressManagementInput,
  AdvancedFilterParamsCases
} from "../types";
import { generateUUID } from "../utils";


function toNumber(value: unknown): number | undefined {
  if (value === null || value === undefined) return undefined;
  const num = typeof value === "number" ? value : Number(value);
  return Number.isFinite(num) ? num : undefined;
}

function normalizeAccount(account: Account): Account {
  return {
    ...account,
    loanAmount: toNumber((account as unknown as Record<string, unknown>).loanAmount) ?? account.loanAmount,
    emiOverdue: toNumber((account as unknown as Record<string, unknown>).emiOverdue) ?? account.emiOverdue,
    bounceCharge: toNumber((account as unknown as Record<string, unknown>).bounceCharge) ?? account.bounceCharge,
    penalCharges: toNumber((account as unknown as Record<string, unknown>).penalCharges) ?? account.penalCharges,
    emiAmount: toNumber((account as unknown as Record<string, unknown>).emiAmount) ?? account.emiAmount,
    dpd: toNumber((account as unknown as Record<string, unknown>).dpd) ?? account.dpd,
    latitude: toNumber((account as unknown as Record<string, unknown>).latitude) ?? account.latitude,
    longitude: toNumber((account as unknown as Record<string, unknown>).longitude) ?? account.longitude,
    customerLatitude: toNumber((account as unknown as Record<string, unknown>).customerLatitude) ?? account.customerLatitude,
    customerLongitude: toNumber((account as unknown as Record<string, unknown>).customerLongitude) ?? account.customerLongitude,
    coapplicantLatitude: toNumber((account as unknown as Record<string, unknown>).coapplicantLatitude) ?? account.coapplicantLatitude,
    coapplicantLongitude: toNumber((account as unknown as Record<string, unknown>).coapplicantLongitude) ?? account.coapplicantLongitude,
    propertyLatitude: toNumber((account as unknown as Record<string, unknown>).propertyLatitude) ?? account.propertyLatitude,
    propertyLongitude: toNumber((account as unknown as Record<string, unknown>).propertyLongitude) ?? account.propertyLongitude,
    propertyValue: toNumber((account as unknown as Record<string, unknown>).propertyValue) ?? account.propertyValue,
    securityGroups: account.securityGroups,
  };
}

function transformAccountToCase(account: Account): Case {
  const normalizedAccount = normalizeAccount(account);
  const fallbackId =
    normalizedAccount.id ||
    normalizedAccount.customerId ||
    normalizedAccount.applicationNumber ||
    normalizedAccount.lanNumber ||
    generateUUID('account');

  return {
    id: fallbackId,
    isAccountOnly: true,
    accountId: account.id,
    caseNumber: normalizedAccount.lanNumber,
    account: normalizedAccount,
    nextActionDate: normalizedAccount.nextDueDate,
    status: normalizedAccount.disbursementStatus,
    emiOverdue: normalizedAccount.emiOverdue,
    bounceCharge: normalizedAccount.bounceCharge,
    penalCharges: normalizedAccount.penalCharges,
    emiAmount: normalizedAccount.emiAmount,
    dpd: normalizedAccount.dpd,
    userId: normalizedAccount.userId,
    securityGroups: normalizedAccount.securityGroups,
    agentName: normalizedAccount.user?.userName,
  };
}

export async function getAccountsAsCases(): Promise<Case[]> {
  const response = await graphqlRequest<{ getAccounts: Account[] }>(GET_ACCOUNTS);

  if (response && typeof response === "object" && "getAccounts" in response) {
    const accounts = response.getAccounts;
    if (Array.isArray(accounts)) {
      return accounts
        .filter((account) => !account?.deleted)
        .map(transformAccountToCase);
    }
  }

  return [];
}

export async function getAccountsAsCasesPaginated(
  limit?: number,
  offset?: number,
  searchFilter?: string,
  filters?: AdvancedFilterParamsCases
): Promise<{
  cases: Case[];
  totalElements: number;
  totalPages: number;
  pageNumber: number;
  first: boolean;
  last: boolean;
}> {
  try {
    const response = await graphqlRequest<{ getAccountsByReportingManagerPaginated: PaginatedResponse<Account> }>(
      GET_ACCOUNTS_PAGINATED,
      {
        limit,
        offset,
        searchFilter,
        lanNumber: filters?.lan || undefined,
        state: filters?.state || undefined,
        branch: filters?.branch || undefined,
        agentName: filters?.agent || undefined,
      }
    );

    if (
      response &&
      typeof response === "object" &&
      "getAccountsByReportingManagerPaginated" in response
    ) {
      const paginatedData = response.getAccountsByReportingManagerPaginated;

      if (paginatedData && Array.isArray(paginatedData.content)) {
        const cases = paginatedData.content
          .filter((account) => !account?.deleted)
          .map(transformAccountToCase);

        return {
          cases,
          totalElements: paginatedData.totalElements || 0,
          totalPages: paginatedData.totalPages || 0,
          pageNumber: paginatedData.pageNumber || 0,
          first: paginatedData.first || false,
          last: paginatedData.last || false,
        };
      }
    }

    return {
      cases: [],
      totalElements: 0,
      totalPages: 0,
      pageNumber: 0,
      first: true,
      last: true,
    };
  } catch (error) {
    console.error("Error fetching accounts:", error);
    throw error;
  }
}


export async function getAccountAsCaseById(id: string): Promise<Case | null> {
  if (!id) {
    return null;
  }

  const response = await graphqlRequest<{ getAccountById: Account }>(
    GET_ACCOUNT_BY_ID,
    { id },
  );

  if (response && typeof response === "object" && "getAccountById" in response) {
    const account = response.getAccountById;
    if (account && !account.deleted) {
      return transformAccountToCase(account);
    }
  }
  return null;
}

export async function getAccountContactsByAccountId(id: string): Promise<AccountContact[]> {
  try {
    const response = await graphqlRequest<{ getAccountContactsByAccountId: AccountContact[] }>(
      GET_ACCOUNT_CONTACTS_BY_ACCOUNT_ID,
      { accountId: id }
    );
    return response?.getAccountContactsByAccountId || [];
  } catch (error) {
    console.error("Error fetching account contacts:", error);
    return [];
  }
}

export async function getAccountAddressesByAccountId(id: string): Promise<AccountAddressManagement[]> {
  try {
    const response = await graphqlRequest<{ getAccountAddressManagementByAccountId: AccountAddressManagement[] }>(
      GET_ACCOUNT_ADDRESSES_BY_ACCOUNT_ID,
      { id }
    );
    return response?.getAccountAddressManagementByAccountId || [];
  } catch (error) {
    console.error("Error fetching account addresses:", error);
    return [];
  }
}

export async function createAccountContact(input: AccountContactInput): Promise<AccountContact | null> {
  try {
    const response = await graphqlRequest<{ createAccountContact: AccountContact }>(
      CREATE_ACCOUNT_CONTACT,
      { accountContact: input }
    );
    return response?.createAccountContact || null;
  } catch (error) {
    console.error("Error creating account contact:", error);
    throw error;
  }
}
export async function createAccountAddressManagement(input: AccountAddressManagementInput): Promise<AccountAddressManagement | null> {
  try {
    const response = await graphqlRequest<{ createAccountAddressManagement: AccountAddressManagement }>(
      CREATE_ACCOUNT_ADDRESS_MANAGEMENT,
      { accountAddressManagement: input }
    );
    return response?.createAccountAddressManagement || null;
  } catch (error) {
    console.error("Error creating account address:", error);
    throw error;
  }
}
