import { graphqlRequest } from '../graphql/client';
import {
  GET_COLL_DEPOSIT_BY_ID,
  GET_BANK_NAMES,
  UPDATE_COLL_DEPOSIT_FIELD_BY_ID,
  DEPOSIT_SEARCH_QUERY_DYNAMIC,
  PROCESS_BANK_DEPOSIT_SLIP_VERIFICATION
} from '../graphql/queries/deposits';
import type { Deposit, SearchDepositResponse, DepositDateType, VerificationType, ProcessBankDepositSlipVerificationResponse, ProcessBankDepositSlipVerificationResult } from '../types';

export async function updateCollDepositField(
  id: string,
  collDeposit?: any,
  adjustDepositSlip?: any
): Promise<any> {
  const variables: any = { id };
  const mutationArgs: string[] = [];
  const inputFields: string[] = [];

  if (collDeposit) {
    variables.collDeposit = collDeposit;
    mutationArgs.push("$collDeposit: CollDepositSlipInput");
    inputFields.push("collDeposit: $collDeposit");
  }

  if (adjustDepositSlip) {
    variables.adjustDepositSlip = adjustDepositSlip;
    mutationArgs.push("$adjustDepositSlip: AdjustDepositSlipInput");
    inputFields.push("adjustDepositSlip: $adjustDepositSlip");
  }

  const mutationArgsStr = mutationArgs.length ? `, ${mutationArgs.join(", ")}` : "";
  const inputFieldsStr = inputFields.length ? `\n      ${inputFields.join("\n      ")}` : "";

  const response = await graphqlRequest<any>(
    UPDATE_COLL_DEPOSIT_FIELD_BY_ID(mutationArgsStr, inputFieldsStr),
    variables
  );
  return response?.updateCollDepositFieldById;
}

export async function getCollDepositById(id: string): Promise<Deposit | null> {
  if (!id) {
    throw new Error('Deposit ID is required');
  }

  const variables = { id };
  const response = await graphqlRequest<{
    getCollDepositById: Deposit | null
  }>(GET_COLL_DEPOSIT_BY_ID, variables);

  if (response && typeof response === 'object' && 'getCollDepositById' in response) {
    const deposit = response.getCollDepositById;
    if (deposit) {
      return deposit;
    }
  }

  return null;
}

export async function searchDepositsPaginated(
  typeOfDeposit: string,
  receiptPaymentType: string,
  depositStatus: string,
  limit: number,
  offset: number,
  query: string = "",
  sortBy: string = "DEPOSITED_AMOUNT",
  sortDir: string = "ASC",
  fromDate?: string,
  toDate?: string,
  dateType?: DepositDateType,
  depositSlipNo?: string,
  bankName?: string
): Promise<SearchDepositResponse> {
  const variables: any = {
    typeOfDeposit,
    receiptPaymentType,
    depositStatus,
    limit,
    offset,
    query,
    sortBy,
    sortDir,
  };

  const dynamicArgs: string[] = [];
  const dynamicInput: string[] = [];

  if (fromDate) {
    variables.fromDate = fromDate;
    dynamicArgs.push("$fromDate: String");
    dynamicInput.push("fromDate: $fromDate");
  }
  if (toDate) {
    variables.toDate = toDate;
    dynamicArgs.push("$toDate: String");
    dynamicInput.push("toDate: $toDate");
  }
  if (depositSlipNo) {
    variables.depositSlipNo = depositSlipNo;
    dynamicArgs.push("$depositSlipNo: String");
    dynamicInput.push("depositSlipNo: $depositSlipNo");
  }
  if (dateType) {
    variables.dateType = dateType;
    dynamicArgs.push("$dateType: DepositDateType");
    dynamicInput.push("dateType: $dateType");
  }
  if (bankName) {
    variables.bankName = bankName;
    dynamicArgs.push("$bankName: String");
    dynamicInput.push("bankName: $bankName");
  }

  const queryArgs = dynamicArgs.length ? `, ${dynamicArgs.join(", ")}` : "";
  const inputFields = dynamicInput.length ? `, ${dynamicInput.join(", ")}` : "";

  const response = await graphqlRequest<{ search: SearchDepositResponse }>(
    DEPOSIT_SEARCH_QUERY_DYNAMIC(queryArgs, inputFields),
    variables
  );

  if (response && typeof response === 'object' && 'search' in response) {
    return response.search;
  }

  return {
    totalRecords: 0,
    totalPages: 0,
    currentPage: 0,
    size: 0,
    numberOfRecords: 0,
    hasNext: false,
    hasPrevious: false,
    content: []
  };
}

export async function getBankNames(): Promise<string[]> {
  const response = await graphqlRequest<{ getBankNames: string[] }>(GET_BANK_NAMES);

  if (response?.getBankNames && Array.isArray(response.getBankNames)) {
    return Array.from(new Set(response.getBankNames))
      .filter((name): name is string => typeof name === 'string' && name.trim() !== "")
      .sort();
  }

  return [];
}

export async function processBankDepositSlipVerification(
  collDepositSlipIds: string[],
  decision: VerificationType,
  remarks?: string,
  date?: string,
  time?: string
): Promise<ProcessBankDepositSlipVerificationResult> {
  const variables = {
    collDepositSlipIds,
    decision,
    remarks,
    date,
    time
  };

  const response = await graphqlRequest<ProcessBankDepositSlipVerificationResponse>(
    PROCESS_BANK_DEPOSIT_SLIP_VERIFICATION,
    variables
  );

  return response.processBankDepositSlipVerification;
}
