import { restClient } from '../api/client';

export interface ExportCasesPayload {
    clientType: "WEB";
    state?: string;
    branchName?: string;
    acceptanceStatus?: string;
    query?: string;
    lanNumber?: string;
    receiptNo?: string;
    agentName?: string;
    status?: string;
    fromDate?: string;
    toDate?: string;
    dateType?: string;
    dpdFrom?: number;
    dpdTo?: number;
    emiPendingBucket?: string;
    disposition?: string;
}

export async function exportCasesRest(payload: ExportCasesPayload, signal?: AbortSignal): Promise<Blob> {
    const cleanPayload = Object.entries(payload).reduce((acc, [key, value]) => {
        if (value !== undefined && value !== "" && value !== null) {
            acc[key as keyof ExportCasesPayload] = value as any;
        }
        return acc;
    }, {} as Partial<ExportCasesPayload>);

    return restClient<Blob>('/cases/export', {
        method: 'POST',
        body: JSON.stringify({
            ...cleanPayload,
            clientType: payload.clientType || "WEB"
        }),
        responseType: 'blob',
        signal,
    });
}

export async function exportBankDepositDetails(signal?: AbortSignal): Promise<Blob> {
    return restClient<Blob>('/api/lms-reverse-feed/export', {
        method: 'GET',
        responseType: 'blob',
        signal,
    });
}
