import { restClient } from '../api/client';

export async function importExcelRest(file: File) {
  const formData = new FormData();
  formData.append('file', file);
  
  return restClient<string>('/api/lms-reverse-feed/import', {
    method: 'POST',
    body: formData,
    responseType: 'text',
  });
}