// Notes Service - for creating task/case notes

import type {
  NoteSearchCriteriaParams,
  PaginatedNotesResponse,
  NoteFromCriteriaAPI,
} from "@/lib/types";

export type { NoteFromCriteriaAPI, PaginatedNotesResponse };

export interface CreateNoteRequest {
  noteTypeId: number; // 1 = CASE, 2 = TASK
  content: string;
  criticality: number;
  loanNumber: string;
  caseId: string; // For Task notes, pass Task ID here
  authorUserId: string;
  authorRole: string;
  authorName?: string;
  authorBranchId?: string;
  authorBranchCode?: string;
}

export interface Note {
  id: string;
  noteTypeId: number;
  content: string;
  criticality: number;
  loanNumber?: string;
  caseId?: string;
  authorUserId: string;
  authorRole?: string;
  authorName?: string;
  createdAt: string;
  updatedAt?: string;
  recipients?: Array<{
    recipientUserId: string;
  }>;
  associations?: Array<unknown>;
}

import { config } from "@/config";
import { apiFetch } from "../api/api-fetch";


/**
 * Create a note (Case or Task)
 * For Task notes: noteTypeId = 2, pass Task ID in caseId field
 * For Case notes: noteTypeId = 1, pass Case ID in caseId field
 */
export async function createNote(request: CreateNoteRequest): Promise<Note> {
  const noteTypeName = request.noteTypeId === 1 ? "CASE" : request.noteTypeId === 2 ? "TASK" : "UNKNOWN";

  const requestBody = {
    noteTypeId: request.noteTypeId,
    content: request.content,
    criticality: request.criticality,
    loanNumber: request.loanNumber,
    caseId: request.caseId,
    authorUserId: request.authorUserId,
    authorRole: request.authorRole,
    authorName: request.authorName,
    authorBranchId: request.authorBranchId,
    authorBranchCode: request.authorBranchCode,
  };

  return apiFetch<Note>("/api/v1/notes", {
    method: "POST",
    baseUrl: config.api.notesUrl,
    headers: {
      "X-User-Id": request.authorUserId,
    },
    body: JSON.stringify(requestBody),
  }).catch((err) => {
    console.error("[NotesService] ERROR - Note Type was:", noteTypeName, "(noteTypeId:", request.noteTypeId, ")");
    console.error("[NotesService] ERROR - caseId field contained:", request.caseId);
    throw err;
  });
}

/**
 * Create a Task note
 * Convenience wrapper for createNote with noteTypeId = 2
 */
export async function createTaskNote(
  taskId: string,
  content: string,
  loanNumber: string,
  authorUserId: string,
  authorRole: string,
  authorName?: string
): Promise<Note> {
  return createNote({
    noteTypeId: 2, // TASK
    content,
    criticality: 1, // Normal
    loanNumber,
    caseId: taskId, // Task ID goes in caseId field
    authorUserId,
    authorRole,
    authorName,
  });
}

/**
 * Create a Case note
 * Convenience wrapper for createNote with noteTypeId = 1
 */
export async function createCaseNote(
  caseId: string,
  content: string,
  loanNumber: string,
  authorUserId: string,
  authorRole: string,
  authorName?: string
): Promise<Note> {
  return createNote({
    noteTypeId: 1, // CASE
    content,
    criticality: 1, // Normal
    loanNumber,
    caseId,
    authorUserId,
    authorRole,
    authorName,
  });
}

/**
 * Get a note by ID
 */
export async function getNoteById(noteId: string, userId: string): Promise<Note> {
  return apiFetch<Note>(`/api/v1/notes/${noteId}`, {
    method: "GET",
    baseUrl: config.api.notesUrl,
    headers: {
      "X-User-Id": userId,
    },
  });
}

/**
 * Get all notes for a user (paginated)
 * Based on Postman: GET /api/v1/notes?page=0&size=10
 */
export async function getAllNotes(
  userId: string,
  page: number = 0,
  size: number = 50
): Promise<{ content: Note[]; totalElements: number; totalPages: number; page: number; size: number }> {
  const data = await apiFetch<any>(`/api/v1/notes?page=${page}&size=${size}`, {
    method: "GET",
    baseUrl: config.api.notesUrl,
    headers: {
      "X-User-Id": userId,
    },
  });

  return data;
}

/**
 * Search notes by keyword
 */
export async function searchNotes(
  keyword: string,
  userId: string,
  page: number = 0,
  size: number = 10
): Promise<{ content: Note[]; totalElements: number; totalPages: number }> {

  const data = await apiFetch<any>(`/api/v1/notes/search?keyword=${encodeURIComponent(keyword)}&page=${page}&size=${size}`, {
    method: "GET",
    baseUrl: config.api.notesUrl,
    headers: {
      "X-User-Id": userId,
    },
  });

  return data;
}

/**
 * Get notes for a specific task by fetching all notes and filtering
 * Uses GET /api/v1/notes to get all notes, then filters by taskId/loanNumber
 */
export async function getNotesForTask(
  taskId: string,
  lanNumber: string,
  userId: string
): Promise<Note[]> {
  try {
    // Get all notes for the user
    const result = await getAllNotes(userId, 0, 50);

    // Filter to only include TASK notes (noteTypeId = 2) that match this task
    const taskNotes = result.content.filter((note) => {
      const isTaskNote = note.noteTypeId === 2;
      // Match by caseId (which contains task ID for task notes) or by loanNumber
      const matchesByCaseId = note.caseId === taskId;
      const matchesByLoan = lanNumber && note.loanNumber === lanNumber;
      const matchesTask = matchesByCaseId || matchesByLoan;

      return isTaskNote && matchesTask;
    });

    return taskNotes;
  } catch (error) {
    console.error("[NotesService] Error in getNotesForTask:", error);
    throw error;
  }
}

/**
 * Get notes for a specific case by searching with case ID or LAN number
 */
export async function getNotesForCase(
  caseId: string,
  lanNumber: string,
  userId: string
): Promise<Note[]> {

  try {
    // Search by LAN number first (more likely to match)
    const searchKeyword = lanNumber || caseId;

    const result = await searchNotes(searchKeyword, userId, 0, 50);

    // Filter to only include CASE notes (noteTypeId = 1)
    const caseNotes = result.content.filter((note) => {
      const isCaseNote = note.noteTypeId === 1;
      const matchesCase = note.caseId === caseId || note.loanNumber === lanNumber;

      return isCaseNote && matchesCase;
    });

    return caseNotes;
  } catch (error) {
    console.error("[NotesService] Error in getNotesForCase:", error);
    throw error;
  }
}

/**
 * Search notes by criteria (loanNumber, year, month) with pagination
 * New API endpoint: GET /api/v1/notes/search/criteria
 * NOTE: The API requires year parameter - defaults to current year if not provided
 */
export async function searchNotesByCriteria(
  params: NoteSearchCriteriaParams,
  userId: string
): Promise<PaginatedNotesResponse> {

  // Default to current year if not provided (API requires year parameter)
  const year = params.year ?? new Date().getFullYear();

  // Build URL with query parameters
  const queryParams = new URLSearchParams({
    loanNumber: params.loanNumber,
    page: params.page.toString(),
    size: params.size.toString(),
    year: year.toString(), // Always include year
  });

  if (params.month !== undefined) {
    queryParams.append("month", params.month.toString());
  }

  const data = await apiFetch<PaginatedNotesResponse>(`/api/v1/notes/search/criteria?${queryParams.toString()}`, {
    method: "GET",
    baseUrl: config.api.notesUrl,
    headers: {
      "X-User-Id": userId,
    },
  });

  // Filter out deleted notes
  if (data.content) {
    data.content = data.content.filter((note) => !note.deleted);
  }

  return data;
}
