// Notifications Service - for fetching user notifications (including notes)

export interface NotificationPayload {
  eventCode?: string;
  navigation_action?: string;
  navigation_target?: string;
  navigation_params?: Record<string, string | number | boolean> | string;
  messageId?: string;
  title?: string;
  body?: string;
  userId?: string;
  context?: {
    agentName?: string;
    receiptList?: string;
    totalAmount?: string;
    [key: string]: string | undefined;
  };
}

export interface Notification {
  id: string;
  messageId?: string;
  userId?: string;
  eventType?: string;
  noteType?: string; // "CASE" | "TASK" | "BROADCAST" | "USER"
  noteTypeId?: number;
  content?: string;
  sent: boolean;
  createdAt: string;
  updatedAt?: string;
  authorUserId?: string;
  authorName?: string;
  authorRole?: string;
  loanNumber?: string;
  caseId?: string;
  criticality?: number;
  read?: boolean;
  // Additional fields that may come from API
  recipientUserId?: string;
  message?: string;
  referenceId?: string;
  // Payload field (JSON string that needs parsing)
  payload?: string;
  // Parsed payload
  parsedPayload?: NotificationPayload;
}

function mapNavigationTarget(target: string): string | null {
  const trimmed = target.trim();

  if (trimmed === "CashInHandScreen") {
    return "/dashboard/deposits/verify";
  }

  if (trimmed === "/tasks/list" || trimmed === "tasks/list" || trimmed === "/tasks") {
    return "/dashboard/tasks";
  }

  if (trimmed === "/cases/list" || trimmed === "cases/list" || trimmed === "/cases") {
    return "/dashboard/cases";
  }

  if (trimmed === "/dashboard/deposits") {
    return "/dashboard/deposits/verify";
  }

  if (trimmed.startsWith("/dashboard/")) {
    return trimmed;
  }

  return null;
}

export function getNotificationNavigationLink(notification: Notification): string | null {
  const payload = notification.parsedPayload;
  if (!payload?.navigation_target) {
    return null;
  }

  const placeholderRegex = /^\{(.+)\}$/;
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

  const normalizeNavigationParams = (
    params: NotificationPayload["navigation_params"]
  ): Record<string, unknown> | null => {
    if (!params) {
      return null;
    }

    if (typeof params === "string") {
      try {
        const parsed = JSON.parse(params);
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          return parsed as Record<string, unknown>;
        }
      } catch (error) {
        console.warn("[NotificationNavigation] Failed to parse navigation_params string:", error);
      }
      return null;
    }

    if (params && typeof params === "object" && !Array.isArray(params)) {
      return params as Record<string, unknown>;
    }

    return null;
  };

  const eventType = notification.eventType?.toUpperCase() || "";
  const noteType =
    notification.noteType?.toUpperCase() ||
    (notification.noteTypeId === 1 ? "CASE" : notification.noteTypeId === 2 ? "TASK" : "");
  const isCaseNote = eventType === "CASE_NOTE_NOTIFICATION" || noteType === "CASE";
  const isTaskNote = eventType === "TASK_NOTE_NOTIFICATION" || noteType === "TASK";

  const rawTarget = payload.navigation_target.trim();
  const [targetPath, targetQueryString] = rawTarget.split("?");
  const targetQueryParams = new URLSearchParams(targetQueryString || "");

  const action = payload.navigation_action?.toUpperCase();
  if (action && action !== "NAVIGATE") {
    return null;
  }

  const route = mapNavigationTarget(targetPath);
  if (!route) {
    return null;
  }

  const searchParams = new URLSearchParams();
  const appendParam = (key: string, value: string) => {
    const strValue = value.trim();
    if (!strValue) {
      return;
    }
    searchParams.set(key, strValue);
  };

  const getCaseInsensitiveValue = (obj: Record<string, unknown> | null | undefined, key: string) => {
    if (!obj) {
      return undefined;
    }
    const lowerKey = key.toLowerCase();
    const entry = Object.entries(obj).find(([k]) => k.toLowerCase() === lowerKey);
    return entry ? entry[1] : undefined;
  };

  const normalizedParams = normalizeNavigationParams(payload.navigation_params);
  const normalizedParamsCaseId = normalizedParams?.caseId;

  const resolveCaseId = () => {
    const candidates = [
      notification.caseId,
      getCaseInsensitiveValue(notification as unknown as Record<string, unknown>, "caseId"),
      getCaseInsensitiveValue(payload as unknown as Record<string, unknown>, "caseId"),
      getCaseInsensitiveValue(payload?.context as Record<string, unknown>, "caseId"),
      getCaseInsensitiveValue(payload?.context as Record<string, unknown>, "accountId"),
      normalizedParamsCaseId,
    ]
      .map((value) => (value !== undefined && value !== null ? String(value).trim() : ""))
      .filter(Boolean)
      .filter((value) => !placeholderRegex.test(value));

    if (candidates.length > 0) {
      return candidates[0];
    }

    const referenceId = notification.referenceId;
    if (referenceId && uuidRegex.test(referenceId)) {
      return referenceId;
    }

    return "";
  };

  const resolvedCaseId = resolveCaseId();
  const resolvedLan =
    notification.loanNumber || notification.referenceId || "";
  const resolvedNoteId = notification.messageId || notification.id || "";

  const resolvePlaceholderValue = (_key: string, value: string): string => {
    const match = value.match(placeholderRegex);
    if (!match) {
      return value;
    }

    const placeholder = match[1]?.trim()?.toLowerCase();
    if (placeholder === "caseid") {
      return resolvedCaseId;
    }
    if (placeholder === "lanlist" || placeholder === "lannumber" || placeholder === "loanNumber") {
      return resolvedLan;
    }
    if (placeholder === "noteid") {
      return resolvedNoteId;
    }

    return "";
  };

  targetQueryParams.forEach((value, key) => {
    const resolved = resolvePlaceholderValue(key, value);
    if (!resolved) {
      return;
    }
    appendParam(key, resolved);
  });

  if (normalizedParams) {
    Object.entries(normalizedParams).forEach(([key, value]) => {
      if (value === null || value === undefined) {
        return;
      }
      const rawValue = String(value);
      const resolved = resolvePlaceholderValue(key, rawValue);
      if (!resolved) {
        return;
      }
      appendParam(key, resolved);
    });
  }

  const recordId = resolvedCaseId;
  const referenceId = resolvedLan;

  if (route === "/dashboard/cases" && isCaseNote) {
    if (recordId && !searchParams.has("caseId")) {
      searchParams.set("caseId", recordId);
    } else if (!searchParams.has("lan") && referenceId) {
      searchParams.set("lan", referenceId);
    }
  }

  if (route === "/dashboard/tasks" && isTaskNote) {
    if (recordId && !searchParams.has("caseId")) {
      searchParams.set("caseId", recordId);
    } else if (!searchParams.has("lan") && referenceId) {
      searchParams.set("lan", referenceId);
    }
  }

  const queryString = searchParams.toString();
  const link = queryString ? `${route}?${queryString}` : route;
  return link;
}

import { config } from "@/config";
import { apiFetch } from "../api/api-fetch";

const UNREAD_STORAGE_KEY = "unread_notifications";

/**
 * Get all notifications for a user
 * Only returns notifications where sent = true
 * Sorted by createdAt (newest first)
 */
export async function getUserNotifications(userId: string): Promise<Notification[]> {

  if (!userId || userId === "null" || userId === "unknown") {
    return [];
  }

  try {
    const jsonList = await apiFetch<any[]>(`/api/notifications/${userId}`, {
      method: "GET",
      baseUrl: config.api.notificationsUrl,
    }).catch(err => {
      if (err.message.includes('404')) {
        return [];
      }
      throw err;
    });

    if (!jsonList || jsonList.length === 0) {
      return [];
    }

    // Filter only sent notifications and sort by createdAt (newest first)
    const notifications = jsonList
      .filter((event: Record<string, unknown>) => event.sent === true)
      .map((notification: Notification) => {
        // Parse payload if it exists
        if (notification.payload) {
          try {
            notification.parsedPayload = JSON.parse(notification.payload);
          } catch (e) {
            console.warn("[NotificationsService] Failed to parse payload for notification:", notification.id);
          }
        }
        return notification;
      })
      .sort((a: Notification, b: Notification) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );

    return notifications;
  } catch (error) {
    console.error("[NotificationsService] ERROR fetching notifications:", error);
    throw error;
  }
}

/**
 * Get unread notification IDs from localStorage
 */
export function getUnreadNotificationIds(userId: string): Set<string> {
  try {
    const key = `${UNREAD_STORAGE_KEY}_${userId}`;
    const stored = localStorage.getItem(key);
    if (stored) {
      const ids = JSON.parse(stored);
      return new Set(ids);
    }
  } catch (error) {
    console.error("Error reading unread notifications from localStorage:", error);
  }
  return new Set();
}

/**
 * Mark notifications as read by storing the IDs that have been seen
 * We store "read" IDs - notifications not in this list are considered unread
 */
export function markNotificationsAsRead(userId: string, notificationIds: string[]): void {
  try {
    const key = `${UNREAD_STORAGE_KEY}_${userId}`;
    const existingReadIds = getReadNotificationIds(userId);
    notificationIds.forEach((id) => existingReadIds.add(id));
    localStorage.setItem(key, JSON.stringify(Array.from(existingReadIds)));
  } catch (error) {
    console.error("Error saving read notifications to localStorage:", error);
  }
}

/**
 * Get read notification IDs from localStorage
 */
export function getReadNotificationIds(userId: string): Set<string> {
  try {
    const key = `${UNREAD_STORAGE_KEY}_${userId}`;
    const stored = localStorage.getItem(key);
    if (stored) {
      const ids = JSON.parse(stored);
      return new Set(ids);
    }
  } catch (error) {
    console.error("Error reading notifications from localStorage:", error);
  }
  return new Set();
}

/**
 * Check if a notification has been read
 */
export function isNotificationRead(userId: string, notificationId: string): boolean {
  const readIds = getReadNotificationIds(userId);
  return readIds.has(notificationId);
}

/**
 * Get count of unread notifications
 */
export function getUnreadCount(userId: string, notifications: Notification[]): number {
  const readIds = getReadNotificationIds(userId);
  return notifications.filter((n) => !readIds.has(n.id)).length;
}

/**
 * Mark all current notifications as read
 */
export function markAllAsRead(userId: string, notifications: Notification[]): void {
  const allIds = notifications.map((n) => n.id);
  markNotificationsAsRead(userId, allIds);
}

/**
 * Clear read status (for testing/debugging)
 */
export function clearReadStatus(userId: string): void {
  const key = `${UNREAD_STORAGE_KEY}_${userId}`;
  localStorage.removeItem(key);
}
