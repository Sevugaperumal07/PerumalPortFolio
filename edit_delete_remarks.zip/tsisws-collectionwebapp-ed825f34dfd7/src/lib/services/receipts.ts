import { graphqlRequest } from '../graphql/client';
import {
  CHECK_COLL_RECEIPT_EDITABLE,
  DELETE_COLLECTION_RECEIPT,
  RECREATE_COLL_RECEIPT,
} from '../graphql/mutations/receipts';
import type {
  CheckReceiptEditableResponse,
  DeleteReceiptResponse,
  RecreateReceiptInput,
  RecreateReceiptResponse,
} from '../types';

/**
 * Check if a receipt is editable or deletable
 * @param receiptNo - The receipt number to check
 * @returns Object containing editable status and reasons if not editable
 */
export async function checkReceiptEditable(receiptNo: string): Promise<CheckReceiptEditableResponse> {
  try {
    const response = await graphqlRequest<{ checkCollReceiptEditable: CheckReceiptEditableResponse }>(
      CHECK_COLL_RECEIPT_EDITABLE,
      { oldReceiptNo: receiptNo }
    );

    if (response && typeof response === 'object' && 'checkCollReceiptEditable' in response) {
      return response.checkCollReceiptEditable;
    }

    throw new Error('Unexpected response format from checkCollReceiptEditable mutation');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to check receipt editable status. Please try again.');
  }
}

/**
 * Delete a collection receipt
 * @param receiptNo - The receipt number to delete
 * @param remarks - Reason for deletion
 * @returns Object containing status and message
 */
export async function deleteReceipt(receiptNo: string, remarks: string): Promise<DeleteReceiptResponse> {
  try {
    const response = await graphqlRequest<{ deleteCollectionReceipt: DeleteReceiptResponse }>(
      DELETE_COLLECTION_RECEIPT,
      { receiptId: receiptNo, remarks }
    );

    if (response && typeof response === 'object' && 'deleteCollectionReceipt' in response) {
      const result = response.deleteCollectionReceipt;

      if (result.status !== 'SUCCESS') {
        throw new Error(result.message || 'Failed to delete receipt');
      }

      return result;
    }

    throw new Error('Unexpected response format from deleteCollectionReceipt mutation');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to delete receipt. Please try again.');
  }
}

/**
 * Recreate (edit) a collection receipt
 * Note: If the editable amount is less than EMI amount, nextActionDate and nextActionTime are required
 * @param input - The recreate receipt input
 * @returns Object containing success status, message, and new/old receipt data
 */
export async function recreateReceipt(input: RecreateReceiptInput): Promise<RecreateReceiptResponse> {
  try {
    const response = await graphqlRequest<{ recreateCollReceipt: RecreateReceiptResponse }>(
      RECREATE_COLL_RECEIPT,
      { input }
    );

    if (response && typeof response === 'object' && 'recreateCollReceipt' in response) {
      const result = response.recreateCollReceipt;

      if (!result.success) {
        throw new Error(result.message || 'Failed to recreate receipt');
      }

      return result;
    }

    throw new Error('Unexpected response format from recreateCollReceipt mutation');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to recreate receipt. Please try again.');
  }
}
