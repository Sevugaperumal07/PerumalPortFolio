import { graphqlRequest } from '../graphql/client';
import { GET_ROLES, GET_CONSOLIDATED_DATA } from '../graphql/queries/roles';
import { CREATE_ROLE, UPDATE_ROLE_BY_ID } from '../graphql/mutations/roles';
import { restClient } from '../api/client';
import type { Role } from '../types';
import type { RoleMatrixResponse, PermissionLevel } from '@/components/dashboard/RoleAccessSetup';

export interface ConsolidatedDataResponse {
  getConsolidatedData: {
    permissionLevels: PermissionLevel[];
  };
}
// In-memory cache for static-like data
let cachedRoles: Role[] | null = null;
let cachedPermissionLevels: PermissionLevel[] | null = null;
let cachedHierarchy: RoleHierarchyNode[] | null = null;

export function clearRoleCache() {
  cachedRoles = null;
  cachedPermissionLevels = null;
  cachedHierarchy = null;
}

export async function getRoles(): Promise<Role[]> {
  if (cachedRoles) return cachedRoles;
  const response = await graphqlRequest<{ getRoles: Role[] }>(GET_ROLES);
  
 if (response && typeof response === 'object' && 'getRoles' in response) {
    const roles = response.getRoles;
    if (Array.isArray(roles)) {
      cachedRoles = roles;
      return roles;
    }
  }  
  throw new Error('Unexpected response format from getRoles query');
}

export async function createRole(input: { name: string; description?: string; code?: string }): Promise<Role> {
  const { code, ...roleInput } = input;
  const response = await graphqlRequest<{ createRole: Role }>(CREATE_ROLE, { aclRole: roleInput });
  clearRoleCache();
  return response.createRole;
}

export async function updateRole(id: string, input: { name?: string; description?: string; code?: string }): Promise<Role> {
  const roles = await getRoles();
  const existingRole = roles.find(r => r.id === id);
  
  if (!existingRole) {
    throw new Error(`Role with ID "${id}" not found`);
  }
  
  const updateData: any = {
    name: input.name || existingRole.name,
    description: input.description !== undefined ? input.description : (existingRole.description || ''),
    deleted: existingRole.deleted || false,
  };
  
  try {
    const response = await graphqlRequest<{ updateRoleById: Role }>(UPDATE_ROLE_BY_ID, { id, aclRole: updateData });
    
    if (response && response.updateRoleById) {
      clearRoleCache();
      return response.updateRoleById;
    }
    
    throw new Error('Unexpected response format from updateRoleById');
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('FieldUndefined') || error.message.includes('undefined')) {
        throw new Error('Updating roles is not supported by the backend API. The GraphQL schema does not include an updateRoleById mutation. Please contact your administrator to add this functionality.');
      }
      throw error;
    }
    throw new Error('Failed to update role: ' + String(error));
  }
}

export async function getRoleMatrix(roleId: string): Promise<RoleMatrixResponse> {
  return restClient<RoleMatrixResponse>(`/api/roles/${roleId}/matrix`);
}

export interface RolePermissionPayload {
  category: string;
  name: string;
  override: number;
}

export async function updateRolePermissions(roleId: string, payload: RolePermissionPayload[]): Promise<void> {
  try {
    await restClient(`/api/roles/${roleId}/update`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    cachedHierarchy = null;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Unexpected end of JSON input')) {
      return;
    }
    throw error;
  }
}

export async function createRolePermissions(roleId: string, payload: RolePermissionPayload[]): Promise<void> {
  try {
    await restClient(`/api/roles/${roleId}/permissions`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    cachedHierarchy = null;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Unexpected end of JSON input')) {
      return;
    }
    throw error;
  }
}

export async function getPermissionLevels(): Promise<PermissionLevel[]> {
  if (cachedPermissionLevels) return cachedPermissionLevels;
  const response = await graphqlRequest<ConsolidatedDataResponse>(GET_CONSOLIDATED_DATA);
  const levels = response.getConsolidatedData.permissionLevels;
  cachedPermissionLevels = levels;
  return levels;
}

export async function deleteRole(id: string): Promise<boolean> {
  const roles = await getRoles();
  const existingRole = roles.find(r => r.id === id);
  
  if (!existingRole) {
    throw new Error(`Role with ID "${id}" not found`);
  }
  
  const updateData: any = {
    name: existingRole.name,
    description: existingRole.description || '',
    deleted: true,
  };
  
  try {
    const response = await graphqlRequest<{ updateRoleById: Role }>(UPDATE_ROLE_BY_ID, { id, aclRole: updateData });
    
    if (response && response.updateRoleById) {
      if (response.updateRoleById.deleted === true) {
        clearRoleCache();
        return true;
      }
      throw new Error('Role update succeeded but deleted field was not set to true');
    }
    
    throw new Error('Failed to update role - unexpected response format');
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('FieldUndefined') || error.message.includes('undefined')) {
        throw new Error('Deleting roles is not supported by the backend API. The GraphQL schema does not include updateRoleById mutation. To enable role deletion, the backend needs to add an updateRoleById mutation that can set the deleted field to true.');
      }
      throw error;
    }
    throw new Error('Failed to delete role: ' + String(error));
  }
}

export interface RoleHierarchyNode {
  id: string;
  name: string;
  children?: RoleHierarchyNode[];
}

export async function getRoleHierarchy(): Promise<RoleHierarchyNode[]> {
  if (cachedHierarchy) return cachedHierarchy;
  const hierarchy = await restClient<RoleHierarchyNode[]>('/api/roles/hierarchy/get');
  cachedHierarchy = hierarchy;
  return hierarchy;
}

export interface RoleHierarchyPayload {
  roleId: string;
  parentRoleId: string | null;
  childRoleId: string | null;
  edit: 'true' | 'false';
}

export async function updateRoleHierarchy(payload: RoleHierarchyPayload): Promise<void> {
  try {
    await restClient('/api/roles/hierarchy/position', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    cachedHierarchy = null;
    cachedRoles = null;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Unexpected end of JSON input')) {
      return;
    }
    throw error;
  }
}