import { config } from '@/config';
import { apiFetch } from '../api/api-fetch';

export type ScreenShotModule = "Deposit Slip" | "Payment Image" | "Selfie Image" | string;

export interface GetScreenShotOptions {
    moduleName: ScreenShotModule;
    refId: string;
    dispositionId?: string;
}

export async function getScreenShot({
    moduleName,
    refId,
    dispositionId = ""
}: GetScreenShotOptions): Promise<{ blob: Blob; filename: string }> {
    const url = `/api/files/download?module=${moduleName}&refId=${refId}&dispositionId=${dispositionId}`;

    return apiFetch<Blob>(url, {
        method: "GET",
        baseUrl: config.api.screenshotUrl,
        responseType: 'blob'
    }).then(async (blob) => {
        return { blob, filename: `screenshot_${refId}.png` };
    });
}

export async function uploadImage(file: File, module: string, refId: string): Promise<any> {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("module", module);
    formData.append("refId", refId);

    return apiFetch<any>(`/api/files/upload`, {
        method: "POST",
        baseUrl: config.api.screenshotUrl,
        body: formData,
    });
}
