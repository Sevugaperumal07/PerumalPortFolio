import { graphqlRequest } from '../graphql/client';
import { GET_SECURITY_GROUPS } from '../graphql/queries/security-groups';
import { CREATE_SECURITY_GROUP, UPDATE_SECURITY_GROUP_BY_ID, LINK_ROLE_TO_SECURITY_GROUP, LINK_BANK_DETAILS_TO_SECURITY_GROUP } from '../graphql/mutations/security-groups';
import type { SecurityGroup, BankDetail } from '../types';

export async function getSecurityGroups(): Promise<SecurityGroup[]> {
  const response = await graphqlRequest<{ getSecurityGroups: SecurityGroup[] }>(GET_SECURITY_GROUPS);

  if (response && typeof response === 'object' && 'getSecurityGroups' in response) {
    const groups = response.getSecurityGroups;
    if (Array.isArray(groups)) {
      return groups;
    }
  }

  console.error('Unexpected response format:', response);
  throw new Error('Unexpected response format from getSecurityGroups query');
}

export async function createSecurityGroup(input: {
  name: string;
  description?: string;
  inheritable?: boolean;
}): Promise<SecurityGroup> {
  const response = await graphqlRequest<{ createSecurityGroups: SecurityGroup }>(CREATE_SECURITY_GROUP, { securityGroups: input });
  return response.createSecurityGroups;
}

export async function updateSecurityGroup(id: string, input: {
  name?: string;
  description?: string;
  inheritable?: boolean;
}): Promise<SecurityGroup> {
  const response = await graphqlRequest<{ updateSecurityGroupsFieldById: SecurityGroup }>(UPDATE_SECURITY_GROUP_BY_ID, { id, securityGroups: input });

  if (response && typeof response === 'object' && 'updateSecurityGroupsFieldById' in response) {
    const group = response.updateSecurityGroupsFieldById;
    if (group && typeof group === 'object') {
      return group;
    }
  }

  console.error('Unexpected response format:', response);
  throw new Error('Unexpected response format from updateSecurityGroupsFieldById mutation');
}

export async function linkRoleToSecurityGroup(roleId: string, securityGroupId: string): Promise<SecurityGroup> {
  const response = await graphqlRequest<{ linkRoleToSecurityGroup: SecurityGroup }>(
    LINK_ROLE_TO_SECURITY_GROUP,
    { roleId, securityId: securityGroupId }
  );

  if (response && typeof response === 'object' && 'linkRoleToSecurityGroup' in response) {
    const group = response.linkRoleToSecurityGroup;
    if (group && typeof group === 'object') {
      return group;
    }
  }

  throw new Error('Unexpected response format from linkRoleToSecurityGroup mutation');
}

export async function linkBankDetailsToSecurityGroup(bankDetailId: string, securityGroupId: string): Promise<BankDetail> {
  const response = await graphqlRequest<{ linkBankDetailsToSecurityGroup: BankDetail }>(
    LINK_BANK_DETAILS_TO_SECURITY_GROUP,
    { bankDetailsId: bankDetailId, securityGroupId }
  );
  
  if (response && typeof response === 'object' && 'linkBankDetailsToSecurityGroup' in response) {
    const bankDetail = response.linkBankDetailsToSecurityGroup;
    if (bankDetail && typeof bankDetail === 'object') {
      return bankDetail;
    }
  }
  
  throw new Error('Unexpected response format from linkBankDetailsToSecurityGroup mutation');
}

