import { restClient } from '../api/client';

export async function sendHeartbeat() {
  return restClient<string>('/api/auth/heartbeat', {
    method: 'POST',
  });
}