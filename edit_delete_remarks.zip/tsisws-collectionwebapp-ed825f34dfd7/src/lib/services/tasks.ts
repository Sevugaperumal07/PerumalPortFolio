import { restClient } from '../api/client';
import { graphqlRequest } from '../graphql/client';
import {
  ASSIGN_CASES_TO_USER,
  CONSOLIDATE_RECEIPT_ACCEPTANCE_REJECTION,
  CREATE_DEPOSIT,
  GET_ALL_EMI_PENDINGS,
  GET_CASE_BY_ID,
  GET_COLL_RECEIPT_BY_ID,
  GET_STATE_SECURITY_GROUPS,
  GET_USERS_BY_SECURITY_GROUP_ID,
  LINK_USER_TO_ACCOUNT,
  LINK_USER_TO_CASE,
  SEARCH_CASES_DYNAMIC
} from '../graphql/queries/tasks';
import type {
  Account,
  AssignCasesToUserResponse,
  Case,
  CollReceipt,
  ConsolidateReceiptAcceptanceRejectionInput,
  ConsolidateReceiptAcceptanceRejectionResult,
  CreateDepositInput,
  CreateDepositResponse,
  EmiPendingBucket,
  GetUsersBySecurityGroupIdResponse,
  SearchCasesOptions,
  SearchCasesResponse,
  StateSecurityGroup,
  Task
} from '../types';
export type BulkAssignType = 'ASSIGN_BOTH' | 'ASSIGN_TASK';
export interface BulkAssignRequest {
  loanNumbers: string[];
  userId: string;
  type: BulkAssignType;
}

export interface BulkAssignResponse {
  success: boolean;
  message: string;
  failedIds?: string[];
}

export async function bulkAssignTasksAndCases(request: BulkAssignRequest): Promise<BulkAssignResponse> {
  try {
    // Use responseType 'text' because the backend may return plain text instead of JSON
    const rawText = await restClient<string>('/api/assignment/bulk-assign', {
      method: 'POST',
      body: JSON.stringify(request),
      responseType: 'text',
    });

    // Try to parse as JSON first; if it fails, treat the plain text as the success message
    try {
      const parsed = JSON.parse(rawText) as BulkAssignResponse;
      return parsed;
    } catch {
      // Backend returned plain text (e.g. "Assignment completed successfully.")
      return {
        success: true,
        message: rawText,
      };
    }
  } catch (error) {
    console.error('Error in bulk assignment:', error);
    throw error;
  }
}


// Format date to DD/MM/YYYY format
function formatDate(dateString?: string | null): string {
  if (!dateString) return 'N/A';

  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'N/A';

    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();

    return `${day} /${month}/${year} `;
  } catch {
    return 'N/A';
  }
}

// Transform Case data to Task display format
function transformCaseToTask(caseData: Case): Task {
  const firstReceipt = caseData.collReceipts && caseData.collReceipts.length > 0
    ? caseData.collReceipts[0]
    : null;

  const account = caseData.account;
  const emiAmount =
    account?.emiAmount ??
    caseData.emiAmount ??
    firstReceipt?.collectedEmiAmount ??
    0;

  return {
    id: caseData.id,
    accountId: caseData.accountId,
    taskNumber: caseData.caseNumber ?? 'N/A',
    receiptNo: firstReceipt?.receiptNo ?? 'N/A',
    agentName: caseData.UserCases?.[0]?.userId?.userName ?? 'N/A',
    customerName: caseData.account?.name ?? 'N/A',
    paymentMode: firstReceipt?.paymentType ?? 'N/A',
    transactionRefNo: firstReceipt?.transactionRefNo ?? 'N/A',
    lan: caseData.loanNumber ?? 'N/A',
    branch: caseData.securityGroups?.[0]?.name ?? 'N/A',
    product: account?.product ?? 'N/A',
    emiOverdue: Number(caseData.emiOverdue),
    receivedAmount: caseData.amountCollected || 0,
    dpd: Number(caseData.dpd),
    status: caseData.status ?? 'N/A',
    disposition: caseData.status ?? 'N/A', // Using status for disposition as per requirement
    dateCreated: formatDate(caseData.dateEntered),
    dateCreatedRaw: caseData.dateEntered ?? '',
    lastModified: formatDate(caseData.dateModified),
    lastModifiedRaw: caseData.dateModified ?? '',
    receipt: firstReceipt,
    activityDate: formatDate(
      caseData.caseDispositions
        ?.filter((d) => d.activityDate && !d.deleted)
        .sort((a, b) => new Date(b.activityDate!).getTime() - new Date(a.activityDate!).getTime())[0]?.activityDate
    ),
    emiAmount,
    activityBy: caseData.caseDispositions
      ?.filter((d) => d.activityDate && d.userName && !d.deleted)
      .sort((a, b) => new Date(b.activityDate!).getTime() - new Date(a.activityDate!).getTime())[0]?.userName ?? 'N/A',
    account: caseData.account,
    UserCases: caseData.UserCases?.map(uc => ({
      id: uc.id,
      userId: {
        id: uc.userId?.id,
        userName: uc.userId?.userName
      }
    })),
    securityGroups: caseData.securityGroups
  };
}

// Fetch tasks (cases) by reporting manager with pagination
export async function searchCasesPaginated(
  options: SearchCasesOptions = {}
): Promise<SearchCasesResponse & { tasks: Task[] }> {
  try {
    const {
      limit = 20,
      offset = 0,
      query = "",
      lanNumber,
      receiptNo,
      taskNumber,
      branchName,
      agentName,
      status,
      fromDate,
      toDate,
      dateType,
      bankName,
      forDeposit,
      dpdFrom,
      dpdTo,
      acceptanceStatus,
      state,
      export: exportFlag,
    } = options;

    const variables: any = {
      limit,
      offset,
    };

    const dynamicArgs: string[] = [];
    const dynamicInput: string[] = [];

    // Always add clientType first
    variables.clientType = "web";
    dynamicArgs.push("$clientType: String");
    dynamicInput.push("clientType: $clientType");

    // Only add optional arguments if they have values
    if (query) {
      variables.query = query;
      dynamicArgs.push("$query: String");
      dynamicInput.push("query: $query");
    }
    if (lanNumber) {
      variables.lanNumber = lanNumber;
      dynamicArgs.push("$lanNumber: String");
      dynamicInput.push("lanNumber: $lanNumber");
    }
    if (receiptNo) {
      variables.receiptNo = receiptNo;
      dynamicArgs.push("$receiptNo: String");
      dynamicInput.push("receiptNo: $receiptNo");
    }
    if (taskNumber) {
      variables.taskNumber = taskNumber;
      dynamicArgs.push("$taskNumber: String");
      dynamicInput.push("taskNumber: $taskNumber");
    }
    if (branchName) {
      variables.branchName = branchName;
      dynamicArgs.push("$branchName: String");
      dynamicInput.push("branchName: $branchName");
    }
    if (agentName) {
      variables.agentName = agentName;
      dynamicArgs.push("$agentName: String");
      dynamicInput.push("agentName: $agentName");
    }
    if (status) {
      variables.status = status;
      dynamicArgs.push("$status: CaseStatus");
      dynamicInput.push("status: $status");
    }
    if (fromDate) {
      variables.fromDate = fromDate;
      dynamicArgs.push("$fromDate: String");
      dynamicInput.push("fromDate: $fromDate");
    }
    if (toDate) {
      variables.toDate = toDate;
      dynamicArgs.push("$toDate: String");
      dynamicInput.push("toDate: $toDate");
    }
    if (dateType) {
      variables.dateType = dateType;
      dynamicArgs.push("$dateType: CommonDateType");
      dynamicInput.push("dateType: $dateType");
    }
    if (bankName) {
      variables.bankName = bankName;
      dynamicArgs.push("$bankName: String");
      dynamicInput.push("bankName: $bankName");
    }
    if (forDeposit !== undefined) {
      variables.forDeposit = forDeposit;
      dynamicArgs.push("$forDeposit: Boolean");
      dynamicInput.push("forDeposit: $forDeposit");
    }
    if (dpdFrom !== undefined) {
      variables.dpdFrom = dpdFrom;
      dynamicArgs.push("$dpdFrom: Float");
      dynamicInput.push("dpdFrom: $dpdFrom");
    }
    if (dpdTo !== undefined) {
      variables.dpdTo = dpdTo;
      dynamicArgs.push("$dpdTo: Float");
      dynamicInput.push("dpdTo: $dpdTo");
    }
    if (acceptanceStatus) {
      variables.acceptanceStatus = acceptanceStatus;
      dynamicArgs.push("$acceptanceStatus: String");
      dynamicInput.push("acceptanceStatus: $acceptanceStatus");
    }
    if (state) {
      variables.state = state;
      dynamicArgs.push("$state: String");
      dynamicInput.push("state: $state");
    }
    if (exportFlag !== undefined) {
      variables.export = exportFlag;
      dynamicArgs.push("$export: Boolean");
      dynamicInput.push("export: $export");
    }

    const queryArgsStr = dynamicArgs.length ? `, ${dynamicArgs.join(", ")}` : "";
    const inputFieldsStr = dynamicInput.length ? `${dynamicInput.join("\n      ")}` : "";

    const response = await graphqlRequest<{ searchCases: SearchCasesResponse }>(
      SEARCH_CASES_DYNAMIC(queryArgsStr, inputFieldsStr),
      variables
    );

    if (response?.searchCases) {
      const paginatedData = response.searchCases;
      // Transform content to tasks
      const tasks = (paginatedData.content || [])
        .filter((caseItem) => !caseItem.deleted)
        .map(transformCaseToTask);

      return {
        ...paginatedData,
        tasks,
      };
    }

    return {
      totalRecords: 0,
      totalPages: 0,
      currentPage: 0,
      size: 0,
      numberOfRecords: 0,
      hasNext: false,
      hasPrevious: false,
      content: [],
      tasks: [],
    };
  } catch (error) {
    console.error('Error fetching tasks:', error);
    throw error;
  }
}

export async function getTaskByCaseId(caseId: string): Promise<Task | null> {
  if (!caseId) {
    return null;
  }

  try {
    const response = await graphqlRequest<{ getCaseById: Case }>(
      GET_CASE_BY_ID,
      { id: caseId }
    );

    if (response && typeof response === 'object' && 'getCaseById' in response) {
      const caseItem = response.getCaseById;
      if (caseItem && !caseItem.deleted) {
        return transformCaseToTask(caseItem);
      }
    }
    return null;
  } catch (error) {
    console.error("[TaskNotification] Error fetching task by caseId:", error);
    throw error;
  }
}

export async function getUsersBySecurityGroupId(
  securityGroupId: string,
  name?: string,
  limit: number = 10,
  offset: number = 0
): Promise<GetUsersBySecurityGroupIdResponse> {
  try {
    const response = await graphqlRequest<{ getUsersBySecurityGroupId: GetUsersBySecurityGroupIdResponse }>(
      GET_USERS_BY_SECURITY_GROUP_ID,
      { securityGroupId, name, limit, offset }
    );
    return response.getUsersBySecurityGroupId;
  } catch (error) {
    console.error('Error fetching users by security group:', error);
    throw error;
  }
}

export async function getStateSecurityGroups(): Promise<StateSecurityGroup[]> {
  try {
    const response = await graphqlRequest<{ getStateSecurityGroups: StateSecurityGroup[] }>(
      GET_STATE_SECURITY_GROUPS,
      {}
    );
    return response.getStateSecurityGroups || [];
  } catch (error) {
    console.error('Error fetching state security groups:', error);
    throw error;
  }
}


export async function assignTasks(caseIds: string[], userId: string): Promise<AssignCasesToUserResponse> {
  try {
    const response = await graphqlRequest<{ assignCasesToUser: AssignCasesToUserResponse }>(
      ASSIGN_CASES_TO_USER,
      { caseIds, userId }
    );
    return response.assignCasesToUser;
  } catch (error) {
    console.error('Error assigning tasks:', error);
    throw error;
  }
}

export async function linkUserToCase(caseId: string, userId: string): Promise<Case | null> {
  try {
    const response = await graphqlRequest<{ linkUserToCase: Case }>(
      LINK_USER_TO_CASE,
      { caseId, userId }
    );
    return response.linkUserToCase;
  } catch (error) {
    console.error('Error linking user to case:', error);
    throw error;
  }
}

export async function linkUserToAccount(accountId: string, userId: string): Promise<Account | null> {
  try {
    const response = await graphqlRequest<{ linkUserToAccount: Account }>(
      LINK_USER_TO_ACCOUNT,
      { accountId, userId }
    );
    return response.linkUserToAccount;
  } catch (error) {
    console.error('Error linking user to account:', error);
    throw error;
  }
}



export async function getAllEmiPendings(): Promise<EmiPendingBucket[]> {
  try {
    const response = await graphqlRequest<{ getAllEmiPendings: EmiPendingBucket[] }>(
      GET_ALL_EMI_PENDINGS,
      {}
    );
    return response.getAllEmiPendings || [];
  } catch (error) {
    console.error('Error fetching EMI pendings:', error);
    throw error;
  }
}

export async function consolidateReceiptAcceptanceRejection(
  input: ConsolidateReceiptAcceptanceRejectionInput
): Promise<ConsolidateReceiptAcceptanceRejectionResult> {
  try {
    const response = await graphqlRequest<{ consolidateReceiptAcceptanceRejection: ConsolidateReceiptAcceptanceRejectionResult }>(
      CONSOLIDATE_RECEIPT_ACCEPTANCE_REJECTION,
      {
        receiptIds: input.receiptIds,
        action: input.action,
        remarks: input.remarks,
        date: input.date,
        time: input.time,
      }
    );
    return response.consolidateReceiptAcceptanceRejection;
  } catch (error) {
    console.error('Error processing receipt acceptance/rejection:', error);
    throw error;
  }
}

export async function createDeposit(input: CreateDepositInput): Promise<CreateDepositResponse> {
  try {
    const response = await graphqlRequest<CreateDepositResponse>(
      CREATE_DEPOSIT,
      { input }
    );
    return response;
  } catch (error) {
    console.error('Error creating deposit:', error);
    throw error;
  }
}
export async function getCollReceiptById(id: string): Promise<CollReceipt | null> {
  if (!id) return null;

  try {
    const response = await graphqlRequest<{ getCollReceiptById: CollReceipt }>(
      GET_COLL_RECEIPT_BY_ID,
      { id }
    );
    return response.getCollReceiptById || null;
  } catch (error) {
    console.error('Error fetching receipt by ID:', error);
    throw error;
  }
}
