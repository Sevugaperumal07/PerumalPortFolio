import { graphqlRequest } from '../graphql/client';
import { restClient } from '../api/client';
import { config } from '@/config';
import { GET_USERS, GET_USER_BY_ID, GET_USER_BY_EMAIL, GET_ROLES_BY_USER_ID, GET_SECURITY_GROUPS_BY_USER_ID, GET_CASES_BY_USER_ID } from '../graphql/queries/users';
import { CREATE_USER, UPDATE_USER_FIELD_BY_ID, DELETE_USER, LINK_USER_TO_ROLE, UNLINK_USER_FROM_ROLE, LINK_EXISTING_SECURITY_TO_USER, UNLINK_SECURITY_FROM_USER } from '../graphql/mutations/users';
import type { User, Role, SecurityGroup } from '../types';

export async function getUsers(): Promise<User[]> {
  const response = await graphqlRequest<{ getUsers: User[] }>(GET_USERS);
  
  if (response && typeof response === 'object' && 'getUsers' in response) {
    const users = response.getUsers;
    if (Array.isArray(users)) {
      return users.map((u) => ({
        ...u,
        roles: [],
        securityGroups: [],
      }));
    }
  }
  
  throw new Error('Unexpected response format from getUsers query');
}

export async function getUserRoles(userId: string): Promise<Role[]> {
  try {
    const rolesResponse = await graphqlRequest<{ getRolesByUserId: Role[] }>(
      GET_ROLES_BY_USER_ID,
      { userId }
    );
    return rolesResponse?.getRolesByUserId || [];
  } catch (error) {
    return [];
  }
}

export async function getUsersRoles(userIds: string[], batchSize: number = 10): Promise<Map<string, Role[]>> {
  const rolesMap = new Map<string, Role[]>();
  
  for (let i = 0; i < userIds.length; i += batchSize) {
    const batch = userIds.slice(i, i + batchSize);
    const batchResults = await Promise.all(
      batch.map(async (userId) => {
        const roles = await getUserRoles(userId);
        return { userId, roles };
      })
    );
    
    batchResults.forEach(({ userId, roles }) => {
      rolesMap.set(userId, roles);
    });
  }
  
  return rolesMap;
}

export async function getUserSecurityGroups(userId: string): Promise<SecurityGroup[]> {
  try {
    const securityGroupsResponse = await graphqlRequest<{ getSecurityGroupsByUserId: { securityGroups: SecurityGroup[] } }>(
      GET_SECURITY_GROUPS_BY_USER_ID,
      { userId }
    );
    return securityGroupsResponse?.getSecurityGroupsByUserId?.securityGroups || [];
  } catch (error) {
    return [];
  }
}

export async function getUsersSecurityGroups(userIds: string[], batchSize: number = 10): Promise<Map<string, SecurityGroup[]>> {
  const securityGroupsMap = new Map<string, SecurityGroup[]>();
  
  for (let i = 0; i < userIds.length; i += batchSize) {
    const batch = userIds.slice(i, i + batchSize);
    const batchResults = await Promise.all(
      batch.map(async (userId) => {
        const securityGroups = await getUserSecurityGroups(userId);
        return { userId, securityGroups };
      })
    );
    
    batchResults.forEach(({ userId, securityGroups }) => {
      securityGroupsMap.set(userId, securityGroups);
    });
  }
  
  return securityGroupsMap;
}

export async function getUserById(id: string): Promise<User> {
  const response = await graphqlRequest<{ getUserById: User | null }>(GET_USER_BY_ID, { id });
  
  if (response && typeof response === 'object' && 'getUserById' in response) {
    const user = response.getUserById;
    if (user === null || user === undefined) {
      throw new Error('User not found');
    }
    if (user && typeof user === 'object') {
      return user;
    }
  }
  
  throw new Error('Unexpected response format from getUserById query');
}

export async function getUserByEmail(email: string): Promise<User> {
  const response = await graphqlRequest<{ getUserByEmail: User | null }>(GET_USER_BY_EMAIL, { email });
  
  if (response && typeof response === 'object' && 'getUserByEmail' in response) {
    const user = response.getUserByEmail;
    if (user === null || user === undefined) {
      throw new Error('User not found');
    }
    if (user && typeof user === 'object') {
      return user;
    }
  }
  
  throw new Error('Unexpected response format from getUserByEmail query');
}

export async function createUser(input: Partial<User>): Promise<User> {
  const { roleIds, securityGroupIds, ...userInput } = input as any;

  const payload: Record<string, unknown> = { ...userInput };
  if ("supervisor" in input) {
    const trimmed =
      typeof input.supervisor === "string" ? input.supervisor.trim() : input.supervisor;
    payload.supervisor = trimmed && trimmed !== "" ? trimmed : null;
  }
  if ("supervisorEmail" in input) {
    const trimmed =
      typeof input.supervisorEmail === "string" ? input.supervisorEmail.trim() : input.supervisorEmail;
    payload.supervisorEmail = trimmed && trimmed !== "" ? trimmed : null;
  }

  if (config.isDev) {
    // eslint-disable-next-line no-console
    console.debug("[createUser] payload:", payload);
  }
  
  const response = await graphqlRequest<{ createUser: User }>(CREATE_USER, { user: payload });
  
  if (response && typeof response === 'object' && 'createUser' in response) {
    const user = response.createUser;
    if (user && typeof user === 'object') {
      return user;
    }
  }
  
  throw new Error('Unexpected response format from createUser mutation');
}

export async function updateUser(id: string, input: Partial<User>): Promise<User> {
  const { roleIds, securityGroupIds, ...userInput } = input as any;

  const payload: Record<string, unknown> = { ...userInput };
  if ("supervisor" in input) {
    const trimmed =
      typeof input.supervisor === "string" ? input.supervisor.trim() : input.supervisor;
    payload.supervisor = trimmed && trimmed !== "" ? trimmed : null;
  }
  if ("supervisorEmail" in input) {
    const trimmed =
      typeof input.supervisorEmail === "string"
        ? input.supervisorEmail.trim()
        : input.supervisorEmail;
    payload.supervisorEmail = trimmed && trimmed !== "" ? trimmed : null;
  }

  if (config.isDev) {
    // eslint-disable-next-line no-console
    console.debug("[updateUser] payload:", payload);
  }
  
  const response = await graphqlRequest<{ updateUserFieldById: User }>(UPDATE_USER_FIELD_BY_ID, { id, user: payload });
  
  if (response && typeof response === 'object' && 'updateUserFieldById' in response) {
    const user = response.updateUserFieldById;
    if (user && typeof user === 'object') {
      return user;
    }
  }
  
  throw new Error('Unexpected response format from updateUserFieldById mutation');
}

export async function getUserCases(userId: string): Promise<number> {
  try {
    const response = await graphqlRequest<any>(
      GET_CASES_BY_USER_ID,
      { id: userId }
    );
    
    // Handle different response structures
    let cases: Array<any> = [];
    
    // Check if response has data wrapper
    if (response && typeof response === 'object') {
      if ('data' in response && response.data && typeof response.data === 'object') {
        // Response has data wrapper: { data: { getCasesByUserId: [...] } }
        cases = response.data.getCasesByUserId || [];
      } else if ('getCasesByUserId' in response) {
        // Response is already unwrapped: { getCasesByUserId: [...] }
        cases = response.getCasesByUserId || [];
      }
    }
    
    // Return the count of cases (even if they're empty objects, they indicate cases exist)
    // Empty objects {} in the array mean the user has cases assigned
    return Array.isArray(cases) ? cases.length : 0;
  } catch (error) {
    console.error("Error fetching user cases:", error);
    return 0;
  }
}

export async function deleteUser(id: string): Promise<boolean> {
  const response = await graphqlRequest<{ deleteUser: string }>(DELETE_USER, { id });
  
  if (response && typeof response === 'object' && 'deleteUser' in response) {
    return true;
  }
  
  throw new Error('Unexpected response format from deleteUser mutation');
}

export async function linkUserToRole(userId: string, roleId: string): Promise<User> {
  const response = await graphqlRequest<{ linkUserToRole: User }>(LINK_USER_TO_ROLE, { userId, roleId });
  
  if (response && typeof response === 'object' && 'linkUserToRole' in response) {
    return response.linkUserToRole;
  }
  
  throw new Error('Unexpected response format from linkUserToRole mutation');
}

export async function unlinkUserFromRole(userId: string, roleId: string): Promise<User> {
  const response = await graphqlRequest<{ unlinkUserFromRole: User }>(UNLINK_USER_FROM_ROLE, { userId, roleId });
  
  if (response && typeof response === 'object' && 'unlinkUserFromRole' in response) {
    return response.unlinkUserFromRole;
  }
  
  throw new Error('Unexpected response format from unlinkUserFromRole mutation');
}

export async function linkSecurityToUser(userId: string, securityGroupId: string): Promise<void> {
  const response = await graphqlRequest<{ linkExistingSecurityToUser: { id: string; name: string } }>(LINK_EXISTING_SECURITY_TO_USER, { userId, securityId: securityGroupId });
  
  if (!response || typeof response !== 'object' || !('linkExistingSecurityToUser' in response)) {
    throw new Error('Unexpected response format from linkExistingSecurityToUser mutation');
  }
}

export async function unlinkSecurityFromUser(userId: string, securityGroupId: string): Promise<void> {
  const response = await graphqlRequest<{ unlinkSecurityFromUser: { id: string; name: string } }>(UNLINK_SECURITY_FROM_USER, { userId, securityId: securityGroupId });
  
  if (!response || typeof response !== 'object' || !('unlinkSecurityFromUser' in response)) {
    throw new Error('Unexpected response format from unlinkSecurityFromUser mutation');
  }
}

export async function updateUserRolesAndSecurityGroups(
  userId: string,
  newRoleIds: string[],
  newSecurityGroupIds: string[],
  currentRoleIds: string[] = [],
  currentSecurityGroupIds: string[] = []
): Promise<void> {
  const rolesToAdd = newRoleIds.filter(id => !currentRoleIds.includes(id));
  const rolesToRemove = currentRoleIds.filter(id => !newRoleIds.includes(id));
  const securityGroupsToAdd = newSecurityGroupIds.filter(id => !currentSecurityGroupIds.includes(id));
  const securityGroupsToRemove = currentSecurityGroupIds.filter(id => !newSecurityGroupIds.includes(id));
  
  for (const roleId of rolesToAdd) {
    await linkUserToRole(userId, roleId);
  }
  
  for (const roleId of rolesToRemove) {
    await unlinkUserFromRole(userId, roleId);
  }
  
  for (const securityGroupId of securityGroupsToAdd) {
    await linkSecurityToUser(userId, securityGroupId);
  }
  
  for (const securityGroupId of securityGroupsToRemove) {
    await unlinkSecurityFromUser(userId, securityGroupId);
  }
}

export async function forceLogoutUser(userId: string, comment: string): Promise<any> {
  return restClient('/api/auth/force-logout', {
    method: 'POST',
    body: JSON.stringify({
      userId,
      comment,
    }),
  });
}


