// API Response Types

export const OTP_TYPES = {
  RESET_PASSWORD: 'RESET_PASSWORD',
  FORGET_PASSWORD: 'FORGET_PASSWORD',
} as const;

export type OtpType = (typeof OTP_TYPES)[keyof typeof OTP_TYPES];

export interface LoginResponse {
  status?: 'PASSWORD_CHANGE_REQUIRED' | string;
  accessToken: string;
  refreshToken: string;
  sessionId: string;
  tokenType: string;
  accessTokenExpiresInSeconds: number;
  refreshTokenExpiresInSeconds: number;
  loginTime: string;
  sessionExpiresAt: string;
  sessionIdleTimeoutMs?: number;
}

export interface TokenRefreshResponse {
  accessToken: string;
  refreshToken: string;
  tokenType: string;
  accessTokenExpiresInSeconds: number;
  refreshTokenExpiresInSeconds: number;
  sessionIdleTimeoutMs?: number;
}

export interface LoginRequest {
  email: string;
  password: string;
  clientType: string;
}

export interface SendOtpRequest {
  email: string;
  otpType: OtpType;
}

export interface VerifyOtpRequest {
  email: string;
  otp: string;
  otpType: OtpType;
}

export interface VerifyOtpResponse {
  tempToken?: string;
}

export interface ResetPasswordRequest {
  newPassword: string;
  confirmNewPassword: string;
}

// User Types
export interface User {
  id: string;
  userName: string;
  userHash?: string;
  email: string;
  systemGeneratedPassword?: string;
  pwdLastChanged?: string;
  authenticateId?: string;
  sugarLogin?: string;
  firstName?: string;
  lastName?: string;
  isAdmin?: boolean;
  externalAuthOnly?: boolean;
  receiveNotifications?: boolean;
  description?: string;
  dateEntered?: string;
  dateModified?: string;
  modifiedUserId?: string;
  createdBy?: string;
  title?: string;
  photo?: string;
  department?: string;
  phoneHome?: string;
  phoneMobile?: string;
  phoneWork?: string;
  phoneOther?: string;
  phoneFax?: string;
  status?: string;
  addressStreet?: string;
  addressCity?: string;
  addressState?: string;
  addressCountry?: string;
  addressPostalcode?: string;
  deleted?: boolean;
  portalOnly?: boolean;
  showOnEmployees?: boolean;
  employeeStatus?: string;
  messengerId?: string;
  messengerType?: string;
  reportsToId?: string;
  isGroup?: boolean;
  factorAuth?: boolean;
  factorAuthInterface?: string;
  supervisor?: string;
  supervisorEmail?: string;
  draCertificationDate?: string;
  draTrainingDate?: string;
  draUrn?: string;
  udid?: string;
  mpin?: string;
  userType?: string;
  deviceId?: string;
  asId?: string;
  isdevicelockedinactivity?: boolean;
  ismpinlocked?: boolean;
  isdeviceregistered?: boolean;
  lastsuccessfullogintimestamp?: string;
  failedloginattemptscount?: number;
  isjailbrokenorrooted?: boolean;
  lastpasswordchangetimestamp?: string;
  logingeolocationflag?: boolean;
  devicefingerprint?: string;
  isaccountlocked?: boolean;
  isrecentdevicechange?: boolean;
  isbiometricauthenabled?: boolean;
  noOfWarningsIssued?: number;
  cessationOfServices?: boolean;
  deviceMobileHash?: string;
  collAgencyId?: string;
  agentType?: string;
  pincodeID?: string;
  mpinHash?: string;
  employeeCode?: string;
  reportingManager?: string;
  reportingManagerEmployeeCode?: string;
  appVersion?: string;
  // Extended fields for list display
  roles?: Role[];
  securityGroups?: SecurityGroup[];
}

// Role Types
export interface Role {
  id: string;
  dateEntered?: string;
  dateModified?: string;
  modifiedUserId?: string;
  createdBy?: string;
  name: string;
  description?: string;
  deleted?: boolean;
}

// Security Group Types
export interface SecurityGroup {
  id: string;
  dateEntered?: string;
  dateModified?: string;
  modifiedUserId?: string;
  createdBy?: string;
  name: string;
  description?: string;
  deleted?: boolean;
  inheritable?: boolean;
  stateMaster?: {
    stateName?: string;
  } | null;
  user?: User[] | null;
}

// Bank Detail Types
export interface BankDetail {
  id: string;
  bankName: string;
  accountNumber: string;
  dateEntered?: string;
  dateModified?: string;
  deleted?: boolean;
  hiveId?: string;
  branchName?: string;
  ifscCode?: string;
}

// Task Types
export interface CollReceipt {
  id: string;
  dateEntered?: string;
  dateModified?: string;
  deleted?: boolean;
  receiptNo?: string;
  receiptdate?: string;
  customerName?: string;
  currencyId?: string;
  collectedEmiAmount?: number;
  status?: string;
  latitude?: number;
  longitude?: number;
  receiptPdf?: string;
  transactionRefNo?: string;
  branchName?: string;
  receiptGenerationTime?: string;
  receiptStoredDateTime?: string;
  caseNo?: string;
  userId?: string;
  branchDepositSlipno?: string;
  bankDepositSlipno?: string;
  receivedSumOfRupees?: number;
  receivedSumInWords?: string;
  collectedBy?: string;
  remarks?: string;
  totalAmount?: number;
  collectedBounceAmount?: number;
  emiOverdueAmount?: number;
  hiveId?: string;
  collectedPenaltyAmount?: number;
  lanNumber?: string;
  serviceChargeTypeId?: string;
  paymentImage?: string;
  selfieImage?: string;
  acceptanceStatus?: string;
  rejectedBy?: string;
  rejectedUserId?: string;
  rejectedTime?: string;
  rejectedDate?: string;
  rejectedRemarks?: string;
  branchOpsUserId?: string;
  pay_EMI_only?: boolean;
  paymentType?: string;
  accountId?: string;
  serviceChargeType?: {
    name: string;
  };
}

export interface Account {
  id?: string;
  name?: string;
  lanNumber?: string;
  applicationNumber?: string;
  customerId?: string;
  coapplicantPhoneNumber?: string;
  emailAddress?: string | null;
  customerAddress?: string;
  billingAddressPostalcode?: string;
  customerPhoneNumber?: string;
  branch?: string;
  latitude?: number;
  longitude?: number;
  propertyType?: string;
  product?: string;
  propertyValue?: number;
  coapplicantAddress?: string;
  coapplicantGender?: string;
  propertyAddress?: string;
  loanAmount?: number | string;
  customerGender?: string;
  coApplicantName?: string;
  customerLatitude?: number;
  customerLongitude?: number;
  coapplicantLatitude?: number;
  coapplicantLongitude?: number;
  propertyLatitude?: number;
  propertyLongitude?: number;
  emiOverdue?: number;
  bounceCharge?: number;
  penalCharges?: number;
  emiAmount?: number;
  dpd?: number | string;
  deleted?: boolean;
  rmName?: string;
  bdmName?: string;
  location?: string;
  disbursementStatus?: string;
  nextDueDate?: string;
  buyOutOwn?: string;
  dataBy?: string | null;
  userId?: string;
  previousUserId?: string | null;
  reassignedOn?: string | null;
  user?: {
    id: string;
    userName?: string;
    reportingManagerEmployeeCode?: string;
    employeeCode?: string;
  };
  hiveId?: string;
  securityGroups?: Array<{
    id: string;
    name: string;
  }>;
}

export interface AccountContact {
  id: string;
  contactNumber?: string;
  contactName?: string;
  latitude?: number;
  longitude?: number;
  dateEntered: string;
  deleted?: boolean;
  dateModified?: string;
  accountId?: string;
  userId?: string;
  accountContactdateEntered?: string;
  hiveId?: string;
}

export interface AccountContactInput {
  contactNumber?: string;
  contactName?: string;
  accountContactdateEntered?: string;
  latitude?: number;
  longitude?: number;
  deleted?: boolean;
  accountId?: string;
  userId?: string;
  hiveId?: string;
}

export interface AccountAddressManagement {
  id: string;
  latitude?: number;
  longitude?: number;
  dateEntered: string;
  dateModified?: string;
  deleted?: boolean;
  address: string;
  accountId?: string;
  accountAddressDateTime?: string;
  collAgentId?: string;
  userId?: string;
  hiveId?: string;
  locname?: string;
}

export interface AccountAddressManagementInput {
  latitude?: number;
  longitude?: number;
  address: string;
  accountId?: string;
  userId?: string;
  locname?: string;
  hiveId?: string;
  deleted?: boolean;
  accountAddressDateTime?: string;
}


export interface Case {
  id: string;
  isAccountOnly?: boolean;
  name?: string;
  dateEntered?: string;
  dateModified?: string;
  caseNumber?: string;
  createdBy?: string;
  totalOverdue?: number;
  amountCollected?: number;
  deleted?: boolean;
  status?: string;
  state?: string;
  accountId?: string;
  lastVisitDate?: string;
  nextActionDate?: string;
  creationDate?: string;
  latitude?: number;
  longitude?: number;
  category?: string;
  userId?: string;
  emi?: number;
  reasonForNonPayment?: string;
  emiOverdue?: number;
  bounceCharge?: number;
  penalCharges?: number;
  pendingInstallmentOverdue?: number;
  pendingBounceCharge?: number;
  pendingPenaltyCharge?: number;
  collectedInstallmentOverdue?: number;
  collectedBounceCharge?: number;
  collectedPenaltyCharge?: number;
  ptpDateDay?: string;
  ptpCounter?: number;
  nextActionTime?: string;
  loanNumber?: string;
  dpd?: number | string;
  ptpAttemptCount?: number;
  serviceChargeTypeId?: string;
  parentCaseId?: string;
  emiAmount?: number;
  securityGroups?: Array<{
    id: string;
    name?: string;
  }>;
  collReceipts?: CollReceipt[];
  caseDispositions?: CaseDisposition[];
  account?: Account;
  agentName?: string;
  UserCases?: Array<{
    id: string;
    userId?: {
      id?: string;
      userName?: string;
      collAgencyId?: string;
      deleted?: boolean;
    };
  }>;
}

// Task display type
export interface Task {
  id: string;
  isAccountOnly?: boolean;
  accountId?: string;
  taskNumber: string;
  customerName: string;
  agentName: string;
  receiptNo: string;
  paymentMode: string;
  transactionRefNo: string;
  lan: string;
  branch: string;
  product: string;
  emiOverdue: number;
  receivedAmount: number;
  dpd: number;
  status: string;
  disposition: string;
  dateCreated: string;
  dateCreatedRaw: string;
  lastModified: string;
  lastModifiedRaw: string;
  receipt?: CollReceipt | null;
  activityDate?: string;
  activityBy?: string;
  emiAmount?: number;
  account?: Account;
  serviceChargeTypeId?: string;
  UserCases?: UserCase[];
  securityGroups?: Array<{
    id: string;
    name?: string;
  }>;
}

export interface UserCase {
  id: string;
  userId?: {
    id?: string;
    userName?: string;
  };
}

export interface AdvancedFilterParams {
  dateType: CommonDateType;
  dateRange: { from?: Date; to?: Date };
  branch: string;
  state: string;
  agent: string;
  disposition: string;
  status: string;
  lan: string;
  receipt: string;
  emiPendingBucket: string;
  dpdFrom?: number;
  dpdTo?: number;
}

export interface AdvancedFilterParamsCases {
  branch: string;
  state: string;
  agent: string;
  lan: string;
}


// Deposit Types
export interface Deposit {
  id: string;
  dateEntered?: string;
  dateModified?: string;
  deleted?: boolean;
  depositSlipno?: string;
  lannumber?: string;
  branchDepositionDate?: string;
  branchDepositAmount?: number;
  branchDepositTime?: string;
  branchName?: string;
  userId?: string;
  typeOfDeposit?: string;
  branchDepositRemarks?: string;
  branchOpsName?: string;
  hiveId?: string;
  userName?: string;
  status?: string;
  branchOpsUserId?: string;
  verifiedBy?: string;
  verifiedUserId?: string;
  verifiedTime?: string;
  verifiedDate?: string;
  verificationRemarks?: string;
  depositSlipImage?: string;
  acceptancePendingRemarks?: string;
  acceptancePendingTime?: string;
  acceptancePendingDate?: string;
  bankDepositDate?: string;
  bankDepositTime?: string;
  bankDepositRemarks?: string;
  bankDepositedBy?: string;
  bankDepositedUserId?: string;
  bankName?: string;
  bankAccountNumber?: string;
  bankDepositedAmount?: number;
  rejectedDate?: string;
  rejectedTime?: string;
  rejectedUserId?: string;
  rejectedRemarks?: string;
  rejectedBy?: string;
  branchDepositedLongitude?: number;
  branchDepositedLatitude?: number;
  bankDepositedLongitude?: number;
  bankDepositedLatitude?: number;
  depositTypeId?: string;
  collReceipts?: CollReceipt[];
  bankCollReceipts?: CollReceipt[];
  user?: User;
  depositType?: {
    id: string;
    name?: string;
    dateEntered?: string;
    dateModified?: string;
    deleted?: boolean;
    hiveId?: string;
  };
}

// Receipt Editable Check Response
export interface CheckReceiptEditableResponse {
  editable: boolean;
  reasons: string[];
}

// Delete Receipt Response
export interface DeleteReceiptResponse {
  status: string;
  message: string;
  spResponse?: string | null;
}

// Recreate Receipt Input
export interface RecreateReceiptInput {
  oldReceiptNo: string;
  newCollectedEmiAmount: number;
  newCollectedBounceAmount: number;
  newCollectedPenaltyAmount: number;
  newAmountCollected?: number | null;
  newTransactionRefNo?: string | null;
  newReceiptDate?: string | null;
  remarks?: string | null;
  nextActionTime?: string | null;  // Format: HH:MM (e.g., "12:20")
  nextActionDate?: string | null;  // Format: YYYY-MM-DD (e.g., "2026-01-12")
}

// Recreate Receipt Response
export interface RecreateReceiptResponse {
  success: boolean;
  message: string;
  newReceipt: CollReceipt | null;
  oldReceipt: CollReceipt | null;
}

// Paginated Response Type
export interface PaginatedResponse<T> {
  content: T[];
  pageNumber: number;
  pageSize: number;
  totalElements: number;
  totalPages: number;
  first: boolean;
  last: boolean;
  empty: boolean;
}

export interface DepositSearchResult {
  id: string;
  depositSlipno: string;
  bankDepositDate: string;
  branchDepositionDate: string;
  branchDepositAmount: string;
  bankDepositedAmount: string;
  status: string;
  bankName: string;
  bankDepositedBy: string;
  userName: string;
  typeOfDeposit: string;
  bankCollReceipts: {
    id: string;
    lanNumber: string;
    customerName: string;
    transactionRefNo: string;
    receiptStoredDateTime: string;
    collectedBy: string;
    branchName: string;
    receiptNo: string;
    totalAmount: string;
    status: string;
    hiveId: string;
    paymentType: string;
  }[];
  collReceipts: {
    id: string;
    lanNumber: string;
    customerName: string;
    transactionRefNo: string;
    receiptStoredDateTime: string;
    collectedBy: string;
    branchName: string;
    receiptNo: string;
    totalAmount: string;
    status: string;
    hiveId: string;
  }[];
}

export interface SearchDepositResponse {
  totalRecords: number;
  totalPages: number;
  currentPage: number;
  size: number;
  numberOfRecords: number;
  hasNext: boolean;
  hasPrevious: boolean;
  content: DepositSearchResult[];
}

// GraphQL Response Wrappers
export interface GraphQLResponse<T> {
  data: T;
  errors?: Array<{
    message: string;
    locations?: Array<{ line: number; column: number }>;
    path?: Array<string | number>;
  }>;
}

// Notes Search Criteria Types
export interface NoteSearchCriteriaParams {
  loanNumber: string;
  page: number;
  size: number;
  year?: number;
  month?: number;
}

export interface NoteAssociation {
  loanNumber?: string;
  caseId?: string;
}

export interface NoteFromCriteriaAPI {
  id: string;
  noteTypeName: string; // "TASK" or "CASE"
  content: string;
  authorName: string;
  authorRole?: string;
  createdAt: string;
  taskNumber?: string;
  associations: NoteAssociation[];
  deleted: boolean;
  noteTypeId?: number;
  loanNumber?: string;
  caseId?: string;
  authorUserId?: string;
  criticality?: number;
  updatedAt?: string;
}

export interface PaginatedNotesResponse {
  content: NoteFromCriteriaAPI[];
  pageNumber: number;
  pageSize: number;
  totalElements: number;
  totalPages: number;
  first: boolean;
  last: boolean;
  empty: boolean;
}

// Assign Tasks Types
export interface AgentRecord {
  id: string;
  userName: string;
}

export interface GetUsersBySecurityGroupIdResponse {
  records: AgentRecord[];
  hasNext: boolean;
  hasPrev: boolean;
}

export interface AssignCasesToUserResponse {
  message: string;
  failedIds: string[];
  successCount: number;
}

export interface BranchRecord {
  id: string;
  name: string;
}

export interface StateSecurityGroup {
  stateId: string;
  stateName: string;
  branches: BranchRecord[];
}

export interface GetStateSecurityGroupsResponse {
  getStateSecurityGroups: StateSecurityGroup[];
}

export interface SearchCasesOptions {
  limit?: number;
  offset?: number;
  query?: string;
  lanNumber?: string;
  receiptNo?: string;
  taskNumber?: string;
  branchName?: string;
  agentName?: string;
  status?: string;
  fromDate?: string;
  toDate?: string;
  dateType?: string;
  bankName?: string;
  forDeposit?: boolean;
  dpdFrom?: number;
  dpdTo?: number;
  acceptanceStatus?: string;
  state?: string;
  export?: boolean;
}

export interface SearchCasesResponse {
  totalRecords: number;
  totalPages: number;
  currentPage: number;
  size: number;
  numberOfRecords: number;
  hasNext: boolean;
  hasPrevious: boolean;
  content: Case[];
  casePendingCount?: number;
  pendingCount?: number;
  acceptancePendingCount?: number;
  branchOpsInHandCount?: number;
  verificationPendingCount?: number;
  verificationCompletedCount?: number;
  verifiedByHOCount?: number;
}

export interface EmiPendingBucket {
  id: string;
  fromRange: number;
  toRange: number;
  bucketCode: string;
}

export type CommonDateType = "ACTIVITY_DATE" | "MODIFIED_DATE";
export type DepositDateType = CommonDateType | "DEPOSIT_DATE";

export type VerificationType = "APPROVE" | "REJECT" | "ACCEPT";

export interface ProcessBankDepositSlipVerificationResult {
  message: string;
  failureBankDepositSlipIds: string[];
  successBankDepositSlipIds: string[];
  failureMessages: string[];
}

export interface ProcessedReceipt {
  id: string;
  acceptanceStatus?: string;
  rejectedBy?: string;
  rejectedUserId?: string;
  rejectedDate?: string;
  rejectedTime?: string;
  rejectedRemarks?: string;
  branchDepositSlipno?: string;
  totalAmount?: number;
}

export interface ConsolidateReceiptAcceptanceRejectionInput {
  receiptIds: string[];
  action: "ACCEPT" | "REJECT";
  remarks: string;
  date?: string;
  time?: string;
}

export interface ConsolidateReceiptAcceptanceRejectionResult {
  success: boolean;
  message: string;
  totalProcessed: number;
  totalFailed: number;
  errors?: string[];
  action?: string;
  acceptanceStatus?: string;
  date?: string;
  time?: string;
  remarks?: string;
  receiptIds?: string[];
  branchDepositSlipnos?: string[];
  rejectedBy?: string;
  rejectedUserId?: string;
  branchDepositAmount?: number;
  depositStatus?: string;
  depositDeleted?: boolean;
  processedReceipts?: ProcessedReceipt[];
}

export interface CreateDepositInput {
  depositSlipType: string;
  receiptIds: string[];
  date: string;
  time: string;
  remarks: string;
  latitude: number;
  longitude: number;
  bankName: string;
  accountNo: string;
  depositSlipImagePath: string;
  totalAmount: string;
}

export interface CreateDepositResponse {
  createDeposit: {
    depositSlipNo: string;
    message: string;
    id: string;
  };
}

export interface ProcessBankDepositSlipVerificationResponse {
  processBankDepositSlipVerification: ProcessBankDepositSlipVerificationResult;
}

// Case Activity History Types
export interface BaseActivityHistory {
  id: string;
  type: "DISPOSITION" | "RECEIPT";
  date: string;
  caseId: string;
  caseNumber: string;
  hiveId?: string;
  latitude?: number;
  longitude?: number;
  hasPaymentImagePath?: boolean;
  hasSelfieImagePath?: boolean;
  remarks?: string;
  activityBy?: string;
}

export interface DispositionHistory extends BaseActivityHistory {
  type: "DISPOSITION";
  activityName: string;
  nextActionDate?: string;
  nextActionTime?: string;
  counter?: number;
}

export interface ReceiptHistory extends BaseActivityHistory {
  type: "RECEIPT";
  status?: string;
  receiptNo?: string;
  collectedAmount?: number;
  receiptGenerationTime?: string;
  due?: number;
  paymentMode?: string;
}

export type CaseActivityHistory = DispositionHistory | ReceiptHistory;

export interface GetCaseActivityHistoryResponse {
  getCaseActivityHistory: CaseActivityHistory[];
}

export interface CaseDisposition {
  activityDate?: string;
  deleted?: boolean;
  userName?: string;
}

export type EntityType = 
    | "RECEIPT"
    | "DEPOSIT_SLIP"
    | "CASE"
    | "CASE_DISPOSITION"
    | "ACCOUNT"
    | "USER_CASE";

export interface CaseAuditHistory {
  id: string;
  action: string;
  changedAt: string;
  currentData: string;
  entityId: string;
  entityType: string;
  fieldChanges: string | null;
  isSystem: boolean;
  modifiedUserId: string;
  modifiedUserName: string;
  parentId: string;
  version: number;
  // Legacy fields for compatibility if needed
  username?: string;
  createdAt?: string;
}

export interface GetAuditHistoryResponse {
  getAuditHistory: {
    content: CaseAuditHistory[];
    currentPage: number;
    hasNext: boolean;
    hasPrevious: boolean;
    size: number;
    totalPages: number;
    totalRecords: number;
  };
}

export type CaseAuditReceiptHistory = CaseAuditHistory;
export type GetCaseAuditReceiptHistoryResponse = GetAuditHistoryResponse;
export type GetCaseAuditHistoryResponse = GetAuditHistoryResponse;