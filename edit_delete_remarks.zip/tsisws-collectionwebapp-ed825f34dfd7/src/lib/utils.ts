import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { format, parseISO, isValid } from "date-fns"
import type { Task } from "./types"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Format a date string for note display
 * Output format: DD/MM/YYYY, h:mm:ss a (e.g., "05/01/2024, 5:30:00 AM")
 */
export function formatNoteDate(isoDate: string): string {
  try {
    const date = parseISO(isoDate)
    if (!isValid(date)) {
      return isoDate // Return original if invalid
    }
    return format(date, "dd/MM/yyyy, h:mm:ss a")
  } catch {
    return isoDate // Return original on error
  }
}

/**
 * Format an ISO date string to a human-readable date and time
 * Output format: DD MMM YYYY, hh:mm A (e.g., "25 Feb 2026, 06:21 PM")
 */
export function formatDateTime(isoDate: string | null | undefined): string {
  if (!isoDate) return "-";
  try {
    const date = parseISO(isoDate);
    if (!isValid(date)) {
      return isoDate;
    }
    return format(date, "dd MMM yyyy, hh:mm a");
  } catch {
    return isoDate;
  }
}

/* Utility to download a Blob object as a file in the browser */
export function downloadBlob(blob: Blob, filename: string) {
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  link.parentNode?.removeChild(link);
  window.URL.revokeObjectURL(url);
}

/* Utility to export tasks to a CSV file */
export const exportTasksToCSV = (tasksToExport: Task[]) => {
  // Define export columns (matching visible columns)
  const exportColumns = [
    { key: "taskNumber", header: "Case Number" },
    { key: "receiptNo", header: "Receipt Id" },
    { key: "paymentMode", header: "Payment Mode" },
    { key: "transactionRefNo", header: "Transaction Id" },
    { key: "lan", header: "Lan Number" },
    { key: "branch", header: "Branch" },
    { key: "product", header: "Product" },
    { key: "emiOverdue", header: "Emi Overdue" },
    { key: "receivedAmount", header: "Amount Paid" },
    { key: "dpd", header: "Dpd" },
    { key: "status", header: "Status" },
    { key: "disposition", header: "Disposition" },
    { key: "lastModified", header: "Date Modified" },
    { key: "activityDate", header: "Activity Date" },
  ];

  const headers = exportColumns.map((col) => col.header);

  const rows = tasksToExport.map((task) => {
    return exportColumns.map((col) => {
      const value = task[col.key as keyof Task];

      if (value === null || value === undefined) {
        return "";
      }

      if (typeof value === "number") {
        return value.toString();
      }

      const stringValue = String(value);
      if (stringValue.includes(",") || stringValue.includes('"') || stringValue.includes("\n")) {
        return `"${stringValue.replace(/"/g, '""')}"`;
      }

      return stringValue;
    });
  });

  // Combine headers and rows
  const csvContent = [
    headers.join(","),
    ...rows.map((row) => row.join(",")),
  ].join("\n");

  // Create blob and download
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);

  link.setAttribute("href", url);
  link.setAttribute("download", `tasks_${format(new Date(), "yyyy-MM-dd_HH-mm-ss")}.csv`);
  link.style.visibility = "hidden";

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  URL.revokeObjectURL(url);
};

/**
 * Generate a unique ID (UUID or random fallback)
 */
export function generateUUID(prefix: string = ''): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }
  const randomPart = Math.random().toString(36).slice(2);
  return prefix ? `${prefix}-${randomPart}` : randomPart;
}
/**
 * Orchestrate the export of tasks to CSV, handling fetching, empty states, and notifications.
 */
export const handleExportTasks = async (
  fetcher: () => Promise<{ tasks: Task[] }>,
  toast: (props: { title: string; description: string; variant?: "default" | "destructive" | "warning" }) => void,
  setIsExporting: (isExporting: boolean) => void
) => {
  setIsExporting(true);
  try {
    const { tasks: allTasks } = await fetcher();
    if (allTasks.length === 0) {
      toast({
        title: "No Data",
        description: "No tasks available to export.",
        variant: "destructive",
      });
      return;
    }
    exportTasksToCSV(allTasks);
    toast({
      title: "Export Successful",
      description: `${allTasks.length} tasks exported.`,
    });
  } catch (err) {
    toast({
      title: "Export Failed",
      description: err instanceof Error ? err.message : "Export failed.",
      variant: "destructive",
    });
  } finally {
    setIsExporting(false);
  }
};
