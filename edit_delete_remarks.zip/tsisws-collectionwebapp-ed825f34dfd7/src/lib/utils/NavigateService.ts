import { useNavigate, type NavigateFunction } from 'react-router-dom';
import { useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';

/**
 * NavigateService allows non-React files (like API clients) to perform 
 * React Router navigation and trigger global application actions like logout.
 */
let navigateInstance: NavigateFunction | null = null;
let logoutInstance: ((options?: { skipApiCall?: boolean }) => Promise<void>) | null = null;

export const SESSION_EXPIRED_EVENT = 'SESSION_EXPIRED_EVENT';

export const NavigateService = {
    setNavigate(navigate: NavigateFunction) {
        navigateInstance = navigate;
    },

    setLogout(logout: (options?: { skipApiCall?: boolean }) => Promise<void>) {
        logoutInstance = logout;
    },

    navigate(to: string, options?: any) {
        if (navigateInstance) {
            navigateInstance(to, options);
        } else {
            console.warn('NavigateService: Instance not set. Falling back to window.location.');
            window.location.href = to;
        }
    },

    /**
     * Triggers the session expired modal instead of immediate logout.
     */
    triggerSessionExpiry(message?: string) {
        window.dispatchEvent(new CustomEvent(SESSION_EXPIRED_EVENT, { detail: { message } }));
    },

    /**
     * Triggers the full application logout logic and redirects to login.
     * Use skipApiCall to avoid redundant/failing network requests during a timeout.
     */
    async logout(options: { skipApiCall?: boolean } = { skipApiCall: true }) {
        if (logoutInstance) {
            await logoutInstance(options);
        }
        this.navigate('/login', { replace: true });
    }
};

/**
 * Component to initialize the NavigateService within the Router and Auth context.
 * Must be mounted inside both <BrowserRouter> and <AuthProvider>.
 */
export const NavigateSetter = () => {
    const navigate = useNavigate();
    const { logout } = useAuth();

    useEffect(() => {
        NavigateService.setNavigate(navigate);
    }, [navigate]);

    useEffect(() => {
        NavigateService.setLogout(logout);
    }, [logout]);

    return null;
};
