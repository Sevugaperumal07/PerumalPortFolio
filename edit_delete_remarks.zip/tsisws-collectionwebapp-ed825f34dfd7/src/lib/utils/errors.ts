/**
 * Custom error class for API failures that includes status and error codes.
 */
export class ApiError extends Error {
  status?: number;
  code?: string;

  constructor(message: string, status?: number, code?: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;

    Object.setPrototypeOf(this, ApiError.prototype);
  }
}

/**
 * Custom error class to signal that a session has expired.
 * This allows the application to distinguish between authentication failures 
 * (which require a re-login) and authorization failures (permissions).
 */
export class SessionExpiredError extends Error {
  constructor(message: string = 'Session expired') {
    super(message);
    this.name = 'SessionExpiredError';

    // Set the prototype explicitly to ensure instanceof works correctly
    Object.setPrototypeOf(this, SessionExpiredError.prototype);
  }
}

