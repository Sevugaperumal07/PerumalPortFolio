import { jsPDF } from 'jspdf';
import type { CollReceipt } from '../types';
import splashLogo from '@/assets/splash.png';

export class ReceiptPdfGenerator {
  private receipt: CollReceipt;

  constructor(receipt: CollReceipt) {
    this.receipt = receipt;
  }

  private formatAmount(value: unknown): string {
    const num = parseFloat(String(value));
    if (isNaN(num)) return 'N/A';
    return num.toFixed(1); // Always show as float with one decimal e.g. 34.0
  }

  private formatValue(value: unknown): string {
    if (value === null || value === undefined || String(value).trim() === '') return 'N/A';
    return String(value);
  }

  public generateAndPreview(): void {
    const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
    const leftMargin = 15;
    const rightMargin = pageWidth - 15;
    const labelX = leftMargin;
    const valueX = rightMargin;

    // ── HEADER ──────────────────────────────────────────────────
    // Logo - top left
    doc.addImage(splashLogo, 'PNG', leftMargin, 12, 48, 22);

    // Title - top right (bold)
    doc.setFontSize(13);
    doc.setFont('helvetica', 'bold');
    doc.text('Payment Receipt (Customer Copy)', valueX, 18, { align: 'right' });

    // Receipt No subtitle - top right (normal)
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text(
      `Receipt No.: ${this.formatValue(this.receipt.receiptNo)}`,
      valueX,
      25,
      { align: 'right' }
    );

    // Horizontal divider after header
    let y = 37;

    y += 5;

    // ── ROWS ─────────────────────────────────────────────────────

    const rows: { label: string; value: string }[] = [
      { label: 'Customer Name:', value: this.formatValue(this.receipt.customerName) },
      { label: 'Receipt No:', value: this.formatValue(this.receipt.receiptNo) },
      { label: 'Received Sum of Rupees:', value: this.formatAmount(this.receipt.totalAmount) },
      { label: 'Date:', value: this.formatValue(this.receipt.receiptdate) },
      { label: 'Time:', value: this.formatValue(this.receipt.receiptGenerationTime) },
      { label: 'Received Sum of Rupees (Words) :', value: this.formatValue(this.receipt.receivedSumInWords) },
      { label: 'Branch:', value: this.formatValue(this.receipt.branchName) },
      { label: 'Application No / Loan Code:', value: this.formatValue(this.receipt.lanNumber) },
      { label: 'Collected By:', value: this.formatValue(this.receipt.collectedBy) },
      { label: 'EMI Overdue Amount:', value: this.formatAmount(this.receipt.emiOverdueAmount) },
      { label: 'Collected EMI Amount:', value: this.formatAmount(this.receipt.collectedEmiAmount) },
      { label: 'Collected Bounce Amount:', value: this.formatAmount(this.receipt.collectedBounceAmount) },
      { label: 'Collected Penalty Amount:', value: this.formatAmount(this.receipt.collectedPenaltyAmount) },
      { label: 'Payment Type:', value: this.formatValue(this.receipt.paymentType) },
      { label: 'Service Payment Type:', value: this.formatValue(this.receipt.serviceChargeType?.name) },
      { label: 'Transaction ID:', value: this.formatValue(this.receipt.transactionRefNo) },
    ];

    const rowHeight = 9;
    doc.setFontSize(10.5);

    for (const row of rows) {
      // Label: bold
      doc.setFont('helvetica', 'bold');
      doc.text(row.label, labelX, y);

      // Value: normal
      doc.setFont('helvetica', 'bold');
      doc.text(row.value, valueX, y, { align: 'right' });

      y += rowHeight;
    }

    // ── DIVIDER ───────────────────────────────────────────────────
    doc.setDrawColor(100);
    doc.setLineWidth(0.4);
    doc.line(leftMargin, y, rightMargin, y);
    y += 8;

    // ── TOTAL AMOUNT (bold label + bold value) ────────────────────
    doc.setFontSize(10.5);
    doc.setFont('helvetica', 'bold');
    doc.text('Total Amount:', labelX, y);
    doc.text(this.formatAmount(this.receipt.totalAmount), valueX, y, { align: 'right' });
    y += rowHeight;

    // ── REMARKS ───────────────────────────────────────────────────
    const remarksLabel = 'Remarks:';
    const remarksValue = this.receipt.remarks?.trim() || '';
    doc.setFont('helvetica', 'bold');
    doc.text(remarksLabel, labelX, y);
    if (remarksValue !== '') {
    const labelWidth = doc.getTextWidth(remarksLabel);
    const valueStartX = labelX + labelWidth + 2; 
    const maxValueWidth = pageWidth - valueStartX - 15; 
    doc.setFont('helvetica', 'bold');
    const words = remarksValue.split(' ');
    let firstLine = '';
    let remainder = '';
    let firstLineDone = false;
    for (const word of words) {
        const test = firstLine ? `${firstLine} ${word}` : word;
        if (!firstLineDone && doc.getTextWidth(test) <= maxValueWidth) {
        firstLine = test;
        } else {
        firstLineDone = true;
        remainder = remainder ? `${remainder} ${word}` : word;
        }
    }
    doc.text(firstLine, valueStartX, y);
    if (remainder) {
        y += 6;
        doc.text(remainder, labelX, y, { maxWidth: pageWidth - labelX - 15 });
        const wrappedLines = doc.splitTextToSize(remainder, pageWidth - labelX - 15);
        y += (wrappedLines.length - 1) * 6;
    }

    y += 10;
    } else {
    y += 8;
    }

    // ── FOOTER ────────────────────────────────────────────────────
    y += 2;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(
      "This document is computer-generated and does not require the Registrar's signature or the Company's stamp.",
      pageWidth / 2,
      y,
      { align: 'center', maxWidth: pageWidth - 20 }
    );
    y += 10;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(
      'Corporate Office: B-003, 215 Kanakia Atrium, Andheri - Kurla Rd, Mumbai, Maharashtra 400093',
      pageWidth / 2,
      y,
      { align: 'center', maxWidth: pageWidth - 20 }
    );

    // ── OPEN PREVIEW ──────────────────────────────────────────────
    window.open(doc.output('bloburl'), '_blank');
  }
}