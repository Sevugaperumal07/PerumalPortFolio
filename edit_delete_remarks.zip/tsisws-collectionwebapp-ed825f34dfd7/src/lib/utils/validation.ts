/**
 * RFC 5322 compliant regex (simplified for practical web use)
 * Matches standard email addresses while allowing standard special characters.
 */
export const EMAIL_REGEX = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/;

/**
 * Validates an email address against RFC 5322 standards.
 * @returns Error message if invalid, or an empty string if valid.
 */
export function validateEmail(email: string): string {
  if (!email) return "Email address is required.";
  if (!EMAIL_REGEX.test(email)) return "Please enter a valid email address.";
  return "";
}
