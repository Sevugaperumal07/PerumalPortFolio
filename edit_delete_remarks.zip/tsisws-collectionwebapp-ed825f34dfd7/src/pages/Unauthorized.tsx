import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { ShieldAlert } from "lucide-react";

export default function Unauthorized() {
    const { logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = async () => {
        await logout();
        navigate("/login", { replace: true });
    };

    return (
        <div className="flex h-screen w-full flex-col items-center justify-center bg-muted/40 p-4 text-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-rose-100 mb-6">
                <ShieldAlert className="h-10 w-10 text-rose-600" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-neutral-900 sm:text-4xl">
                Access Denied
            </h1>
            <p className="mt-4 text-lg text-neutral-600 max-w-md">
                You don't have permission to access this page. Please contact your administrator if you believe this is a mistake.
            </p>
            <div className="mt-10 flex gap-4">
                <Button
                    onClick={handleLogout}
                    className="bg-rose-600 hover:bg-rose-700 px-8"
                >
                    Return to Login
                </Button>
            </div>
        </div>
    );
}
