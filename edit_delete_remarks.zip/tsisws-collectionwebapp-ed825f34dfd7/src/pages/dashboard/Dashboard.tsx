import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { FileX, Loader2 } from 'lucide-react';
import { config } from '@/config';
import { apiFetch } from '@/lib/api/api-fetch';

interface IDashboard {
  dashboard_id: number;
  dashboard_name: string;
  embed_url: string;
}

export default function Dashboard() {
  const [dashboards, setDashboards] = useState<IDashboard[]>([]);
  const [activeTab, setActiveTab] = useState<number | null>(null);
  const [embedUrl, setEmbedUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDashboards = async () => {
      setLoading(true);
      setError(null);

      try {
        const data = await apiFetch<IDashboard[]>(
          `/api/v1/dashboards/published/for-user`,
          {
            method: 'GET',
            baseUrl: config.api.dashboardUrl,
          }
        );

        const fetchedDashboards = Array.isArray(data) ? data : [];
        
        if (fetchedDashboards.length === 0) {
          setError('No dashboards available');
          setLoading(false);
          return;
        }

        setDashboards(fetchedDashboards);
        // Set first dashboard as active tab
        if (fetchedDashboards.length > 0) {
          setActiveTab(fetchedDashboards[0].dashboard_id);
        }
        setLoading(false);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch dashboards');
        setLoading(false);
      }
    };

    fetchDashboards();
  }, []);

  useEffect(() => {
    if (activeTab === null || dashboards.length === 0) {
      return;
    }

    const fetchDashboardUrl = async () => {
      setLoading(true);
      setError(null);
      setEmbedUrl(null);

      try {
        const data = await apiFetch<IDashboard[]>(
          `/api/v1/dashboards/published/for-user`,
          {
            method: 'GET',
            baseUrl: config.api.dashboardUrl,
          }
        );

        const fetchedDashboards = Array.isArray(data) ? data : [];
        
        const selectedDashboard = fetchedDashboards.find(
          (dashboard) => dashboard.dashboard_id === activeTab
        );

        if (!selectedDashboard) {
          setError(`Dashboard not found`);
          setLoading(false);
          return;
        }

        if (!selectedDashboard.embed_url) {
          setError('Embed URL not available for this dashboard');
          setLoading(false);
          return;
        }

        setEmbedUrl(selectedDashboard.embed_url);
        setLoading(false);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch dashboard');
        setLoading(false);
      }
    };

    fetchDashboardUrl();
  }, [activeTab, dashboards.length]);

  const handleTabChange = (dashboardId: number) => {
    setActiveTab(dashboardId);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold mb-2">Analytics Dashboards</h1>
        <p className="text-sm sm:text-base text-muted-foreground">
          Your centralized view for data and insights.
        </p>
      </div>

      <div className="flex flex-col flex-1">
        <div className="flex gap-1 border-b border-border mb-6">
          {dashboards.map((dashboard) => (
            <button
              key={dashboard.dashboard_id}
              onClick={() => handleTabChange(dashboard.dashboard_id)}
              className={cn(
                'px-4 py-2 text-sm font-medium transition-colors border-b-2',
                activeTab === dashboard.dashboard_id
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground'
              )}
            >
              {dashboard.dashboard_name}
            </button>
          ))}
        </div>

        <div className="flex-1 bg-muted/40 rounded-lg flex items-center justify-center min-h-[900px] relative overflow-hidden">
          {loading && (
            <div className="flex flex-col items-center gap-4 text-muted-foreground">
              <Loader2 className="h-16 w-16 animate-spin" />
              <p className="text-sm">Loading dashboard...</p>
            </div>
          )}

          {error && !loading && (
            <div className="flex flex-col items-center gap-4 text-muted-foreground">
              <FileX className="h-16 w-16" />
              <p className="text-sm">{error}</p>
            </div>
          )}

          {embedUrl && !loading && !error && (
            <iframe
              src={embedUrl}
              className="absolute inset-0 w-full h-full border-0"
              title={`Dashboard: ${dashboards.find((d: IDashboard) => d.dashboard_id === activeTab)?.dashboard_name || ''}`}
              allowFullScreen
            />
          )}
        </div>
      </div>
    </div>
  );
}

