import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { generateUUID } from '@/lib/utils';
import { createBankDetail, linkBankDetailsToSecurityGroup } from '@/lib/services/bank-details';
import { useSecurityGroups } from '@/hooks/bank/useSecurityGroups';
import { SearchableSelect } from '@/components/ui/searchable-select';
import type { SecurityGroup } from '@/lib/types';

const bankDetailFormSchema = z.object({
  bankName: z.string().min(1, 'Bank name is required').regex(/^[a-zA-Z\s]+$/, 'Numeric & Special Characters are not allowed'),
  accountNumber: z.string()
    .max(19, 'Account number cannot exceed 19 digits')
    .regex(/^[a-zA-Z0-9]+$/, 'Special Characters are not allowed'),
  branchName: z.string().min(1, 'Branch name is required').regex(/^[a-zA-Z\s]+$/, 'Numeric & Special Characters are not allowed'),
  ifscCode: z.string().min(1, 'IFSC code is required').regex(/^[a-zA-Z0-9]+$/, 'Special Character are not allowed'),
  hiveId: z.string().min(1, 'Hive ID is required'),
  securityGroupId: z.string().min(1, 'Security Group is required'),
});

type BankDetailFormValues = z.infer<typeof bankDetailFormSchema>;

export default function AddBankDetail() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const form = useForm<BankDetailFormValues>({
    resolver: zodResolver(bankDetailFormSchema),
    mode: 'onChange',
    defaultValues: {
      bankName: '',
      accountNumber: '',
      branchName: '',
      ifscCode: '',
      hiveId: generateUUID('bank'),
      securityGroupId: '',
    },
  });

  const { securityGroups, loading: groupsLoading } = useSecurityGroups();

  const handleSubmit = async (data: BankDetailFormValues) => {
    if (loading) return; // Prevent double submission

    try {
      setLoading(true);

      // Validate all required fields are filled
      if (!data.bankName?.trim() || !data.accountNumber?.trim() ||
        !data.branchName?.trim() || !data.ifscCode?.trim() || !data.hiveId?.trim()) {
        toast({
          title: 'Validation Error',
          description: 'All fields are required. Please fill in all fields.',
          variant: 'destructive',
        });
        return;
      }

      const payload = {
        bankName: data.bankName.trim(),
        accountNumber: data.accountNumber.trim(),
        branchName: data.branchName.trim(),
        ifscCode: data.ifscCode.trim(),
        hiveId: data.hiveId.trim(),
        deleted: false,
      };


      const result = await createBankDetail(payload);

      if (result && result.id) {
        // Link to Security Group
        await linkBankDetailsToSecurityGroup(result.id, data.securityGroupId);

        toast({
          title: 'Success',
          description: 'Bank detail created and linked to security group successfully',
        });
        setTimeout(() => {
          navigate('/dashboard/bank-details', {
            state: { refresh: true, timestamp: Date.now() }
          });
        }, 500);
      } else {
        throw new Error('No valid response from server. Bank detail may not have been created.');
      }
    } catch (error) {
      const errorMessage = error instanceof Error
        ? error.message
        : 'Failed to create bank detail. Please try again.';

      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold">Add Bank Detail</h1>
        <p className="text-sm sm:text-base text-muted-foreground">Create a new bank account detail</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Bank Information</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 sm:space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="bankName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bank Name <span className="text-red-500 ml-0.5">*</span></FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          onChange={(e) => {
                            const rawValue = e.target.value;
                            const strippedValue = rawValue.replace(/[^a-zA-Z\s]/g, '');

                            field.onChange(strippedValue);

                            if (rawValue !== strippedValue) {
                              setTimeout(() => {
                                form.setError('bankName', {
                                  type: 'manual',
                                  message: 'Numeric & Special Characters are not allowed'
                                });
                              }, 0);
                            } else {
                              form.clearErrors('bankName');
                            }
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="accountNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account Number <span className="text-red-500 ml-0.5">*</span></FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          minLength={8}
                          maxLength={19}
                          onChange={(e) => {
                            const rawValue = e.target.value;
                            const strippedValue = rawValue.replace(/[^a-zA-Z0-9]/g, '');

                            field.onChange(strippedValue);

                            if (rawValue !== strippedValue) {
                              setTimeout(() => {
                                form.setError('accountNumber', {
                                  type: 'manual',
                                  message: 'Special Characters are not allowed'
                                });
                              }, 0);
                            } else {
                              form.clearErrors('accountNumber');
                            }
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="branchName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Branch Name <span className="text-red-500 ml-0.5">*</span></FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          onChange={(e) => {
                            const rawValue = e.target.value;
                            const strippedValue = rawValue.replace(/[^a-zA-Z\s]/g, '');

                            field.onChange(strippedValue);

                            if (rawValue !== strippedValue) {
                              setTimeout(() => {
                                form.setError('branchName', {
                                  type: 'manual',
                                  message: 'Numeric & Special Characters are not allowed'
                                });
                              }, 0);
                            } else {
                              form.clearErrors('branchName');
                            }
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="ifscCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>IFSC Code <span className="text-red-500 ml-0.5">*</span></FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          onChange={(e) => {
                            const rawValue = e.target.value;
                            const strippedValue = rawValue.replace(/[^a-zA-Z0-9]/g, '');

                            field.onChange(strippedValue);

                            if (rawValue !== strippedValue) {
                              setTimeout(() => {
                                form.setError('ifscCode', {
                                  type: 'manual',
                                  message: 'Special Character are not allowed'
                                });
                              }, 0);
                            } else {
                              form.clearErrors('ifscCode');
                            }
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="securityGroupId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Security Group <span className="text-red-500 ml-0.5">*</span></FormLabel>
                      <SearchableSelect
                        placeholder={groupsLoading ? "Loading groups..." : "Select a security group"}
                        onValueChange={field.onChange}
                        value={field.value}
                        disabled={groupsLoading}
                        options={securityGroups.map((group: SecurityGroup) => ({
                          value: group.id,
                          label: `${group.name}${group.stateMaster?.stateName ? ` (${group.stateMaster.stateName})` : ''}`
                        }))}
                      />
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/dashboard/bank-details')}
                  disabled={loading}
                  className="w-full sm:w-auto"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full sm:w-auto"
                >
                  {loading ? 'Saving...' : 'Create Bank Detail'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}

