import { useState, useEffect, useCallback } from "react";
import { Link, useLocation } from "react-router-dom";
import type {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  RowSelectionState,
} from "@tanstack/react-table";
import {
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Plus, List, LayoutGrid, Pencil, Trash2, ChevronDown, X } from "lucide-react";
import { getBankDetails, deleteBankDetail } from "@/lib/services/bank-details";
import type { BankDetail } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { BankDetailCard } from "@/components/dashboard/bank-detail-card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useUserRole } from "@/contexts/UserRoleContext";

const createColumns = (
  onDelete: (id: string) => void,
  canAccessCategory: (category: string, action?: string) => boolean
): ColumnDef<BankDetail>[] => [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && "indeterminate")
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "bankName",
    header: "Bank Name",
  },
  {
    accessorKey: "branchName",
    header: "Branch Name",
  },
  {
    accessorKey: "accountNumber",
    header: "Account Number",
  },
  {
    accessorKey: "ifscCode",
    header: "IFSC Code",
  },
  {
    accessorKey: "dateModified",
    header: "Last Modified",
    cell: ({ row }) => {
      const date = row.original.dateModified || row.original.dateEntered;
      return date ? new Date(date).toLocaleDateString() : "-";
    },
  },
  {
    id: "actions",
    header: "Actions",
    cell: ({ row }) => {
      const bank = row.original;
      return (
        <div className="flex items-center justify-start gap-2">
          {canAccessCategory("BankDetailsWeb", "EDIT") && (<Button
            variant="ghost"
            size="icon"
            asChild
            className="h-8 w-8"
          >
            <Link to={`/dashboard/bank-details/${bank.id}/edit`}>
              <Pencil className="h-4 w-4" />
            </Link>
          </Button>)}
          {canAccessCategory("BankDetailsWeb", "DELETE") && (<Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-destructive hover:text-destructive"
            onClick={() => onDelete(bank.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>)}
        </div>
      );
    },
    enableSorting: false,
  },
];

export default function BankDetailsList() {
  const [banks, setBanks] = useState<BankDetail[]>([]);
  const [loading, setLoading] = useState(true);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
  const [globalFilter, setGlobalFilter] = useState("");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [bankToDelete, setBankToDelete] = useState<string | null>(null);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [view, setView] = useState<"table" | "card">("table");
  const location = useLocation();
  const { canAccessCategory } = useUserRole();

  useEffect(() => {
    if (isMobile !== undefined) {
      setView(isMobile ? "card" : "table");
    }
  }, [isMobile]);

  const loadBanks = useCallback(async () => {
    try {
      setLoading(true);
      const data = await getBankDetails();

      const sortedData = [...data].sort((a, b) => {
        const dateA = a.dateModified || a.dateEntered || '';
        const dateB = b.dateModified || b.dateEntered || '';
        return dateB.localeCompare(dateA);
      });
      
      setBanks(sortedData);
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to load bank details",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadBanks();
    
    if (location.state?.refresh && window.history.state) {
      window.history.replaceState({ ...window.history.state, refresh: false }, '');
    }
  }, [location.pathname, location.state, loadBanks]);

  const handleDeleteClick = (id: string) => {
    setBankToDelete(id);
    setDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!bankToDelete) return;

    try {
      await deleteBankDetail(bankToDelete);
      toast({
        title: "Success",
        description: "Bank detail deleted successfully",
      });
      setDeleteDialogOpen(false);
      setBankToDelete(null);
      loadBanks();
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to delete bank detail",
        variant: "destructive",
      });
    }
  };

  const columns = createColumns(handleDeleteClick, canAccessCategory);

  const table = useReactTable({
    data: banks,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onRowSelectionChange: setRowSelection,
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    enableRowSelection: true,
    globalFilterFn: (row, _columnId, filterValue) => {
      const searchValue = filterValue.toLowerCase();
      const bankName = row.original.bankName?.toLowerCase() || "";
      const ifscCode = row.original.ifscCode?.toLowerCase() || "";
      return bankName.includes(searchValue) || ifscCode.includes(searchValue);
    },
    initialState: {
      pagination: {
        pageSize: 20,
      },
    },
    state: {
      sorting,
      columnFilters,
      rowSelection,
      globalFilter,
    },
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">Loading...</div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <div className="sticky top-0 z-30 pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Bank Details</h1>
            <p className="text-sm text-muted-foreground">Manage bank account information.</p>
          </div>
        </div>

        <div className="flex items-center py-2 gap-2">
          <div className="relative max-w-sm w-full">
            <Input
              placeholder="Search by Bank Name or IFSC"
              value={globalFilter ?? ""}
              onChange={(event) => setGlobalFilter(event.target.value)}
              className="pr-8"
            />
            {globalFilter && (
              <button
                onClick={() => setGlobalFilter("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 hover:text-foreground transition-colors"
              >
                <X className="h-4 w-4 text-muted-foreground" />
              </button>
            )}
          </div>

          <div className="hidden sm:flex items-center gap-2 ml-auto">
            {canAccessCategory("BankDetailsWeb", "CREATE") && (<Button asChild className="bg-primary">
              <Link to="/dashboard/bank-details/new">
                <Plus className="mr-2 h-4 w-4" />
                Add Bank
              </Link>
            </Button>)}
            <div className="flex items-center gap-1 border bg-muted p-1 rounded-md">
              <Button
                variant={view === "table" ? "secondary" : "ghost"}
                size="icon"
                className="h-7 w-7"
                onClick={() => setView("table")}
              >
                <List className="h-4 w-4" />
              </Button>
              <Button
                variant={view === "card" ? "secondary" : "ghost"}
                size="icon"
                className="h-7 w-7"
                onClick={() => setView("card")}
              >
                <LayoutGrid className="h-4 w-4" />
              </Button>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="h-9">
                  Columns
                  <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[200px]">
                {table
                  .getAllColumns()
                  .filter(
                    (column) =>
                      typeof column.accessorFn !== "undefined" &&
                      column.getCanHide()
                  )
                  .map((column) => {
                    return (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                          column.toggleVisibility(!!value)
                        }
                      >
                        {column.id}
                      </DropdownMenuCheckboxItem>
                    );
                  })}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col min-h-0">
        {view === "table" && !isMobile ? (
          <div className="flex-1 flex flex-col min-h-0 rounded-lg border bg-card shadow-sm overflow-hidden">
            <div className="flex-1 overflow-auto scrollbar-thin">
              <Table className="w-full">
                <TableHeader className="sticky top-0 z-20 bg-card">
                  {table.getHeaderGroups().map((headerGroup) => (
                    <TableRow key={headerGroup.id}>
                      {headerGroup.headers.map((header) => (
                        <TableHead key={header.id} className="bg-card">
                          {header.isPlaceholder
                            ? null
                            : flexRender(
                              header.column.columnDef.header,
                              header.getContext(),
                            )}
                        </TableHead>
                      ))}
                    </TableRow>
                  ))}
                </TableHeader>
                <TableBody>
                  {table.getRowModel().rows?.length ? (
                    table.getRowModel().rows.map((row) => (
                      <TableRow key={row.id}>
                        {row.getVisibleCells().map((cell) => (
                          <TableCell key={cell.id} className="whitespace-nowrap">
                            {flexRender(
                              cell.column.columnDef.cell,
                              cell.getContext(),
                            )}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={columns.length}
                        className="h-24 text-center"
                      >
                        No results.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto scrollbar-thin">
            <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-1">
              {table.getRowModel().rows?.length ? (
                table
                  .getRowModel()
                  .rows.map((row) => (
                    <BankDetailCard key={row.original.id} bank={row.original} onDelete={handleDeleteClick} />
                  ))
              ) : (
                <div className="col-span-full text-center py-8 text-muted-foreground">
                  No results.
                </div>
              )}
            </div>
          </div>
        )}

        <div className="sticky bottom-0 z-30 pt-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-2">
              <p className="text-xs sm:text-sm text-muted-foreground">
                {Object.keys(rowSelection).length} of {table.getFilteredRowModel().rows.length} row(s) selected.
              </p>
            </div>
            <div className="flex items-center justify-center sm:justify-end gap-2">
              <Button
                variant="outline"
                size="sm"
                className="text-xs sm:text-sm"
                onClick={() => table.previousPage()}
                disabled={!table.getCanPreviousPage()}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="text-xs sm:text-sm"
                onClick={() => table.nextPage()}
                disabled={!table.getCanNextPage()}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the bank detail.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
