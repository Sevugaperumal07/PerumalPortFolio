import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { getBankDetails, updateBankDetail } from '@/lib/services/bank-details';
import type { BankDetail } from '@/lib/types';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const bankDetailFormSchema = z.object({
  bankName: z.string().min(1, 'Bank name is required').regex(/^[a-zA-Z\s]+$/, 'Numeric & Special Characters are not allowed'),
  accountNumber: z.string()
    .min(8, 'Account number must be at least 8 digits')
    .max(19, 'Account number cannot exceed 19 digits')
    .regex(/^[a-zA-Z0-9]+$/, 'Special Characters are not allowed'),
  branchName: z.string().min(1, 'Branch name is required').regex(/^[a-zA-Z\s]+$/, 'Numeric & Special Characters are not allowed'),
  ifscCode: z.string().min(1, 'IFSC code is required').regex(/^[a-zA-Z0-9]+$/, 'Special Character are not allowed'),
  hiveId: z.string().min(1, 'Hive ID is required'),
});

type BankDetailFormValues = z.infer<typeof bankDetailFormSchema>;

export default function EditBankDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [bank, setBank] = useState<BankDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingBank, setLoadingBank] = useState(true);

  const form = useForm<BankDetailFormValues>({
    resolver: zodResolver(bankDetailFormSchema),
    defaultValues: {
      bankName: '',
      accountNumber: '',
      branchName: '',
      ifscCode: '',
      hiveId: '',
    },
  });

  useEffect(() => {
    if (id) {
      loadBank();
    }
  }, [id]);

  const loadBank = async () => {
    if (!id) return;

    try {
      setLoadingBank(true);
      const banks = await getBankDetails();
      const foundBank = banks.find(b => b.id === id);
      if (foundBank) {
        setBank(foundBank);
        form.reset({
          bankName: foundBank.bankName || '',
          accountNumber: foundBank.accountNumber || '',
          branchName: foundBank.branchName || '',
          ifscCode: foundBank.ifscCode || '',
          hiveId: foundBank.hiveId || '',
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to load bank detail',
        variant: 'destructive',
      });
    } finally {
      setLoadingBank(false);
    }
  };

  const handleSubmit = async (data: BankDetailFormValues) => {
    if (!id || !bank) return;

    try {
      setLoading(true);

      // All fields are required according to GraphQL schema BankDetailsInput!
      // Include deleted field from existing bank record if it exists
      const payload = {
        bankName: data.bankName.trim(),
        accountNumber: data.accountNumber.trim(),
        branchName: data.branchName.trim(),
        ifscCode: data.ifscCode.trim(),
        hiveId: data.hiveId.trim(),
        ...(bank.deleted !== undefined && { deleted: bank.deleted }),
      };

      const result = await updateBankDetail(id, payload);

      if(result){
        toast({
          title: 'Success',
          description: 'Bank detail updated successfully',
        });
      }
      setTimeout(() => {
        navigate('/dashboard/bank-details');
      }, 1000);
    } catch (error) {
      console.error('Error updating bank detail:', error);
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to update bank detail',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (loadingBank) {
    return <div className="flex items-center justify-center p-8">Loading...</div>;
  }

  if (!bank) {
    return (
      <div className="flex flex-col items-center justify-center p-8 gap-4">
        <p className="text-muted-foreground">Bank detail not found</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold">Edit Bank Detail</h1>
        <p className="text-sm sm:text-base text-muted-foreground">Update bank account detail</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Bank Information</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 sm:space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="bankName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bank Name <span className="text-red-500 ml-0.5">*</span></FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          onChange={(e) => {
                            const rawValue = e.target.value;
                            const strippedValue = rawValue.replace(/[^a-zA-Z\s]/g, '');

                            field.onChange(strippedValue);

                            if (rawValue !== strippedValue) {
                              setTimeout(() => {
                                form.setError('bankName', {
                                  type: 'manual',
                                  message: 'Numeric & Special Characters are not allowed'
                                });
                              }, 0);
                            } else {
                              form.clearErrors('bankName');
                            }
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="accountNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account Number <span className="text-red-500 ml-0.5">*</span></FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          minLength={8}
                          maxLength={19}
                          onChange={(e) => {
                            const rawValue = e.target.value;
                            const strippedValue = rawValue.replace(/[^a-zA-Z0-9]/g, '');

                            field.onChange(strippedValue);

                            if (rawValue !== strippedValue) {
                              setTimeout(() => {
                                form.setError('accountNumber', {
                                  type: 'manual',
                                  message: 'Special Characters are not allowed'
                                });
                              }, 0);
                            } else {
                              form.clearErrors('accountNumber');
                            }
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="branchName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Branch Name <span className="text-red-500 ml-0.5">*</span></FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          onChange={(e) => {
                            const rawValue = e.target.value;
                            const strippedValue = rawValue.replace(/[^a-zA-Z\s]/g, '');

                            field.onChange(strippedValue);

                            if (rawValue !== strippedValue) {
                              setTimeout(() => {
                                form.setError('branchName', {
                                  type: 'manual',
                                  message: 'Numeric & Special Characters are not allowed'
                                });
                              }, 0);
                            } else {
                              form.clearErrors('branchName');
                            }
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="ifscCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>IFSC Code <span className="text-red-500 ml-0.5">*</span></FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          onChange={(e) => {
                            const rawValue = e.target.value;
                            const strippedValue = rawValue.replace(/[^a-zA-Z0-9]/g, '');

                            field.onChange(strippedValue);

                            if (rawValue !== strippedValue) {
                              setTimeout(() => {
                                form.setError('ifscCode', {
                                  type: 'manual',
                                  message: 'Special Character are not allowed'
                                });
                              }, 0);
                            } else {
                              form.clearErrors('ifscCode');
                            }
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-4">
                <Button type="button" variant="outline" onClick={() => window.history.back()} className="w-full sm:w-auto">
                  Cancel
                </Button>
                <Button type="submit" disabled={loading} className="w-full sm:w-auto">
                  {loading ? 'Saving...' : 'Saving Details'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}

