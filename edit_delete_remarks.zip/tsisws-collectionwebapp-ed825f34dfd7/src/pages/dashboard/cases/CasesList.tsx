import { AddAddress } from "@/components/Cases/AddAddress";
import { AddContact } from "@/components/Cases/AddContact";
import { CaseActionsGuide } from "@/components/Cases/CaseActionsGuide";
import { AddCaseNotesDialog } from "@/components/dashboard/AddCaseNotesDialog";
import { CaseHistorySheet } from "@/components/history/CaseHistorySheet";
import { AdvanceSearchCases } from "@/components/Cases/AdvanceSearchCases";
import { BulkAssignTaskSheet } from "@/components/Tasks/BulkAssignTaskSheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { useAdvancedSearchCases } from "@/hooks/Cases/useAdvancedSearchCases";
import { useGeoLocation } from "@/hooks/use-location";
import { useToast } from "@/hooks/use-toast";
import { getAccountAsCaseById, getAccountsAsCasesPaginated } from "@/lib/services/cases";
import { getStateSecurityGroups } from "@/lib/services/tasks";
import type { AdvancedFilterParamsCases, Case, StateSecurityGroup, Task } from "@/lib/types";
import { cn } from "@/lib/utils";
import type {
    ColumnDef,
    ColumnFiltersState,
    RowSelectionState,
    SortingState,
} from "@tanstack/react-table";
import {
    flexRender,
    getCoreRowModel,
    getSortedRowModel,
    useReactTable,
} from "@tanstack/react-table";

import {
    ChevronDown,
    Eye,
    File,
    Filter,
    History,
    Home,
    Info,
    LayoutGrid,
    List,
    ListChecks,
    Loader2,
    MoreVertical,
    UserPlus,
    X,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import ViewCase from "./ViewCase";
import { useUserRole } from "@/contexts/UserRoleContext";



const createColumns = (
    onViewCase: (caseItem: Case) => void,
    onViewHistory: (caseItem: Case) => void,
    onViewTasks: (caseItem: Case) => void,
    onOpenAddContact: (caseItem: Case) => void,
    onOpenAddAddress: (caseItem: Case) => void,
    canAccessCategory: (category: string) => boolean
): ColumnDef<Case>[] => [
        {
            id: "select",
            header: ({ table }) => (
                <Checkbox
                    checked={
                        table.getIsAllPageRowsSelected() ||
                        (table.getIsSomePageRowsSelected() && "indeterminate")
                    }
                    onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                    aria-label="Select all"
                />
            ),
            cell: ({ row }) => (
                <Checkbox
                    checked={row.getIsSelected()}
                    onCheckedChange={(value) => row.toggleSelected(!!value)}
                    aria-label="Select row"
                />
            ),
            enableSorting: false,
            enableHiding: false,
            size: 50,
            minSize: 50,
            maxSize: 50,
        },
        {
            accessorKey: "caseNumber",
            header: "LAN",
            cell: ({ row }) => {
                const lan = row.original.account?.lanNumber || row.original.caseNumber || "";
                return <span>{lan}</span>;
            },
            size: 100,
            minSize: 90,
            maxSize: 120,
        },
        {
            id: "customerName",
            header: "Customer Name",
            cell: ({ row }) => {
                const customerName = row.original.account?.name || "";
                return <span>{customerName}</span>;
            },
            size: 150,
            minSize: 130,
            maxSize: 180,
        },
        {
            id: "product",
            header: "Product",
            cell: ({ row }) => {
                const product = row.original.account?.product || "";
                return <span>{product}</span>;
            },
            size: 120,
            minSize: 110,
            maxSize: 140,
        },
        {
            id: "branch",
            header: "Branch",
            cell: ({ row }) => {
                const branch = row.original.account?.branch || "";
                return <span>{branch}</span>;
            },
            size: 100,
            minSize: 90,
            maxSize: 120,
        },
        {
            id: "loanAmount",
            header: "Loan Amount",
            cell: ({ row }) => {
                const amount = row.original.account?.loanAmount || 0;
                return <span>₹{amount.toLocaleString("en-IN")}</span>;
            },
            size: 130,
            minSize: 120,
            maxSize: 150,
        },
        {
            id: "nextDueDate",
            header: "Next Due Date",
            cell: ({ row }) => {
                const date = row.original.nextActionDate || "";
                return <span>{date}</span>;
            },
            size: 130,
            minSize: 120,
            maxSize: 150,
        },
        {
            accessorKey: "status",
            header: "Status",
            cell: ({ row }) => {
                const status = row.getValue("status") as string;
                return (
                    <Badge variant="outline" className="text-gray-800 font-semibold">
                        {status}
                    </Badge>
                );
            },
            size: 120,
            minSize: 110,
            maxSize: 140,
        },
        {
            id: "actions",
            header: "Actions",
            cell: ({ row }) => {
                const caseItem = row.original;
                return (
                    <div className="flex items-center justify-start gap-3 gap-2">
                        <Button
                            variant="ghost"
                            className="h-10 w-10 p-0 [&_svg]:!h-5 [&_svg]:!w-5"
                            onClick={() => onViewTasks(caseItem)}
                            title="View recovery tasks"
                        >
                            <ListChecks className="h-5 w-5" />
                        </Button>
                        <Button
                            variant="ghost"
                            className="h-10 w-10 p-0 [&_svg]:!h-5 [&_svg]:!w-5"
                            onClick={() => onViewHistory(caseItem)}
                            title="View case history"
                        >
                            <History className="h-5 w-5" />
                        </Button>
                        <Button
                            variant="ghost"
                            className="h-10 w-10 p-0 [&_svg]:!h-5 [&_svg]:!w-5"
                            onClick={() => onViewCase(caseItem)}
                            title="View case details"
                        >
                            <Eye className="h-5 w-5" />
                        </Button>
                        {(canAccessCategory("AddContact") || canAccessCategory("AddAddress")) && <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-10 w-10 p-0 [&_svg]:!h-5 [&_svg]:!w-5">
                                    <MoreVertical className="h-5 w-5" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                {canAccessCategory("AddContact") && <DropdownMenuItem onClick={() => onOpenAddContact(caseItem)}>
                                    <UserPlus className="mr-2 h-4 w-4" />
                                    <span>Add Contact</span>
                                </DropdownMenuItem>}
                                {canAccessCategory("AddAddress") && <DropdownMenuItem onClick={() => onOpenAddAddress(caseItem)}>
                                    <Home className="mr-2 h-4 w-4" />
                                    <span>Add Address</span>
                                </DropdownMenuItem>}
                            </DropdownMenuContent>
                        </DropdownMenu>}
                    </div>
                );
            },
            size: 200,
            minSize: 180,
            maxSize: 220,
        },
    ];

export default function CasesList() {
    const navigate = useNavigate();
    const [cases, setCases] = useState<Case[]>([]);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [sorting, setSorting] = useState<SortingState>([]);
    const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
    const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
    const [globalFilter, setGlobalFilter] = useState("");
    const [view, setView] = useState<"table" | "card">("table");
    const [isActionsGuideOpen, setIsActionsGuideOpen] = useState(false);
    const [selectedCase, setSelectedCase] = useState<Case | null>(null);
    const [isViewCaseOpen, setIsViewCaseOpen] = useState(false);
    const [isNotesDialogOpen, setIsNotesDialogOpen] = useState(false);
    const [isHistorySheetOpen, setIsHistorySheetOpen] = useState(false);
    const [selectedCaseForHistory, setSelectedCaseForHistory] = useState<Case | null>(null);
    const [totalPages, setTotalPages] = useState(0);
    const [isFirstPage, setIsFirstPage] = useState(true);
    const [isLastPage, setIsLastPage] = useState(true);
    const [pageIndex, setPageIndex] = useState(0);
    const [pageSize] = useState(20);
    const [isAddContactOpen, setIsAddContactOpen] = useState(false);
    const [isAddAddressOpen, setIsAddAddressOpen] = useState(false);
    const [selectedAccountForAction, setSelectedAccountForAction] = useState<Case | null>(null);
    const [totalCases, setTotalCases] = useState(0);
    const [selectedCasesRecord, setSelectedCasesRecord] = useState<Record<string, Case>>({});
    const [highlightedLan, setHighlightedLan] = useState<string | null>(null);
    const [searchParams] = useSearchParams();
    const [debouncedFilter, setDebouncedFilter] = useState("");
    const caseIdParam = useMemo(() => searchParams.get("caseId")?.trim() || "", [searchParams]);
    const lanParam = useMemo(
        () => searchParams.get("lan") || searchParams.get("lanList") || "",
        [searchParams]
    );
    const highlightedRowRef = useRef<HTMLTableRowElement>(null);

    const { canAccessCategory } = useUserRole()
    const [isSingleAssignDialogOpen, setIsSingleAssignDialogOpen] = useState(false);
    const [isFilterBlinking, setIsFilterBlinking] = useState(false);
    const [states, setStates] = useState<StateSecurityGroup[]>([]);

    const { toast } = useToast();
    const { withLocation } = useGeoLocation();

    // Initialize Advanced Search hook
    const advancedSearch = useAdvancedSearchCases({
        states,
        pageIndex,
        pageSize,
    });

    // Fetch states for the filter
    useEffect(() => {
        const fetchData = async () => {
            try {
                const statesData = await getStateSecurityGroups();
                setStates(statesData);
            } catch (err) {
                console.error("Error fetching states:", err);
            }
        };
        fetchData();
    }, []);


    // Fetch specific case when caseId param is present (from notification click)
    useEffect(() => {
        if (!caseIdParam) return;

        const fetchCaseById = async () => {
            setLoading(true);
            setError(null);
            try {
                const caseItem = await getAccountAsCaseById(caseIdParam);

                if (caseItem) {
                    setCases([caseItem]);
                    setTotalCases(1);
                    setTotalPages(1);
                    setIsFirstPage(true);
                    setIsLastPage(true);
                } else {
                    setCases([]);
                    setTotalCases(0);
                }
            } catch (err) {
                setError(err instanceof Error ? err.message : "Failed to fetch case");
                setCases([]);
            } finally {
                setLoading(false);
            }
        };

        fetchCaseById();
    }, [caseIdParam]);

    // Debounce globalFilter value
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedFilter(globalFilter);
        }, 500);

        return () => {
            clearTimeout(handler);
        };
    }, [globalFilter]);

    // Reset pagination when filter changes
    useEffect(() => {
        setPageIndex(0);
        setRowSelection({});
    }, [advancedSearch.appliedFilters]);

    const selectionCount = useMemo(() => {
        return Object.values(rowSelection).filter(Boolean).length;
    }, [rowSelection]);

    const selectedCasesRecordCount = useMemo(() => {
        return Object.keys(selectedCasesRecord).length;
    }, [selectedCasesRecord]);

    const fetchCasesData = useCallback(async () => {
        if (caseIdParam) return;
        setLoading(true);
        setError(null);
        try {
            const offset = pageIndex * pageSize;
            
            // Fetch cases with advanced filters
            const data = await getAccountsAsCasesPaginated(pageSize, offset, debouncedFilter, advancedSearch.appliedFilters);
            
            setCases(data.cases);
            setTotalCases(data.totalElements);
            setTotalPages(data.totalPages);
            setIsFirstPage(data.first);
            setIsLastPage(data.last);
        } catch (err) {
            setError(err instanceof Error ? err.message : "Failed to fetch cases");
            setCases([]);
        } finally {
            setLoading(false);
        }
    }, [pageIndex, pageSize, debouncedFilter, caseIdParam, advancedSearch.appliedFilters]);

    // Fetch paginated cases (only if no caseId param)
    useEffect(() => {
        fetchCasesData();
    }, [fetchCasesData]);

    // Handle URL query parameter for highlighting and selecting a case
    useEffect(() => {

        if (cases.length === 0) return;

        let matchingCase: Case | undefined;

        // First try to match by caseId (exact ID match)
        if (caseIdParam) {
            matchingCase = cases.find((c) => c.id === caseIdParam);
        }

        // If no match by ID, try by LAN
        if (!matchingCase && lanParam) {
            matchingCase = cases.find(
                (c) => (c.account?.lanNumber || c.caseNumber || "").toLowerCase() === lanParam.toLowerCase()
            );
        }

        if (matchingCase) {

            // Set the highlighted LAN (use the case's LAN for highlighting)
            const caseLan = (matchingCase.account?.lanNumber || matchingCase.caseNumber || matchingCase.id).toLowerCase();
            setHighlightedLan(caseLan);

            // Select the checkbox for this case
            setRowSelection((prev) => ({
                ...prev,
                [matchingCase.id]: true,
            }));

            // Scroll to the row after a short delay (to allow rendering)
            setTimeout(() => {
                if (highlightedRowRef.current) {
                    highlightedRowRef.current.scrollIntoView({
                        behavior: "smooth",
                        block: "center",
                    });
                }
            }, 100);

            // Remove highlight after 5 seconds
            setTimeout(() => {
                setHighlightedLan(null);
            }, 5000);
        }
    }, [caseIdParam, lanParam, cases]);

    const handleOpenViewCase = useCallback((caseItem: Case) => {
        setSelectedCase(caseItem);
        setIsViewCaseOpen(true);
    }, []);

    const handleViewCaseToggle = useCallback((open: boolean) => {
        setIsViewCaseOpen(open);
        if (!open) {
            setSelectedCase(null);
        }
    }, []);

    const handleViewHistory = useCallback((caseItem: Case) => {
        setSelectedCaseForHistory(caseItem);
        setIsHistorySheetOpen(true);
    }, []);

    const handleHistoryToggle = useCallback((open: boolean) => {
        setIsHistorySheetOpen(open);
        if (!open) {
            setSelectedCaseForHistory(null);
        }
    }, []);

    /** Navigate to tasks list with LAN filter using location state */
    const handleViewTasks = useCallback((caseItem: Case) => {
        const lan = caseItem.account?.lanNumber || caseItem.caseNumber || "";
        if (lan) {
            navigate(`/dashboard/tasks`, { state: { lan } });
        }
    }, [navigate]);

    const handleOpenAddContact = useCallback((caseItem: Case) => {
        setSelectedAccountForAction(caseItem);
        setIsAddContactOpen(true);
    }, []);

    const handleOpenAddAddress = useCallback((caseItem: Case) => {
        setSelectedAccountForAction(caseItem);
        setIsAddAddressOpen(true);
    }, []);

    // ── Filter chip helpers ───────────────────────────────────────────────────
    const removeAppliedFilter = (type: string) => {
        const update: Partial<AdvancedFilterParamsCases> = {};
        switch (type) {
            case "state": update.state = ""; break;
            case "branch": update.branch = ""; break;
            case "agent": update.agent = ""; break;
            case "lan": update.lan = ""; break;
            default: return;
        }
        advancedSearch.updateFilter(update);
        advancedSearch.setAppliedFilters((prev: AdvancedFilterParamsCases) => ({ ...prev, ...update }));
    };

    const appliedFilterChips = useMemo(() => {
        const chips: { label: string; value: string; type: string }[] = [];
        const af = advancedSearch.appliedFilters;

        if (af.state && af.state !== "all") chips.push({ label: "State", value: af.state, type: "state" });
        if (af.branch && af.branch !== "all") chips.push({ label: "Branch", value: af.branch, type: "branch" });
        if (af.agent && af.agent !== "all") chips.push({ label: "Agent", value: af.agent, type: "agent" });
        if (af.lan.trim()) chips.push({ label: "LAN", value: af.lan.trim(), type: "lan" });

        return chips;
    }, [advancedSearch.appliedFilters]);

    // ── Assign guard ──────────────────────────────────────────────────────────
    const canAssignTask = useMemo(() => {
        return !!advancedSearch.appliedFilters.branch && advancedSearch.appliedFilters.branch !== "all";
    }, [advancedSearch.appliedFilters.branch]);

    const handleAssignClick = () => {
        withLocation(() => {
            if (selectedCasesRecordCount === 0) return;
            if (!canAssignTask) {
                toast({
                    title: "Branch Required",
                    description: "Please select a branch in Advanced Filter to assign cases.",
                    variant: "warning",
                });
                setIsFilterBlinking(true);
                setTimeout(() => setIsFilterBlinking(false), 3000);
                return;
            }
            setIsSingleAssignDialogOpen(true);
        });
    };

    const columns = useMemo(
        () => createColumns(handleOpenViewCase, handleViewHistory, handleViewTasks, handleOpenAddContact, handleOpenAddAddress, canAccessCategory),
        [handleOpenViewCase, handleViewHistory, handleViewTasks, handleOpenAddContact, handleOpenAddAddress, canAccessCategory]
    );

    // Map column IDs to dropdown display names
    const columnDisplayNames: Record<string, string> = {
        caseNumber: "LAN",
        customerName: "Customer Name",
        product: "Product",
        branch: "Branch",
        loanAmount: "Loan Amount",
        nextDueDate: "Next Due Date",
        status: "Status",
        actions: "Actions",
    };

    const table = useReactTable({
        data: cases,
        columns,
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        onRowSelectionChange: setRowSelection,
        onGlobalFilterChange: setGlobalFilter,
        getRowId: (row) => String(row.id || row.caseNumber || ""), // Ensure unique IDs for selection
        getCoreRowModel: getCoreRowModel(),
        getSortedRowModel: getSortedRowModel(),
        manualPagination: true,
        manualFiltering: true,
        pageCount: totalPages,
        onPaginationChange: (updater) => {
            if (typeof updater === 'function') {
                const nextState = updater({ pageIndex, pageSize });
                setPageIndex(nextState.pageIndex);
            } else {
                setPageIndex(updater.pageIndex);
            }
        },
        enableRowSelection: true,
        enableGlobalFilter: true,
        initialState: {
            pagination: {
                pageIndex: 0,
                pageSize: 20,
            },
        },
        state: {
            sorting,
            columnFilters,
            rowSelection,
            globalFilter,
            pagination: {
                pageIndex,
                pageSize,
            },
        },
    });

    // Sync selectedCasesRecord with rowSelection and current cases
    useEffect(() => {
        setSelectedCasesRecord(prev => {
            const next = { ...prev };
            let changed = false;

            // Remove items no longer in rowSelection
            Object.keys(next).forEach(id => {
                if (!rowSelection[id]) {
                    delete next[id];
                    changed = true;
                }
            });

            // Add new items from currently displayed cases (paginated)
            cases.forEach(caseItem => {
                if (rowSelection[caseItem.id] && !next[caseItem.id]) {
                    next[caseItem.id] = caseItem;
                    changed = true;
                }
            });

            return changed ? next : prev;
        });
    }, [rowSelection, cases]);

    // Get selected cases for notes dialog
    const getSelectedCases = useCallback((): Case[] => {
        return Object.values(selectedCasesRecord);
    }, [selectedCasesRecord]);

    // Handle add notes button click
    const handleAddNotes = useCallback(() => {
        const selected = getSelectedCases();
        if (selected.length === 0) return;
        setIsNotesDialogOpen(true);
    }, [getSelectedCases]);

    // Selected cases for the notes dialog
    const selectedCasesForNotes = useMemo(() => {
        return getSelectedCases();
    }, [getSelectedCases]);

    // Memoized selection for BulkAssignTaskSheet to prevent state resets
    const selectedTasksList = useMemo(() => {
        return getSelectedCases().map(caseItem => ({
            id: caseItem.id,
            lan: caseItem.account?.lanNumber || caseItem.caseNumber || "N/A",
            agentName: caseItem.UserCases?.[0]?.userId?.userName || caseItem.account?.user?.userName || "N/A",
            UserCases: [
                ...(caseItem.UserCases ?? []),
                // Include the account-level assigned agent so they are also excluded from the dropdown
                ...(caseItem.account?.user?.userName
                    ? [
                        {
                            id: `acct-user-${caseItem.id}`,
                            userId: { 
                                id: caseItem.account.user.id,
                                userName: caseItem.account.user.userName 
                            },
                        },
                    ]
                    : []),
            ],
        } as Task));
    }, [selectedCasesRecord]);

    const renderTableSkeleton = (rows: number) => {
        const columns = table.getVisibleLeafColumns();
        return Array.from({ length: rows }).map((_, rowIndex) => (
            <TableRow key={`skeleton-row-${rowIndex}`}>
                {columns.map((column) => (
                    <TableCell
                        key={`skeleton-${rowIndex}-${column.id}`}
                        style={{ width: column.getSize() }}
                        className={cn(
                            "whitespace-nowrap",
                            column.id === "actions" && "sticky right-0 z-10 bg-card shadow-[-4px_0_4px_-2px_rgba(0,0,0,0.1)]"
                        )}
                    >
                        <div
                            className={cn(
                                "h-4 rounded bg-muted animate-pulse",
                                column.id === "select" ? "w-6" : "w-24"
                            )}
                        />
                    </TableCell>
                ))}
            </TableRow>
        ));
    };

    return (
        <div className="flex flex-col h-[calc(100vh-8rem)]">
            <div className="sticky top-0 z-30 pb-4">
                {/* Header Section */}
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
                    <div>
                        <h1 className="text-2xl font-bold tracking-tight">Cases</h1>
                        <p className="text-sm text-muted-foreground">
                            Here's a list of loan account cases.
                        </p>
                    </div>
                </div>

                {/* Filter Bar */}
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="relative max-w-64 w-full overflow-hidden rounded-md border border-gray-200 bg-white">
                            <Input
                                placeholder=""
                                value={globalFilter ?? ""}
                                onChange={(event) => setGlobalFilter(event.target.value)}
                                className="border-none focus-visible:ring-0 relative z-10 bg-transparent pr-8"
                            />
                            {!globalFilter && (
                                <div className="absolute inset-y-0 left-0 w-full flex items-center pointer-events-none overflow-hidden">
                                    <div className="w-full text-xs sm:text-sm text-muted-foreground whitespace-nowrap animate-marquee-rtl">
                                        Filter by customer name, LAN or...
                                    </div>
                                </div>
                            )}
                            {(loading || globalFilter !== debouncedFilter) ? (
                                <div className="absolute right-2 top-1/2 -translate-y-1/2 z-20">
                                    <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                                </div>
                            ) : globalFilter && (
                                <button
                                    onClick={() => setGlobalFilter("")}
                                    className="absolute right-2 top-1/2 -translate-y-1/2 z-20 hover:text-foreground transition-colors"
                                >
                                    <X className="h-4 w-4 text-muted-foreground" />
                                </button>
                            )}

                        </div>
                        <div className="relative">
                            <Button
                                variant="ghost"
                                size="icon"
                                className={cn(
                                    "h-10 w-10 border border-gray-200 p-2 bg-white/20 transition-all",
                                    isFilterBlinking && "animate-pulse ring-2 ring-blue-500 bg-blue-50"
                                )}
                                onClick={() => advancedSearch.setIsAdvancedSearchOpen(true)}
                                title="Advanced Filter"
                            >
                                <Filter className="h-5 w-5 text-blue-800" strokeWidth={2.5} />
                            </Button>
                            {advancedSearch.isFilterApplied && (
                                <div className="absolute -top-1 -right-1 flex items-center justify-center w-4 h-4 bg-red-500 rounded-full border-2 border-white">
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 20 20"
                                        fill="currentColor"
                                        className="w-2.5 h-2.5 text-white"
                                    >
                                        <path
                                            fillRule="evenodd"
                                            d="M16.704 5.29a1 1 0 010 1.42l-7.25 7.25a1 1 0 01-1.41 0l-3.75-3.75a1 1 0 111.41-1.42L9 11.59l6.29-6.3a1 1 0 011.41 0z"
                                            clipRule="evenodd"
                                        />
                                    </svg>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Top Right Icons */}
                    <div className="flex items-center gap-2 flex-wrap">
                        {/* Assign button — enabled only when cases are selected */}
                        {canAccessCategory("AssignCases") && <Button
                            variant="ghost"
                            size="icon"
                            className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                            disabled={selectedCasesRecordCount === 0}
                            onClick={handleAssignClick}
                            title={selectedCasesRecordCount === 0 ? "Select cases to assign" : `Assign ${selectedCasesRecordCount} case(s)`}
                        >
                            <UserPlus className="h-5 w-5 text-blue-800" strokeWidth={2.5} />
                        </Button>}
                        {canAccessCategory("AddNotesCases") && <Button
                            variant="ghost"
                            size="icon"
                            className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                            disabled={selectedCasesForNotes.length === 0}
                            onClick={handleAddNotes}
                            title={selectedCasesForNotes.length === 0 ? "Select cases to add notes" : `Add notes to ${selectedCasesForNotes.length} case(s)`}
                        >
                            <File className="h-5 w-5" strokeWidth={2.5} />
                        </Button>}
                        <Button
                            variant="ghost"
                            size="icon"
                            className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                            onClick={() => setIsActionsGuideOpen(true)}
                        >
                            <Info className="h-5 w-5 text-blue-800" strokeWidth={2.5} />
                        </Button>
                        <div className="sm:flex items-center gap-1 border bg-muted p-1 rounded-md">
                            <Button
                                variant={view === "table" ? "secondary" : "ghost"}
                                size="icon"
                                className="h-7 w-7"
                                onClick={() => setView("table")}
                            >
                                <List className="h-4 w-4" />
                            </Button>
                            <Button
                                variant={view === "card" ? "secondary" : "ghost"}
                                size="icon"
                                className="h-7 w-7"
                                onClick={() => setView("card")}
                            >
                                <LayoutGrid className="h-4 w-4" />
                            </Button>
                        </div>
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="outline" className="h-10">
                                    Columns
                                    <ChevronDown className="ml-2 h-4 w-4" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-[220px]">
                                {table
                                    .getAllLeafColumns()
                                    .filter((column) => column.id !== "select")
                                    .map((column) => {
                                        const displayName = columnDisplayNames[column.id] || column.id;
                                        const canHide = column.getCanHide();

                                        return (
                                            <DropdownMenuCheckboxItem
                                                key={column.id}
                                                checked={column.getIsVisible()}
                                                disabled={!canHide}
                                                onCheckedChange={(value) =>
                                                    canHide ? column.toggleVisibility(!!value) : undefined
                                                }
                                            >
                                                {displayName}
                                            </DropdownMenuCheckboxItem>
                                        );
                                    })}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                </div>
            </div>

            {/* Table or Card View */}
            <div className="flex-1 overflow-hidden flex flex-col min-h-0">
                {/* Applied filter chips */}
                {advancedSearch.isFilterApplied && appliedFilterChips.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2 mb-3">
                        <span className="text-sm font-semibold text-gray-800">Applied Filters:</span>
                        {appliedFilterChips.map((chip) => (
                            <span
                                key={`${chip.label}-${chip.value}`}
                                className="flex items-center gap-1 rounded-full bg-muted px-3 text-xs"
                            >
                                <span className="font-semibold">{chip.label}:</span>
                                <span className="font-semibold">{chip.value}</span>
                                <button
                                    aria-label={`Remove ${chip.label}`}
                                    className="ml-1 text-muted-foreground hover:text-foreground flex items-center justify-center"
                                    onClick={() => removeAppliedFilter(chip.type)}
                                >
                                    <X className="h-3 w-3" />
                                </button>
                            </span>
                        ))}
                        <Button
                            variant="link"
                            className="text-sm text-blue-800 px-0"
                            onClick={advancedSearch.resetFilters}
                        >
                            Clear All
                        </Button>
                    </div>
                )}
                {view === "table" ? (
                    <div className="flex-1 flex flex-col min-h-0 rounded-lg border bg-card shadow-sm overflow-hidden">
                        <div className="flex-1 overflow-auto scrollbar-thin">
                            <Table className="w-full">
                                <TableHeader className="sticky top-0 z-20 bg-card">
                                    {table.getHeaderGroups().map((headerGroup) => (
                                        <TableRow key={headerGroup.id}>
                                            {headerGroup.headers.map((header) => (
                                                <TableHead
                                                    key={header.id}
                                                    className={cn(
                                                        "bg-card text-muted-foreground",
                                                        header.id === "actions" && "sticky right-0 z-30 bg-card text-center shadow-[-4px_0_4px_-2px_rgba(0,0,0,0.1)]"
                                                    )}
                                                    style={{ width: header.getSize() }}
                                                >
                                                    {header.isPlaceholder
                                                        ? null
                                                        : flexRender(
                                                            header.column.columnDef.header,
                                                            header.getContext()
                                                        )}
                                                </TableHead>
                                            ))}
                                        </TableRow>
                                    ))}
                                </TableHeader>
                                <TableBody>
                                    {loading ? (
                                        renderTableSkeleton(12)
                                    ) : error ? (
                                        <TableRow>
                                            <TableCell colSpan={columns.length} className="h-24 text-center text-red-600">
                                                {error}
                                            </TableCell>
                                        </TableRow>
                                    ) : table.getRowModel().rows?.length ? (
                                        table.getRowModel().rows.map((row) => {
                                            const caseLan = (row.original.account?.lanNumber || row.original.caseNumber || row.original.id).toLowerCase();
                                            const isHighlighted = highlightedLan && caseLan === highlightedLan;
                                            return (
                                                <TableRow
                                                    key={row.id}
                                                    ref={isHighlighted ? highlightedRowRef : undefined}
                                                    className={cn(
                                                        isHighlighted && "bg-yellow-100 dark:bg-yellow-900/30 ring-2 ring-yellow-400 ring-inset animate-pulse"
                                                    )}
                                                >
                                                    {row.getVisibleCells().map((cell) => (
                                                        <TableCell
                                                            key={cell.id}
                                                            className={cn(
                                                                "whitespace-nowrap",
                                                                cell.column.id === "actions" && "sticky right-0 z-10 bg-card text-right shadow-[-4px_0_4px_-2px_rgba(0,0,0,0.1)]"
                                                            )}
                                                            style={{ width: cell.column.getSize() }}
                                                        >
                                                            {flexRender(
                                                                cell.column.columnDef.cell,
                                                                cell.getContext()
                                                            )}
                                                        </TableCell>
                                                    ))}
                                                </TableRow>
                                            );
                                        })
                                    ) : (
                                        <TableRow>
                                            <TableCell
                                                colSpan={columns.length}
                                                className="h-24 text-center"
                                            >
                                                No results.
                                            </TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </div>
                    </div>
                ) : (
                    <div className="flex-1 overflow-auto scrollbar-thin">
                        {loading ? (
                            <div className="flex items-center justify-center h-24">
                                <p className="text-muted-foreground">Loading cases...</p>
                            </div>
                        ) : error ? (
                            <div className="flex items-center justify-center h-24">
                                <p className="text-red-600">{error}</p>
                            </div>
                        ) : table.getFilteredRowModel().rows?.length ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 p-4">
                                {table.getFilteredRowModel().rows.map((row) => {
                                    const caseItem = row.original;
                                    const isSelected = rowSelection[caseItem.id] === true;
                                    const customerName = caseItem.account?.name || "";
                                    const lan = caseItem.account?.lanNumber || caseItem.caseNumber || "";
                                    const product = caseItem.account?.product || "";
                                    const loanAmount = caseItem.account?.loanAmount || 0;
                                    const nextDueDate = caseItem.nextActionDate || "";
                                    const status = caseItem.status || "";

                                    return (
                                        <div
                                            key={caseItem.id}
                                            className="relative bg-white border border-gray-200 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow"
                                        >
                                            {/* Checkbox - Top Left */}
                                            <div className="absolute top-4 left-4">
                                                <Checkbox
                                                    checked={isSelected}
                                                    onCheckedChange={(value) => {
                                                        setRowSelection((prev) => ({
                                                            ...prev,
                                                            [caseItem.id]: !!value,
                                                        }));
                                                    }}
                                                    aria-label="Select case"
                                                />
                                            </div>

                                            {/* Status Badge - Top Right */}
                                            <div className="absolute top-4 right-4">
                                                <Badge variant="secondary" className="text-gray-800 font-semibold text-xs px-2 py-0.5 rounded-full border border-gray-300 bg-white">
                                                    {status}
                                                </Badge>
                                            </div>

                                            {/* Customer Name - Large Bold */}
                                            <div className="mt-8 mb-1">
                                                <h3 className="text-lg font-bold text-gray-900">{customerName}</h3>
                                            </div>

                                            {/* LAN - Smaller Lighter Gray */}
                                            <div className="mb-4">
                                                <span className="text-sm text-gray-500">{lan}</span>
                                            </div>

                                            {/* Product */}
                                            <div className="mb-3">
                                                <span className="text-xs text-gray-500">Product </span>
                                                <div className="text-sm font-semibold text-gray-900">
                                                    {product}
                                                </div>
                                            </div>

                                            {/* Loan Amount */}
                                            <div className="mb-3">
                                                <span className="text-xs text-gray-500">Loan Amount </span>
                                                <div className="text-sm font-bold text-gray-900">
                                                    ₹{loanAmount.toLocaleString("en-IN")}
                                                </div>
                                            </div>

                                            {/* Next Due Date */}
                                            <div className="mb-4">
                                                <span className="text-sm text-gray-500">Next Due Date: </span>
                                                <div className="text-sm font-semibold text-gray-900">
                                                    {nextDueDate}
                                                </div>
                                            </div>

                                            {/* Action Icons */}
                                            <div className="flex items-center justify-end gap-2 pt-3">
                                                <Button variant="ghost" size="icon" className="h-10 w-10 p-0 hover:bg-transparent">
                                                    <ListChecks className="h-6 w-6 text-gray-900" />
                                                </Button>
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="h-10 w-10 p-0 hover:bg-transparent"
                                                    onClick={() => handleViewHistory(caseItem)}
                                                    title="View case history"
                                                >
                                                    <History className="h-6 w-6 text-gray-900" />
                                                </Button>
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="h-10 w-10 p-0 hover:bg-transparent"
                                                    onClick={() => handleOpenViewCase(caseItem)}
                                                >
                                                    <Eye className="h-6 w-6 text-gray-900" />
                                                </Button>
                                                {/* <Button variant="ghost" size="icon" className="h-10 w-10 p-0 hover:bg-transparent">
                                                    <MoreVertical className="h-6 w-6 text-gray-900" />
                                                </Button> */}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        ) : (
                            <div className="flex items-center justify-center h-24">
                                <p className="text-muted-foreground">No results.</p>
                            </div>
                        )}
                    </div>
                )}

                {/* Pagination */}
                <div className="sticky bottom-0 z-30 pt-2 pb-2 bg-gradient-to-t from-white via-white/95 to-transparent">
                    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 px-2">
                        {/* Left Section - Selection Info */}
                        <div className="flex items-center justify-center lg:justify-start gap-3">
                            <div className="bg-gray-100/80 backdrop-blur-sm text-gray-700 px-4 py-2 rounded-lg border border-gray-200 shadow-sm">
                                <div className="flex items-center gap-2">
                                    <svg className="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                    </svg>
                                    <span className="text-xs font-semibold whitespace-nowrap">
                                        {selectionCount} selected out of {totalCases} Cases
                                    </span>
                                    {selectionCount > 0 && (
                                        <Button
                                            variant="link"
                                            size="sm"
                                            className="h-auto p-0 text-blue-600 hover:text-blue-800 text-[10px] font-bold ml-2 underline uppercase tracking-wider"
                                            onClick={() => {
                                                setRowSelection({});
                                                setSelectedCasesRecord({});
                                            }}
                                        >
                                            Clear All
                                        </Button>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Right Section - Pagination Controls */}
                        <div className="flex flex-col md:flex-row items-center justify-center lg:justify-end gap-3">
                            {/* Stats Badges */}
                            <div className="flex flex-wrap items-center justify-center gap-2">
                                <div className="bg-gray-100/80 backdrop-blur-sm text-gray-700 px-4 py-2 rounded-lg border border-gray-200 shadow-sm">
                                    <div className="flex items-center gap-2">
                                        <List className="w-3.5 h-3.5" />
                                        <span className="text-[11px] font-bold whitespace-nowrap">
                                            {table.getRowModel().rows.length} Cases on this page
                                        </span>
                                    </div>
                                </div>
                                <div className="bg-gray-100/80 backdrop-blur-sm text-gray-700 px-4 py-2 rounded-lg border border-gray-200 shadow-sm">
                                    <div className="flex items-center gap-2">
                                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                                        </svg>
                                        <span className="text-[11px] font-bold whitespace-nowrap">
                                            {totalPages || 1} Page{totalPages !== 1 ? 's' : ''}
                                        </span>
                                    </div>
                                </div>
                            </div>

                            {/* Pagination Navigation */}
                            <div className="flex items-center gap-1 h-8 w-100 p-1">
                                {/* First Page */}
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    className={cn(
                                        "h-8 w-8 p-0 bg-blue-50 hover:bg-blue-100 hover:text-blue-700 transition-all",
                                        (isFirstPage || loading) && "opacity-40 cursor-not-allowed"
                                    )}
                                    onClick={() => setPageIndex(0)}
                                    disabled={isFirstPage || loading}
                                    title="First page"
                                >
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
                                    </svg>
                                </Button>

                                {/* Previous Page */}
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    className={cn(
                                        "h-8 px-2 sm:px-3 bg-blue-50 hover:bg-blue-100 hover:text-blue-700 transition-all font-medium",
                                        (isFirstPage || loading) && "opacity-40 cursor-not-allowed"
                                    )}
                                    onClick={() => setPageIndex(Math.max(0, pageIndex - 1))}
                                    disabled={isFirstPage || loading}
                                >
                                    <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                                    </svg>
                                    <span className="hidden xs:inline">Prev</span>
                                </Button>

                                {/* Page Info */}
                                <div className="flex items-center gap-1.5 px-3 py-2 bg-gray-100 rounded-lg">
                                    <span className="text-[10px] font-bold text-gray-900 uppercase tracking-wider">
                                        {pageIndex + 1}
                                    </span>
                                    <span className="text-[10px] font-bold text-gray-500 tracking-wider">of</span>
                                    <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">
                                        {totalPages || 1}
                                    </span>
                                </div>

                                {/* Next Page */}
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    className={cn(
                                        "h-8 px-2 sm:px-3 bg-blue-50 hover:bg-blue-100 hover:text-blue-700 transition-all font-medium",
                                        (isLastPage || loading) && "opacity-40 cursor-not-allowed"
                                    )}
                                    onClick={() => setPageIndex(pageIndex + 1)}
                                    disabled={isLastPage || loading}
                                >
                                    <span className="hidden xs:inline mr-1">Next</span>
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                    </svg>
                                </Button>

                                {/* Last Page */}
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    className={cn(
                                        "h-8 w-8 p-0 bg-blue-50 hover:bg-blue-100 hover:text-blue-700 transition-all",
                                        (isLastPage || loading) && "opacity-40 cursor-not-allowed"
                                    )}
                                    onClick={() => setPageIndex(totalPages - 1)}
                                    disabled={isLastPage || loading}
                                    title="Last page"
                                >
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" />
                                    </svg>
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <ViewCase
                open={isViewCaseOpen}
                onOpenChange={handleViewCaseToggle}
                caseData={selectedCase}
            />
            <CaseActionsGuide
                isOpen={isActionsGuideOpen}
                setIsOpen={setIsActionsGuideOpen}
            />
            <AddCaseNotesDialog
                isOpen={isNotesDialogOpen}
                onOpenChange={setIsNotesDialogOpen}
                cases={selectedCasesForNotes}
            />
            <CaseHistorySheet
                isOpen={isHistorySheetOpen}
                onOpenChange={handleHistoryToggle}
                caseItem={selectedCaseForHistory}
            />

            <AddContact
                isOpen={isAddContactOpen}
                onOpenChange={setIsAddContactOpen}
                caseData={selectedAccountForAction}
            />
            <AddAddress
                isOpen={isAddAddressOpen}
                onOpenChange={setIsAddAddressOpen}
                caseData={selectedAccountForAction}
            />
            {isSingleAssignDialogOpen && (
                <BulkAssignTaskSheet
                    isOpen={isSingleAssignDialogOpen}
                    onOpenChange={setIsSingleAssignDialogOpen}
                    selectedTasks={selectedTasksList}
                    onSuccess={() => {
                        setRowSelection({}); // Clear selection
                        fetchCasesData(); // Refresh data
                    }}
                    securityGroupId={advancedSearch.selectedSecurityGroupId}
                />
            )}

            <AdvanceSearchCases
                isOpen={advancedSearch.isAdvancedSearchOpen}
                setIsOpen={advancedSearch.setIsAdvancedSearchOpen}
                filters={advancedSearch.filters}
                updateFilter={advancedSearch.updateFilter}
                onResetFilters={advancedSearch.resetFilters}
                onApplyFilters={() => {
                    advancedSearch.applyFilters();
                    advancedSearch.setIsAdvancedSearchOpen(false);
                }}
                states={states}
                branches={advancedSearch.branches}
                agents={advancedSearch.agents}
                isLoadingAgents={advancedSearch.isLoadingAgents}
            />
        </div>
    );
}

