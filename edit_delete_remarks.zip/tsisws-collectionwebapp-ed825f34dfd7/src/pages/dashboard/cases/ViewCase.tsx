import { type ReactNode, useState, useEffect, useCallback } from "react";
import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetDescription,
} from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { User, Phone, Building, MapPin, Loader2, UserPlus, Home } from "lucide-react";
import type { Case, AccountContact, AccountAddressManagement } from "@/lib/types";
import { getAccountContactsByAccountId, getAccountAddressesByAccountId } from "@/lib/services/cases";
import { Button } from "@/components/ui/button";
import { AddContact } from "@/components/Cases/AddContact";
import { AddAddress } from "@/components/Cases/AddAddress";
import { useUserRole } from "@/contexts/UserRoleContext";

type ViewCaseProps = {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    caseData: Case | null;
};

function InfoRow({
    label,
    value,
}: {
    label: string;
    value?: ReactNode;
}) {
    return (
        <div className="flex justify-between gap-3 text-sm">
            <span className="text-muted-foreground">{label}</span>
            <span className="font-semibold text-gray-900 text-right">
                {value ?? "-"}
            </span>
        </div>
    );
}

function Currency({ amount }: { amount?: number | string | null }) {
    if (amount === null || amount === undefined || amount === "") return <span>-</span>;
    const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
    if (isNaN(numAmount)) return <span>-</span>;
    return <span>₹{numAmount.toLocaleString("en-IN")}</span>;
}

export default function ViewCase({ open, onOpenChange, caseData }: ViewCaseProps) {
    const [activeTab, setActiveTab] = useState<"details" | "contacts" | "addresses">("details");
    const [contacts, setContacts] = useState<AccountContact[]>([]);
    const [addresses, setAddresses] = useState<AccountAddressManagement[]>([]);
    const [loadingContacts, setLoadingContacts] = useState(false);
    const [loadingAddresses, setLoadingAddresses] = useState(false);
    const [isAddContactOpen, setIsAddContactOpen] = useState(false);
    const [isAddAddressOpen, setIsAddAddressOpen] = useState(false);
    const { canAccessCategory } = useUserRole();
    const account = caseData?.account;
    const accountId = caseData?.id;

    // Fetch contacts
    const fetchContacts = useCallback(async () => {
        if (!accountId) return;
        setLoadingContacts(true);
        try {
            const data = await getAccountContactsByAccountId(accountId);
            setContacts(data);
        } finally {
            setLoadingContacts(false);
        }
    }, [accountId]);

    // Fetch addresses
    const fetchAddresses = useCallback(async () => {
        if (!accountId) return;
        setLoadingAddresses(true);
        try {
            const data = await getAccountAddressesByAccountId(accountId);
            setAddresses(data);
        } finally {
            setLoadingAddresses(false);
        }
    }, [accountId]);

    useEffect(() => {
        if (!open || !accountId) return;

        if (activeTab === "contacts") {
            fetchContacts();
        } else if (activeTab === "addresses") {
            fetchAddresses();
        }
    }, [open, accountId, activeTab, fetchContacts, fetchAddresses]);

    // Reset tab and data when sheet closes/opens for a new case
    useEffect(() => {
        if (open) {
            setActiveTab("details");
            setContacts([]);
            setAddresses([]);
        }
    }, [open]);

    return (
        <Sheet
            open={open}
            onOpenChange={onOpenChange}
        >
            <SheetContent
                side="right"
                className="w-full sm:max-w-lg overflow-y-auto"
            >
                <SheetHeader className="text-left mb-4">
                    <SheetTitle>Case Details - {account?.applicationNumber ?? caseData?.caseNumber ?? "-"}</SheetTitle>
                    <SheetDescription>
                        Review details for {account?.name ?? "the selected customer"}.
                    </SheetDescription>
                </SheetHeader>

                {caseData ? (
                    <div className="space-y-5">
                        <div className="flex items-center gap-0 rounded-md overflow-hidden bg-muted px-1 py-0.5">
                            {(["details", "contacts", "addresses"] as const).map((tab) => (
                                <button
                                    key={tab}
                                    type="button"
                                    onClick={() => setActiveTab(tab)}
                                    className={`flex-1 px-4 py-2 text-sm font-semibold transition-colors ${activeTab === tab
                                        ? "bg-white text-gray-900 rounded"
                                        : "bg-transparent text-gray-600"
                                        }`}
                                >
                                    {tab.charAt(0).toUpperCase() + tab.slice(1)}
                                </button>
                            ))}
                        </div>

                        {activeTab === "details" && (
                            <div className="space-y-6">
                                <div className="space-y-4 rounded-lg border p-4 bg-white">
                                    <div className="flex items-center justify-between">
                                        <h3 className="font-semibold text-gray-900">
                                            Case Information
                                        </h3>
                                        {caseData.status ? (
                                            <Badge variant="secondary" className="text-gray-800">
                                                {caseData.status}
                                            </Badge>
                                        ) : null}
                                    </div>
                                    <div className="space-y-2">
                                        <InfoRow label="LAN Number" value={account?.lanNumber} />
                                        <InfoRow label="Application Number" value={account?.applicationNumber} />
                                        <InfoRow label="Product" value={account?.product} />
                                        <InfoRow label="Loan Amount" value={<Currency amount={account?.loanAmount} />} />
                                        <InfoRow label="Disbursement Status" value={account?.disbursementStatus} />
                                        <InfoRow label="Next Due Date" value={account?.nextDueDate ?? caseData.nextActionDate} />
                                        <InfoRow label="Branch" value={account?.branch} />
                                        <InfoRow label="BDM Name" value={account?.bdmName} />
                                        <InfoRow label="RM Name" value={account?.rmName} />
                                    </div>
                                </div>

                                <div className="space-y-4 rounded-lg border p-4 bg-white">
                                    <h3 className="font-semibold text-gray-900">Customer Information</h3>
                                    <div className="space-y-2">
                                        <InfoRow label="Customer ID" value={account?.customerId} />
                                        <InfoRow label="Customer Name" value={account?.name} />
                                        <InfoRow label="Gender" value={account?.customerGender} />
                                        <InfoRow label="Phone Number" value={account?.customerPhoneNumber} />
                                        <InfoRow label="Email" value={account?.emailAddress} />
                                    </div>
                                </div>

                                <div className="space-y-4 rounded-lg border p-4 bg-white">
                                    <h3 className="font-semibold text-gray-900">Co-Applicant Information</h3>
                                    <div className="space-y-2">
                                        <InfoRow label="Name" value={account?.coApplicantName} />
                                        <InfoRow label="Gender" value={account?.coapplicantGender} />
                                        <InfoRow label="Phone Number" value={account?.coapplicantPhoneNumber} />
                                    </div>
                                </div>

                                <div className="space-y-4 rounded-lg border p-4 bg-white">
                                    <h3 className="font-semibold text-gray-900">Property Information</h3>
                                    <div className="space-y-2">
                                        <InfoRow label="Property Type" value={account?.propertyType} />
                                        <InfoRow label="Property Value" value={<Currency amount={account?.propertyValue} />} />
                                    </div>
                                </div>
                            </div>
                        )}

                        {activeTab === "contacts" && (
                            <div className="space-y-4 py-6">
                                <div className="flex justify-between items-center mb-2">
                                    <h3 className="font-semibold text-gray-900">Contacts</h3>
                                    {canAccessCategory("AddContact") && <Button
                                        variant="outline"
                                        size="sm"
                                        className="h-8 gap-1"
                                        onClick={() => setIsAddContactOpen(true)}
                                    >
                                        <UserPlus className="h-4 w-4" />
                                        Add Contact
                                    </Button>}
                                </div>
                                {loadingContacts ? (
                                    <div className="flex flex-col items-center justify-center py-12 gap-2">
                                        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                                        <p className="text-sm text-muted-foreground">Loading contacts...</p>
                                    </div>
                                ) : contacts && contacts.length > 0 ? (
                                    contacts.map((contact: AccountContact) => (
                                        <Card key={contact.id}>
                                            <CardHeader className="pb-0">
                                                <CardTitle className="text-[13px] sm:text-[13px] font-bold uppercase tracking-tight flex items-center justify-between">
                                                    <span><User className="inline-block mr-2 h-4 w-4" />{contact.contactName}</span>
                                                </CardTitle>
                                            </CardHeader>
                                            <CardContent className="!pt-0 space-y-2">
                                                <p className="text-sm text-gray-800 leading-relaxed font-medium flex items-center gap-2"><Phone className="h-4 w-4" /> {contact.contactNumber}</p>
                                                <p className="text-xs text-muted-foreground mt-2">Added on: {new Date(contact.dateEntered).toLocaleDateString()}</p>
                                            </CardContent>
                                        </Card>
                                    ))
                                ) : (
                                    <p className="text-muted-foreground text-center py-8">No contacts found.</p>
                                )}
                            </div>
                        )}

                        {activeTab === "addresses" && (
                            <div className="space-y-4 py-6">
                                <div className="flex justify-between items-center mb-2">
                                    <h3 className="font-semibold text-gray-900">Addresses</h3>
                                    {canAccessCategory("AddAddress") && <Button
                                        variant="outline"
                                        size="sm"
                                        className="h-8 gap-1"
                                        onClick={() => setIsAddAddressOpen(true)}
                                    >
                                        <Home className="h-4 w-4" />
                                        Add Address
                                    </Button>}
                                </div>
                                {(() => {
                                    const defaultAddresses = [
                                        {
                                            id: "default-customer",
                                            locname: "Customer Address",
                                            address: account?.customerAddress,
                                            latitude: account?.customerLatitude,
                                            longitude: account?.customerLongitude,
                                        },
                                        {
                                            id: "default-coapplicant",
                                            locname: "Co-Applicant Address",
                                            address: account?.coapplicantAddress,
                                            latitude: account?.coapplicantLatitude,
                                            longitude: account?.coapplicantLongitude,
                                        },
                                        {
                                            id: "default-property",
                                            locname: "Property Address",
                                            address: account?.propertyAddress,
                                            latitude: account?.propertyLatitude,
                                            longitude: account?.propertyLongitude,
                                        }
                                    ].filter(addr => addr.address);

                                    const allAddresses = [...defaultAddresses, ...addresses];

                                    if (loadingAddresses && addresses.length === 0) {
                                        return (
                                            <div className="flex flex-col items-center justify-center py-12 gap-2">
                                                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                                                <p className="text-sm text-muted-foreground">Loading addresses...</p>
                                            </div>
                                        );
                                    }

                                    if (allAddresses.length === 0) {
                                        return <p className="text-muted-foreground text-center py-8">No addresses found.</p>;
                                    }

                                    return allAddresses.map((address) => (
                                        <Card key={address.id} className="shadow-none border-gray-100">
                                            <CardHeader className="p-3 pb-0">
                                                <CardTitle className="text-[13px] sm:text-[13px] font-bold uppercase tracking-tight flex items-center justify-between">
                                                    <span className="flex items-center">
                                                        <Building className="inline-block mr-1.5 h-3 w-3" />
                                                        {address.locname}
                                                    </span>
                                                    {address.latitude && address.longitude && (
                                                        <a
                                                            href={`https://www.google.com/maps/search/?api=1&query=${address.latitude},${address.longitude}`}
                                                            target="_blank"
                                                            rel="noopener noreferrer"
                                                            className="flex items-center gap-1 text-[10px] text-blue-600 hover:underline font-medium"
                                                        >
                                                            <MapPin className="h-3 w-3" />
                                                            View on Map
                                                        </a>
                                                    )}
                                                </CardTitle>
                                            </CardHeader>
                                            <CardContent className="!pt-0 space-y-2">
                                                <p className="text-xs text-gray-800 leading-relaxed font-medium">{address.address}</p>
                                                {'dateEntered' in address && (
                                                    <p className="text-[10px] text-muted-foreground pt-1">
                                                        Added on: {new Date(address.dateEntered).toLocaleDateString()}
                                                    </p>
                                                )}
                                            </CardContent>
                                        </Card>
                                    ));
                                })()}
                            </div>
                        )}
                        <AddContact
                            isOpen={isAddContactOpen}
                            onOpenChange={setIsAddContactOpen}
                            caseData={caseData}
                            onSuccess={fetchContacts}
                        />
                        <AddAddress
                            isOpen={isAddAddressOpen}
                            onOpenChange={setIsAddAddressOpen}
                            caseData={caseData}
                            onSuccess={fetchAddresses}
                        />
                    </div>
                ) : (
                    <div className="text-sm text-muted-foreground">
                        Select a case to view its details.
                    </div>
                )}
            </SheetContent>
        </Sheet>
    );
}
