import { useState, useEffect, useCallback, useMemo, Fragment, useRef } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { format } from "date-fns";
import type {
    ColumnDef,
    ColumnFiltersState,
    SortingState,
    RowSelectionState,
    ExpandedState,
} from "@tanstack/react-table";
import {
    flexRender,
    getCoreRowModel,
    getSortedRowModel,
    getExpandedRowModel,
    useReactTable,
} from "@tanstack/react-table";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
    Eye,
    List,
    LayoutGrid,
    ChevronDown,
    Search,
    Filter,
    X,
    Loader2,
    ClipboardCheck,
} from "lucide-react";
import {
    searchDepositsPaginated,
} from "@/lib/services/deposits";
import type { CollReceipt, DepositSearchResult } from "@/lib/types";
import { ReceiptManagement } from "@/components/dashboard/ReceiptManagement";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { usePagination } from "@/hooks/use-pagination";
import { useDepositDetails } from "@/hooks/use-deposit-details";
import { useDebounce } from "@/hooks/use-debounce";
import { Pagination } from "@/components/common/pagination";
import { DepositDetailsSheet } from "@/components/deposits/DepositDetailsSheet";
import { useAdvancedDepositSearch } from "@/hooks/deposits/useAdvancedDepositSearch";
import { AdvancedDepositSearch } from "@/components/deposits/AdvancedDepositSearch";
import { useApproveRejectTasks } from "@/hooks/Tasks/useApproveRejectTasks";
import { useGeoLocation } from "@/hooks/use-location";
import { ApproveRejectTasks } from "@/components/Tasks/ApproveRejectTasks";
import { cn, formatDateTime } from "@/lib/utils";
import { useUserRole } from "@/contexts/UserRoleContext";



const columnDisplayNames: Record<string, string> = {
    depositSlipno: "Deposit Slip No",
    bankDepositDate: "Deposit Date",
    bankDepositedAmount: "Total Amount",
    status: "Status",
    bankName: "Bank Name",
    actions: "Actions",
};

const createColumns = (
    onViewDeposit: (deposit: DepositSearchResult) => void,
): ColumnDef<DepositSearchResult>[] => [
        {
            id: "select",
            header: ({ table }) => (
                <Checkbox
                    checked={
                        table.getIsAllPageRowsSelected() ||
                        (table.getIsSomePageRowsSelected() && "indeterminate")
                    }
                    onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                    aria-label="Select all"
                />
            ),
            cell: ({ row }) => (
                <Checkbox
                    checked={row.getIsSelected()}
                    onCheckedChange={(value) => row.toggleSelected(!!value)}
                    aria-label="Select row"
                />
            ),
            enableSorting: false,
            enableHiding: false,
        },
        {
            accessorKey: "depositSlipno",
            header: () => (
                <div className="flex items-center gap-2">
                    <div className="w-6" />
                    <span>Deposit Slip No</span>
                </div>
            ),
            cell: ({ row }) => {
                const canExpand = row.getCanExpand();
                return (
                    <div className="flex items-center gap-2">
                        {canExpand ? (
                            <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 p-0 hover:bg-gray-10"
                                onClick={(e) => {
                                    e.stopPropagation();
                                    row.toggleExpanded();
                                }}
                            >
                                <ChevronDown
                                    className={cn(
                                        "h-4 w-4 text-blue-600 transition-transform duration-200",
                                        row.getIsExpanded() ? "rotate-180" : ""
                                    )}
                                />
                            </Button>
                        ) : (
                            <div className="w-6" />
                        )}
                        <span className="font-medium">{row.original.depositSlipno || "-"}</span>
                    </div>
                );
            },
        },
        {
            accessorKey: "branchDepositionDate",
            header: "Deposit Date",
            cell: ({ row }) => {
                const date = row.original.branchDepositionDate;
                if (!date) return "";
                try {
                    const dateObj = new Date(date);
                    return dateObj.toLocaleDateString("en-GB", {
                        day: "2-digit",
                        month: "2-digit",
                        year: "numeric",
                    });
                } catch {
                    return date;
                }
            },
        },
        {
            accessorKey: "branchDepositAmount",
            header: () => <div className="text-right">Amount</div>,
            cell: ({ row }) => {
                const amount = row.original.branchDepositAmount;
                const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
                return (
                    <div className="text-right font-medium">
                        {numAmount ? `₹${numAmount.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : ""}
                    </div>
                );
            },
        },
        {
            accessorKey: "userName",
            header: "Deposited By",
            cell: ({ row }) => row.original.userName || "-",
        },
        {
            id: "actions",
            header: () => <div className="text-right">Actions</div>,
            size: 100,
            cell: ({ row }) => {
                const deposit = row.original;
                return (
                    <div className="flex items-center justify-end gap-2">
                        <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => onViewDeposit(deposit)}
                        >
                            <Eye className="h-4 w-4 text-blue-600" />
                        </Button>
                    </div>
                );
            },
            enableSorting: false,
        },
    ];

export default function AcceptancePendingList() {
    const navigate = useNavigate();
    const [deposits, setDeposits] = useState<DepositSearchResult[]>([]);
    const [loading, setLoading] = useState(true);
    const [refreshNonce, setRefreshNonce] = useState(0);
    const prevFilters = useRef({ debouncedFilter: "", appliedFilters: {} as any });
    const [sorting, setSorting] = useState<SortingState>([]);
    const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
    const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
    const [expanded, setExpanded] = useState<ExpandedState>({});
    const [globalFilter, setGlobalFilter] = useState("");
    const debouncedFilter = useDebounce(globalFilter, 500);
    const { canAccessCategory } = useUserRole();
    const [view, setView] = useState<"table" | "card">("table");
    const [isAdvancedSearchOpen, setIsAdvancedSearchOpen] = useState(false);

    // Server-side pagination state
    const {
        pageIndex,
        setPageIndex,
        pageSize,
        totalRecords,
        totalPages,
        hasNext,
        hasPrevious,
        updatePagination,
        resetPagination,
    } = usePagination(20);

    const {
        filters,
        appliedFilters,
        tempDepositDateRange,
        dateRangePopoverOpen,
        bankNames,
        loadingBankNames,
        activeFilters,
        setDepositSlipNo,
        setSelectedBank,
        setTempDepositDateRange,
        handleApplyFilters,
        handleResetFilters,
        handleApplyDateRange,
        handleCancelDateRange,
        handleDateRangeOpenChange,
        removeFilter,
        clearAllFilters,
    } = useAdvancedDepositSearch(() => {setPageIndex(0); setRowSelection({});});

    // Pagination helpers
    const selectionCount = Object.keys(rowSelection).length;
    // Receipt management state
    const [selectedReceipt, setSelectedReceipt] = useState<CollReceipt | null>(null);
    const [receiptManagementMode, setReceiptManagementMode] = useState<"edit" | "delete" | "check">("check");
    const [isReceiptManagementOpen, setIsReceiptManagementOpen] = useState(false);
    const [searchParams] = useSearchParams();
    const { toast } = useToast();
    const isMobile = useIsMobile();
    const { withLocation } = useGeoLocation();

    const approveReject = useApproveRejectTasks({
        onSuccess: () => {
            setRowSelection({});
            loadDeposits();
        },
    });

    const receiptListParam = useMemo(() => searchParams.get("receiptList")?.trim() || "", [searchParams]);

    const parseReceiptList = useCallback((raw: string): string[] => {
        if (!raw) return [];
        const trimmed = raw.trim();
        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            try {
                const parsed = JSON.parse(trimmed);
                if (Array.isArray(parsed)) {
                    return parsed.map((value) => String(value).trim()).filter(Boolean);
                }
            } catch {
                // fall through to split-based parsing
            }
        }
        return trimmed
            .split(/[,\s]+/)
            .map((value) => value.trim())
            .filter(Boolean);
    }, []);

    useEffect(() => {
        if (isMobile !== undefined) {
            setView(isMobile ? "card" : "table");
        }
    }, [isMobile]);



    // Reset pagination when refresh requested
    useEffect(() => {
        setRowSelection({});
        resetPagination();
    }, [resetPagination, refreshNonce]);

    // Reset page index when filter changes
    useEffect(() => {
        let isCurrent = true;

        const load = async () => {
            try {
                setLoading(true);
                const offset = pageIndex * pageSize;
                const depositStatus = "Verification Pending";

                const fromDate = appliedFilters.depositDateRange.from
                    ? format(appliedFilters.depositDateRange.from, "yyyy-MM-dd")
                    : undefined;
                const toDate = appliedFilters.depositDateRange.to
                    ? format(appliedFilters.depositDateRange.to, "yyyy-MM-dd")
                    : undefined;

                const data = await searchDepositsPaginated(
                    "Branch Deposit",
                    "Cash",
                    depositStatus,
                    pageSize,
                    offset,
                    debouncedFilter,
                    "DEPOSITED_AMOUNT",
                    "ASC",
                    fromDate,
                    toDate,
                    "DEPOSIT_DATE",
                    appliedFilters.depositSlipNo,
                    appliedFilters.selectedBank
                );

                if (!isCurrent) return;

                setDeposits(data.content);
                updatePagination({
                    totalRecords: data.totalRecords,
                    totalPages: data.totalPages,
                    hasNext: data.hasNext,
                    hasPrevious: data.hasPrevious
                });

            } catch (error) {
                if (!isCurrent) return;
                const errorMessage =
                    error instanceof Error ? error.message : "Failed to load deposits";
                if (!errorMessage.includes("401") && !errorMessage.includes("403")) {
                    toast({
                        title: "Error",
                        description: errorMessage,
                        variant: "destructive",
                    });
                }
            } finally {
                if (isCurrent) {
                    setLoading(false);
                }
            }
        };

        const filtersChanged = prevFilters.current.debouncedFilter !== debouncedFilter ||
            prevFilters.current.appliedFilters !== appliedFilters;

        if (filtersChanged && pageIndex !== 0) {
            setPageIndex(0);
            prevFilters.current = { debouncedFilter, appliedFilters };
            return;
        }

        prevFilters.current = { debouncedFilter, appliedFilters };
        load();

        return () => {
            isCurrent = false;
        };
    }, [pageIndex, pageSize, debouncedFilter, appliedFilters, refreshNonce, updatePagination, toast]);

    const loadDeposits = useCallback(() => {
        setRefreshNonce(n => n + 1);
    }, []);

    // Deposit Details hook (after loadDeposits)
    const depositDetails = useDepositDetails();

    useEffect(() => {
        if (!receiptListParam) {
            return;
        }
        const receipts = parseReceiptList(receiptListParam);
        if (receipts.length === 0) {
            return;
        }

        setGlobalFilter(receipts.join(" "));
    }, [parseReceiptList, receiptListParam]);

    // Server-side filtering is now used, so this returns the current deposits list
    const filteredDeposits = useMemo(() => {
        return deposits;
    }, [deposits]);

    const handleViewDeposit = useCallback(async (deposit: DepositSearchResult) => {
        if (deposit.id) {
            depositDetails.openDetails(deposit.id);
        }
    }, [depositDetails]);

    const columns = useMemo(() => createColumns(handleViewDeposit), [handleViewDeposit]);

    const selectedTasksForDialog = useMemo(() => {
        const selectedDeposits = deposits.filter((d) => rowSelection[d.id]);
        const tasks: any[] = [];
        selectedDeposits.forEach((d) => {
            (d.collReceipts || []).forEach((r) => {
                if (r.id) {
                    tasks.push({
                        id: r.id,
                        receiptNo: r.receiptNo,
                        totalAmount: typeof r.totalAmount === 'string' ? parseFloat(r.totalAmount) : r.totalAmount,
                    });
                }
            });
        });
        return tasks;
    }, [deposits, rowSelection]);

    // Receipt management handlers
    const handleEditReceipt = useCallback((receipt: CollReceipt) => {
        setSelectedReceipt(receipt);
        setReceiptManagementMode("edit");
        setIsReceiptManagementOpen(true);
    }, []);

    const handleDeleteReceipt = useCallback((receipt: CollReceipt) => {
        setSelectedReceipt(receipt);
        setReceiptManagementMode("delete");
        setIsReceiptManagementOpen(true);
    }, []);

    const handleReceiptManagementClose = useCallback(() => {
        setIsReceiptManagementOpen(false);
        setSelectedReceipt(null);
    }, []);

    
    /** Navigate to tasks list with LAN filter using location state */
    const handleViewTasks = useCallback((receipt: CollReceipt) => {
        const receiptNo = receipt?.receiptNo || "";
        const lan = receipt?.lanNumber || "";
        if (receiptNo) {
            navigate(`/dashboard/tasks`, { state: { receiptNo, lan, tab: "Acceptance Pending", openHistory: true} });
        }
    }, [navigate]);

    // ── AcceptReject ────────────────────────────────────────────────────
    const handleAcceptRejectClick = () => {
        withLocation(() => {
            if (selectionCount === 0) {
                toast({
                    title: "No Deposits Selected",
                    description: "Please select at least one deposit to approve or reject.",
                    variant: "destructive",
                });
                return;
            }
            if (selectedTasksForDialog.length === 0) {
                toast({
                    title: "No Valid Receipts",
                    description: "None of the selected deposits have valid linked receipts.",
                    variant: "destructive",
                });
                return;
            }
            approveReject.openApproveReject(selectedTasksForDialog.map(t => t.id));
        });
    };

    const handleReceiptManagementSuccess = useCallback(() => {
        // Reload the deposit details to reflect changes in both sidebars if open
        if (depositDetails.isOpen && depositDetails.selectedDeposit?.id) {
            depositDetails.refreshDetails();
        }
        // Reload the main list
        loadDeposits();
    }, [depositDetails, loadDeposits]);



    const table = useReactTable({
        data: filteredDeposits,
        columns,
        getRowId: (row) => row.id,
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        onRowSelectionChange: setRowSelection,
        onGlobalFilterChange: setGlobalFilter,
        onExpandedChange: setExpanded,
        getCoreRowModel: getCoreRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getExpandedRowModel: getExpandedRowModel(),
        getRowCanExpand: (row) => (row.original.collReceipts || []).length > 0,
        manualPagination: true,
        manualFiltering: true,
        pageCount: totalPages,
        onPaginationChange: (updater) => {
            if (typeof updater === 'function') {
                const nextState = updater({ pageIndex, pageSize });
                setPageIndex(nextState.pageIndex);
            } else {
                setPageIndex(updater.pageIndex);
            }
        },
        enableRowSelection: true,
        state: {
            sorting,
            columnFilters,
            rowSelection,
            globalFilter,
            expanded,
            pagination: {
                pageIndex,
                pageSize,
            },
        },
    });

    const renderTableSkeleton = (rows: number) => {
        const leafColumns = table.getVisibleLeafColumns();
        return Array.from({ length: rows }).map((_, rowIndex) => (
            <TableRow key={`skeleton-row-${rowIndex}`} className="border-b border-gray-300">
                {leafColumns.map((column) => (
                    <TableCell
                        key={`skeleton-${rowIndex}-${column.id}`}
                        className="whitespace-nowrap"
                    >
                        <div
                            className={cn(
                                "h-4 rounded bg-gray-100 animate-pulse",
                                column.id === "select" ? "w-6" : "w-24"
                            )}
                        />
                    </TableCell>
                ))}
            </TableRow>
        ));
    };


    return (
        <div className="flex flex-col h-[calc(100vh-8rem)]">
            <div className="sticky top-0 z-30 pb-4">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
                    <div>
                        <h1 className="text-2xl font-bold tracking-tight">Acceptance Pending</h1>
                        <p className="text-sm text-muted-foreground">
                            View the history of all acceptance pending.
                        </p>
                    </div>
                </div>

                {/* Applied Filters */}
                {activeFilters.length > 0 && (
                    <div className="mb-4 flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-medium text-gray-700">Applied Filters:</span>
                        {activeFilters.map((filter) => (
                            <div
                                key={filter.key}
                                className="inline-flex items-center gap-1.5 px-3 py-0.5 bg-muted rounded-full text-xs font-bold"
                            >
                                <span className="text-gray-700">
                                    <span className="font-bold">{filter.label}:</span> {filter.value}
                                </span>
                                <button
                                    onClick={() => removeFilter(filter.key)}
                                    className="ml-1 hover:bg-blue-100 rounded-full p-0.5 transition-colors"
                                    aria-label={`Remove ${filter.label} filter`}
                                >
                                    <X className="h-3.5 w-3.5 text-gray-600" />
                                </button>
                            </div>
                        ))}
                        <button
                            onClick={clearAllFilters}
                            className="text-sky-700 hover:text-sky-900 font-medium"
                        >
                            Clear All
                        </button>
                    </div>
                )}


            </div>

            {/* Table */}
            <div
                className="flex-1 overflow-hidden flex flex-col min-h-0 border-2 rounded-b-md transition-colors -mt-3 border-green-500"
            >
                {/* Search and Controls */}
                <div className="flex items-center gap-2 flex-wrap px-4 my-2">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                        <Input
                            placeholder="Search by LAN, Slip No, Txn ID..."
                            value={globalFilter ?? ""}
                            onChange={(event) => setGlobalFilter(event.target.value)}
                            className="pl-9 mr-10 pr-10"
                        />
                        {(loading || globalFilter !== debouncedFilter) ? (
                            <div className="absolute right-12 top-1/2 -translate-y-1/2">
                                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                            </div>
                        ) : globalFilter && (
                            <button
                                onClick={() => setGlobalFilter("")}
                                className="absolute right-12 top-1/2 -translate-y-1/2 hover:text-foreground transition-colors"
                            >
                                <X className="h-4 w-4 text-muted-foreground" />
                            </button>
                        )}

                    </div>
                    <div className="flex items-center gap-2">
                        <div className="relative">
                            <Button
                                variant="outline"
                                size="icon"
                                className="h-10 w-10 border-gray-300 bg-white hover:bg-rose-500"
                                onClick={() => setIsAdvancedSearchOpen(true)}
                            >
                                <Filter className="h-9 w-9 text-blue-700" strokeWidth={2.5} />
                            </Button>
                            {activeFilters.length > 0 && (
                                <div className="absolute -top-1 -right-1 flex items-center justify-center w-4 h-4 bg-red-500 rounded-full border-2 border-white">
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 20 20"
                                        fill="currentColor"
                                        className="w-2.5 h-2.5 text-white"
                                    >
                                        <path
                                            fillRule="evenodd"
                                            d="M16.704 5.29a1 1 0 010 1.42l-7.25 7.25a1 1 0 01-1.41 0l-3.75-3.75a1 1 0 111.41-1.42L9 11.59l6.29-6.3a1 1 0 011.41 0z"
                                            clipRule="evenodd"
                                        />
                                    </svg>
                                </div>
                            )}
                        </div>
                    </div>
                    <div className="flex items-center gap-2 ml-auto">
                        {canAccessCategory("ApproveRejectCashAP") && (<Button
                            variant="ghost"
                            size="icon"
                            className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                            disabled={selectionCount === 0}
                            onClick={handleAcceptRejectClick}
                            title="Accept / Reject Cash"
                        >
                            <ClipboardCheck className="h-9 w-9" />
                        </Button>)}
                        <div className="sm:flex items-center gap-1 border bg-muted p-1 rounded-md">
                            <Button
                                variant={view === "table" ? "secondary" : "ghost"}
                                size="icon"
                                className="h-7 w-7"
                                onClick={() => setView("table")}
                            >
                                <List className="h-4 w-4" />
                            </Button>
                            <Button
                                variant={view === "card" ? "secondary" : "ghost"}
                                size="icon"
                                className="h-7 w-7"
                                onClick={() => setView("card")}
                            >
                                <LayoutGrid className="h-4 w-4" />
                            </Button>
                        </div>
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="outline" className="h-10">
                                    Columns
                                    <ChevronDown className="ml-2 h-4 w-4" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent
                                align="end"
                                className="w-[200px] border-gray-300 bg-white"
                            >
                                {table
                                    .getAllColumns()
                                    .filter(
                                        (column) =>
                                            column.getCanHide() &&
                                            column.id !== "select"
                                    )
                                    .map((column) => {
                                        const displayName = columnDisplayNames[column.id] || column.id;

                                        return (
                                            <DropdownMenuCheckboxItem
                                                key={column.id}
                                                checked={column.getIsVisible()}
                                                onCheckedChange={(value) =>
                                                    column.toggleVisibility(!!value)
                                                }
                                                className="text-gray-900"
                                            >
                                                {displayName}
                                            </DropdownMenuCheckboxItem>
                                        );
                                    })}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                </div>

                {view === "table" && !isMobile ? (
                    <div className="flex-1 flex flex-col min-h-0 rounded-md border border-gray-200 bg-white overflow-hidden mx-4 mb-4">
                        <div className="flex-1 overflow-auto scrollbar-thin">
                            <Table className="w-full">
                                <TableHeader className="sticky top-0 z-20 bg-white border-b border-gray-300">
                                    {table.getHeaderGroups().map((headerGroup) => (
                                        <TableRow key={headerGroup.id} className="border-b border-gray-300">
                                            {headerGroup.headers.map((header) => {
                                                const isActions = header.column.id === "actions";
                                                const isAmount = header.column.id === "branchDepositAmount";
                                                return (
                                                    <TableHead
                                                        key={header.id}
                                                        className={cn(
                                                            "bg-white text-gray-500 font-medium",
                                                            (isActions || isAmount) && "text-right"
                                                        )}
                                                    >
                                                        {header.isPlaceholder
                                                            ? null
                                                            : flexRender(
                                                                header.column.columnDef.header,
                                                                header.getContext()
                                                            )}
                                                    </TableHead>
                                                );
                                            })}
                                        </TableRow>
                                    ))}
                                </TableHeader>
                                <TableBody>
                                    {loading ? (
                                        renderTableSkeleton(10)
                                    ) : table.getRowModel().rows?.length ? (
                                        table.getRowModel().rows.map((row) => (
                                            <Fragment key={row.id}>
                                                <TableRow className="border-b border-gray-300">
                                                    {row.getVisibleCells().map((cell) => {
                                                        const isActions = cell.column.id === "actions";
                                                        const isAmount = cell.column.id === "branchDepositAmount";
                                                        return (
                                                            <TableCell
                                                                key={cell.id}
                                                                className={cn(
                                                                    "whitespace-nowrap",
                                                                    (isActions || isAmount) && "text-right"
                                                                )}
                                                            >
                                                                {flexRender(
                                                                    cell.column.columnDef.cell,
                                                                    cell.getContext()
                                                                )}
                                                            </TableCell>
                                                        );
                                                    })}
                                                </TableRow>
                                                {row.getIsExpanded() && (
                                                    <TableRow className="bg-blue-50/30 border-b border-gray-300">
                                                        <TableCell colSpan={columns.length} className="p-0">
                                                            <div className="px-6 py-3 space-y-2">
                                                                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                                                                    Linked Receipts ({(row.original.collReceipts || []).length})
                                                                </div>
                                                                <div className="grid grid-cols-1 gap-2">
                                                                    {(row.original.collReceipts || []).map((receipt: any) => (
                                                                        <div
                                                                            key={receipt.id}
                                                                            className="grid grid-cols-[1.5fr_1.5fr_1.2fr_2.4fr_1.4fr_0.8fr_auto] items-center gap-3 py-2 px-3 bg-white rounded border border-gray-200 shadow-sm"
                                                                        >
                                                                            <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">LAN Number</div>
                                                                                <div className="text-[11px] font-semibold text-blue-600 hover:underline cursor-pointer whitespace-nowrap" onClick={() => handleViewTasks(receipt)} title={receipt.lanNumber}>{receipt.lanNumber}</div>
                                                                            </div>
                                                                            <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">Receipt Number</div>
                                                                                <div className="text-[11px] font-semibold text-gray-900 truncate" title={receipt.receiptNo}>{receipt.receiptNo}</div>
                                                                            </div>
                                                                            <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">Customer Name</div>
                                                                                <div className="text-[11px] font-semibold text-gray-900 truncate" title={receipt.customerName}>{receipt.customerName}</div>
                                                                            </div>
                                                                            <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">Date & Time</div>
                                                                                <div className="text-[11px] font-semibold text-gray-900 whitespace-nowrap" title={formatDateTime(receipt.receiptStoredDateTime)}>{formatDateTime(receipt.receiptStoredDateTime)}</div>
                                                                            </div>
                                                                            <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">Collected By</div>
                                                                                <div className="text-[11px] font-semibold text-gray-900 truncate" title={receipt.collectedBy}>{receipt.collectedBy}</div>
                                                                            </div>
                                                                            <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">Amount</div>
                                                                                <div className="text-[11px] font-medium text-gray-900 truncate">₹{receipt.totalAmount?.toLocaleString("en-IN") || "0"}</div>
                                                                            </div>
                                                                            <div className="flex justify-end min-w-0 pl-3 border-l border-gray-100">
                                                                                <Badge variant="secondary" className="text-[10px] bg-gray-100 text-gray-600 truncate">
                                                                                    {receipt.status || "Pending"}
                                                                                </Badge>
                                                                            </div>
                                                                        </div>
                                                                    ))}
                                                                </div>
                                                            </div>
                                                        </TableCell>
                                                    </TableRow>
                                                )}
                                            </Fragment>
                                        ))
                                    ) : (
                                        <TableRow className="border-b border-gray-300">
                                            <TableCell
                                                colSpan={columns.length}
                                                className="h-24 text-center"
                                            >
                                                No results found.
                                            </TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </div>
                    </div>
                ) : (
                    <div className="flex-1 overflow-y-auto px-4 pb-4 scrollbar-thin">
                        {loading ? (
                            <div className="flex flex-col items-center justify-center h-48 gap-3">
                                <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
                                <p className="text-sm text-muted-foreground animate-pulse">Loading deposits...</p>
                            </div>
                        ) : filteredDeposits.length > 0 ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                                {table.getRowModel().rows.map((row) => {
                                    const deposit = row.original;
                                    const receipts = deposit.collReceipts || [];
                                    const lanNo = receipts.length > 0 ? receipts[0].lanNumber : "-";
                                    const date = deposit.bankDepositDate;
                                    let formattedDate = "";
                                    if (date) {
                                        try {
                                            const dateObj = new Date(date);
                                            formattedDate = dateObj.toLocaleDateString("en-GB", {
                                                day: "2-digit",
                                                month: "2-digit",
                                                year: "numeric",
                                            });
                                        } catch {
                                            formattedDate = date;
                                        }
                                    }
                                    const status = deposit.status || "Pending";

                                    return (
                                        <div
                                            key={deposit.id}
                                            className="relative bg-white border border-gray-200 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow"
                                        >
                                            {/* Checkbox */}
                                            <div className="absolute top-3 left-3">
                                                <Checkbox
                                                    checked={row.getIsSelected()}
                                                    onCheckedChange={(value) => row.toggleSelected(!!value)}
                                                    aria-label="Select deposit"
                                                />
                                            </div>

                                            {/* Status Badge */}
                                            <div className="absolute top-3 right-3 flex items-center gap-1">
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="h-8 w-8"
                                                    onClick={() => handleViewDeposit(deposit)}
                                                >
                                                    <Eye className="h-4 w-4 text-blue-600" />
                                                </Button>
                                            </div>

                                            {/* Content */}
                                            <div className="mt-8 space-y-3">
                                                <div className="flex items-center gap-2 justify-between">
                                                    {/* Deposit ID */}
                                                    <div>
                                                        <p className="text-sm font-semibold text-gray-900">
                                                            {deposit.depositSlipno || "-"}
                                                        </p>
                                                    </div>
                                                    <Badge
                                                        variant="secondary"
                                                        className="bg-gray-100 text-gray-700 hover:bg-gray-100 font-normal text-xs"
                                                    >
                                                        {status}
                                                    </Badge>
                                                </div>

                                                {/* LAN Number */}
                                                <div>
                                                    <div className="flex items-center gap-2">
                                                        <p className="text-sm font-bold text-gray-900">{lanNo}</p>
                                                        {receipts.length > 1 && (
                                                            <Badge variant="outline" className="text-[10px] h-4 px-1">
                                                                +{receipts.length - 1} more
                                                            </Badge>
                                                        )}
                                                    </div>
                                                </div>

                                                {/* Date */}
                                                <div>
                                                    <p className="text-sm text-gray-900">{formattedDate || ""}</p>
                                                </div>

                                                {/* Actions */}
                                                <div className="flex items-center gap-2 pt-2 border-t border-gray-100 w-full">
                                                    {/* Total Amount */}
                                                    <div className="flex items-center gap-2 justify-between w-full">
                                                        <div className="text-gray-700 text-xs">Total Amount</div>
                                                        <div className="text-base font-semibold text-gray-900">
                                                            {deposit.branchDepositAmount != null
                                                                ? `₹${parseFloat(deposit.branchDepositAmount).toLocaleString("en-IN", {
                                                                    minimumFractionDigits: 2,
                                                                    maximumFractionDigits: 2,
                                                                })}`
                                                                : "-"}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        ) : (
                            <div className="text-center py-8 text-muted-foreground">
                                No results found.
                            </div>
                        )}
                    </div>
                )}

                {/* Pagination */}
                <Pagination
                    table={table}
                    totalRecords={totalRecords}
                    totalPages={totalPages}
                    pageIndex={pageIndex}
                    setPageIndex={setPageIndex}
                    hasNext={hasNext}
                    hasPrevious={hasPrevious}
                    loading={loading}
                    entityName="Deposits"
                    selectionCount={selectionCount}
                    onClearSelection={() => setRowSelection({})}
                />
            </div>

            {/* Advanced Deposit Search Sidebar */}
            <AdvancedDepositSearch
                isOpen={isAdvancedSearchOpen}
                onOpenChange={setIsAdvancedSearchOpen}
                activeTab={"Cash"}
                showBankSearch={false}
                tempDepositDateRange={tempDepositDateRange}
                depositSlipNo={filters.depositSlipNo}
                selectedBank={filters.selectedBank}
                dateRangePopoverOpen={dateRangePopoverOpen}
                bankNames={bankNames}
                loadingBankNames={loadingBankNames}
                setDepositSlipNo={setDepositSlipNo}
                setSelectedBank={setSelectedBank}
                setTempDepositDateRange={setTempDepositDateRange}
                handleApplyFilters={() => {
                    handleApplyFilters();
                    setIsAdvancedSearchOpen(false);
                }}
                handleResetFilters={() => {
                    handleResetFilters();
                    setIsAdvancedSearchOpen(false);
                }}
                handleApplyDateRange={handleApplyDateRange}
                handleCancelDateRange={handleCancelDateRange}
                handleDateRangeOpenChange={handleDateRangeOpenChange}
            />

            {/* Deposit Details Sidebar */}
            <DepositDetailsSheet
                isOpen={depositDetails.isOpen}
                onOpenChange={depositDetails.setIsOpen}
                loading={depositDetails.loading}
                selectedDeposit={depositDetails.selectedDeposit}
                activeTab={"Cash"}
                isAcceptancePending={true}
                onEditReceipt={handleEditReceipt}
                onDeleteReceipt={handleDeleteReceipt}
                isSubmitting={depositDetails.isSubmitting}
                onSubmission={depositDetails.handleDepositSubmission}
                onSuccess={loadDeposits}
            />

            {/* Receipt Management Dialog */}
            <ReceiptManagement
                receipt={selectedReceipt}
                isOpen={isReceiptManagementOpen}
                onClose={handleReceiptManagementClose}
                onSuccess={handleReceiptManagementSuccess}
                mode={receiptManagementMode}
            />
            {/* Approve/Reject Tasks Dialog */}
            <ApproveRejectTasks
                isOpen={approveReject.isOpen}
                onOpenChange={approveReject.setIsOpen}
                selectedTasks={selectedTasksForDialog}
                decision={approveReject.decision}
                remarks={approveReject.remarks}
                setRemarks={approveReject.setRemarks}
                isSubmitting={approveReject.isSubmitting}
                onSubmit={approveReject.handleSubmit}
            />
        </div>
    );
}
