import { useState, useMemo, useEffect, useCallback, useRef } from "react";
import {
    flexRender,
    getCoreRowModel,
    getSortedRowModel,
    useReactTable,
} from "@tanstack/react-table";
import type { 
    ColumnDef,
    SortingState,
    ColumnFiltersState,
    RowSelectionState,
    ColumnSizingState,
} from "@tanstack/react-table";

import { DataTableColumnHeader } from "@/components/ui/data-table-column-header";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetDescription,
} from "@/components/ui/sheet";
import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
    Filter,
    Info,
    List,
    LayoutGrid,
    ChevronDown,
    Pencil,
    History,
    Banknote,
    Loader2,
    X,
    CheckCircle2,
} from "lucide-react";

import type { 
    Task, 
    CollReceipt, 
    StateSecurityGroup, 
    BankDetail,
    AdvancedFilterParams 
} from "@/lib/types";
import { ReceiptManagement } from "@/components/dashboard/ReceiptManagement";
import { TaskHistorySheet } from "@/components/history/TaskHistorySheet";
import { cn } from "@/lib/utils";
import { DepositCashSheet } from "@/components/Tasks/DepositCashSheet";
import { AdvanceSearchTasks } from "@/components/Tasks/AdvanceSearchTasks";
import { Pagination } from "@/components/common/pagination";
import { useDebounce } from "@/hooks/use-debounce";
import { useUserRole } from "@/contexts/UserRoleContext";
import { useToast } from "@/hooks/use-toast";
import { useGeoLocation } from "@/hooks/use-location";
import { usePagination } from "@/hooks/use-pagination";
import { useAdvancedSearchTasks } from "@/hooks/Tasks/useAdvancedSearchTasks";
import { 
    searchCasesPaginated, 
    getStateSecurityGroups 
} from "@/lib/services/tasks";
import { getBankDetails } from "@/lib/services/bank-details";
import { format } from "date-fns";

// ---------------------------------------------------------------------------
// Pure UI Helpers
// ---------------------------------------------------------------------------

const getDpdBorderClasses = (dpd: number): string => {
    if (dpd <= 30) return "border-l-4 border-l-green-500 border-t border-r border-b border-t-green-200 border-r-green-200 border-b-green-200";
    if (dpd <= 90) return "border-l-4 border-l-yellow-500 border-t border-r border-b border-t-yellow-200 border-r-yellow-200 border-b-yellow-200";
    return "border-l-4 border-l-red-500 border-t border-r border-b border-t-red-200 border-r-red-200 border-b-red-200";
};

const getDpdTextClass = (dpd: number): string => {
    if (dpd <= 30) return "text-green-600";
    if (dpd <= 90) return "text-yellow-600";
    return "text-red-600";
};

const naLastStringSortFn = (
    rowA: { getValue: (id: string) => unknown },
    rowB: { getValue: (id: string) => unknown },
    columnId: string
): number => {
    const a = String(rowA.getValue(columnId) ?? "").toLowerCase();
    const b = String(rowB.getValue(columnId) ?? "").toLowerCase();
    if (a === "n/a" || a === "") return 1;
    if (b === "n/a" || b === "") return -1;
    return a.localeCompare(b);
};

const COLUMN_DISPLAY_NAMES: Record<string, string> = {
    taskNumber: "Case Number",
    receiptNo: "Receipt Id",
    paymentMode: "Payment Mode",
    transactionRefNo: "Transaction Id",
    lan: "Lan Number",
    branch: "Branch",
    product: "Product",
    emiOverdue: "Emi Overdue",
    receivedAmount: "Amount Paid",
    dpd: "Dpd",
    status: "Status",
    disposition: "Disposition",
    activityDate: "Activity Date",
    lastModified: "Date Modified",
    activityBy: "Activity By",
};

// ---------------------------------------------------------------------------
// Column definition factory
// ---------------------------------------------------------------------------

const buildColumns = (
    onEditReceipt: (task: Task) => void,
    onViewHistory: (task: Task) => void,
    canAccessCategory: (category: string, action?: string) => boolean,
): ColumnDef<Task>[] => [
        {
            id: "select",
            header: ({ table }) => (
                <Checkbox
                    checked={
                        table.getIsAllPageRowsSelected() ||
                        (table.getIsSomePageRowsSelected() && "indeterminate")
                    }
                    onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                    aria-label="Select all"
                />
            ),
            cell: ({ row }) => (
                <Checkbox
                    checked={row.getIsSelected()}
                    onCheckedChange={(value) => row.toggleSelected(!!value)}
                    aria-label="Select row"
                />
            ),
            enableSorting: false,
            enableHiding: false,
            size: 50,
        },
        {
            accessorKey: "lan",
            header: ({ column }) => <DataTableColumnHeader column={column} title="LAN" />,
            cell: ({ row }) => <span>{row.getValue("lan")}</span>,
            sortingFn: naLastStringSortFn,
            size: 90,
        },
        {
            accessorKey: "branch",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Branch" />,
            cell: ({ row }) => <span>{row.getValue("branch")}</span>,
            sortingFn: naLastStringSortFn,
            size: 100,
        },
        {
            accessorKey: "receiptNo",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Receipt No." />,
            cell: ({ row }) => (
                <span className={cn("font-medium", getDpdTextClass(row.original.dpd))}>
                    {row.getValue("receiptNo")}
                </span>
            ),
            sortingFn: naLastStringSortFn,
            size: 100,
        },
        {
            accessorKey: "agentName",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Agent Name" />,
            cell: ({ row }) => <span>{row.getValue("agentName")}</span>,
            sortingFn: naLastStringSortFn,
            size: 100,
        },
        {
            accessorKey: "customerName",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Customer Name" />,
            cell: ({ row }) => <span>{row.getValue("customerName")}</span>,
            sortingFn: naLastStringSortFn,
            size: 100,
        },
        {
            accessorKey: "lastModified",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Last Modified" />,
            cell: ({ row }) => <span>{String(row.getValue("lastModified") ?? "").replace(/\s+/g, "")}</span>,
            size: 110,
        },
        {
            accessorKey: "activityDate",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Activity Date" />,
            cell: ({ row }) => <span>{String(row.getValue("activityDate") ?? "").replace(/\s+/g, "")}</span>,
            sortingFn: (rowA, rowB, columnId) => {
                const a = String(rowA.getValue(columnId) ?? "");
                const b = String(rowB.getValue(columnId) ?? "");
                if (a === "N/A" || a === "") return 1;
                if (b === "N/A" || b === "") return -1;
                const toMs = (s: string) => {
                    const [d, m, y] = s.split("/").map(Number);
                    return new Date(y, m - 1, d).getTime();
                };
                return toMs(a) - toMs(b);
            },
            size: 110, minSize: 100, maxSize: 130,
        },
        {
            accessorKey: "activityBy",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Activity By" />,
            cell: ({ row }) => <span>{row.getValue("activityBy")}</span>,
            sortingFn: naLastStringSortFn,
            size: 110, minSize: 100, maxSize: 130,
        },
        {
            accessorKey: "paymentMode",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Payment Mode" />,
            cell: ({ row }) => (
                <span className="text-muted-foreground">{row.getValue("paymentMode")}</span>
            ),
            sortingFn: naLastStringSortFn,
            size: 110,
        },
        {
            accessorKey: "receivedAmount",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Received Amount" />,
            cell: ({ row }) => (
                <span>₹{(row.getValue("receivedAmount") as number).toLocaleString("en-IN")}</span>
            ),
            size: 120,
        },
        {
            accessorKey: "dpd",
            header: ({ column }) => <DataTableColumnHeader column={column} title="DPD" />,
            cell: ({ row }) => <span>{row.getValue("dpd") as number}</span>,
            size: 70,
        },
        {
            accessorKey: "status",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Status" />,
            cell: ({ row }) => (
                <Badge variant="secondary" className="bg-gray-100 text-gray-800 font-semibold">
                    {row.getValue("status") as string}
                </Badge>
            ),
            sortingFn: naLastStringSortFn,
            size: 130,
        },
        {
            id: "actions",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Actions" />,
            cell: ({ row }) => {
                const hasReceipt = row.original.receiptNo !== "N/A" && !!row.original.receipt;
                return (
                    <div className="flex gap-2">
                        {canAccessCategory("ReceiptActions", "EDIT") && (
                            <Button
                                variant="ghost"
                                size="icon"
                                disabled={!hasReceipt}
                                onClick={() => onEditReceipt(row.original)}
                                title={hasReceipt ? "Edit Receipt" : "No receipt available to edit"}
                            >
                                <Pencil className={cn("h-4 w-4", hasReceipt ? "text-blue-600" : "text-gray-400")} />
                            </Button>
                        )}
                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => onViewHistory(row.original)}
                            title="View History"
                        >
                            <History className="h-4 w-4 text-blue-600" />
                        </Button>
                    </div>
                );
            },
            size: 100,
        },
    ];

// ---------------------------------------------------------------------------
// Main Component
// ---------------------------------------------------------------------------

export default function InHandBranchList() {
    const ACCEPTANCE_STATUS = "Branch Ops In Hand";

    // 1. Hooks & Contexts
    const { canAccessCategory } = useUserRole();
    const { toast } = useToast();
    const { withLocation } = useGeoLocation();

    // 2. Data State
    const [tasks, setTasks] = useState<Task[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [states, setStates] = useState<StateSecurityGroup[]>([]);
    const [bankDetails, setBankDetails] = useState<BankDetail[]>([]);

    // 3. Table UI State
    const [view, setView] = useState<"table" | "card">("table");
    const [globalFilter, setGlobalFilter] = useState("");
    const debouncedFilter = useDebounce(globalFilter, 500);
    const [sorting, setSorting] = useState<SortingState>([]);
    const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
    const [columnSizing, setColumnSizing] = useState<ColumnSizingState>({});
    const [columnVisibility, setColumnVisibility] = useState<Record<string, boolean>>({
        lastModified: false,
    });

    // 4. Pagination
    const {
        pageIndex,
        setPageIndex,
        pageSize,
        totalRecords,
        totalPages,
        hasNext,
        hasPrevious,
        updatePagination,
    } = usePagination(20);

    // 5. Advanced Search
    const advancedSearch = useAdvancedSearchTasks({ states, pageIndex, pageSize });

    // 6. Selection State
    const [selectedTasksMap, setSelectedTasksMap] = useState<Record<string, Task>>({});
    
    const rowSelection = useMemo<RowSelectionState>(
        () => Object.fromEntries(Object.keys(selectedTasksMap).map((id) => [id, true])),
        [selectedTasksMap]
    );

    const selectedTasksList = useMemo(() => Object.values(selectedTasksMap), [selectedTasksMap]);
    const selectionCount = selectedTasksList.length;

    // 7. Actions / Dialog State
    const [selectedReceipt, setSelectedReceipt] = useState<CollReceipt | null>(null);
    const [isReceiptManagementOpen, setIsReceiptManagementOpen] = useState(false);
    const [isHistorySheetOpen, setIsHistorySheetOpen] = useState(false);
    const [selectedTaskForHistory, setSelectedTaskForHistory] = useState<Task | null>(null);
    const [isDepositDialogOpen, setIsDepositDialogOpen] = useState(false);
    const [isGuideOpen, setIsGuideOpen] = useState(false);

    const hasInitialized = useRef(false);

    // 8. Handlers
    const toggleTaskSelection = useCallback((task: Task, selected: boolean) => {
        setSelectedTasksMap((prev) => {
            if (selected) return { ...prev, [task.id]: task };
            const next = { ...prev };
            delete next[task.id];
            return next;
        });
    }, []);

    const replaceSelection = useCallback(
        (updaterOrValue: RowSelectionState | ((prev: RowSelectionState) => RowSelectionState)) => {
            setSelectedTasksMap((prevMap) => {
                const prevRowSelection = Object.fromEntries(Object.keys(prevMap).map((id) => [id, true]));
                const nextRowSelection = typeof updaterOrValue === "function" ? updaterOrValue(prevRowSelection) : updaterOrValue;
                const nextMap: Record<string, Task> = {};
                Object.entries(nextRowSelection).forEach(([id, isSelected]) => {
                    if (isSelected) {
                        nextMap[id] = prevMap[id] ?? tasks.find((t) => t.id === id)!;
                    }
                });
                return nextMap;
            });
        },
        [tasks]
    );

    const clearSelection = useCallback(() => setSelectedTasksMap({}), []);

    const loadTasks = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);

            const f = advancedSearch.appliedFilters;
            const response = await searchCasesPaginated({
                limit: pageSize,
                offset: pageIndex * pageSize,
                query: debouncedFilter,
                acceptanceStatus: ACCEPTANCE_STATUS,
                lanNumber: f.lan,
                receiptNo: f.receipt,
                branchName: f.branch,
                agentName: f.agent,
                status: f.status,
                fromDate: f.dateRange.from ? format(f.dateRange.from, "yyyy-MM-dd") : undefined,
                toDate: f.dateRange.to ? format(f.dateRange.to, "yyyy-MM-dd") : undefined,
                dateType: f.dateType,
                dpdFrom: f.dpdFrom,
                dpdTo: f.dpdTo,
                state: f.state,
            });

            setTasks(response.tasks);
            updatePagination({
                totalRecords: response.totalRecords,
                totalPages: response.totalPages,
                hasNext: response.hasNext,
                hasPrevious: response.hasPrevious,
            });
        } catch (err) {
            const msg = err instanceof Error ? err.message : "Failed to load tasks";
            if (!msg.includes("401") && !msg.includes("403")) {
                toast({ title: "Error", description: msg, variant: "destructive" });
            }
            setError(msg);
            setTasks([]);
        } finally {
            setLoading(false);
        }
    }, [pageIndex, pageSize, debouncedFilter, advancedSearch.appliedFilters, toast, updatePagination]);

    const handleEditReceipt = useCallback((task: Task) => {
        if (!task.receipt?.receiptNo || task.receiptNo === "N/A") {
            toast({ title: "Receipt Unavailable", description: "No receipt details available.", variant: "destructive" });
            return;
        }
        setSelectedReceipt(task.receipt);
        setIsReceiptManagementOpen(true);
    }, [toast]);

    const handleViewHistory = useCallback((task: Task) => {
        setSelectedTaskForHistory(task);
        setIsHistorySheetOpen(true);
    }, []);

    const handleDepositSuccess = useCallback(() => {
        clearSelection();
        loadTasks();
        toast({ title: "Success", description: "Cash deposited successfully." });
    }, [clearSelection, loadTasks, toast]);

    const removeAppliedFilter = useCallback((type: string) => {
        const update: Partial<AdvancedFilterParams> = {};
        switch (type) {
            case "dateRange" : update.dateRange = {}; break;
            case "state": update.state = ""; break;
            case "branch": update.branch = ""; break;
            case "agent": update.agent = ""; break;
            case "status": update.status = ""; break;
            case "disposition": update.disposition = ""; break;
            case "emiPendingBucket":
                update.emiPendingBucket = "";
                update.dpdFrom = undefined;
                update.dpdTo = undefined;
                break;
            case "lan": update.lan = ""; break;
            case "receipt": update.receipt = ""; break;
            default: return;
        }
        advancedSearch.updateFilter(update);
        advancedSearch.setAppliedFilters((prev: AdvancedFilterParams) => ({ ...prev, ...update }));
    }, [advancedSearch]);

    const appliedFilterChips = useMemo(() => {
        const chips: { label: string; value: string; type: string }[] = [];
        const af = advancedSearch.appliedFilters;
        const dateLabel = advancedSearch.formatDateRangeLabel(af.dateRange);
        const dateTypeLabel = af.dateType === "ACTIVITY_DATE" ? "Activity Date" : "Date Modified";

        if (dateLabel) chips.push({ label: dateTypeLabel, value: dateLabel, type: "dateRange" });
        if (af.state && af.state !== "all" && af.state !== "") chips.push({ label: "State", value: af.state, type: "state" });
        if (af.branch && af.branch !== "all" && af.branch !== "") chips.push({ label: "Branch", value: af.branch, type: "branch" });
        if (af.agent && af.agent !== "all" && af.agent !== "") chips.push({ label: "Agent", value: af.agent, type: "agent" });
        if (af.status && af.status !== "all" && af.status !== "") chips.push({ label: "Status", value: af.status.replace(/_/g, " "), type: "status" });
        if (af.disposition && af.disposition !== "all" && af.disposition !== "") chips.push({ label: "Disposition", value: af.disposition, type: "disposition" });
        if (af.emiPendingBucket && af.emiPendingBucket !== "all" && af.emiPendingBucket !== "") {
            const bucket = advancedSearch.emiPendings.find(
                (b) => b.bucketCode === af.emiPendingBucket || b.id === af.emiPendingBucket
            );
            chips.push({ label: "EMI Pending Bucket", value: bucket?.bucketCode ?? af.emiPendingBucket, type: "emiPendingBucket" });
        }
        if (af.lan.trim()) chips.push({ label: "LAN", value: af.lan.trim(), type: "lan" });
        if (af.receipt.trim()) chips.push({ label: "Receipt", value: af.receipt.trim(), type: "receipt" });

        return chips;
    }, [advancedSearch]);

    // 9. Effects
    useEffect(() => {
        if (hasInitialized.current) return;
        const init = async () => {
            try {
                const [fetchedStates, fetchedBanks] = await Promise.all([
                    getStateSecurityGroups(),
                    getBankDetails(),
                ]);
                setStates(fetchedStates);
                setBankDetails(fetchedBanks);
                hasInitialized.current = true;
            } catch (err) {
                console.error("Error fetching initial data:", err);
            }
        };
        init();
    }, []);

    // Reset pagination and clear selection when advanced filters change
    useEffect(() => {
        setPageIndex(0);
        clearSelection();
    }, [advancedSearch.appliedFilters, setPageIndex, clearSelection]);

    useEffect(() => {
        loadTasks();
    }, [loadTasks]);

    useEffect(() => {
        const mql = window.matchMedia("(max-width: 1024px)");
        const handleViewChange = (e: MediaQueryListEvent | MediaQueryList) => {
            setView(e.matches ? "card" : "table");
        };
        handleViewChange(mql);
        mql.addEventListener("change", handleViewChange);
        return () => mql.removeEventListener("change", handleViewChange);
    }, []);

    // 10. Memoize columns
    const columns = useMemo(
        () => buildColumns(handleEditReceipt, handleViewHistory, canAccessCategory),
        [handleEditReceipt, handleViewHistory, canAccessCategory]
    );

    // 11. Initialize table
    const table = useReactTable({
        data: tasks,
        columns,
        getRowId: (row) => row.id,
        state: {
            sorting,
            columnFilters,
            rowSelection,
            globalFilter,
            columnSizing,
            columnVisibility,
            pagination: { pageIndex, pageSize },
        },
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        onRowSelectionChange: replaceSelection,
        onGlobalFilterChange: setGlobalFilter,
        onColumnSizingChange: setColumnSizing,
        onColumnVisibilityChange: setColumnVisibility,
        onPaginationChange: (updater) => {
            if (typeof updater === "function") {
                const next = updater({ pageIndex, pageSize });
                setPageIndex(next.pageIndex);
            }
        },
        getCoreRowModel: getCoreRowModel(),
        getSortedRowModel: getSortedRowModel(),
        enableRowSelection: true,
        manualFiltering: true,
        manualPagination: true,
        pageCount: totalPages,
    });

    // 12. Skeleton helper
    const renderTableSkeleton = (rowCount: number) =>
        Array.from({ length: rowCount }).map((_, i) => (
            <TableRow key={`skeleton-${i}`}>
                {table.getVisibleLeafColumns().map((col) => (
                    <TableCell
                        key={col.id}
                        className={cn(
                            col.id === "actions" && "sticky right-0 z-10 bg-white shadow-[-4px_0_4px_-2px_rgba(0,0,0,0.1)]"
                        )}
                    >
                        <div className={cn("h-4 rounded bg-muted animate-pulse", col.id === "select" ? "w-6" : "w-24")} />
                    </TableCell>
                ))}
            </TableRow>
        ));

    return (
        <div className="flex flex-col h-[calc(100vh-8rem)]">
            <div className="sticky top-0 z-30 pb-4">
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
                    <div>
                        <h1 className="text-2xl font-bold tracking-tight">In-Hand Branch</h1>
                        <p className="text-sm text-muted-foreground">
                            Manage tasks pending cash deposit at branch.
                        </p>
                    </div>
                </div>

                {error && (
                    <div className="mb-4 p-4 text-sm text-red-800 rounded-lg bg-red-50 border border-red-200" role="alert">
                        <span className="font-medium">Error:</span> {error}
                    </div>
                )}

                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="relative max-w-64 overflow-hidden rounded-md border border-gray-200 bg-white">
                            <Input
                                value={globalFilter ?? ""}
                                onChange={(e) => setGlobalFilter(e.target.value)}
                                placeholder=""
                                className="max-w-64 border-none focus-visible:ring-0 relative z-10 bg-transparent pr-8"
                            />

                            {!globalFilter && (
                                <div className="absolute inset-y-0 left-0 w-full flex items-center pointer-events-none overflow-hidden">
                                    <div className="w-full text-xs sm:text-sm text-muted-foreground whitespace-nowrap animate-marquee-rtl">
                                        Search by LAN, Receipt, Customer Name
                                    </div>
                                </div>
                            )}
                            {(loading || globalFilter !== debouncedFilter) ? (
                                <div className="absolute right-3 top-1/2 -translate-y-1/2 z-20">
                                    <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                                </div>
                            ) : globalFilter && (
                                <button
                                    onClick={() => setGlobalFilter("")}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 z-20 hover:text-foreground transition-colors"
                                >
                                    <X className="h-4 w-4 text-muted-foreground" />
                                </button>
                            )}

                        </div>
                        <Button
                            variant="outline"
                            size="icon"
                            className="h-10 w-10 border-gray-300 bg-white hover:bg-rose-500 relative"
                            onClick={() => advancedSearch.setIsAdvancedSearchOpen(true)}
                        >
                            <Filter className="h-4 w-4 text-blue-700" strokeWidth={2.5} />
                            {advancedSearch.isFilterApplied && (
                                <div className="absolute -top-1 -right-0.5 h-4 w-4 rounded-full bg-red-500 border-2 border-white flex items-center justify-center">
                                    <CheckCircle2 className="h-1 text-white" strokeWidth={2} />
                                </div>
                            )}
                        </Button>

                        <div className="flex items-center gap-4">
                            {[
                                { color: "bg-green-500", label: "0–30 DPD" },
                                { color: "bg-orange-500", label: "31–90 DPD" },
                                { color: "bg-red-500", label: ">90 DPD" },
                            ].map(({ color, label }) => (
                                <div key={label} className="flex items-center gap-2">
                                    <div className={`h-3 w-3 rounded-full ${color}`} />
                                    <span className="text-sm">{label}</span>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="flex items-center gap-2">
                        {canAccessCategory('DepositCashinBank') && (
                            <Button
                                variant="outline"
                                size="icon"
                                className="h-10 w-10 border-gray-300 bg-white hover:bg-rose-500"
                                disabled={selectionCount === 0}
                                onClick={() => withLocation(() => setIsDepositDialogOpen(true))}
                                title={selectionCount === 0 ? "Select tasks to deposit" : "Deposit cash in bank"}
                            >
                                <Banknote className="h-4 w-4 text-blue-700" strokeWidth={2.5} />
                            </Button>
                        )}


                        <Button
                            variant="outline"
                            size="icon"
                            className="h-10 w-10 border-gray-300 bg-white hover:bg-rose-500"
                            onClick={() => setIsGuideOpen(true)}
                        >
                            <Info className="h-4 w-4 text-blue-700" />
                        </Button>

                        <div className="sm:flex items-center gap-1 border bg-muted p-1 rounded-md">
                            <Button variant={view === "table" ? "secondary" : "ghost"} size="icon" className="h-7 w-7" onClick={() => setView("table")}>
                                <List className="h-4 w-4" />
                            </Button>
                            <Button variant={view === "card" ? "secondary" : "ghost"} size="icon" className="h-7 w-7" onClick={() => setView("card")}>
                                <LayoutGrid className="h-4 w-4" />
                            </Button>
                        </div>

                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="outline" className="h-10">Columns <ChevronDown className="ml-2 h-4 w-4" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-[200px] border border-gray-300 bg-white">
                                {table.getAllColumns().filter(col => col.getCanHide()).map(col => (
                                    <DropdownMenuCheckboxItem
                                        key={col.id}
                                        checked={col.getIsVisible()}
                                        onCheckedChange={v => col.toggleVisibility(!!v)}
                                    >
                                        {COLUMN_DISPLAY_NAMES[col.id] ?? col.id}
                                    </DropdownMenuCheckboxItem>
                                ))}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                </div>
            </div>

            {/* Applied filter chips */}
            {advancedSearch.isFilterApplied && appliedFilterChips.length > 0 && (
                <div className="flex flex-wrap items-center gap-2 mb-3 px-1">
                    <span className="text-sm font-semibold text-gray-800">Applied Filters:</span>
                    {appliedFilterChips.map((chip) => (
                        <span
                            key={`${chip.label}-${chip.value}`}
                            className="flex items-center gap-1 rounded-full bg-muted px-3 py-1 text-xs border border-gray-200"
                        >
                            <span className="font-semibold text-muted-foreground">{chip.label}:</span>
                            <span className="font-semibold text-gray-900">{chip.value}</span>
                            <button
                                aria-label={`Remove ${chip.label}`}
                                className="ml-1 text-muted-foreground hover:text-foreground flex items-center justify-center transition-colors"
                                onClick={() => removeAppliedFilter(chip.type)}
                            >
                                <X className="h-3 w-3" />
                            </button>
                        </span>
                    ))}
                    <Button
                        variant="link"
                        className="text-sm text-blue-800 px-0 h-auto py-0 font-semibold"
                        onClick={advancedSearch.resetFilters}
                    >
                        Clear All
                    </Button>
                </div>
            )}

            <div className="flex-1 overflow-hidden flex flex-col min-h-0">
                {view === "table" ? (
                    <div className="flex-1 overflow-auto rounded-xl border bg-card shadow-sm scrollbar-thin">
                        <Table>
                            <TableHeader className="sticky top-0 z-20 bg-card">
                                {table.getHeaderGroups().map(hg => (
                                    <TableRow key={hg.id} className="bg-slate-50 text-muted-foreground font-semibold h-10">
                                        {hg.headers.map(header => (
                                            <TableHead
                                                key={header.id}
                                                className={cn(
                                                    "bg-slate-50",
                                                    header.id === "actions" && "sticky right-0 z-30 bg-slate-50 text-center shadow-[-4px_0_4px_-2px_rgba(0,0,0,0.1)]"
                                                )}
                                                style={{ width: header.getSize() }}
                                            >
                                                {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                                            </TableHead>
                                        ))}
                                    </TableRow>
                                ))}
                            </TableHeader>
                            <TableBody>
                                {loading ? renderTableSkeleton(10) : tasks.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={columns.length} className="h-32 text-center text-muted-foreground">
                                            No results.
                                        </TableCell>
                                    </TableRow>
                                ) : table.getRowModel().rows.map(row => (
                                    <TableRow key={row.id}>
                                        {row.getVisibleCells().map(cell => (
                                            <TableCell
                                                key={cell.id}
                                                className={cn(
                                                    "whitespace-nowrap py-4",
                                                    cell.column.id === "actions" && "sticky right-0 z-10 bg-white text-right shadow-[-4px_0_4px_-2px_rgba(0,0,0,0.1)]"
                                                )}
                                            >
                                                {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                ) : (
                    <div className="flex-1 overflow-auto scrollbar-thin">
                        {tasks.length === 0 ? (
                            <div className="h-32 flex items-center justify-center text-muted-foreground">
                                No results.
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 p-4">
                                {tasks.map(task => {
                                    const hasReceipt = task.receiptNo !== "N/A" && !!task.receipt;
                                    return (
                                        <div key={task.id} className={`bg-white ${getDpdBorderClasses(task.dpd)} rounded-lg p-4 shadow-sm`}>
                                            <div className="flex justify-between items-start mb-4">
                                                <Checkbox checked={!!selectedTasksMap[task.id]} onCheckedChange={v => toggleTaskSelection(task, !!v)} />
                                                <Badge variant="secondary">{task.disposition}</Badge>
                                            </div>
                                            <h3 className={cn("text-lg font-bold mb-1", getDpdTextClass(task.dpd))}>{task.receiptNo}</h3>
                                            <p className="text-sm text-gray-500 mb-4">{task.lan}</p>
                                            <div className="grid grid-cols-2 gap-2 text-sm">
                                                <div><p className="text-xs text-gray-500">Amount</p><p className="font-bold">₹{task.receivedAmount?.toLocaleString("en-IN")}</p></div>
                                                <div><p className="text-xs text-gray-500">DPD</p><p className="font-bold">{task.dpd}</p></div>
                                            </div>
                                            <div className="flex justify-end gap-2 mt-4">
                                                {canAccessCategory("DepositCashinBank") && (
                                                    <Button
                                                        variant="ghost"
                                                        size="icon"
                                                        onClick={() => withLocation(() => {
                                                            toggleTaskSelection(task, true);
                                                            setIsDepositDialogOpen(true);
                                                        })}
                                                        title="Deposit Cash"
                                                    >
                                                        <Banknote className="h-4 w-4 text-blue-600" />
                                                    </Button>
                                                )}
                                                {canAccessCategory("ReceiptActions", "EDIT") && (
                                                    <Button
                                                        variant="ghost"
                                                        size="icon"
                                                        disabled={!hasReceipt}
                                                        onClick={() => handleEditReceipt(task)}
                                                        title={hasReceipt ? "Edit Receipt" : "No receipt available to edit"}
                                                    >
                                                        <Pencil className={cn("h-4 w-4", hasReceipt ? "text-blue-600" : "text-gray-400")} />
                                                    </Button>
                                                )}
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    onClick={() => handleViewHistory(task)}
                                                    title="View History"
                                                >
                                                    <History className="h-4 w-4 text-blue-600" />
                                                </Button>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                )}

                <Pagination
                    table={table}
                    totalRecords={totalRecords}
                    totalPages={totalPages}
                    pageIndex={pageIndex}
                    setPageIndex={setPageIndex}
                    hasNext={hasNext}
                    hasPrevious={hasPrevious}
                    loading={loading}
                    entityName="Tasks"
                    selectionCount={selectionCount}
                    onClearSelection={clearSelection}
                />
            </div>

            <AdvanceSearchTasks
                isOpen={advancedSearch.isAdvancedSearchOpen}
                setIsOpen={advancedSearch.setIsAdvancedSearchOpen}
                filters={advancedSearch.filters}
                updateFilter={advancedSearch.updateFilter}
                states={advancedSearch.states}
                branches={advancedSearch.branches}
                agents={advancedSearch.agents}
                isLoadingAgents={advancedSearch.isLoadingAgents}
                emiPendings={advancedSearch.emiPendings}
                isLoadingEmiPendings={advancedSearch.isLoadingEmiPendings}
                onApplyFilters={() => { advancedSearch.applyFilters(); advancedSearch.setIsAdvancedSearchOpen(false); }}
                onResetFilters={advancedSearch.resetFilters}
            />

            <ReceiptManagement
                receipt={selectedReceipt}
                isServiceChargeType={!!selectedReceipt && selectedReceipt.serviceChargeTypeId !== null}
                isOpen={isReceiptManagementOpen}
                onClose={() => setIsReceiptManagementOpen(false)}
                onSuccess={() => { clearSelection(); loadTasks(); }}
                mode="edit"
            />

            <TaskHistorySheet isOpen={isHistorySheetOpen} onOpenChange={setIsHistorySheetOpen} task={selectedTaskForHistory} />

            {isDepositDialogOpen && (
                <DepositCashSheet
                    isOpen={isDepositDialogOpen}
                    onOpenChange={setIsDepositDialogOpen}
                    tasks={selectedTasksList}
                    bankDetails={bankDetails}
                    onSuccess={handleDepositSuccess}
                />
            )}

            {/* Actions Guide Sidebar */}
            <Sheet open={isGuideOpen} onOpenChange={setIsGuideOpen}>
                <SheetContent side="right" className="w-[400px] sm:w-[450px] bg-white p-6 overflow-y-auto">
                    <SheetHeader className="mb-6">
                        <SheetTitle className="text-xl font-semibold text-gray-900">
                            Actions Guide
                        </SheetTitle>
                        <SheetDescription className="text-sm text-gray-600 mt-2">
                            A quick reference for the actions available on this page.
                        </SheetDescription>
                    </SheetHeader>
                    <div className="space-y-6">
                        {/* Action 1: Action Descriptions */}
                        <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 mt-0.5">
                                <Info className="h-6 w-6 text-blue-800" />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-semibold text-gray-900 mb-1">Action Descriptions</h3>
                                <p className="text-sm text-gray-700 leading-relaxed">
                                    Displays this guide to all available actions.
                                </p>
                            </div>
                        </div>

                        {/* Action 2: Advanced Search */}
                        <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 mt-0.5">
                                <Filter className="h-6 w-6 text-blue-800" />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-semibold text-gray-900 mb-1">Advanced Search</h3>
                                <p className="text-sm text-gray-700 leading-relaxed">
                                    Open a dialog to filter tasks by multiple criteria including date ranges, branch, agent, and more.
                                </p>
                            </div>
                        </div>

                        {/* Action 3: Deposit Cash in Bank */}
                        <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 mt-0.5">
                                <Banknote className="h-6 w-6 text-blue-800" />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-semibold text-gray-900 mb-1">Deposit Cash in Bank</h3>
                                <p className="text-sm text-gray-700 leading-relaxed">
                                    Record cash deposits into a bank account. Enabled for tasks with "In-Hand Branch" status.
                                </p>
                            </div>
                        </div>

                        {/* Action 4: Edit Receipt */}
                        <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 mt-0.5">
                                <Pencil className="h-6 w-6 text-blue-800" />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-semibold text-gray-900 mb-1">Edit Receipt</h3>
                                <p className="text-sm text-gray-700 leading-relaxed">
                                    Update the collected EMI, bounce, and penalty amounts for a single receipt. The "Received Amount" will be recalculated automatically.
                                </p>
                            </div>
                        </div>

                        {/* Action 5: View History */}
                        <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 mt-0.5">
                                <History className="h-6 w-6 text-blue-800" />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-semibold text-gray-900 mb-1">View History</h3>
                                <p className="text-sm text-gray-700 leading-relaxed">
                                    View the transaction and modification history for a specific task.
                                </p>
                            </div>
                        </div>
                    </div>
                </SheetContent>
            </Sheet>
        </div>
    );
}
