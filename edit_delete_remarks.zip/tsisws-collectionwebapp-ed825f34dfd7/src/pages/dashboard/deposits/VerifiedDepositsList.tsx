import { useState, useEffect, useCallback, useMemo, Fragment, useRef } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { format } from "date-fns";
import type {
    ColumnDef,
    ColumnFiltersState,
    SortingState,
    RowSelectionState,
    ExpandedState,
} from "@tanstack/react-table";
import {
    flexRender,
    getCoreRowModel,
    getSortedRowModel,
    getExpandedRowModel,
    useReactTable,
} from "@tanstack/react-table";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { getScreenShot } from "@/lib/services/screenShot";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetDescription,
} from "@/components/ui/sheet";
import {
    Eye,
    Download,
    Info,
    List,
    LayoutGrid,
    ChevronDown,
    Search,
    Smartphone,
    ClipboardCheck,
    Pencil,
    Banknote,
    Filter,
    X,
    Loader2,
} from "lucide-react";
import {
    searchDepositsPaginated,
} from "@/lib/services/deposits";
import type { CollReceipt, DepositSearchResult, DepositDateType } from "@/lib/types";
import { ReceiptManagement } from "@/components/dashboard/ReceiptManagement";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { usePagination } from "@/hooks/use-pagination";
import { useDepositDetails } from "@/hooks/use-deposit-details";
import { useEditCashDeposit } from "@/hooks/use-edit-cash-deposit";
import { useDebounce } from "@/hooks/use-debounce";
import { Pagination } from "@/components/common/pagination";
import { DepositDetailsSheet } from "@/components/deposits/DepositDetailsSheet";
import { EditCashDeposit } from "@/components/deposits/EditCashDeposit";
import { useAdvancedDepositSearch } from "@/hooks/deposits/useAdvancedDepositSearch";
import { AdvancedDepositSearch } from "@/components/deposits/AdvancedDepositSearch";
import { cn, downloadBlob, formatDateTime } from "@/lib/utils";
import { useUserRole } from "@/contexts/UserRoleContext"
import paymentTab from "@/constants/PaymentTab";
import { PaymentTypes } from "@/constants/PaymentTypes";

const isCashTab = paymentTab.CASH;

type PaymentChannel = "Digital" | "Cash";

const columnDisplayNames: Record<string, string> = {
    depositSlipno: "Deposit Slip No",
    bankDepositDate: "Deposit Date",
    bankDepositedAmount: "Total Amount",
    status: "Status",
    bankName: "Bank Name",
    actions: "Actions",
};

const createColumns = (
    onViewDeposit: (deposit: DepositSearchResult) => void,
    onEditDeposit: (deposit: DepositSearchResult) => void,
    onDownloadScreenshot: (deposit: DepositSearchResult) => void,
    activeTab: PaymentChannel,
    canAccessCategory: (category: string, action?: string) => boolean
): ColumnDef<DepositSearchResult>[] => {
    const cols: ColumnDef<DepositSearchResult>[] = [
        {
            id: "select",
            header: ({ table }) => (
                <Checkbox
                    checked={
                        table.getIsAllPageRowsSelected() ||
                        (table.getIsSomePageRowsSelected() && "indeterminate")
                    }
                    onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                    aria-label="Select all"
                />
            ),
            cell: ({ row }) => (
                <Checkbox
                    checked={row.getIsSelected()}
                    onCheckedChange={(value) => row.toggleSelected(!!value)}
                    aria-label="Select row"
                />
            ),
            enableSorting: false,
            enableHiding: false,
        },
        {
            accessorKey: "depositSlipno",
            header: () => (
                <div className="flex items-center gap-2">
                    <div className="w-6" />
                    <span>Deposit Slip No</span>
                </div>
            ),
            cell: ({ row }) => {
                const canExpand = row.getCanExpand();
                return (
                    <div className="flex items-center gap-2">
                        {canExpand ? (
                            <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 p-0 hover:bg-gray-10"
                                onClick={(e) => {
                                    e.stopPropagation();
                                    row.toggleExpanded();
                                }}
                            >
                                <ChevronDown
                                    className={cn(
                                        "h-4 w-4 text-blue-600 transition-transform duration-200",
                                        row.getIsExpanded() ? "rotate-180" : ""
                                    )}
                                />
                            </Button>
                        ) : (
                            <div className="w-6" />
                        )}
                        <span className="font-medium">{row.original.depositSlipno || "-"}</span>
                    </div>
                );
            },
        },
        {
            accessorKey: "bankDepositDate",
            header: "Deposit Date",
            cell: ({ row }) => {
                const date = row.original.bankDepositDate;
                if (!date) return "";
                try {
                    const dateObj = new Date(date);
                    return dateObj.toLocaleDateString("en-GB", {
                        day: "2-digit",
                        month: "2-digit",
                        year: "numeric",
                    });
                } catch {
                    return date;
                }
            },
        },
        {
            accessorKey: "bankDepositedAmount",
            header: () => <div className="text-right">Amount</div>,
            cell: ({ row }) => {
                const amount = row.original.bankDepositedAmount;
                const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
                return (
                    <div className="text-right font-medium">
                        {numAmount ? `₹${numAmount.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : ""}
                    </div>
                );
            },
        },
        {
            accessorKey: "bankDepositedBy",
            header: "Deposited By",
            cell: ({ row }) => row.original.bankDepositedBy || "-",
        },
    ];

    
    if (activeTab !== "Cash") {
        cols.push({
            accessorKey: "",
            header: "Payment Type",
            cell: ({ row }) => row.original.bankCollReceipts[0].paymentType
        })
    }

    if (activeTab === "Cash") {
        cols.push({
            accessorKey: "bankName",
            header: "Bank",
            cell: ({ row }) => row.original.bankName || "-",
        });
    }

    cols.push({
        id: "actions",
        header: () => <div className="text-right">Actions</div>,
        size: 100,
        cell: ({ row }) => {
            const deposit = row.original;
            return (
                <div className="flex items-center justify-end gap-2">
                    <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => onViewDeposit(deposit)}
                    >
                        <Eye className="h-4 w-4 text-blue-600" />
                    </Button>
                    {canAccessCategory("EditCashDepositVC") && activeTab === isCashTab && (
                        <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => onEditDeposit(deposit)}
                        >
                            <Pencil className="h-4 w-4 text-blue-600" />
                        </Button>
                    )}
                    <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => onDownloadScreenshot(deposit)}
                    >
                        <Download className="h-4 w-4 text-gray-600" />
                    </Button>
                </div>
            );
        },
        enableSorting: false,
    });

    return cols;
};

export default function VerifiedDepositsList() {
    const navigate = useNavigate();
    const [deposits, setDeposits] = useState<DepositSearchResult[]>([]);
    const [loading, setLoading] = useState(true);
    const [refreshNonce, setRefreshNonce] = useState(0);
    const prevFilters = useRef({ debouncedFilter: "", activeTab: "Cash" as PaymentChannel, appliedFilters: {} as any });
    const [sorting, setSorting] = useState<SortingState>([]);
    const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
    const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
    const [expanded, setExpanded] = useState<ExpandedState>({});
    const [globalFilter, setGlobalFilter] = useState("");
    const debouncedFilter = useDebounce(globalFilter, 500);
    const [activeTab, setActiveTab] = useState<PaymentChannel>("Cash");
    const [view, setView] = useState<"table" | "card">("table");
    const [isActionsGuideOpen, setIsActionsGuideOpen] = useState(false);
    const [isAdvancedSearchOpen, setIsAdvancedSearchOpen] = useState(false);
    const { canAccessCategory } = useUserRole();


    // Server-side pagination state
    const {
        pageIndex,
        setPageIndex,
        pageSize,
        totalRecords,
        totalPages,
        hasNext,
        hasPrevious,
        updatePagination,
        resetPagination,
    } = usePagination(20);

    const {
        filters,
        appliedFilters,
        tempDepositDateRange,
        dateRangePopoverOpen,
        bankNames,
        loadingBankNames,
        activeFilters,
        setDepositSlipNo,
        setSelectedBank,
        setTempDepositDateRange,
        handleApplyFilters,
        handleResetFilters,
        handleApplyDateRange,
        handleCancelDateRange,
        handleDateRangeOpenChange,
        removeFilter,
        clearAllFilters,
    } = useAdvancedDepositSearch(() => {setPageIndex(0); setRowSelection({});});

    // Pagination helpers
    const selectionCount = Object.keys(rowSelection).length;
    // Receipt management state
    const [selectedReceipt, setSelectedReceipt] = useState<CollReceipt | null>(null);
    const [receiptManagementMode, setReceiptManagementMode] = useState<"edit" | "delete" | "check">("check");
    const [isReceiptManagementOpen, setIsReceiptManagementOpen] = useState(false);
    const [searchParams] = useSearchParams();
    const { toast } = useToast();
    const isMobile = useIsMobile();

    const receiptListParam = useMemo(() => searchParams.get("receiptList")?.trim() || "", [searchParams]);

    const parseReceiptList = useCallback((raw: string): string[] => {
        if (!raw) return [];
        const trimmed = raw.trim();
        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            try {
                const parsed = JSON.parse(trimmed);
                if (Array.isArray(parsed)) {
                    return parsed.map((value) => String(value).trim()).filter(Boolean);
                }
            } catch {
                // fall through to split-based parsing
            }
        }
        return trimmed
            .split(/[,\s]+/)
            .map((value) => value.trim())
            .filter(Boolean);
    }, []);

    useEffect(() => {
        if (isMobile !== undefined) {
            setView(isMobile ? "card" : "table");
        }
    }, [isMobile]);



    // Clear row selection and reset pagination when switching tabs
    useEffect(() => {
        setRowSelection({});
        resetPagination();
    }, [activeTab, resetPagination]);

    useEffect(() => {
        let isCurrent = true;

        const load = async () => {
            try {
                setLoading(true);
                const offset = pageIndex * pageSize;
                const receiptPaymentType = activeTab;
                const depositStatus = "Verification Completed";

                const fromDate = appliedFilters.depositDateRange.from
                    ? format(appliedFilters.depositDateRange.from, "yyyy-MM-dd")
                    : undefined;
                const toDate = appliedFilters.depositDateRange.to
                    ? format(appliedFilters.depositDateRange.to, "yyyy-MM-dd")
                    : undefined;

                const data = await searchDepositsPaginated(
                    "Bank Deposit",
                    receiptPaymentType,
                    depositStatus,
                    pageSize,
                    offset,
                    debouncedFilter,
                    "DEPOSITED_AMOUNT",
                    "ASC",
                    fromDate,
                    toDate,
                    (activeTab === "Cash" ? "DEPOSIT_DATE" : "CREATED_DATE") as DepositDateType,
                    appliedFilters.depositSlipNo,
                    appliedFilters.selectedBank
                );

                if (!isCurrent) return;

                setDeposits(data.content);
                updatePagination({
                    totalRecords: data.totalRecords,
                    totalPages: data.totalPages,
                    hasNext: data.hasNext,
                    hasPrevious: data.hasPrevious
                });

            } catch (error) {
                if (!isCurrent) return;
                const errorMessage =
                    error instanceof Error ? error.message : "Failed to load deposits";
                if (!errorMessage.includes("401") && !errorMessage.includes("403")) {
                    toast({
                        title: "Error",
                        description: errorMessage,
                        variant: "destructive",
                    });
                }
            } finally {
                if (isCurrent) {
                    setLoading(false);
                }
            }
        };

        const filtersChanged = prevFilters.current.debouncedFilter !== debouncedFilter ||
            prevFilters.current.activeTab !== activeTab ||
            prevFilters.current.appliedFilters !== appliedFilters;

        if (filtersChanged && pageIndex !== 0) {
            setPageIndex(0);
            setRowSelection({});
            prevFilters.current = { debouncedFilter, activeTab, appliedFilters };
            return;
        }

        prevFilters.current = { debouncedFilter, activeTab, appliedFilters };
        load();

        return () => {
            isCurrent = false;
        };
    }, [pageIndex, pageSize, debouncedFilter, activeTab, appliedFilters, refreshNonce, updatePagination, toast]);

    const loadDeposits = useCallback(() => {
        setRefreshNonce(n => n + 1);
    }, []);

    // Deposit Details hook (after loadDeposits)
    const depositDetails = useDepositDetails();

    // Edit Cash Deposit hook (after loadDeposits)
    const editCashDeposit = useEditCashDeposit(loadDeposits);


    useEffect(() => {
        if (!receiptListParam) {
            return;
        }
        const receipts = parseReceiptList(receiptListParam);
        if (receipts.length === 0) {
            return;
        }
        setActiveTab("Cash");
        setGlobalFilter(receipts.join(" "));
    }, [parseReceiptList, receiptListParam]);

    // Server-side filtering is now used, so this returns the current deposits list
    const filteredDeposits = useMemo(() => {
        return deposits;
    }, [deposits]);

    const handleEditCashDeposit = useCallback(async (deposit: DepositSearchResult) => {
        editCashDeposit.openEdit(deposit);
    }, [editCashDeposit]);

    const handleViewDeposit = useCallback(async (deposit: DepositSearchResult) => {
        if (deposit.id) {
            depositDetails.openDetails(deposit.id);
        }
    }, [depositDetails]);


    const handleDownloadScreenshot = useCallback(async (deposit: DepositSearchResult) => {
        if (!deposit?.id) return;
        try {
            toast({
                title: "Download",
                description: "Screenshot download initiated.",
            });
            if (deposit.bankCollReceipts?.[0]?.paymentType === PaymentTypes.CASH) {
                const { blob, filename } = await getScreenShot({
                    moduleName: "Deposit Slip",
                    refId: deposit.id
                });
                downloadBlob(blob, filename);
            } else if (deposit.bankCollReceipts?.[0]?.hiveId) {
                const { blob, filename } = await getScreenShot({
                    moduleName: "Payment Image",
                    refId: deposit.bankCollReceipts[0].hiveId
                });
                downloadBlob(blob, filename);
            } else {
                throw new Error("Payment information unavailable.");
            }
            toast({
                title: "Success",
                description: "Screenshot downloaded successfully.",
            });
        } catch (error) {
            console.error("Download failed:", error);
            toast({
                title: "Screenshot unavailable",
                description: error instanceof Error ? error.message : "An error occurred while downloading the screenshot.",
            });
        }
    }, [toast]);


    const columns = useMemo(() => createColumns(handleViewDeposit, handleEditCashDeposit, handleDownloadScreenshot, activeTab, canAccessCategory), [handleViewDeposit, handleEditCashDeposit, handleDownloadScreenshot, activeTab, canAccessCategory]);

    // Receipt management handlers
    const handleEditReceipt = useCallback((receipt: CollReceipt) => {
        setSelectedReceipt(receipt);
        setReceiptManagementMode("edit");
        setIsReceiptManagementOpen(true);
    }, []);

    const handleDeleteReceipt = useCallback((receipt: CollReceipt) => {
        setSelectedReceipt(receipt);
        setReceiptManagementMode("delete");
        setIsReceiptManagementOpen(true);
    }, []);

    const handleReceiptManagementClose = useCallback(() => {
        setIsReceiptManagementOpen(false);
        setSelectedReceipt(null);
    }, []);

    const handleReceiptManagementSuccess = useCallback(() => {
        // Reload the deposit details to reflect changes in both sidebars if open
        if (depositDetails.isOpen && depositDetails.selectedDeposit?.id) {
            depositDetails.refreshDetails();
        }
        if (editCashDeposit.isOpen && editCashDeposit.selectedDeposit?.id) {
            editCashDeposit.refreshEditDetails();
        }
        // Reload the main list
        loadDeposits();
    }, [depositDetails, editCashDeposit, loadDeposits]);
 
    /** Navigate to tasks list with LAN filter using location state */
    const handleViewTasks = useCallback((receipt: CollReceipt) => {
        const receiptNo = receipt?.receiptNo || "";
        const lan = receipt?.lanNumber || "";
        if (receiptNo) {
            navigate(`/dashboard/tasks`, { state: { receiptNo, lan, tab: "Verification Completed", openHistory: true} });
        }
    }, [navigate]);

    const table = useReactTable({
        data: filteredDeposits,
        columns,
        getRowId: (row) => row.id,
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        onRowSelectionChange: setRowSelection,
        onGlobalFilterChange: setGlobalFilter,
        onExpandedChange: setExpanded,
        getCoreRowModel: getCoreRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getExpandedRowModel: getExpandedRowModel(),
        getRowCanExpand: (row) => (row.original.bankCollReceipts || []).length > 0,
        manualPagination: true,
        manualFiltering: true,
        pageCount: totalPages,
        onPaginationChange: (updater) => {
            if (typeof updater === 'function') {
                const nextState = updater({ pageIndex, pageSize });
                setPageIndex(nextState.pageIndex);
            } else {
                setPageIndex(updater.pageIndex);
            }
        },
        enableRowSelection: true,
        state: {
            sorting,
            columnFilters,
            rowSelection,
            globalFilter,
            expanded,
            pagination: {
                pageIndex,
                pageSize,
            },
        },
    });

    const renderTableSkeleton = (rows: number) => {
        const leafColumns = table.getVisibleLeafColumns();
        return Array.from({ length: rows }).map((_, rowIndex) => (
            <TableRow key={`skeleton-row-${rowIndex}`} className="border-b border-gray-300">
                {leafColumns.map((column) => (
                    <TableCell
                        key={`skeleton-${rowIndex}-${column.id}`}
                        className="whitespace-nowrap"
                    >
                        <div
                            className={cn(
                                "h-4 rounded bg-gray-100 animate-pulse",
                                column.id === "select" ? "w-6" : "w-24"
                            )}
                        />
                    </TableCell>
                ))}
            </TableRow>
        ));
    };


    return (
        <div className="flex flex-col h-[calc(100vh-8rem)]">
            <div className="sticky top-0 z-30 pb-4">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
                    <div>
                        <h1 className="text-2xl font-bold tracking-tight">Verification Completed</h1>
                        <p className="text-sm text-muted-foreground">
                            View the history of all approved deposits.
                        </p>
                    </div>
                </div>

                {/* Applied Filters */}
                {activeFilters.length > 0 && (
                    <div className="mb-4 flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-medium text-gray-700">Applied Filters:</span>
                        {activeFilters.map((filter) => (
                            <div
                                key={filter.key}
                                className="inline-flex items-center gap-1.5 px-3 py-0.5 bg-muted rounded-full text-xs font-bold"
                            >
                                <span className="text-gray-700">
                                    <span className="font-bold">{filter.label}:</span> {filter.value}
                                </span>
                                <button
                                    onClick={() => removeFilter(filter.key)}
                                    className="ml-1 hover:bg-blue-100 rounded-full p-0.5 transition-colors"
                                    aria-label={`Remove ${filter.label} filter`}
                                >
                                    <X className="h-3.5 w-3.5 text-gray-600" />
                                </button>
                            </div>
                        ))}
                        <button
                            onClick={clearAllFilters}
                            className="text-sky-700 hover:text-sky-900 font-medium"
                        >
                            Clear All
                        </button>
                    </div>
                )}

                {/* Tabs */}
                <div className="flex items-center justify-around mb-0">
                    <button
                        onClick={() => setActiveTab("Cash")}
                        className={cn(
                            "flex items-center justify-center gap-2 w-full py-2 font-medium transition-colors relative z-10 border-2 border-b-0",
                            activeTab === "Cash"
                                ? "bg-green-300/50 text-green-500 border-green-500"
                                : "text-muted-foreground hover:text-foreground border-transparent"
                        )}
                    >
                        <Banknote className={cn("h-4 w-4", activeTab === "Cash" && "text-green-500")} />
                        Cash
                    </button>
                    <button
                        onClick={() => setActiveTab("Digital")}
                        className={cn(
                            "flex items-center justify-center gap-2 w-full py-2 font-medium transition-colors relative z-10 border-2 border-b-0",
                            activeTab === "Digital"
                                ? "bg-sky-300/50 text-sky-500 border-sky-500"
                                : "text-muted-foreground hover:text-foreground border-transparent"
                        )}
                    >
                        <Smartphone className={cn("h-4 w-4", activeTab === "Digital" && "text-sky-500")} />
                        Digital
                    </button>
                </div>
            </div>

            {/* Table */}
            <div
                className={cn(
                    "flex-1 overflow-hidden flex flex-col min-h-0 border-2 rounded-b-md transition-colors -mt-3",
                    activeTab === "Digital" && "border-sky-500",
                    activeTab === "Cash" && "border-green-500"
                )}
            >
                {/* Search and Controls */}
                <div className="flex items-center gap-2 flex-wrap px-4 my-2">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                        <Input
                            placeholder="Search by LAN, Slip No, Txn ID..."
                            value={globalFilter ?? ""}
                            onChange={(event) => setGlobalFilter(event.target.value)}
                            className="pl-9 mr-10 pr-10"
                        />
                        {(loading || globalFilter !== debouncedFilter) ? (
                            <div className="absolute right-12 top-1/2 -translate-y-1/2">
                                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                            </div>
                        ) : globalFilter && (
                            <button
                                onClick={() => setGlobalFilter("")}
                                className="absolute right-12 top-1/2 -translate-y-1/2 hover:text-foreground transition-colors"
                            >
                                <X className="h-4 w-4 text-muted-foreground" />
                            </button>
                        )}

                    </div>
                    <div className="flex items-center gap-2">
                        <div className="relative">
                            <Button
                                variant="outline"
                                size="icon"
                                className="h-10 w-10 border-gray-300 bg-white hover:bg-rose-500"
                                onClick={() => setIsAdvancedSearchOpen(true)}
                            >
                                <Filter className="h-9 w-9 text-blue-700" strokeWidth={2.5} />
                            </Button>
                            {activeFilters.length > 0 && (
                                <div className="absolute -top-1 -right-1 flex items-center justify-center w-4 h-4 bg-red-500 rounded-full border-2 border-white">
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 20 20"
                                        fill="currentColor"
                                        className="w-2.5 h-2.5 text-white"
                                    >
                                        <path
                                            fillRule="evenodd"
                                            d="M16.704 5.29a1 1 0 010 1.42l-7.25 7.25a1 1 0 01-1.41 0l-3.75-3.75a1 1 0 111.41-1.42L9 11.59l6.29-6.3a1 1 0 011.41 0z"
                                            clipRule="evenodd"
                                        />
                                    </svg>
                                </div>
                            )}
                        </div>
                    </div>
                    <div className="flex items-center gap-2 ml-auto">
                        <Button
                            variant="outline"
                            size="icon"
                            className="h-10 w-10 border-gray-300 bg-white hover:bg-rose-500"
                            onClick={() => setIsActionsGuideOpen(true)}
                        >
                            <Info className="h-4 w-4 text-blue-700" />
                        </Button>
                        <div className="sm:flex items-center gap-1 border bg-muted p-1 rounded-md">
                            <Button
                                variant={view === "table" ? "secondary" : "ghost"}
                                size="icon"
                                className="h-7 w-7"
                                onClick={() => setView("table")}
                            >
                                <List className="h-4 w-4" />
                            </Button>
                            <Button
                                variant={view === "card" ? "secondary" : "ghost"}
                                size="icon"
                                className="h-7 w-7"
                                onClick={() => setView("card")}
                            >
                                <LayoutGrid className="h-4 w-4" />
                            </Button>
                        </div>
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="outline" className="h-10">
                                    Columns
                                    <ChevronDown className="ml-2 h-4 w-4" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent
                                align="end"
                                className="w-[200px] border-gray-300 bg-white"
                            >
                                {table
                                    .getAllColumns()
                                    .filter(
                                        (column) =>
                                            column.getCanHide() &&
                                            column.id !== "select"
                                    )
                                    .map((column) => {
                                        const displayName = columnDisplayNames[column.id] || column.id;

                                        return (
                                            <DropdownMenuCheckboxItem
                                                key={column.id}
                                                checked={column.getIsVisible()}
                                                onCheckedChange={(value) =>
                                                    column.toggleVisibility(!!value)
                                                }
                                                className="text-gray-900"
                                            >
                                                {displayName}
                                            </DropdownMenuCheckboxItem>
                                        );
                                    })}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                </div>

                {view === "table" && !isMobile ? (
                    <div className="flex-1 flex flex-col min-h-0 rounded-md border border-gray-200 bg-white overflow-hidden mx-4 mb-4">
                        <div className="flex-1 overflow-auto scrollbar-thin">
                            <Table className="w-full">
                                <TableHeader className="sticky top-0 z-20 bg-white border-b border-gray-300">
                                    {table.getHeaderGroups().map((headerGroup) => (
                                        <TableRow key={headerGroup.id} className="border-b border-gray-300">
                                            {headerGroup.headers.map((header) => {
                                                const isActions = header.column.id === "actions";
                                                const isAmount = header.column.id === "branchDepositAmount";
                                                return (
                                                    <TableHead
                                                        key={header.id}
                                                        className={cn(
                                                            "bg-white text-gray-500 font-medium",
                                                            (isActions || isAmount) && "text-right"
                                                        )}
                                                    >
                                                        {header.isPlaceholder
                                                            ? null
                                                            : flexRender(
                                                                header.column.columnDef.header,
                                                                header.getContext()
                                                            )}
                                                    </TableHead>
                                                );
                                            })}
                                        </TableRow>
                                    ))}
                                </TableHeader>
                                <TableBody>
                                    {loading ? (
                                        renderTableSkeleton(10)
                                    ) : table.getRowModel().rows?.length ? (
                                        table.getRowModel().rows.map((row) => (
                                            <Fragment key={row.id}>
                                                <TableRow className="border-b border-gray-300">
                                                    {row.getVisibleCells().map((cell) => {
                                                        const isActions = cell.column.id === "actions";
                                                        const isAmount = cell.column.id === "branchDepositAmount";
                                                        return (
                                                            <TableCell
                                                                key={cell.id}
                                                                className={cn(
                                                                    "whitespace-nowrap",
                                                                    (isActions || isAmount) && "text-right"
                                                                )}
                                                            >
                                                                {flexRender(
                                                                    cell.column.columnDef.cell,
                                                                    cell.getContext()
                                                                )}
                                                            </TableCell>
                                                        );
                                                    })}
                                                </TableRow>
                                                {row.getIsExpanded() && (
                                                    <TableRow className="bg-blue-50/30 border-b border-gray-300">
                                                        <TableCell colSpan={columns.length} className="p-0">
                                                            <div className="px-6 py-3 space-y-2">
                                                                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                                                                    Linked Receipts ({(row.original.bankCollReceipts || []).length})
                                                                </div>
                                                                <div className="grid grid-cols-1 gap-2">
                                                                    {(row.original.bankCollReceipts || []).map((receipt: any) => (
                                                                        <div
                                                                            key={receipt.id}
                                                                            className={cn(
                                                                                "grid items-center gap-3 py-1 px-2 bg-white rounded border border-gray-200 shadow-sm",
                                                                                activeTab === "Digital"
                                                                                    ? "grid-cols-[1.5fr_1.5fr_1.2fr_2.2fr_1.3fr_0.8fr_1.2fr_auto]"
                                                                                    : "grid-cols-[1.5fr_1.5fr_1.2fr_2.4fr_1.4fr_0.8fr_auto]"
                                                                            )}
                                                                        >
                                                                            <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">LAN Number</div>
                                                                                <div className="text-[11px] font-semibold text-blue-600 hover:underline cursor-pointer whitespace-nowrap" onClick={() => handleViewTasks(receipt)} title={receipt.lanNumber}>{receipt.lanNumber}</div>
                                                                            </div>
                                                                            <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">Receipt Number</div>
                                                                                <div className="text-[11px] font-semibold text-gray-900 truncate" title={receipt.receiptNo}>{receipt.receiptNo}</div>
                                                                            </div>
                                                                            <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">Customer Name</div>
                                                                                <div className="text-[11px] font-semibold text-gray-900 truncate" title={receipt.customerName}>{receipt.customerName}</div>
                                                                            </div>
                                                                            <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">Date & Time</div>
                                                                                <div className="text-[11px] font-semibold text-gray-900 whitespace-nowrap" title={formatDateTime(receipt.receiptStoredDateTime)}>{formatDateTime(receipt.receiptStoredDateTime)}</div>
                                                                            </div>
                                                                            <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">Collected By</div>
                                                                                <div className="text-[11px] font-semibold text-gray-900 truncate" title={receipt.collectedBy}>{receipt.collectedBy}</div>
                                                                            </div>
                                                                            <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">Amount</div>
                                                                                <div className="text-[11px] font-medium text-gray-900 truncate">₹{receipt.totalAmount?.toLocaleString("en-IN") || "0"}</div>
                                                                            </div>
                                                                            {activeTab === "Digital" && <div className="min-w-0 pl-3 border-l border-gray-100">
                                                                                <div className="text-[10px] text-gray-500 uppercase font-medium">Transaction Ref</div>
                                                                                <div className="text-[11px] font-medium text-gray-700 truncate" title={receipt.transactionRefNo || "-"}>{receipt.transactionRefNo || "-"}</div>
                                                                            </div>}
                                                                            <div className="flex justify-end min-w-0 pl-3 border-l border-gray-100">
                                                                                <Badge variant="secondary" className="text-[10px] bg-gray-100 text-gray-600 truncate">
                                                                                    {receipt.status || "Pending"}
                                                                                </Badge>
                                                                            </div>
                                                                        </div>
                                                                    ))}
                                                                </div>
                                                            </div>
                                                        </TableCell>
                                                    </TableRow>
                                                )}
                                            </Fragment>
                                        ))
                                    ) : (
                                        <TableRow className="border-b border-gray-300">
                                            <TableCell
                                                colSpan={columns.length}
                                                className="h-24 text-center"
                                            >
                                                No results found.
                                            </TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </div>
                    </div>
                ) : (
                    <div className="flex-1 overflow-y-auto px-4 pb-4 scrollbar-thin">
                        {loading ? (
                            <div className="flex flex-col items-center justify-center h-48 gap-3">
                                <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
                                <p className="text-sm text-muted-foreground animate-pulse">Loading deposits...</p>
                            </div>
                        ) : filteredDeposits.length > 0 ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                                {table.getRowModel().rows.map((row) => {
                                    const deposit = row.original;
                                    const receipts = deposit.bankCollReceipts || [];
                                    const lanNo = receipts.length > 0 ? receipts[0].lanNumber : "-";
                                    const date = deposit.bankDepositDate;
                                    let formattedDate = "";
                                    if (date) {
                                        try {
                                            const dateObj = new Date(date);
                                            formattedDate = dateObj.toLocaleDateString("en-GB", {
                                                day: "2-digit",
                                                month: "2-digit",
                                                year: "numeric",
                                            });
                                        } catch {
                                            formattedDate = date;
                                        }
                                    }
                                    const status = deposit.status || "Pending";

                                    return (
                                        <div
                                            key={deposit.id}
                                            className="relative bg-white border border-gray-200 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow"
                                        >
                                            {/* Checkbox */}
                                            <div className="absolute top-3 left-3">
                                                <Checkbox
                                                    checked={row.getIsSelected()}
                                                    onCheckedChange={(value) => row.toggleSelected(!!value)}
                                                    aria-label="Select deposit"
                                                />
                                            </div>

                                            {/* Status Badge */}
                                            <div className="absolute top-3 right-3 flex items-center gap-1">
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="h-8 w-8"
                                                    onClick={() => handleViewDeposit(deposit)}
                                                >
                                                    <Eye className="h-4 w-4 text-blue-600" />
                                                </Button>
                                                {canAccessCategory("EditCashDepositVC") && activeTab === "Cash" && (
                                                    <Button
                                                        variant="ghost"
                                                        size="icon"
                                                        className="h-8 w-8"
                                                        onClick={() => handleEditCashDeposit(deposit)}
                                                    >
                                                        <Pencil className="h-4 w-4 text-blue-600" />
                                                    </Button>
                                                )}
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="h-8 w-8"
                                                    onClick={() => handleDownloadScreenshot(deposit)}
                                                >
                                                    <Download className="h-4 w-4 text-gray-600" />
                                                </Button>
                                            </div>

                                            {/* Content */}
                                            <div className="mt-8 space-y-3">
                                                <div className="flex items-center gap-2 justify-between">
                                                    {/* Deposit ID */}
                                                    <div>
                                                        <p className="text-sm font-semibold text-gray-900">
                                                            {deposit.depositSlipno || "-"}
                                                        </p>
                                                    </div>
                                                    <Badge
                                                        variant="secondary"
                                                        className="bg-gray-100 text-gray-700 hover:bg-gray-100 font-normal text-xs"
                                                    >
                                                        {status}
                                                    </Badge>
                                                </div>

                                                {/* LAN Number */}
                                                <div>
                                                    <div className="flex items-center gap-2">
                                                        <p className="text-sm font-bold text-gray-900">{lanNo}</p>
                                                        {receipts.length > 1 && (
                                                            <Badge variant="outline" className="text-[10px] h-4 px-1">
                                                                +{receipts.length - 1} more
                                                            </Badge>
                                                        )}
                                                    </div>
                                                </div>

                                                {/* Date */}
                                                <div>
                                                    <p className="text-sm text-gray-900">{formattedDate || ""}</p>
                                                </div>

                                                {/* Actions */}
                                                <div className="flex items-center gap-2 pt-2 border-t border-gray-100 w-full">
                                                    {/* Total Amount */}
                                                    <div className="flex items-center gap-2 justify-between w-full">
                                                        <div className="text-gray-700 text-xs">Total Amount</div>
                                                        <div className="text-base font-semibold text-gray-900">
                                                            {deposit.bankDepositedAmount != null
                                                                ? `₹${parseFloat(deposit.bankDepositedAmount).toLocaleString("en-IN", {
                                                                    minimumFractionDigits: 2,
                                                                    maximumFractionDigits: 2,
                                                                })}`
                                                                : "-"}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        ) : (
                            <div className="text-center py-8 text-muted-foreground">
                                No results found.
                            </div>
                        )}
                    </div>
                )}

                {/* Pagination */}
                <Pagination
                    table={table}
                    totalRecords={totalRecords}
                    totalPages={totalPages}
                    pageIndex={pageIndex}
                    setPageIndex={setPageIndex}
                    hasNext={hasNext}
                    hasPrevious={hasPrevious}
                    loading={loading}
                    entityName="Deposits"
                    selectionCount={selectionCount}
                    onClearSelection={() => setRowSelection({})}
                />
            </div>

            {/* Actions Guide Sidebar */}
            <Sheet open={isActionsGuideOpen} onOpenChange={setIsActionsGuideOpen}>
                <SheetContent side="right" className="w-[400px] sm:w-[450px] bg-white p-6">
                    <SheetHeader className="mb-6">
                        <SheetTitle className="text-xl font-semibold text-gray-900">
                            Actions Guide
                        </SheetTitle>
                        <SheetDescription className="text-sm text-gray-600 mt-2">
                            A quick reference for the actions available on this page.
                        </SheetDescription>
                    </SheetHeader>
                    <div className="space-y-6">
                        {/* Action 1: Info */}
                        <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 mt-0.5">
                                <Info className="h-6 w-6 text-blue-800" />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-semibold text-gray-900 mb-1">Action Descriptions</h3>
                                <p className="text-sm text-gray-700 leading-relaxed">
                                    Displays this guide to all available actions.
                                </p>
                            </div>
                        </div>

                        {/* Action 2: Approve/Reject */}
                        <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 mt-0.5">
                                <ClipboardCheck className="h-6 w-6 text-blue-800" />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-semibold text-gray-900 mb-1">Approve/Reject Deposits</h3>
                                <p className="text-sm text-gray-700 leading-relaxed">
                                    Approve or reject one or more selected deposits after verification.
                                </p>
                            </div>
                        </div>

                        {/* Action 3: Edit Cash Deposit */}
                        <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 mt-0.5">
                                <Pencil className="h-6 w-6 text-blue-800" />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-semibold text-gray-900 mb-1">Edit Cash Deposit</h3>
                                <p className="text-sm text-gray-700 leading-relaxed">
                                    Modify the date or linked tasks for a single pending cash deposit. This will reject the old deposit and create a new one for re-verification.
                                </p>
                            </div>
                        </div>

                        {/* Action 4: Download ScreenShot */}
                        <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 mt-0.5">
                                <Download className="h-6 w-6 text-blue-800" />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-semibold text-gray-900 mb-1">Download ScreenShot</h3>
                                <p className="text-sm text-gray-700 leading-relaxed">
                                    Download the screenshot of the deposit.
                                </p>
                            </div>
                        </div>
                    </div>
                </SheetContent>
            </Sheet>

            {/* Advanced Deposit Search Sidebar */}
            <AdvancedDepositSearch
                isOpen={isAdvancedSearchOpen}
                onOpenChange={setIsAdvancedSearchOpen}
                activeTab={activeTab}
                tempDepositDateRange={tempDepositDateRange}
                depositSlipNo={filters.depositSlipNo}
                selectedBank={filters.selectedBank}
                dateRangePopoverOpen={dateRangePopoverOpen}
                bankNames={bankNames}
                loadingBankNames={loadingBankNames}
                setDepositSlipNo={setDepositSlipNo}
                setSelectedBank={setSelectedBank}
                setTempDepositDateRange={setTempDepositDateRange}
                handleApplyFilters={() => {
                    handleApplyFilters();
                    setIsAdvancedSearchOpen(false);
                }}
                handleResetFilters={() => {
                    handleResetFilters();
                    setIsAdvancedSearchOpen(false);
                }}
                handleApplyDateRange={handleApplyDateRange}
                handleCancelDateRange={handleCancelDateRange}
                handleDateRangeOpenChange={handleDateRangeOpenChange}
            />

            {/* Edit Cash Deposit Sidebar */}
            <EditCashDeposit
                isOpen={editCashDeposit.isOpen}
                onOpenChange={editCashDeposit.setIsOpen}
                loading={editCashDeposit.loading}
                isSaving={editCashDeposit.isSaving}
                deposit={editCashDeposit.selectedDeposit}
                editDate={editCashDeposit.editDate}
                setEditDate={editCashDeposit.setEditDate}
                editTime={editCashDeposit.editTime}
                setEditTime={editCashDeposit.setEditTime}
                editRemarks={editCashDeposit.editRemarks}
                setEditRemarks={editCashDeposit.setEditRemarks}
                editLinkedReceipts={editCashDeposit.editLinkedReceipts}
                removedReceipts={editCashDeposit.removedReceipts}
                handleRemoveReceipt={editCashDeposit.handleRemoveReceipt}
                handleAddReceipt={editCashDeposit.handleAddReceipt}
                onAddTasks={editCashDeposit.handleAddTasks}
                onSave={editCashDeposit.saveEdit}
                initialLockedReceiptIds={editCashDeposit.initialLockedReceiptIds}
            />

            {/* Deposit Details Sidebar */}
            <DepositDetailsSheet
                isOpen={depositDetails.isOpen}
                onOpenChange={depositDetails.setIsOpen}
                loading={depositDetails.loading}
                selectedDeposit={depositDetails.selectedDeposit}
                activeTab={activeTab}
                onEditReceipt={handleEditReceipt}
                onDeleteReceipt={handleDeleteReceipt}
            />

            {/* Receipt Management Dialog */}
            <ReceiptManagement
                receipt={selectedReceipt}
                isOpen={isReceiptManagementOpen}
                onClose={handleReceiptManagementClose}
                onSuccess={handleReceiptManagementSuccess}
                mode={receiptManagementMode}
            />
        </div >
    );
}
