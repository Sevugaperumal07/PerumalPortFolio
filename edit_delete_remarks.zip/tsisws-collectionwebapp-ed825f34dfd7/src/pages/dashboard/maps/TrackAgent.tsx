﻿import * as React from "react"
import { format } from "date-fns"
import { SearchableSelect } from "@/components/ui/searchable-select"
import {
    Calendar as CalendarIcon,
    MapPin,
    Clock,
    Route,
    Loader2,
    AlertCircle,
    ArrowRight,
    BatteryCharging,
    ChevronDown,
    ChevronUp,
    PanelLeftClose,
    PanelLeftOpen,
    RefreshCcw,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "@/components/ui/popover"
import { Label } from "@/components/ui/label"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Checkbox } from "@/components/ui/checkbox"
import { MapView } from "@/components/dashboard/MapView"
import { useAuth } from "@/contexts/AuthContext"
import { graphqlRequest } from "@/lib/graphql/client"
import { GET_SECURITY_GROUPS_BY_USER_ID, GET_USER_BY_EMAIL } from "@/lib/graphql/queries/users"
import type { SecurityGroup, User } from "@/lib/types"
import { fetchAgentDistanceRecords } from "@/lib/services/agent-tracker"
import {
    processTimelineEvents,
    type TimelineEvent,
} from "@/lib/services/TimelineEventProcessor"

const EVENT_LABELS: Record<TimelineEvent["type"], string> = {
    checkin: "Check-in",
    checkout: "Check-out",
    collection: "Task",
    halt: "Location Halt",
    movement: "Location Ping",
}

const EVENT_STYLES: Record<
    TimelineEvent["type"],
    { icon: typeof ArrowRight; iconClassName?: string; pill: string }
> = {
    checkin: { icon: ArrowRight, pill: "text-green-600 bg-green-100 border-green-200" },
    checkout: { icon: ArrowRight, iconClassName: "-scale-x-100", pill: "text-red-600 bg-red-100 border-red-200" },
    collection: { icon: Route, pill: "text-purple-600 bg-purple-100 border-purple-200" },
    halt: { icon: Clock, pill: "text-yellow-600 bg-yellow-100 border-yellow-200" },
    movement: { icon: MapPin, pill: "text-gray-500 bg-gray-100 border-gray-200" },
}

const formatDurationLabel = (seconds?: number | null): string | null => {
    if (typeof seconds !== "number" || Number.isNaN(seconds) || seconds <= 0) {
        return null
    }
    const rounded = Math.floor(seconds)
    const minutes = Math.floor(rounded / 60)
    const hours = Math.floor(minutes / 60)
    const remainingMinutes = minutes % 60

    const parts: string[] = []
    if (hours > 0) {
        parts.push(`${hours}h`)
    }
    if (remainingMinutes > 0) {
        parts.push(`${remainingMinutes}m`)
    }
    if (parts.length === 0) {
        parts.push(`${Math.max(rounded, 1)}s`)
    }
    return parts.join(" ")
}

const formatCoordinates = (lat: number, lon: number): string => {
    const latDir = lat >= 0 ? "N" : "S"
    const lonDir = lon >= 0 ? "E" : "W"
    return `${Math.abs(lat).toFixed(4)}°${latDir}, ${Math.abs(lon).toFixed(4)}°${lonDir}`
}


const getEventTitle = (event: TimelineEvent): string => {
    if (event.type === "collection") {
        return event.meta?.activityName || EVENT_LABELS.collection
    }
    return EVENT_LABELS[event.type]
}

const getEventDescription = (event: TimelineEvent, durationLabel: string | null): string | null => {
    if (event.type === "checkin") return "Agent started their workday."
    if (event.type === "checkout") return "Agent ended their workday."
    if (event.type === "collection") return event.meta?.remarks || "Collection activity."
    if (event.type === "halt") {
        return durationLabel ? `Duration: ${durationLabel}` : "Agent stayed at this location."
    }
    if (event.type === "movement") return "Location update."
    return null
}

const TimelineCard = ({
    event,
    onLocationClick,
}: {
    event: TimelineEvent
    onLocationClick: (event: TimelineEvent) => void
}) => {
    const style = EVENT_STYLES[event.type]
    const Icon = style.icon
    const title = getEventTitle(event)
    const durationLabel = formatDurationLabel(event.duration ?? null)
    const description = getEventDescription(event, durationLabel)
    const coordinateLabel = formatCoordinates(event.lat, event.lon)
    const taskNumber = event.meta?.caseNumber || event.meta?.casesId
    const customerName = event.meta?.customerName
    const taskHref = taskNumber ? `/dashboard/cases?case=${encodeURIComponent(taskNumber)}` : null
    const batteryValue = typeof event.meta?.batteryPercentage === "number"
        ? Math.round(event.meta.batteryPercentage)
        : null

    return (
        <div className="flex gap-3">
            <div className="flex flex-col items-center">
                <div className={cn("h-8 w-8 rounded-full flex items-center justify-center border", style.pill)}>
                    <Icon className={cn("h-5 w-5", style.iconClassName)} />
                </div>
                <div className="flex-1 w-px bg-border my-2"></div>
            </div>
            <div className="w-full pb-6">
                <div className="flex items-center justify-between">
                    <p className="text-xs text-muted-foreground">{event.startTime}</p>
                    {batteryValue !== null && (
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <BatteryCharging className="h-3 w-3" />
                            <span>{batteryValue}%</span>
                        </div>
                    )}
                </div>
                <div
                    className="mt-1 p-3 rounded-lg border bg-card/50 shadow-sm cursor-pointer hover:bg-accent transition-colors"
                    onClick={() => onLocationClick(event)}
                >
                    <p className="font-bold text-sm">{title}</p>
                    {description && <p className="text-xs text-muted-foreground">{description}</p>}
                    {(taskNumber || customerName) && (
                        <div className="mt-1 text-xs space-y-0.5">
                            {taskNumber && taskHref && (
                                <p>
                                    Task:{" "}
                                    <a href={taskHref} className="text-primary hover:underline">
                                        {taskNumber}
                                    </a>
                                </p>
                            )}
                            {customerName && <p>Customer: {customerName}</p>}
                        </div>
                    )}
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                        <MapPin className="h-3 w-3" />
                        <span>{coordinateLabel}</span>
                    </div>
                </div>
            </div>
        </div>
    )
}

const ENABLE_LOCATION_API =
    (import.meta.env.VITE_ENABLE_LOCATIONS_API ?? "true").toLowerCase() !== "false"

type StoredAuthUser = {
    email?: string | null
    userName?: string | null
}

export default function TrackAgent() {
    const [date, setDate] = React.useState<Date | undefined>(new Date())
    const [selectedState, setSelectedState] = React.useState<string>("")
    const [selectedBranch, setSelectedBranch] = React.useState<string>("")
    const [selectedAgent, setSelectedAgent] = React.useState<string>("")
    const [totalDistanceKm, setTotalDistanceKm] = React.useState(0)
    const [isFilterSectionOpen, setIsFilterSectionOpen] = React.useState(true)
    const [isTimelineOpen, setIsTimelineOpen] = React.useState(true)
    const [hasRequestedTimeline, setHasRequestedTimeline] = React.useState(false)
    const [timelineRefreshToken, setTimelineRefreshToken] = React.useState(0)
    const [branches, setBranches] = React.useState<SecurityGroup[]>([])
    const [branchesLoading, setBranchesLoading] = React.useState(false)
    const [branchesError, setBranchesError] = React.useState<string | null>(null)
    const [currentUserId, setCurrentUserId] = React.useState<string | null>(null)
    const [currentUserError, setCurrentUserError] = React.useState<string | null>(null)
    const [currentUserLoading, setCurrentUserLoading] = React.useState(false)
    const [timelineEvents, setTimelineEvents] = React.useState<TimelineEvent[]>([])
    const [timelineLoading, setTimelineLoading] = React.useState(false)
    const [timelineError, setTimelineError] = React.useState<string | null>(null)
    const [selectedLocation, setSelectedLocation] = React.useState<TimelineEvent | null>(null)
    const [isDatePickerOpen, setIsDatePickerOpen] = React.useState(false)
    const [showFullTimeline, setShowFullTimeline] = React.useState(false)

    const { user, loading: authLoading } = useAuth()
    const [storedUser, setStoredUser] = React.useState<StoredAuthUser | null>(null)

    React.useEffect(() => {
        if (user?.email) {
            setStoredUser(null)
            return
        }
        if (typeof window === "undefined") {
            return
        }
        try {
            const raw = sessionStorage.getItem("auth:user")
            if (raw) {
                setStoredUser(JSON.parse(raw))
            }
        } catch {
            setStoredUser(null)
        }
    }, [user?.email])

    const userEmail = user?.email ?? storedUser?.email ?? undefined

    const hasSelections = Boolean(selectedState && selectedBranch && selectedAgent && date)
    const showResults = hasSelections && hasRequestedTimeline

    React.useEffect(() => {
        if (authLoading) {
            setCurrentUserError(null)
            return
        }
        if (!userEmail) {
            setCurrentUserId(null)
            setCurrentUserError("Unable to identify user. Please re-login.")
            return
        }

        let isCancelled = false
        const fetchCurrentUser = async () => {
            setCurrentUserLoading(true)
            setCurrentUserError(null)
            try {
                const response = await graphqlRequest<{ getUserByEmail: User | null }>(
                    GET_USER_BY_EMAIL,
                    { email: userEmail }
                )

                if (!isCancelled) {
                    const fetchedId = response?.getUserByEmail?.id ?? null
                    setCurrentUserId(fetchedId)
                    if (!fetchedId) {
                        setCurrentUserError("User record not found for the current session.")
                    }
                }
            } catch (error) {
                if (!isCancelled) {
                    const message = error instanceof Error ? error.message : "Unable to load user details"
                    setCurrentUserError(message)
                    setCurrentUserId(null)
                }
            } finally {
                if (!isCancelled) {
                    setCurrentUserLoading(false)
                }
            }
        }

        fetchCurrentUser()

        return () => {
            isCancelled = true
        }
    }, [userEmail, authLoading])

    React.useEffect(() => {
        if (!currentUserId) {
            setBranches([])
            setBranchesError(currentUserError)
            return
        }

        let isCancelled = false
        const fetchBranches = async () => {
            setBranchesLoading(true)
            setBranchesError(null)
            try {
                const response = await graphqlRequest<{ getSecurityGroupsByUserId: { securityGroups: SecurityGroup[] } }>(
                    GET_SECURITY_GROUPS_BY_USER_ID,
                    { userId: currentUserId }
                )
                if (!isCancelled) {
                    setBranches(response?.getSecurityGroupsByUserId?.securityGroups ?? [])
                }
            } catch (error) {
                if (!isCancelled) {
                    const message = error instanceof Error ? error.message : "Unable to load branches"
                    setBranchesError(message)
                    setBranches([])
                }
            } finally {
                if (!isCancelled) {
                    setBranchesLoading(false)
                }
            }
        }

        fetchBranches()

        return () => {
            isCancelled = true
        }
    }, [currentUserId, currentUserError])

    // Extract unique states from branches
    const availableStates = React.useMemo(() => {
        const stateSet = new Set<string>()
        branches.forEach((branch) => {
            const stateName = branch.stateMaster?.stateName
            if (stateName && stateName.trim()) {
                stateSet.add(stateName.trim())
            }
        })
        return Array.from(stateSet).sort()
    }, [branches])

    // Filter branches by selected state
    const filteredBranches = React.useMemo(() => {
        if (!selectedState) return branches
        return branches.filter(
            (branch) => branch.stateMaster?.stateName?.trim() === selectedState
        )
    }, [branches, selectedState])

    // Sort branches alphabetically by name
    const sortedBranches = React.useMemo(() => {
        return [...filteredBranches].sort((a, b) => {
            const nameA = (a.name || "").toLowerCase()
            const nameB = (b.name || "").toLowerCase()
            return nameA.localeCompare(nameB)
        })
    }, [filteredBranches])

    React.useEffect(() => {
        if (!selectedState) {
            setSelectedBranch("")
            setSelectedAgent("")
            return
        }
        // Reset branch and agent when state changes
        const stillExists = filteredBranches.some((branch) => branch.id === selectedBranch)
        if (!stillExists) {
            setSelectedBranch("")
            setSelectedAgent("")
        }
    }, [selectedState, filteredBranches, selectedBranch])

    React.useEffect(() => {
        if (!selectedBranch) return
        const stillExists = filteredBranches.some((branch) => branch.id === selectedBranch)
        if (!stillExists) {
            setSelectedBranch("")
            setSelectedAgent("")
        }
    }, [filteredBranches, selectedBranch])

    const selectedBranchData = React.useMemo(
        () => filteredBranches.find((branch) => branch.id === selectedBranch),
        [filteredBranches, selectedBranch]
    )
    const branchUsers = selectedBranchData?.user ?? []

    // Sort users alphabetically by display name
    const sortedBranchUsers = React.useMemo(() => {
        return [...branchUsers].sort((a, b) => {
            const nameA = (
                a.userName ||
                [a.firstName, a.lastName].filter(Boolean).join(" ") ||
                "Unnamed User"
            ).toLowerCase()
            const nameB = (
                b.userName ||
                [b.firstName, b.lastName].filter(Boolean).join(" ") ||
                "Unnamed User"
            ).toLowerCase()
            return nameA.localeCompare(nameB)
        })
    }, [branchUsers])

    const selectedAgentData = React.useMemo(
        () => branchUsers.find((branchUser) => branchUser.id === selectedAgent),
        [branchUsers, selectedAgent]
    )
    const agentDisplayName =
        selectedAgentData?.userName ||
        [selectedAgentData?.firstName, selectedAgentData?.lastName].filter(Boolean).join(" ").trim() ||
        selectedAgent

    const requestDate = React.useMemo(() => (date ? format(date, "yyyy-MM-dd") : undefined), [date])

    React.useEffect(() => {
        setHasRequestedTimeline(false)
        setSelectedLocation(null)
    }, [selectedState, selectedBranch, selectedAgent, date])

    React.useEffect(() => {
        if (!selectedAgent || !requestDate || !ENABLE_LOCATION_API || !hasRequestedTimeline) {
            setSelectedLocation(null)
            setTotalDistanceKm(0)
            return
        }

        let isCancelled = false;

        const fetchDistance = async () => {
            try {
                // Fetch Distance Records
                const distanceResponse = await fetchAgentDistanceRecords(selectedAgent, requestDate);
                if (isCancelled) return;

                const distanceValue =
                    distanceResponse?.[selectedAgent] ?? 0;

                if (!isCancelled) {
                    setTotalDistanceKm(distanceValue);
                }
            } catch (error) {
                if (isCancelled) return;
                console.error("Error fetching distance:", error);
                setTotalDistanceKm(0);
            }
        };

        fetchDistance();

        return () => {
            isCancelled = true;
        };
    }, [selectedAgent, requestDate, hasRequestedTimeline, timelineRefreshToken]);


    React.useEffect(() => {
        if (!selectedAgent || !requestDate || !hasRequestedTimeline) {
            setTimelineEvents([])
            setTimelineError(null)
            setTimelineLoading(false)
            return
        }

        let isCancelled = false
        const fetchTimelineData = async () => {
            setTimelineLoading(true)
            setTimelineError(null)
            setTimelineEvents([])

            try {
                const events = await processTimelineEvents(selectedAgent, requestDate)
                if (!isCancelled) {
                    setTimelineEvents(events)
                }
            } catch (error) {
                if (isCancelled) return
                const message = error instanceof Error ? error.message : "Unable to load timeline data"
                setTimelineError(message)
                setTimelineEvents([])
            } finally {
                if (!isCancelled) {
                    setTimelineLoading(false)
                }
            }
        }

        fetchTimelineData()

        return () => {
            isCancelled = true
        }
    }, [selectedAgent, requestDate, hasRequestedTimeline, timelineRefreshToken])

    const displayTimelineEvents = React.useMemo(() => {
        if (showFullTimeline) {
            return timelineEvents
        }
        return timelineEvents.filter((event) => event.type !== "movement")
    }, [timelineEvents, showFullTimeline])

    const mapPathPoints = React.useMemo(() => {
        const allPoints = timelineEvents
            .filter((event) => typeof event.lat === "number" && typeof event.lon === "number")
            .map((event) => ({
                lat: event.lat,
                lng: event.lon,
                type: event.type,
                title:
                    event.type === "checkin"
                        ? "Check-in"
                        : event.type === "checkout"
                            ? "Check-out"
                            : event.type === "halt"
                                ? "Location Halt"
                                : event.type === "collection"
                                    ? event.meta?.activityName || "Collection"
                                    : undefined,
                eventTime: event.startTime,
                duration: event.duration,
            }))

        let sequenceCounter = 1
        return allPoints.map((point) => {
            if (point.type !== "movement") {
                return {
                    ...point,
                    sequenceNumber: sequenceCounter++,
                }
            }
            return point
        })
    }, [timelineEvents])


    const hasTimelineData = displayTimelineEvents.length > 0

    const timelineStatusMessage = React.useMemo(() => {
        if (!timelineLoading && !timelineError && !hasTimelineData) {
            return "No timeline data available."
        }
        return null
    }, [timelineLoading, timelineError, hasTimelineData])

    const handleRefreshTimeline = React.useCallback(() => {
        if (!hasSelections) return
        setHasRequestedTimeline(true)
        setSelectedLocation(null)
        setTimelineRefreshToken((value) => value + 1)
    }, [hasSelections])

    React.useEffect(() => {
        if (!selectedLocation) {
            return
        }
        const nextRecord = displayTimelineEvents.find(
            (record) =>
                record.lat === selectedLocation.lat &&
                record.lon === selectedLocation.lon &&
                record.startTime === selectedLocation.startTime
        ) ?? null
        if (nextRecord && nextRecord !== selectedLocation) {
            setSelectedLocation(nextRecord)
        }
    }, [displayTimelineEvents, selectedLocation])

    return (
        <div className="flex flex-col">
            <Collapsible open={isFilterSectionOpen} onOpenChange={setIsFilterSectionOpen} className="border-b">
                <div className="p-4 flex items-center justify-between">
                    <div>
                        <h1 className="text-2xl font-bold tracking-tight">Agent Tracker</h1>
                        <p className="text-muted-foreground text-sm">Track agent locations and daily activities.</p>
                    </div>
                    <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="icon">
                            {isFilterSectionOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                            <span className="sr-only">Toggle Filters</span>
                        </Button>
                    </CollapsibleTrigger>
                </div>
                <CollapsibleContent className="p-4 pt-0 space-y-4">
                    <div className="grid gap-4 md:grid-cols-4">
                        <div className="space-y-2">
                            <Label>State</Label>
                            <SearchableSelect
                                placeholder="Select a state"
                                onValueChange={(value) => {
                                    setSelectedState(value)
                                    setSelectedBranch("")
                                    setSelectedAgent("")
                                }}
                                value={selectedState}
                                options={availableStates.map(state => ({ value: state, label: state }))}
                                disabled={
                                    branchesLoading ||
                                    currentUserLoading ||
                                    !!currentUserError ||
                                    availableStates.length === 0
                                }
                            />
                            {(currentUserError || branchesError) && (
                                <p className="text-sm text-red-600">
                                    {currentUserError ?? branchesError}
                                </p>
                            )}
                        </div>

                        <div className="space-y-2">
                            <Label>Branch</Label>
                            <SearchableSelect
                                placeholder={!selectedState ? "Select a state first" : "Select a branch"}
                                onValueChange={(value) => {
                                    setSelectedBranch(value)
                                    setSelectedAgent("")
                                }}
                                value={selectedBranch}
                                options={sortedBranches.map(branch => ({ value: branch.id, label: branch.name || "Unnamed Branch" }))}
                                disabled={
                                    branchesLoading ||
                                    currentUserLoading ||
                                    !!currentUserError ||
                                    !selectedState ||
                                    filteredBranches.length === 0
                                }
                            />
                        </div>

                        <div className="space-y-2">
                            <Label>Agent</Label>
                            <SearchableSelect
                                placeholder={!selectedBranch ? "Select a branch first" : "Select an agent"}
                                onValueChange={setSelectedAgent}
                                value={selectedAgent}
                                options={sortedBranchUsers.map(userOption => ({
                                    value: userOption.id,
                                    label: userOption.userName ||
                                        [userOption.firstName, userOption.lastName].filter(Boolean).join(" ") ||
                                        "Unnamed User"
                                }))}
                                disabled={!selectedBranch || branchUsers.length === 0}
                            />
                        </div>

                        <div className="space-y-2">
                            <Label>Date</Label>
                            <Popover open={isDatePickerOpen} onOpenChange={setIsDatePickerOpen}>
                                <PopoverTrigger asChild>
                                    <Button
                                        variant="outline"
                                        className={cn(
                                            "w-full justify-start text-left font-normal",
                                            !date && "text-muted-foreground"
                                        )}
                                    >
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {date ? format(date, "dd MMM yyyy") : <span>Pick a date</span>}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="end">
                                    <Calendar
                                        mode="single"
                                        selected={date}
                                        onSelect={(selectedDate) => {
                                            setDate(selectedDate)
                                            setIsDatePickerOpen(false)
                                        }}
                                        defaultMonth={date}
                                        toDate={new Date()}
                                        disabled={{ after: new Date() }}
                                        initialFocus
                                    />
                                </PopoverContent>
                            </Popover>
                        </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-4">
                        <Button
                            onClick={() => {
                                if (!hasSelections) return
                                handleRefreshTimeline()
                                setIsTimelineOpen(true)
                            }}
                            disabled={!hasSelections || timelineLoading}
                        >
                            {timelineLoading ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                                <MapPin className="mr-2 h-4 w-4" />
                            )}
                            View Timeline
                        </Button>
                        {showResults && (
                            <div className="flex items-center gap-4 rounded-lg bg-muted p-2">
                                <div>
                                    <p className="font-bold">{agentDisplayName || "Agent"}</p>
                                    <p className="text-sm text-muted-foreground">
                                        {selectedBranchData?.name || "Branch"}
                                    </p>
                                </div>
                                <div className="flex items-center gap-3 border-l pl-4">
                                    <Route className="h-6 w-6 text-primary" />
                                    <div>
                                        <p className="text-xs text-muted-foreground">Distance Travelled</p>
                                        <p className="font-bold text-lg">
                                            {totalDistanceKm > 0 ? `${totalDistanceKm.toFixed(2)} km` : "0 km"}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </CollapsibleContent>
            </Collapsible>

            {showResults ? (
                <div
                    className={cn(
                        "grid grid-cols-1 rounded-lg border",
                        isTimelineOpen && "md:grid-cols-[320px_1fr]"
                    )}
                >
                    {isTimelineOpen ? (
                        <div className="flex flex-col border-r bg-background" style={{ height: "450px" }}>
                            <div className="p-4 border-b flex items-center justify-between shrink-0">
                                <div>
                                    <h3 className="font-semibold">Timeline</h3>
                                    <p className="text-sm text-muted-foreground">
                                        {agentDisplayName || "Agent"} on {date ? format(date, "PPP") : ""}
                                    </p>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={handleRefreshTimeline}
                                        disabled={timelineLoading}
                                    >
                                        <RefreshCcw className={cn("h-4 w-4", timelineLoading && "animate-spin")} />
                                        <span className="sr-only">Refresh Timeline</span>
                                    </Button>
                                    <Button variant="ghost" size="icon" onClick={() => setIsTimelineOpen(false)}>
                                        <PanelLeftClose className="h-5 w-5" />
                                        <span className="sr-only">Hide Timeline</span>
                                    </Button>
                                </div>
                            </div>
                            <div className="px-4 py-2 border-b flex items-center space-x-2 shrink-0">
                                <Checkbox
                                    id="show-full-timeline"
                                    checked={showFullTimeline}
                                    onCheckedChange={(checked) => setShowFullTimeline(checked === true)}
                                />
                                <label
                                    htmlFor="show-full-timeline"
                                    className="text-sm font-medium leading-none cursor-pointer"
                                >
                                    Show full timeline
                                </label>
                            </div>
                            <ScrollArea className="flex-1">
                                <div className="p-4">
                                    {timelineLoading ? (
                                        <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground py-6">
                                            <Loader2 className="h-4 w-4 animate-spin" />
                                            Fetching timeline data...
                                        </div>
                                    ) : timelineError ? (
                                        <div className="flex items-center gap-2 rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
                                            <AlertCircle className="h-4 w-4" />
                                            <span>{timelineError}</span>
                                        </div>
                                    ) : !hasTimelineData ? (
                                        <div className="text-center text-muted-foreground py-10">
                                            {timelineStatusMessage ?? "No timeline data available."}
                                        </div>
                                    ) : (
                                        displayTimelineEvents.map((event) => (
                                            <TimelineCard
                                                key={`${event.type}-${event.startTime}-${event.lat}-${event.lon}`}
                                                event={event}
                                                onLocationClick={setSelectedLocation}
                                            />
                                        ))
                                    )}
                                </div>
                            </ScrollArea>
                        </div>
                    ) : null}

                    <div className="flex flex-col bg-muted relative">
                        {!isTimelineOpen && (
                            <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => setIsTimelineOpen(true)}
                                className="absolute top-3 left-3 z-10 bg-background hover:bg-accent"
                            >
                                <PanelLeftOpen className="h-5 w-5" />
                                <span className="sr-only">Show Timeline</span>
                            </Button>
                        )}
                        <div className="p-4">
                            {mapPathPoints.length > 0 ? (
                                <MapView
                                    path={mapPathPoints}
                                    totalDistance={totalDistanceKm}
                                    highlightedLocation={
                                        selectedLocation && selectedLocation.lat !== undefined && selectedLocation.lon !== undefined
                                            ? { lat: selectedLocation.lat, lng: selectedLocation.lon, startTime: selectedLocation.startTime }
                                            : null
                                    }
                                />
                            ) : timelineLoading ? (
                                <div className="flex h-full items-center justify-center text-muted-foreground">
                                    <Loader2 className="h-5 w-5 animate-spin" />
                                    <span className="ml-2">Loading map...</span>
                                </div>
                            ) : (
                                <div className="flex h-full items-center justify-center text-muted-foreground">
                                    Select a timeline event to see it on the map.
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            ) : (
                <div className="flex-1 flex items-center justify-center text-muted-foreground bg-gray-50 rounded-lg border">
                    <p>Select an agent and date, then click "View Timeline" to see results.</p>
                </div>
            )}
        </div>
    )
}
