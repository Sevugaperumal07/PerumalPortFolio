import { useState, useEffect, useCallback, useMemo } from "react";
import { Link } from "react-router-dom";
import {
  AlertTriangle,
  Banknote,
  Bell,
  Briefcase,
  ClipboardCheck,
  Clock,
  HandCoins,
  ListTodo,
  Loader2,
  Megaphone,
  Search,
  Users,
  CircleX,
  X,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { getNotificationNavigationLink, getUserNotifications, type Notification } from "@/lib/services/notifications";

type ToneKey =
  | "amber"
  | "rose"
  | "orange"
  | "red"
  | "emerald"
  | "teal"
  | "yellow"
  | "blue"
  | "sky"
  | "cyan"
  | "slate";

type NotificationStyle = {
  label: string;
  icon: LucideIcon;
  tone: ToneKey;
  toneClass?: string;
};

const toneStyles: Record<ToneKey, string> = {
  amber: "bg-amber-100 text-amber-700",
  rose: "bg-rose-100 text-rose-700",
  orange: "bg-orange-100 text-orange-700",
  red: "bg-red-100 text-red-700",
  emerald: "bg-emerald-100 text-emerald-700",
  teal: "bg-teal-100 text-teal-700",
  yellow: "bg-yellow-100 text-yellow-700",
  blue: "bg-blue-100 text-blue-700",
  sky: "bg-sky-100 text-sky-700",
  cyan: "bg-cyan-100 text-cyan-700",
  slate: "bg-slate-100 text-slate-700",
};

const notificationStyles: Record<string, NotificationStyle> = {
  MISSED_CHECKIN_AGENT: {
    label: "Missed Check-in",
    icon: Clock,
    tone: "amber",
  },
  MISSED_CHECKIN_MANAGER: {
    label: "Missed Check-in",
    icon: Clock,
    tone: "rose",
  },
  REFUSE_TO_PAY_AGENT: {
    label: "Refuse to Pay",
    icon: HandCoins,
    tone: "orange",
  },
  REFUSE_TO_PAY_MANAGER: {
    label: "Refuse to Pay",
    icon: CircleX,
    tone: "red",
  },
  HIGH_CASH_AGENT: {
    label: "High Cash Alert",
    icon: Banknote,
    tone: "red",
  },
  HIGH_CASH_MANAGER: {
    label: "High Cash Alert",
    icon: AlertTriangle,
    tone: "red",
  },
  PTP_DUE_TODAY_AGENT: {
    label: "PTP Due Today",
    icon: ClipboardCheck,
    tone: "emerald",
  },
  PTP_DUE_TODAY_MANAGER: {
    label: "PTP Due Today",
    icon: ClipboardCheck,
    tone: "teal",
  },
  BROKEN_PTP_AGENT: {
    label: "Broken PTP",
    icon: CircleX,
    tone: "slate",
  },
  BROKEN_PTP_MANAGER: {
    label: "Broken PTP",
    icon: AlertTriangle,
    tone: "rose",
  },
  TASK_NOTE_NOTIFICATION: {
    label: "Task Note",
    icon: ListTodo,
    tone: "orange",
    toneClass: "bg-amber-500 text-white",
  },
  CASE_NOTE_NOTIFICATION: {
    label: "Case Note",
    icon: Briefcase,
    tone: "emerald",
    toneClass: "bg-green-500 text-white",
  },
};

const formatEventLabel = (eventType: string) =>
  eventType
    .toLowerCase()
    .split("_")
    .filter(Boolean)
    .map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1))
    .join(" ");

export default function NotificationsList() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const getUserId = () => {
    try {
      const stored = localStorage.getItem("userData");
      if (stored) {
        const userData = JSON.parse(stored);
        return userData?.id;
      }
    } catch (error) {
      console.error("Error reading userData from localStorage:", error);
    }
    return null;
  };

  const fetchNotifications = useCallback(async () => {
    const userId = getUserId();
    if (!userId) {
      setError("User not found. Please log in again.");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const result = await getUserNotifications(userId);
      setNotifications(result);
    } catch (err) {
      console.error("Error fetching notifications:", err);
      setError(err instanceof Error ? err.message : "Failed to fetch notifications");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  const formatTimestamp = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleString("en-US", {
        month: "numeric",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
        second: "2-digit",
      });
    } catch {
      return "";
    }
  };

  const getNoteType = (notification: Notification) =>
    notification.noteType ||
    (notification.noteTypeId === 1
      ? "CASE"
      : notification.noteTypeId === 2
        ? "TASK"
        : notification.noteTypeId === 3
          ? "BROADCAST"
          : notification.noteTypeId === 4
            ? "USER"
            : "");

  const getMessage = (notification: Notification) => {
    const payload = notification.parsedPayload;
    return (
      payload?.body ||
      notification.content ||
      notification.message ||
      payload?.title ||
      "New note"
    );
  };

  const getSummary = (notification: Notification) => {
    const payload = notification.parsedPayload;
    if (payload?.body && payload?.title && payload.title !== payload.body) {
      return payload.title;
    }
    return null;
  };

  const getLink = (notification: Notification) => {
    const eventType = notification.eventType?.toUpperCase() || "";
    const noteType = getNoteType(notification);

    const payloadLink = getNotificationNavigationLink(notification);
    if (payloadLink) {
      return payloadLink;
    }

    const recordId = notification.caseId?.trim() || "";
    const referenceId = notification.loanNumber || notification.referenceId || "";

    if (eventType === "CASE_NOTE_NOTIFICATION" || noteType === "CASE") {
      if (recordId) {
        return `/dashboard/cases?caseId=${encodeURIComponent(recordId)}`;
      }
      if (referenceId) {
        return `/dashboard/cases?lan=${encodeURIComponent(referenceId)}`;
      }
      return "/dashboard/cases";
    }
    if (eventType === "TASK_NOTE_NOTIFICATION" || noteType === "TASK") {
      if (recordId) {
        return `/dashboard/tasks?caseId=${encodeURIComponent(recordId)}`;
      }
      if (referenceId) {
        return `/dashboard/tasks?lan=${encodeURIComponent(referenceId)}`;
      }
      return "/dashboard/tasks";
    }
    return "#";
  };

  const resolveNotificationStyle = (notification: Notification) => {
    const eventType = notification.eventType?.toUpperCase() || "";
    const noteType = getNoteType(notification);

    if (eventType && notificationStyles[eventType]) {
      const style = notificationStyles[eventType];
      return { eventType, ...style };
    }

    if (eventType.includes("BROADCAST") || noteType === "BROADCAST") {
      return {
        eventType,
        label: "Broadcast",
        icon: Megaphone,
        tone: "blue" as const,
        toneClass: "bg-blue-500 text-white",
      };
    }

    if (eventType.includes("USER") || noteType === "USER") {
      return { eventType, label: "User Alert", icon: Users, tone: "sky" as const };
    }

    if (noteType === "CASE") {
      const style = notificationStyles.CASE_NOTE_NOTIFICATION;
      return { eventType, ...style };
    }

    if (noteType === "TASK") {
      const style = notificationStyles.TASK_NOTE_NOTIFICATION;
      return { eventType, ...style };
    }

    if (eventType) {
      return { eventType, label: formatEventLabel(eventType), icon: Bell, tone: "slate" as const };
    }

    return { eventType, label: "Notification", icon: Bell, tone: "slate" as const };
  };

  const filteredNotifications = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    if (!term) return notifications;

    return notifications.filter((notification) => {
      const payload = notification.parsedPayload;
      const context = payload?.context;
      const searchable = [
        getMessage(notification),
        getSummary(notification),
        payload?.title,
        payload?.body,
        notification.authorName,
        context?.agentName,
        context?.customerName,
        notification.loanNumber,
        notification.caseId,
        notification.referenceId,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      return searchable.includes(term);
    });
  }, [notifications, searchTerm]);

  return (
    <div className="space-y-4 max-w-4xl">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Notes</h1>
        <p className="text-sm text-muted-foreground">
          View and manage all notes and broadcasts.
        </p>
      </div>
      <div className="relative max-w-2xl">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={searchTerm}
          onChange={(event) => setSearchTerm(event.target.value)}
          placeholder="Search notes by content, author, LAN, or customer..."
          className="pl-9 pr-8"
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm("")}
            className="absolute right-2 top-1/2 -translate-y-1/2 hover:text-foreground transition-colors"
          >
            <X className="h-4 w-4 text-muted-foreground" />
          </button>
        )}

      </div>

      <div className="mt-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            <span className="ml-3 text-muted-foreground">Loading notes...</span>
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-red-500 mb-4">{error}</p>
            <Button variant="outline" onClick={fetchNotifications}>
              Try Again
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredNotifications.length === 0 ? (
              <div className="text-center py-12 bg-muted/30 rounded-lg">
                <Bell className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">
                  {searchTerm.trim()
                    ? "No notes match your search."
                    : "No notes yet."}
                </p>
              </div>
            ) : (
              filteredNotifications.map((notification, index) => {
                const message = getMessage(notification);
                const summary = getSummary(notification);
                const style = resolveNotificationStyle(notification);
                const typeLabel = style.label || formatEventLabel(style.eventType || "NOTIFICATION");
                const link = getLink(notification);
                const hasLink = link !== "#";
                const tone = style.toneClass ?? toneStyles[style.tone];
                const Icon = style.icon;
                const referenceId = notification.loanNumber || notification.caseId || notification.referenceId || "";
                const customerName = notification.parsedPayload?.context?.customerName;
                const authorName = notification.parsedPayload?.context?.agentName || notification.authorName;

                const eventType = notification.eventType?.toUpperCase() || "";
                const isHighCashAlert = eventType.includes("HIGH_CASH");

                // Senior dev rule: High cash alerts navigate to Tasks -> Branch Ops In Hand
                const navigationLink = isHighCashAlert ? "/dashboard/tasks" : link;
                const navigationState = isHighCashAlert ? { tab: "Pending" } : undefined;

                const content = (
                  <Card className={cn(
                    "border border-slate-200/70 bg-white p-4 shadow-sm transition-colors",
                    hasLink && "hover:border-slate-300 hover:bg-slate-50/60 cursor-pointer"
                  )}>
                    <div className="flex items-start gap-3">
                      <div className={cn(
                        "mt-0.5 flex h-10 w-10 items-center justify-center rounded-full",
                        tone
                      )}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="flex-1 min-w-0 space-y-2">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="text-sm font-semibold text-gray-900">{typeLabel}</p>
                            <p className="text-xs text-muted-foreground">{formatTimestamp(notification.createdAt)}</p>
                          </div>
                          {authorName && (
                            <Badge variant="secondary" className="shrink-0 whitespace-nowrap">
                              {authorName}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-700 leading-relaxed">
                          {message}
                        </p>
                        {summary && (
                          <p className="text-xs text-muted-foreground">{summary}</p>
                        )}
                        {(customerName || referenceId) && (
                          <div className="text-xs text-muted-foreground space-y-1">
                            {customerName && <p>Customer: {customerName}</p>}
                            {referenceId && <p>Reference #: {referenceId}</p>}
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                );

                if (hasLink || isHighCashAlert) {
                  return (
                    <Link
                      key={notification.id || notification.messageId || index}
                      to={navigationLink}
                      state={navigationState}
                    >
                      {content}
                    </Link>
                  );
                }

                return <div key={notification.id || notification.messageId || index}>{content}</div>;
              })
            )}
          </div>
        )}
      </div>
    </div>
  );
}
