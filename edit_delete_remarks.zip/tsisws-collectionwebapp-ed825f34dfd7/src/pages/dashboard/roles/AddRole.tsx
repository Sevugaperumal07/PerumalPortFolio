import { RoleAccessSetup, type RoleMatrixResponse } from '@/components/dashboard/RoleAccessSetup';
import { RoleHierarchyIntegrated } from '@/components/dashboard/RoleHierarchyIntegrated';
import { useRoleHierarchy } from '@/hooks/use-role-hierarchy';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useUserRole } from '@/contexts/UserRoleContext';
import { useToast } from '@/hooks/use-toast';
import { createRole, createRolePermissions, getRoleMatrix, getRoles, getPermissionLevels, updateRoleHierarchy, type RolePermissionPayload, type RoleHierarchyPayload } from '@/lib/services/roles';
import type { Role } from '@/lib/types';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { RoleForm } from './RoleForm';
import type { PermissionLevel } from '@/components/dashboard/RoleAccessSetup';

export default function AddRole() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { refreshRoleData } = useUserRole();
  const { data: hierarchyTree, loading: loadingHierarchy } = useRoleHierarchy();
  const [loading, setLoading] = useState(false);
  const [savingPermissions, setSavingPermissions] = useState(false);
  const [createdRole, setCreatedRole] = useState<Role | null>(null);
  const [matrixData, setMatrixData] = useState<RoleMatrixResponse | undefined>(undefined);
  const [allRoles, setAllRoles] = useState<Role[]>([]);
  const [permissionLevels, setPermissionLevels] = useState<PermissionLevel[]>([]);
  const [isHierarchySaved, setIsHierarchySaved] = useState(false);
  const [isSavingHierarchy, setIsSavingHierarchy] = useState(false);
  const [hierarchyData, setHierarchyData] = useState<{ parentRoleId: string | null; childRoleId: string | null; isValid: boolean }>({
    parentRoleId: null,
    childRoleId: null,
    isValid: true
  });

  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const [roles, levels] = await Promise.all([
          getRoles(),
          getPermissionLevels()
        ]);
        setAllRoles(roles);
        setPermissionLevels(levels);
      } catch (error) {
        console.error('Failed to fetch initial data:', error);
      }
    };
    fetchInitialData();
  }, []);

  const handleSubmit = async (data: { name: string; description?: string }) => {
    try {
      setLoading(true);
      const newRole = await createRole(data);
      setCreatedRole(newRole);
      setIsHierarchySaved(false);

      // Fetch matrix data for the newly created role
      try {
        const matrix = await getRoleMatrix(newRole.id);
        setMatrixData(matrix);
        toast({
          title: 'Success',
          description: 'Role created successfully. Please set up permissions below.',
        });
      } catch (matrixError) {
        toast({
          title: 'Warning',
          description: 'Role created but failed to load permission matrix. You can set permissions later.',
          variant: 'destructive',
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to create role',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePermissionChange = (category: string, action: string, effectiveLevel: number) => {
    if (!matrixData) return;

    setMatrixData({
      ...matrixData,
      matrix: matrixData.matrix.map(categoryMatrix => {
        if (categoryMatrix.category === category) {
          return {
            ...categoryMatrix,
            actions: categoryMatrix.actions.map(actionPerm => {
              if (actionPerm.action === action) {
                return {
                  ...actionPerm,
                  effectiveLevel,
                };
              }
              return actionPerm;
            }),
          };
        }
        return categoryMatrix;
      }),
    });
  };

  const buildPermissionPayload = (data: RoleMatrixResponse): RolePermissionPayload[] => {
    const payload: RolePermissionPayload[] = [];

    data.matrix.forEach(categoryMatrix => {
      categoryMatrix.actions.forEach(actionPerm => {
        payload.push({
          category: categoryMatrix.category,
          name: actionPerm.action,
          override: actionPerm.effectiveLevel,
        });
      });
    });

    return payload;
  };

  const handleHierarchySave = async () => {
    if (!createdRole) return;

    try {
      setIsSavingHierarchy(true);
      if (hierarchyData.parentRoleId || hierarchyData.childRoleId) {
        const payload: RoleHierarchyPayload = { 
          roleId: createdRole.id,
          parentRoleId: hierarchyData.parentRoleId,
          childRoleId: hierarchyData.childRoleId,
          edit: 'false'
        };
        await updateRoleHierarchy(payload);
      }
      setIsHierarchySaved(true);
      toast({
        title: 'Hierarchy Set',
        description: 'Role hierarchy saved successfully. Now you can set up permissions.',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to save hierarchy',
        variant: 'destructive',
      });
    } finally {
      setIsSavingHierarchy(false);
    }
  };

  const handleCancelHierarchy = () => {
    setIsHierarchySaved(true);
    toast({
      title: 'Hierarchy Setup Skipped',
      description: 'You can now proceed to set up role permissions.',
    });
  };

  const handleSavePermissions = async () => {
    if (!createdRole || !matrixData) return;

    try {
      setSavingPermissions(true);
      const payload = buildPermissionPayload(matrixData);

      // Create permissions
      await createRolePermissions(createdRole.id, payload);

      await refreshRoleData();
      toast({
        title: 'Success',
        description: 'Role setup (hierarchy & permissions) completed successfully',
      });
      navigate('/dashboard/roles');
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to save permissions',
        variant: 'destructive',
      });
    } finally {
      setSavingPermissions(false);
    }
  };

  const handleSkipPermissions = () => {
    toast({
      title: 'Success',
      description: 'Role created successfully. You can set permissions later.',
    });
    navigate('/dashboard/roles');
  };

  return (
    <div className="space-y-3 sm:space-y-4 md:space-y-6" style={{ width: '1800px', minWidth: '1800px' }}>
      <div className="px-1 sm:px-0">
        <h1 className="text-lg sm:text-xl md:text-2xl font-bold">Add Role</h1>
        <p className="text-xs sm:text-sm md:text-base text-muted-foreground mt-1">Create a new role</p>
      </div>

      <Card className="overflow-visible" style={{ minWidth: '600px' }}>
        <CardHeader className="px-2 sm:px-4 md:px-6 py-3 sm:py-4 md:py-6">
          <CardTitle className="text-sm sm:text-base md:text-lg">Role Information</CardTitle>
        </CardHeader>
        <CardContent className="px-2 sm:px-4 md:px-6 pb-4 sm:pb-6 md:pb-8 pt-0 overflow-visible">
          <RoleForm
            onSubmit={handleSubmit}
            loading={loading}
            showCode={false}
            showButtons={!createdRole}
            disabled={!!createdRole}
          />
        </CardContent>
      </Card>

      {createdRole && matrixData && (
        <>
          <div className="mt-6 space-y-12">
            <RoleHierarchyIntegrated
              roles={allRoles}
              roots={hierarchyTree}
              loading={loadingHierarchy}
              currentRoleName={createdRole.name}
              currentRoleId={createdRole.id}
              onHierarchyChange={setHierarchyData}
              showButtons={!isHierarchySaved}
              onSave={handleHierarchySave}
              onCancel={handleCancelHierarchy}
              isSaving={isSavingHierarchy}
              disabled={isHierarchySaved}
            />

            {isHierarchySaved && (
              <RoleAccessSetup
                data={matrixData}
                onChange={handlePermissionChange}
                permissionLevels={permissionLevels}
                showPlatformTabs={true}
              />
            )}
          </div>

          {isHierarchySaved && (
            <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-4 mt-8">
              <Button
                type="button"
                variant="outline"
                onClick={handleSkipPermissions}
                className="w-full sm:w-auto"
                disabled={savingPermissions}
              >
                Skip Permissions
              </Button>
              <Button
                type="button"
                onClick={handleSavePermissions}
                disabled={savingPermissions}
                className="w-full sm:w-auto bg-[#0052CC] hover:bg-rose-500 text-white"
              >
                {savingPermissions ? 'Saving Permissions...' : 'Save Permissions'}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

