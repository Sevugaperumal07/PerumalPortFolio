import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { getRoles, createRole } from '@/lib/services/roles';
import type { Role } from '@/lib/types';
import { RoleForm } from './RoleForm';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
// import { RoleAccessSetup, type ModulePermissions } from '@/components/dashboard/RoleAccessSetup';
import { Button } from '@/components/ui/button';

export default function CloneRole() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [sourceRole, setSourceRole] = useState<Role | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingRole, setLoadingRole] = useState(true);
  // const [permissions, setPermissions] = useState<ModulePermissions[]>([]);
  const [clonedRole, setClonedRole] = useState<Role | null>(null);

  useEffect(() => {
    if (id) {
      loadRole();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const loadRole = async () => {
    if (!id) return;
    
    try {
      setLoadingRole(true);
      const roles = await getRoles();
      const foundRole = roles.find(r => r.id === id);
      if (foundRole) {
        setSourceRole(foundRole);
        
        // Create cloned role data with "- Copy" suffix
        const roleName = foundRole.name || '';
        const roleCode = (foundRole as any).code || roleName.toUpperCase().replace(/\s+/g, '-');
        
        setClonedRole({
          ...foundRole,
          id: '', // New role will get a new ID
          name: `${roleName} - Copy`,
          code: `${roleCode}-COPY`,
          description: foundRole.description || '',
        } as Role);
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to load role',
        variant: 'destructive',
      });
    } finally {
      setLoadingRole(false);
    }
  };

  const handleSubmit = async (data: { name: string; code?: string; description?: string }) => {
    try {
      setLoading(true);
      await createRole({
        name: data.name,
        description: data.description,
        // Note: code field is not sent as AclRoleInput doesn't support it
      });
      toast({
        title: 'Success',
        description: 'Role cloned successfully',
      });
      navigate('/dashboard/roles');
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to clone role',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (loadingRole) {
    return <div className="flex items-center justify-center p-8">Loading...</div>;
  }

  if (!sourceRole || !clonedRole) {
    return (
      <div className="flex flex-col items-center justify-center p-8 gap-4">
        <p className="text-muted-foreground">Role not found</p>
        <Button onClick={() => navigate('/dashboard/roles')}>Back to Roles</Button>
      </div>
    );
  }

  return (
    <div className="space-y-4" style={{ width: '1800px', minWidth: '1800px' }}>
      <div>
        <h1 className="text-xl sm:text-2xl font-bold">Clone Role</h1>
        <p className="text-sm sm:text-base text-muted-foreground">
          Cloning role "{sourceRole.name}". Fill out the new details below.
        </p>
      </div>

      <Card style={{ minWidth: '600px' }}>
        <CardHeader>
          <CardTitle>Role Information</CardTitle>
        </CardHeader>
        <CardContent>
          <RoleForm role={clonedRole as Role} onSubmit={handleSubmit} loading={loading} showButtons={false} showCode={false} />
        </CardContent>
      </Card>

      {/* <div className="mt-6">
        <RoleAccessSetup 
          permissions={permissions} 
          onChange={setPermissions}
        />
      </div> */}

      <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-4">
        <Button 
          type="button" 
          variant="outline" 
          onClick={() => navigate('/dashboard/roles')} 
          className="w-full sm:w-auto"
        >
          Cancel
        </Button>
        <Button 
          type="button" 
          onClick={() => {
            const formElement = document.getElementById('role-form') as HTMLFormElement;
            if (formElement) {
              formElement.requestSubmit();
            }
          }}
          disabled={loading} 
          className="w-full sm:w-auto"
        >
          {loading ? 'Saving...' : 'Save'}
        </Button>
      </div>
    </div>
  );
}

