import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { getRoles, getRoleMatrix, updateRolePermissions, updateRoleHierarchy, getPermissionLevels, type RolePermissionPayload, type RoleHierarchyPayload } from '@/lib/services/roles';
import type { Role } from '@/lib/types';
import { RoleForm } from './RoleForm';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RoleAccessSetup, type RoleMatrixResponse, type CategoryMatrix, type ActionPermission, type PermissionLevel } from '@/components/dashboard/RoleAccessSetup';
import { Button } from '@/components/ui/button';
import { useUserRole } from '@/contexts/UserRoleContext';
import { useRoleHierarchy } from '@/hooks/use-role-hierarchy';
import { RoleHierarchyEditIntegrated } from '@/components/dashboard/RoleHierarchyEditIntegrated';
import { AlertCircle } from 'lucide-react';

export default function EditRole() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { refreshRoleData } = useUserRole();
  const { data: roots, loading: loadingHierarchy } = useRoleHierarchy();
  
  const [role, setRole] = useState<Role | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingRole, setLoadingRole] = useState(true);
  const [matrixData, setMatrixData] = useState<RoleMatrixResponse | undefined>(undefined);
  const [allRoles, setAllRoles] = useState<Role[]>([]);
  const [permissionLevels, setPermissionLevels] = useState<PermissionLevel[]>([]);
  const [hierarchyData, setHierarchyData] = useState<{ parentRoleId: string | null; childRoleId: string | null; isValid: boolean }>({ 
    parentRoleId: null, 
    childRoleId: null,
    isValid: true 
  });

  useEffect(() => {
    if (id) {
      fetchPageData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const fetchPageData = async () => {
    if (!id) return;

    try {
      setLoadingRole(true);
      // Fetch all required data in parallel
      const [roles, matrix, levels] = await Promise.all([
        getRoles(),
        getRoleMatrix(id),
        getPermissionLevels()
      ]);

      // Set roles and current role
      const foundRole = roles.find(r => r.id === id);
      if (foundRole) {
        setRole(foundRole);
      }
      
      setAllRoles(roles.filter(r => r.id !== id));
      setMatrixData(matrix);
      setPermissionLevels(levels);
      
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to load page data',
        variant: 'destructive',
      });
    } finally {
      setLoadingRole(false);
    }
  };

  const handleSubmit = async () => {
    // Role metadata update is disabled - form is read-only
    // This handler is kept for form compatibility but does nothing
  };

  const handlePermissionChange = (category: string, action: string, effectiveLevel: number) => {
    if (!matrixData) return;

    setMatrixData({
      ...matrixData,
      matrix: matrixData.matrix.map((categoryMatrix: CategoryMatrix) => {
        if (categoryMatrix.category === category) {
          return {
            ...categoryMatrix,
            actions: categoryMatrix.actions.map((actionPerm: ActionPermission) => {
              if (actionPerm.action === action) {
                return {
                  ...actionPerm,
                  effectiveLevel,
                };
              }
              return actionPerm;
            }),
          };
        }
        return categoryMatrix;
      }),
    });
  };

  const buildPermissionPayload = (data: RoleMatrixResponse): RolePermissionPayload[] => {
    const payload: RolePermissionPayload[] = [];
    
    data.matrix.forEach((categoryMatrix: CategoryMatrix) => {
      categoryMatrix.actions.forEach((actionPerm: ActionPermission) => {
        payload.push({
          category: categoryMatrix.category,
          name: actionPerm.action,
          override: actionPerm.effectiveLevel,
        });
      });
    });
    
    return payload;
  };

    
  if (loadingRole) {
    return <div className="flex items-center justify-center p-8">Loading...</div>;
  }

  if (!role) {
    return (
      <div className="flex flex-col items-center justify-center p-8 gap-4">
        <p className="text-muted-foreground">Role not found</p>
      </div>
    );
  }

  return (
    <div className="space-y-4" style={{ minWidth: '1800px', width: 'max-content' }}>
        <div>
          <h1 className="text-xl sm:text-2xl font-bold">Edit Role</h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Update the details for the "{role.name}" role.
          </p>
        </div>

        <Card style={{ minWidth: '600px' }}>
          <CardHeader>
            <CardTitle>Role Information</CardTitle>
          </CardHeader>
          <CardContent>
            <RoleForm role={role} onSubmit={handleSubmit} loading={loading} showButtons={false} showCode={false} />
          </CardContent>
        </Card>

        <div className="mt-6 space-y-12">
          {id && (
            <RoleHierarchyEditIntegrated 
              currentRoleId={id}
              currentRoleName={role.name}
              roles={allRoles}
              roots={roots}
              loading={loadingHierarchy}
              onHierarchyChange={setHierarchyData}
            />
          )}

          <RoleAccessSetup 
            data={matrixData} 
            onChange={handlePermissionChange}
            permissionLevels={permissionLevels}
            showPlatformTabs={true}
          />
        </div>

        <div className="flex flex-col items-end gap-3 mt-8 pb-10">
          {!hierarchyData.isValid && (
            <p className="text-sm text-red-500 font-medium flex items-center gap-2 mr-1 animate-in fade-in slide-in-from-right-2 duration-300">
              <AlertCircle className="w-4 h-4" />
              Please select the child or parent role to enable saving
            </p>
          )}
          <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-4 w-full sm:w-auto">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => navigate('/dashboard/roles')} 
              className="w-full sm:w-auto border-slate-200 text-slate-600 hover:bg-rose-500 hover:text-white"
              disabled={loading}
            >
              Cancel
            </Button>
            <Button 
              type="button" 
              onClick={async () => {
                if (!id || !matrixData) return;
                
                try {
                  setLoading(true);
                  const payload = buildPermissionPayload(matrixData);
                  
                  const hierarchyPayload: RoleHierarchyPayload = {
                    roleId: id,
                    parentRoleId: hierarchyData.parentRoleId,
                    childRoleId: hierarchyData.childRoleId,
                    edit: 'true'
                  };

                  await Promise.all([
                    updateRolePermissions(id, payload),
                    (hierarchyData.parentRoleId || hierarchyData.childRoleId)
                      ? updateRoleHierarchy(hierarchyPayload)
                      : Promise.resolve()
                  ]);

                  await refreshRoleData();
                  toast({
                    title: 'Success',
                    description: 'Hierarchy and permissions updated successfully',
                  });
                  navigate('/dashboard/roles');
                } catch (error) {
                  toast({
                    title: 'Error',
                    description: error instanceof Error ? error.message : 'Failed to update role permissions',
                    variant: 'destructive',
                  });
                } finally {
                  setLoading(false);
                }
              }}
              disabled={loading || !hierarchyData.isValid} 
              className="w-full sm:w-auto bg-primary hover:bg-rose-500 text-white px-8"
            >
              {loading ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </div>
    </div>
  );
}

