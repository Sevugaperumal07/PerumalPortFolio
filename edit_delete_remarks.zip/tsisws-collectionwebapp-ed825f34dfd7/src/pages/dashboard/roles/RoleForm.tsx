import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import type { Role } from '@/lib/types';

const roleFormSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  // code: z.string().optional(),
  description: z.string().optional(),
});

type RoleFormValues = z.infer<typeof roleFormSchema>;

interface RoleFormProps {
  role?: Role;
  onSubmit: (data: RoleFormValues) => Promise<void>;
  loading?: boolean;
  showButtons?: boolean;
  showCode?: boolean;
  disabled?: boolean;
}

export function RoleForm({ role, onSubmit, loading, showButtons = true, showCode = true, disabled = false }: RoleFormProps) {
  const form = useForm<RoleFormValues>({
    resolver: zodResolver(roleFormSchema),
    defaultValues: {
      name: '',
      // code: '',
      description: '',
    },
  });

  // Update form when role prop changes
  useEffect(() => {
    if (role) {
      form.reset({
        name: role.name || '',
        // code: (role as any).code || '',
        description: role.description || '',
      });
    }
  }, [role, form.reset]);

  return (
    <Form {...form}>
      <form id="role-form" onSubmit={form.handleSubmit(onSubmit)} className="space-y-3 sm:space-y-4 md:space-y-6 w-full">
        <div className={showCode ? "grid grid-cols-1 sm:grid-cols-2 gap-4" : ""}>
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs sm:text-sm">Role Name <span className="text-red-500 ml-0.5">*</span></FormLabel>
                <FormControl>
                  <Input {...field} className="text-sm sm:text-base" disabled={disabled} />
                </FormControl>
                <FormMessage className="text-xs" />
              </FormItem>
            )}
          />

          {/* {showCode && (
            <FormField
              control={form.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs sm:text-sm">Code</FormLabel>
                  <FormControl>
                    <Input {...field} className="text-sm sm:text-base" disabled={disabled} />
                  </FormControl>
                  <FormMessage className="text-xs" />
                </FormItem>
              )}
            />
          )} */}
        </div>

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-xs sm:text-sm">Description</FormLabel>
              <FormControl>
                <Textarea {...field} rows={3} className="text-sm sm:text-base resize-none" disabled={disabled} />
              </FormControl>
              <FormMessage className="text-xs" />
            </FormItem>
          )}
        />

        {showButtons && (
          <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-3 md:gap-4 pt-3 sm:pt-4 md:pt-6 pb-1 sm:pb-0">
            <Button type="button" variant="outline" onClick={() => window.history.back()} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-9 md:h-10 min-h-[36px]">
              Cancel
            </Button>
            <Button type="submit" disabled={loading} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-9 md:h-10 min-h-[36px]">
              {loading ? 'Saving...' : role ? 'Update Role' : 'Save Role'}
            </Button>
          </div>
        )}
      </form>
    </Form>
  );
}

