import { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { getRoles, getRoleMatrix, getPermissionLevels } from '@/lib/services/roles';
import type { Role } from '@/lib/types';
import RoleHierarchyBoth from '@/components/dashboard/RoleHierarchyViewBoth';
import { useRoleHierarchy } from '@/hooks/use-role-hierarchy';
import { RoleAccessSetup, type RoleMatrixResponse, type PermissionLevel } from '@/components/dashboard/RoleAccessSetup';
import { Button } from '@/components/ui/button';

export default function ViewRole() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [role, setRole] = useState<Role | null>(null);
  const [loadingRole, setLoadingRole] = useState(true);
  const [matrixData, setMatrixData] = useState<RoleMatrixResponse | undefined>(undefined);
  const [permissionLevels, setPermissionLevels] = useState<PermissionLevel[]>([]);

  const { data: hierarchyRoots, loading: loadingHierarchy } = useRoleHierarchy();

  const hierarchyInfo = useMemo(() => {
    if (!id || !hierarchyRoots.length) return { parentName: '', childNames: '' };

    let parentName = '';
    let childNames = '';

    const findNodeAndNames = (nodes: any[], targetId: string, currentParent?: any): any | null => {
      for (const node of nodes) {
        if (node.id === targetId) {
          if (currentParent) parentName = currentParent.name;
          if (node.children && node.children.length > 0) {
            childNames = node.children.map((c: any) => c.name).join(', ');
          }
          return node;
        }
        if (node.children) {
          const found = findNodeAndNames(node.children, targetId, node);
          if (found) return found;
        }
      }
      return null;
    };

    findNodeAndNames(hierarchyRoots, id);
    return { parentName, childNames };
  }, [id, hierarchyRoots]);

  useEffect(() => {
    if (id) {
      fetchPageData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const fetchPageData = async () => {
    if (!id) return;

    try {
      setLoadingRole(true);
      const [roles, matrix, levels] = await Promise.all([
        getRoles(),
        getRoleMatrix(id),
        getPermissionLevels()
      ]);

      const foundRole = roles.find(r => r.id === id);
      if (foundRole) {
        setRole(foundRole);
      }
      setMatrixData(matrix);
      setPermissionLevels(levels);
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to load role data',
        variant: 'destructive',
      });
    } finally {
      setLoadingRole(false);
    }
  };

  if (loadingRole) {
    return <div className="flex items-center justify-center p-8">Loading...</div>;
  }

  if (!role) {
    return (
      <div className="flex flex-col items-center justify-center p-8 gap-4">
        <p className="text-muted-foreground">Role not found</p>
        <Button onClick={() => navigate('/dashboard/roles')}>Back to Roles</Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold">Role: {role.name}</h1>
          <p className="text-sm sm:text-base text-muted-foreground mt-1">
            {role.description || 'Standard role.'}
          </p>
        </div>
      </div>
      <div className="mt-6">
        <RoleHierarchyBoth
          roots={hierarchyRoots}
          currentRoleId={id}
          loading={loadingHierarchy}
          parentRoleName={hierarchyInfo.parentName}
          childRoleName={hierarchyInfo.childNames}
        />
      </div>

      <div className="mt-6">
        <RoleAccessSetup
          data={matrixData}
          onChange={() => {
          }}
          permissionLevels={permissionLevels}
          readOnly={true}
          showPlatformTabs={true}
        />
      </div>
    </div>
  );
}