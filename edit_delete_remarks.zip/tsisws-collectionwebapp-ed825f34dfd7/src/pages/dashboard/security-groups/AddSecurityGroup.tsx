import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MultiSelect } from '@/components/ui/multi-select';
import { createSecurityGroup, linkBankDetailsToSecurityGroup } from '@/lib/services/security-groups';
import { getBankDetails } from '@/lib/services/bank-details';
import { getUsers, linkSecurityToUser } from '@/lib/services/users';
import type { BankDetail, User } from '@/lib/types';

const securityGroupFormSchema = z.object({
  name: z.string().min(1, 'Group name is required'),
  description: z.string().optional(),
  bankDetailIds: z.array(z.string()).optional(),
  userIds: z.array(z.string()).optional(),
});

type SecurityGroupFormValues = z.infer<typeof securityGroupFormSchema>;

export default function AddSecurityGroup() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<{
    bankDetails: BankDetail[];
    users: User[];
  } | null>(null);
  const [dataLoading, setDataLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadData() {
      try {
        setDataLoading(true);
        const [bankDetails, users] = await Promise.all([
          getBankDetails(),
          getUsers(),
        ]);
        setData({ bankDetails, users });
      } catch (err) {
        setError('Failed to load necessary data.');
      } finally {
        setDataLoading(false);
      }
    }
    loadData();
  }, []);

  const form = useForm<SecurityGroupFormValues>({
    resolver: zodResolver(securityGroupFormSchema),
    defaultValues: {
      name: '',
      description: '',
      bankDetailIds: [],
      userIds: [],
    },
    mode: 'onChange',
  });

  const handleSubmit = async (data: SecurityGroupFormValues) => {
    try {
      setLoading(true);
      const { bankDetailIds, userIds, ...securityGroupData } = data;

      // Create the security group first
      const createdGroup = await createSecurityGroup(securityGroupData);

      // Link bank details to the security group
      try {
        for (const bankDetailId of bankDetailIds ?? []) {
          await linkBankDetailsToSecurityGroup(bankDetailId, createdGroup.id);
        }
      } catch (error) {
        toast({
          title: 'Warning',
          description: 'Security group created, but there was an issue linking bank details.',
          variant: 'default',
        });
      }

      // Link users to the security group using linkExistingSecurityToUser
      try {
        for (const userId of userIds ?? []) {
          await linkSecurityToUser(userId, createdGroup.id);
        }
      } catch (error) {
        toast({
          title: 'Warning',
          description: 'Security group created, but there was an issue linking users.',
          variant: 'default',
        });
      }

      toast({
        title: 'Success',
        description: 'Security group created successfully',
      });
      navigate('/dashboard/security-groups');
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to create security group',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (dataLoading) {
    return (
      <div className="space-y-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold">Create New Security Group</h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Fill out the form below to add a new security group.
          </p>
        </div>
        <div className="rounded-lg border bg-card p-4 md:p-8">
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="space-y-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold">Create New Security Group</h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Fill out the form below to add a new security group.
          </p>
        </div>
        <div className="rounded-lg border bg-card p-4 md:p-8">
          <p className="text-destructive">{error || 'Could not load data.'}</p>
        </div>
      </div>
    );
  }

  // Map all bank details to options (matching the bank details page which shows all banks)
  const bankDetailOptions = data.bankDetails.map((bd) => ({
    value: bd.id,
    label: `${bd.bankName} - ${bd.accountNumber}`,
  }));

  const userOptions = data.users.map((user) => ({
    value: user.id,
    label: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.userName,
  }));


  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold">Create New Security Group</h1>
        <p className="text-sm sm:text-base text-muted-foreground">
          Fill out the form below to add a new security group.
        </p>
      </div>

      <div className="rounded-lg border bg-card p-4 md:p-8">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Group Name <span className="text-red-500 ml-0.5">*</span></FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g., North Region" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      rows={4}
                      placeholder="Enter a brief description of the group's purpose."
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="bankDetailIds"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Bank Details</FormLabel>
                  <MultiSelect
                    options={bankDetailOptions}
                    selected={field.value || []}
                    onChange={field.onChange}
                    placeholder="Select bank details..."
                  />
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="userIds"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Users</FormLabel>
                  <MultiSelect
                    options={userOptions}
                    selected={field.value || []}
                    onChange={field.onChange}
                    placeholder="Select users..."
                  />
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => window.history.back()}
                className="w-full sm:w-auto"
              >
                Cancel
              </Button>
              <Button type="submit" disabled={loading || !form.formState.isValid} className="w-full sm:w-auto">
                {loading ? 'Saving...' : 'Save Group'}
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}

