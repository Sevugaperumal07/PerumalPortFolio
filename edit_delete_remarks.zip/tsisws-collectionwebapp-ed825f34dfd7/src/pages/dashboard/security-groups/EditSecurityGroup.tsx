import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { getSecurityGroups, updateSecurityGroup } from '@/lib/services/security-groups';
import type { SecurityGroup } from '@/lib/types';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const securityGroupFormSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  description: z.string().optional(),
  inheritable: z.boolean().optional(),
});

type SecurityGroupFormValues = z.infer<typeof securityGroupFormSchema>;

export default function EditSecurityGroup() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [group, setGroup] = useState<SecurityGroup | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingGroup, setLoadingGroup] = useState(true);

  const form = useForm<SecurityGroupFormValues>({
    resolver: zodResolver(securityGroupFormSchema),
    mode: 'onChange',
    defaultValues: {
      name: '',
      description: '',
      inheritable: false,
    },
  });

  useEffect(() => {
    if (id) {
      loadGroup();
    }
  }, [id]);

  const loadGroup = async () => {
    if (!id) return;

    try {
      setLoadingGroup(true);
      const groups = await getSecurityGroups();
      const foundGroup = groups.find(g => g.id === id);
      if (foundGroup) {
        setGroup(foundGroup);
        form.reset({
          name: foundGroup.name || '',
          description: foundGroup.description || '',
          inheritable: foundGroup.inheritable || false,
        });
        form.trigger();
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to load security group',
        variant: 'destructive',
      });
    } finally {
      setLoadingGroup(false);
    }
  };

  const handleSubmit = async (data: SecurityGroupFormValues) => {
    if (!id) return;

    try {
      setLoading(true);
      await updateSecurityGroup(id, data);
      toast({
        title: 'Success',
        description: 'Security group updated successfully',
      });
      navigate('/dashboard/security-groups');
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to update security group',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (loadingGroup) {
    return <div className="flex items-center justify-center p-8">Loading...</div>;
  }

  if (!group) {
    return (
      <div className="flex flex-col items-center justify-center p-8 gap-4">
        <p className="text-muted-foreground">Security group not found</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold">Edit Security Group</h1>
        <p className="text-sm sm:text-base text-muted-foreground">Update security group information</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Security Group Information</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 sm:space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name <span className="text-red-500 ml-0.5">*</span></FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea {...field} rows={4} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="inheritable"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Inheritable</FormLabel>
                    </div>
                  </FormItem>
                )}
              />

              <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-4">
                <Button type="button" variant="outline" onClick={() => window.history.back()} className="w-full sm:w-auto">
                  Cancel
                </Button>
                <Button type="submit" disabled={loading || !form.formState.isValid} className="w-full sm:w-auto">
                  {loading ? 'Saving...' : 'Update Security Group'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}

