import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import type {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  RowSelectionState,
  VisibilityState,
} from "@tanstack/react-table";
import {
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Plus, List, LayoutGrid, Pencil, Trash2, Copy, ChevronDown, Users, UserCog, Landmark, X } from "lucide-react";
import { getSecurityGroups } from "@/lib/services/security-groups";
import { graphqlRequest } from "@/lib/graphql/client";
import { GET_USERS_BY_SECURITY_GROUP_ID, GET_ROLES_BY_SECURITY_GROUP_ID } from "@/lib/graphql/queries/security-groups";
import type { SecurityGroup } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { SecurityGroupCard } from "@/components/dashboard/security-group-card";
import { format } from "date-fns";
import { useUserRole } from "@/contexts/UserRoleContext";

interface SecurityGroupWithCounts extends SecurityGroup {
  userCount?: number;
  roleCount?: number;
}

export default function SecurityGroupsList() {
  const [groups, setGroups] = useState<SecurityGroupWithCounts[]>([]);
  const [loading, setLoading] = useState(true);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [groupToDelete, setGroupToDelete] = useState<SecurityGroupWithCounts | null>(null);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [view, setView] = useState<"table" | "card">("table");
  const { canAccessCategory } = useUserRole();

  const handleDeleteClick = (group: SecurityGroupWithCounts) => {
    setGroupToDelete(group);
    setDeleteDialogOpen(true);
  };

  const createColumns = (
    canAccessCategory: (category: string, action?: string) => boolean,
    onDelete: (group: SecurityGroupWithCounts) => void): ColumnDef<SecurityGroupWithCounts>[] => [
    {
      id: "select",
      header: ({ table }) => (
        <Checkbox
          checked={
            table.getIsAllPageRowsSelected() ||
            (table.getIsSomePageRowsSelected() && "indeterminate")
          }
          onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
          aria-label="Select all"
        />
      ),
      cell: ({ row }) => (
        <Checkbox
          checked={row.getIsSelected()}
          onCheckedChange={(value) => row.toggleSelected(!!value)}
          aria-label="Select row"
        />
      ),
      enableSorting: false,
      enableHiding: false,
    },
    {
      accessorKey: "name",
      header: "Name",
    },
    {
      accessorKey: "description",
      header: "Description",
    },
    {
      id: "assignments",
      header: "Assignments",
      cell: ({ row }) => {
        const group = row.original;
        return (
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 rounded-full bg-muted px-1 py-0.5 text-xs" title="Users">
              <Users className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium">{group.userCount ?? 0}</span>
            </div>
            <div className="flex items-center gap-2 rounded-full bg-muted px-1 py-0.5 text-xs" title="Roles">
              <UserCog className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium">{group.roleCount ?? 0}</span>
            </div>
            <div className="flex items-center gap-2 rounded-full bg-muted px-1 py-0.5 text-xs" title="Banks">
              <Landmark className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium">0</span>
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "dateModified",
      header: "Last Modified",
      cell: ({ row }) => {
        const date = row.original.dateModified;
        if (!date) return "-";
        try {
          return format(new Date(date), "dd/MM/yyyy");
        } catch {
          return date;
        }
      },
    },
    {
      id: "actions",
      header: "",
      cell: ({ row }) => {
        const group = row.original;
        return (
          <div className="flex items-center gap-2">
            {canAccessCategory("SecurityGroups", "EDIT") && (<Button variant="ghost" size="icon" className="h-8 w-8" asChild>
              <Link to={`/dashboard/security-groups/${group.id}/edit`}>
                <Pencil className="h-4 w-4" />
              </Link>
            </Button>)}
            {canAccessCategory("SecurityGroups", "EDIT") && (<Button variant="ghost" size="icon" className="h-8 w-8" asChild>
              <Link to={`/dashboard/security-groups/${group.id}/clone`}>
                <Copy className="h-4 w-4" />
              </Link>
            </Button>)}
            {canAccessCategory("SecurityGroups", "DELETE") && (<Button
              variant="ghost"
              size="icon"
              disabled={true}
              className="h-8 w-8 text-destructive hover:text-destructive"
              onClick={() => onDelete(group)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
            )}
          </div>
        );
      },
      enableSorting: false,
      enableHiding: false,
    },
  ];

  useEffect(() => {
    if (isMobile !== undefined) {
      setView(isMobile ? "card" : "table");
    }
  }, [isMobile]);

  useEffect(() => {
    loadGroups();
  }, []);

  const loadGroups = async () => {
    try {
      setLoading(true);
      const data = await getSecurityGroups();

      // Load assignment counts for each group
      const groupsWithCounts = await Promise.all(
        data.map(async (group) => {
          try {
            const [usersResponse, rolesResponse] = await Promise.all([
              graphqlRequest<{ getUsersBySecurityGroupId: { id: string }[] }>(
                GET_USERS_BY_SECURITY_GROUP_ID,
                { securityGroupId: group.id }
              ).catch(() => ({ getUsersBySecurityGroupId: [] })),
              graphqlRequest<{ getRoleBySecurityGroupId: { id: string }[] }>(
                GET_ROLES_BY_SECURITY_GROUP_ID,
                { securityGroupId: group.id }
              ).catch(() => ({ getRoleBySecurityGroupId: [] })),
            ]);
            return {
              ...group,
              userCount: usersResponse?.getUsersBySecurityGroupId?.length ?? 0,
              roleCount: rolesResponse?.getRoleBySecurityGroupId?.length ?? 0,
            };
          } catch (error) {
            console.error(`Error loading counts for group ${group.id}:`, error);
            return {
              ...group,
              userCount: 0,
              roleCount: 0,
            };
          }
        })
      );

      setGroups(groupsWithCounts);
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to load security groups",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const columns = createColumns(canAccessCategory, handleDeleteClick);

  const table = useReactTable({
    data: groups,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onRowSelectionChange: setRowSelection,
    onColumnVisibilityChange: setColumnVisibility,
    initialState: {
      pagination: {
        pageSize: 20,
      },
    },
    state: {
      sorting,
      columnFilters,
      rowSelection,
      columnVisibility,
    },
  });

  const handleDelete = async () => {
    if (!groupToDelete) return;

    // TODO: Implement delete functionality
    toast({
      title: "Success",
      description: "Security group deleted successfully",
    });
    setDeleteDialogOpen(false);
    setGroupToDelete(null);
    loadGroups();
  };

  const selectedRows = table.getFilteredSelectedRowModel().rows;
  const selectedCount = selectedRows.length;

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">Loading...</div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <div className="sticky top-0 z-30 pb-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Security Groups</h1>
          <p className="text-sm text-muted-foreground">Manage security groups and their assignments.</p>
        </div>

        <div className="flex items-center py-2 gap-4">
          <div className="relative max-w-sm w-full">
            <Input
              placeholder="Search by Group Name"
              value={(table.getColumn("name")?.getFilterValue() as string) ?? ""}
              onChange={(event) =>
                table.getColumn("name")?.setFilterValue(event.target.value)
              }
              className="pr-8"
            />
            {!!table.getColumn("name")?.getFilterValue() && (
              <button
                onClick={() => table.getColumn("name")?.setFilterValue("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 hover:text-foreground transition-colors"
              >
                <X className="h-4 w-4 text-muted-foreground" />
              </button>
            )}
          </div>

          <div className="ml-auto flex items-center gap-2">
            {canAccessCategory("SecurityGroups", "CREATE") && (<Button asChild>
              <Link to="/dashboard/security-groups/new">
                <Plus className="mr-2 h-4 w-4" />
                Add Group
              </Link>
            </Button>)}
            <div className="hidden sm:flex items-center gap-1 border bg-muted p-1 rounded-md">
              <Button
                variant={view === "table" ? "secondary" : "ghost"}
                size="icon"
                className="h-7 w-7"
                onClick={() => setView("table")}
              >
                <List className="h-4 w-4" />
              </Button>
              <Button
                variant={view === "card" ? "secondary" : "ghost"}
                size="icon"
                className="h-7 w-7"
                onClick={() => setView("card")}
              >
                <LayoutGrid className="h-4 w-4" />
              </Button>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto">
                  Columns <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => {
                    return (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                          column.toggleVisibility(!!value)
                        }
                      >
                        {column.id}
                      </DropdownMenuCheckboxItem>
                    );
                  })}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col min-h-0">
        {view === "table" && !isMobile ? (
          <div className="flex-1 flex flex-col min-h-0 rounded-lg border bg-card shadow-sm overflow-hidden">
            <div className="flex-1 overflow-auto scrollbar-thin">
              <Table className="w-full">
                <TableHeader className="sticky top-0 z-20 bg-card">
                  {table.getHeaderGroups().map((headerGroup) => (
                    <TableRow key={headerGroup.id}>
                      {headerGroup.headers.map((header) => (
                        <TableHead key={header.id} className="bg-card">
                          {header.isPlaceholder
                            ? null
                            : flexRender(
                              header.column.columnDef.header,
                              header.getContext(),
                            )}
                        </TableHead>
                      ))}
                    </TableRow>
                  ))}
                </TableHeader>
                <TableBody>
                  {table.getRowModel().rows?.length ? (
                    table.getRowModel().rows.map((row) => (
                      <TableRow key={row.id}>
                        {row.getVisibleCells().map((cell) => (
                          <TableCell
                            key={cell.id}
                            className={
                              cell.column.id === "description"
                                ? ""
                                : "whitespace-nowrap"
                            }
                          >
                            {flexRender(
                              cell.column.columnDef.cell,
                              cell.getContext(),
                            )}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={columns.length}
                        className="h-24 text-center"
                      >
                        No results.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto scrollbar-thin">
            <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-1">
              {table.getRowModel().rows?.length ? (
                table
                  .getRowModel()
                  .rows.map((row) => (
                    <SecurityGroupCard key={row.original.id} group={row.original} />
                  ))
              ) : (
                <div className="col-span-full text-center py-8 text-muted-foreground">
                  No results.
                </div>
              )}
            </div>
          </div>
        )}

        <div className="sticky bottom-0 z-30 pt-4">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              {selectedCount} of {table.getFilteredRowModel().rows.length} row(s) selected.
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => table.previousPage()}
                disabled={!table.getCanPreviousPage()}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => table.nextPage()}
                disabled={!table.getCanNextPage()}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the security group
              "{groupToDelete?.name}".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
