import { format } from "date-fns";
import { useState, useMemo, useEffect, useCallback, useRef } from "react";
import { useSearchParams, useLocation } from "react-router-dom";
import type {
    ColumnDef,
    ColumnFiltersState,
    SortingState,
    RowSelectionState,
    ColumnSizingState,
} from "@tanstack/react-table";
import {
    flexRender,
    getCoreRowModel,
    getSortedRowModel,
    useReactTable,
} from "@tanstack/react-table";
import { DataTableColumnHeader } from "@/components/ui/data-table-column-header";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
    Filter,
    Info,
    FileDown,
    UserPlus,
    List,
    LayoutGrid,
    ChevronDown,
    Pencil,
    History,
    QrCode,
    File,
    Trash,
    Loader2,
    X,
    Landmark,
    CheckCircle2,
    ShieldQuestion,
    Hourglass,
    UserCheck,
    Clock,
    // HandCoins,
    FileUp
} from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
    searchCasesPaginated,
    getTaskByCaseId,
    getStateSecurityGroups,
} from "@/lib/services/tasks";
import type {
    CollReceipt,
    Task,
    StateSecurityGroup,
    AdvancedFilterParams,
    BankDetail,
} from "@/lib/types";
import { ReceiptManagement } from "@/components/dashboard/ReceiptManagement";
import { AddTaskNotesDialog } from "@/components/dashboard/AddTaskNotesDialog";
import { TaskHistorySheet } from "@/components/history/TaskHistorySheet";
import { useUserRole } from "@/contexts/UserRoleContext";
import { useExport } from "@/contexts/ExportContext";
import { useToast } from "@/hooks/use-toast";
import { cn, downloadBlob } from "@/lib/utils";
import { exportCasesRest, exportBankDepositDetails } from "@/lib/services/export";
import { importExcelRest } from "@/lib/services/importExcel";
import { ExportTasksDialog } from "@/components/Tasks/ExportTasksDialog";
import { BulkAssignTaskSheet } from "@/components/Tasks/BulkAssignTaskSheet";
import { DepositCashSheet } from "@/components/Tasks/DepositCashSheet";
import { AdvanceSearchTasks } from "@/components/Tasks/AdvanceSearchTasks";
import { TaskActionsGuide } from "@/components/Tasks/TaskActionsGuide";
import { getBankDetails } from "@/lib/services/bank-details";
import { useAdvancedSearchTasks } from "@/hooks/Tasks/useAdvancedSearchTasks";
import { useGeoLocation } from "@/hooks/use-location";
import { usePagination } from "@/hooks/use-pagination";
import { Pagination } from "@/components/common/pagination";
import { useDebounce } from "@/hooks/use-debounce";
import { useApproveRejectTasks } from "@/hooks/Tasks/useApproveRejectTasks";
import { ApproveRejectTasks } from "@/components/Tasks/ApproveRejectTasks";
import { ImportDialog } from "@/components/Tasks/ImportDialog";
import acceptanceStatusTabs from "@/constants/AcceptanceStatusTabs";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type TabValue =
    | "Case Pending"
    | "Pending"
    | "Acceptance Pending"
    | "Branch Ops In Hand"
    | "Verification Pending"
    | "Verification Completed"
    | "Verified By HO";

interface TabCounts {
    casePendingCount: number;
    pending: number;
    acceptancePending: number;
    branchOpsInHand: number;
    verificationPending: number;
    verificationCompleted: number;
    verifiedByHo: number;
}

// ---------------------------------------------------------------------------
// Pure helpers (defined outside component to avoid re-creation on each render)
// ---------------------------------------------------------------------------

const getDpdBorderClasses = (dpd: number): string => {
    if (dpd <= 30) return "border-l-4 border-l-green-500  border-t border-r border-b border-t-green-200  border-r-green-200  border-b-green-200";
    if (dpd <= 90) return "border-l-4 border-l-yellow-500 border-t border-r border-b border-t-yellow-200 border-r-yellow-200 border-b-yellow-200";
    return "border-l-4 border-l-red-500    border-t border-r border-b border-t-red-200    border-r-red-200    border-b-red-200";
};

const getDpdTextClass = (dpd: number): string => {
    if (dpd <= 30) return "text-green-600";
    if (dpd <= 90) return "text-yellow-600";
    return "text-red-600";
};

/** Custom sort that always puts "n/a" / empty strings at the bottom. */
const naLastStringSortFn = (
    rowA: { getValue: (id: string) => unknown },
    rowB: { getValue: (id: string) => unknown },
    columnId: string
): number => {
    const a = String(rowA.getValue(columnId) ?? "").toLowerCase();
    const b = String(rowB.getValue(columnId) ?? "").toLowerCase();
    if (a === "n/a" || a === "") return 1;
    if (b === "n/a" || b === "") return -1;
    return a.localeCompare(b);
};

const COLUMN_DISPLAY_NAMES: Record<string, string> = {
    taskNumber: "Case Number",
    receiptNo: "Receipt Id",
    paymentMode: "Payment Mode",
    transactionRefNo: "Transaction Id",
    lan: "Lan Number",
    branch: "Branch",
    product: "Product",
    emiOverdue: "Emi Overdue",
    receivedAmount: "Amount Paid",
    dpd: "Dpd",
    status: "Status",
    disposition: "Disposition",
    lastModified: "Date Modified",
    activityDate: "Activity Date",
    actions: "Actions",
    activityBy: "Activity By",
};

// ---------------------------------------------------------------------------
// Column definition factory
// ---------------------------------------------------------------------------

const buildColumns = (
    onEditReceipt: (task: Task) => void,
    onViewHistory: (task: Task) => void,
    canAccessCategory: (category: string, action?: string) => boolean,
    activeTab: TabValue
): ColumnDef<Task>[] => [
        {
            id: "select",
            header: ({ table }) => (
                <Checkbox
                    checked={
                        table.getIsAllPageRowsSelected() ||
                        (table.getIsSomePageRowsSelected() && "indeterminate")
                    }
                    onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                    aria-label="Select all"
                />
            ),
            cell: ({ row }) => (
                <Checkbox
                    checked={row.getIsSelected()}
                    onCheckedChange={(value) => row.toggleSelected(!!value)}
                    aria-label="Select row"
                />
            ),
            enableSorting: false,
            enableHiding: false,
            size: 50,
            minSize: 50,
            maxSize: 50,
        },
        {
            accessorKey: "lan",
            header: ({ column }) => <DataTableColumnHeader column={column} title="LAN" />,
            cell: ({ row }) => <span>{row.getValue("lan")}</span>,
            sortingFn: naLastStringSortFn,
            size: 90, minSize: 80, maxSize: 110,
        },
        {
            accessorKey: "branch",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Branch" />,
            cell: ({ row }) => <span>{row.getValue("branch")}</span>,
            sortingFn: naLastStringSortFn,
            size: 100, minSize: 90, maxSize: 120,
        },
        {
            accessorKey: "receiptNo",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Receipt No." />,
            cell: ({ row }) => (
                <span className={cn("font-medium", getDpdTextClass(row.original.dpd))}>
                    {row.getValue("receiptNo")}
                </span>
            ),
            sortingFn: naLastStringSortFn,
            size: 100, minSize: 90, maxSize: 120,
        },
        {
            accessorKey: "agentName",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Agent Name" />,
            cell: ({ row }) => <span>{row.getValue("agentName")}</span>,
            sortingFn: naLastStringSortFn,
            size: 100, minSize: 90, maxSize: 120,
        },
        {
            accessorKey: "customerName",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Customer Name" />,
            cell: ({ row }) => <span>{row.getValue("customerName")}</span>,
            sortingFn: naLastStringSortFn,
            size: 100, minSize: 90, maxSize: 120,
        },
        {
            accessorKey: "lastModified",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Last Modified" />,
            cell: ({ row }) => <span>{String(row.getValue("lastModified") ?? "").replace(/\s+/g, "")}</span>,
            sortingFn: (rowA, rowB, columnId) => {
                const a = String(rowA.getValue(columnId) ?? "");
                const b = String(rowB.getValue(columnId) ?? "");
                if (a === "N/A" || a === "") return 1;
                if (b === "N/A" || b === "") return -1;
                const toMs = (s: string) => {
                    const [d, m, y] = s.split("/").map(Number);
                    return new Date(y, m - 1, d).getTime();
                };
                return toMs(a) - toMs(b);
            },
            size: 110, minSize: 100, maxSize: 130,
        },
        {
            accessorKey: "activityDate",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Activity Date" />,
            cell: ({ row }) => <span>{String(row.getValue("activityDate") ?? "").replace(/\s+/g, "")}</span>,
            sortingFn: (rowA, rowB, columnId) => {
                const a = String(rowA.getValue(columnId) ?? "");
                const b = String(rowB.getValue(columnId) ?? "");
                if (a === "N/A" || a === "") return 1;
                if (b === "N/A" || b === "") return -1;
                const toMs = (s: string) => {
                    const [d, m, y] = s.split("/").map(Number);
                    return new Date(y, m - 1, d).getTime();
                };
                return toMs(a) - toMs(b);
            },
            size: 110, minSize: 100, maxSize: 130,
        },
        {
            accessorKey: "activityBy",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Activity By" />,
            cell: ({ row }) => <span>{row.getValue("activityBy")}</span>,
            sortingFn: naLastStringSortFn,
            size: 110, minSize: 100, maxSize: 130,
        },
        {
            accessorKey: "paymentMode",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Payment Mode" />,
            cell: ({ row }) => (
                <span className="text-muted-foreground">{row.getValue("paymentMode")}</span>
            ),
            sortingFn: naLastStringSortFn,
            size: 110, minSize: 100, maxSize: 130,
        },
        {
            accessorKey: "transactionRefNo",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Transaction Ref No" />,
            cell: ({ row }) => (
                <span className="text-muted-foreground">{row.getValue("transactionRefNo")}</span>
            ),
            sortingFn: naLastStringSortFn,
            size: 140, minSize: 130, maxSize: 160,
        },
        {
            accessorKey: "emiOverdue",
            header: ({ column }) => <DataTableColumnHeader column={column} title="EMI Overdue" />,
            cell: ({ row }) => (
                <span>₹{(row.getValue("emiOverdue") as number).toLocaleString("en-IN")}</span>
            ),
            size: 110, minSize: 100, maxSize: 130,
        },
        {
            accessorKey: "receivedAmount",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Received Amount" />,
            cell: ({ row }) => (
                <span>₹{(row.getValue("receivedAmount") as number).toLocaleString("en-IN")}</span>
            ),
            sortingFn: (rowA, rowB, columnId) => {
                const parse = (v: unknown) =>
                    parseFloat(String(v ?? "").replace(/[₹,]/g, "")) || 0;
                const a = String(rowA.getValue(columnId) ?? "");
                const b = String(rowB.getValue(columnId) ?? "");
                if (a === "N/A" || a === "") return 1;
                if (b === "N/A" || b === "") return -1;
                return parse(a) - parse(b);
            },
            size: 120, minSize: 110, maxSize: 140,
        },
        {
            accessorKey: "dpd",
            header: ({ column }) => <DataTableColumnHeader column={column} title="DPD" />,
            cell: ({ row }) => <span>{row.getValue("dpd") as number}</span>,
            size: 70, minSize: 60, maxSize: 90,
        },
        {
            accessorKey: "status",
            header: ({ column }) => <DataTableColumnHeader column={column} title="Status" />,
            cell: ({ row }) => (
                <Badge variant="secondary" className="bg-gray-100 text-gray-800 font-semibold">
                    {row.getValue("status") as string}
                </Badge>
            ),
            sortingFn: naLastStringSortFn,
            size: 130, minSize: 120, maxSize: 150,
        },
        {
            id: "actions",
            header: "Actions",
            cell: ({ row }) => {
                const task = row.original;
                const hasReceipt =
                    !!task.receipt?.receiptNo && task.receiptNo !== "N/A";
                const canEdit = hasReceipt && canAccessCategory("ReceiptActions", "EDIT");
                return (
                    <div className="flex items-center justify-start gap-0">
                        {activeTab !== acceptanceStatusTabs.CASE_PENDING && activeTab !== acceptanceStatusTabs.VERIFIED_BY_HO && canAccessCategory("ReceiptActions", "EDIT") && (
                            <Button
                                variant="ghost"
                                className="h-10 w-10 p-0 [&_svg]:!h-5 [&_svg]:!w-5"
                                onClick={() => onEditReceipt(task)}
                                disabled={!canEdit}
                                title={
                                    !canEdit
                                        ? "Insufficient permissions"
                                        : !hasReceipt
                                            ? "No receipt available"
                                            : "Edit receipt"
                                }
                            >
                                <Pencil className="h-6 w-6 text-muted-foreground" />
                            </Button>
                        )}
                        <Button
                            variant="ghost"
                            className="h-10 w-10 p-0 [&_svg]:!h-5 [&_svg]:!w-5"
                            onClick={() => onViewHistory(task)}
                            title="View task history"
                        >
                            <History className="h-6 w-6" />
                        </Button>
                    </div>
                );
            },
            size: 140, minSize: 130, maxSize: 150,
        },
    ];

// ---------------------------------------------------------------------------
// Tab config (static — no counts yet, counts are injected in component)
// ---------------------------------------------------------------------------

const TAB_CONFIG: { value: TabValue; label: string; icon: React.ElementType }[] = [
    { value: "Case Pending", label: "Open", icon: Clock },
    { value: "Pending", label: "In-Hand Agents", icon: UserCheck },
    { value: "Acceptance Pending", label: "Acceptance Pending", icon: Hourglass },
    { value: "Branch Ops In Hand", label: "In-Hand Branch", icon: Landmark },
    { value: "Verification Pending", label: "Verification Pending", icon: ShieldQuestion },
    { value: "Verification Completed", label: "Verification Completed", icon: CheckCircle2 },
    { value: "Verified By HO", label: "Verified By HO", icon: CheckCircle2 },
];

const TAB_PERMISSIONS: Record<TabValue, string> = {
    "Case Pending": "",
    "Pending": "InHandAgents",
    "Acceptance Pending": "AcceptancePending",
    "Branch Ops In Hand": "InHandBranch",
    "Verification Pending": "VerificationPending",
    "Verification Completed": "VerificationCompleted",
    "Verified By HO": "VerifiedByHO",
};


// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export default function TasksList() {
    // ── Hooks ─────────────────────────────────────────────────────────────────
    const { canAccessCategory } = useUserRole();
    const { toast } = useToast();
    const { withLocation } = useGeoLocation();
    // ── Data state ────────────────────────────────────────────────────────────
    const [tasks, setTasks] = useState<Task[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [states, setStates] = useState<StateSecurityGroup[]>([]);
    const [bankDetails, setBankDetails] = useState<BankDetail[]>([]);
    const [counts, setCounts] = useState<TabCounts>({
        casePendingCount: 0,
        pending: 0,
        acceptancePending: 0,
        branchOpsInHand: 0,
        verificationPending: 0,
        verificationCompleted: 0,
        verifiedByHo: 0,
    });

    // ── URL params ────────────────────────────────────────────────────────────
    const [searchParams] = useSearchParams();
    const location = useLocation();

    // ── Table / filter state (Moved down so location is available) ─────────────
    const [sorting, setSorting] = useState<SortingState>([]);
    const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
    const [columnSizing, setColumnSizing] = useState<ColumnSizingState>({});
    const [globalFilter, setGlobalFilter] = useState(() => {
        if (location.state?.receiptNo) return location.state.receiptNo;
        if (location.state?.lan) return location.state.lan;
        return "";
    });
    const debouncedFilter = useDebounce(globalFilter, 500);

    // ── Tab / acceptance filter ───────────────────────────────────────────────
    const filteredTabs = useMemo(() => {
        return TAB_CONFIG.filter((tab) => {
            const permission = TAB_PERMISSIONS[tab.value];
            if (tab.value === "Case Pending") return true;
            return canAccessCategory(permission);
        });
    }, [canAccessCategory]);

    const [activeTab, setActiveTab] = useState<TabValue>(() => {
        if (location.state?.tab) return location.state.tab;
        return filteredTabs[0]?.value || null;
    });

    const [acceptanceStatusFilter, setAcceptanceStatusFilter] = useState<string | undefined>(() => {
        if (location.state?.tab) return location.state.tab;
        return filteredTabs[0]?.value || undefined;
    });

    // ── View ──────────────────────────────────────────────────────────────────
    const [view, setView] = useState<"table" | "card">(() => {
        return "table";
    });

    // Automatic view switching based on screen width
    useEffect(() => {
        const mql = window.matchMedia("(max-width: 1024px)");
        const handleViewChange = (e: MediaQueryListEvent | MediaQueryList) => {
            setView(e.matches ? "card" : "table");
        };

        // Initial check
        handleViewChange(mql);

        mql.addEventListener("change", handleViewChange);
        return () => mql.removeEventListener("change", handleViewChange);
    }, []);

    // rowSelection for TanStack is derived from it, never stored separately.
    const [selectedTasksMap, setSelectedTasksMap] = useState<Record<string, Task>>({});

    // Derived from selectedTasksMap — passed to TanStack table as controlled state
    const rowSelection = useMemo<RowSelectionState>(
        () => Object.fromEntries(Object.keys(selectedTasksMap).map((id) => [id, true])),
        [selectedTasksMap]
    );

    // ── Dialogs / sheet state ─────────────────────────────────────────────────
    const [selectedReceipt, setSelectedReceipt] = useState<CollReceipt | null>(null);
    const [receiptManagementMode, setReceiptManagementMode] = useState<"edit" | "delete">("edit");
    const [isReceiptManagementOpen, setIsReceiptManagementOpen] = useState(false);

    const [isHistorySheetOpen, setIsHistorySheetOpen] = useState(false);
    const [selectedTaskForHistory, setSelectedTaskForHistory] = useState<Task | null>(null);
    const [shouldOpenHistoryFromState, setShouldOpenHistoryFromState] = useState(() => !!location.state?.openHistory);

    const [isNotesDialogOpen, setIsNotesDialogOpen] = useState(false);
    const [isSingleAssignDialogOpen, setIsSingleAssignDialogOpen] = useState(false);
    const [isFilterBlinking, setIsFilterBlinking] = useState(false);
    const [isDepositDialogOpen, setIsDepositDialogOpen] = useState(false);
    const [isGuideOpen, setIsGuideOpen] = useState(false);
    const { isExporting, setIsExporting } = useExport();

    // ── Highlight (notification deep-link) ───────────────────────────────────
    const [highlightedTaskId, setHighlightedTaskId] = useState<string | null>(null);
    const hasInitialized = useRef(false);
    const highlightedRowRef = useRef<HTMLTableRowElement>(null);
    const isInitialNavWithCompletedTab = useRef(location.state?.tab === "Verification Completed");

    // ── URL params ────────────────────────────────────────────────────────────
    const caseIdParam = useMemo(
        () => searchParams.get("caseId")?.trim() ?? "",
        [searchParams]
    );

    const {
        pageIndex,
        setPageIndex,
        pageSize,
        totalRecords,
        totalPages,
        hasNext,
        hasPrevious,
        updatePagination,
    } = usePagination(20);

    const advancedSearch = useAdvancedSearchTasks({ states, pageIndex, pageSize });

    const approveReject = useApproveRejectTasks({
        onSuccess: () => {
            clearSelection();
            loadTasks();
        },
    });


    // ── Derived selection values ──────────────────────────────────────────────
    const selectedTasksList = useMemo(
        () => Object.values(selectedTasksMap),
        [selectedTasksMap]
    );
    const selectionCount = selectedTasksList.length;

    /** The single selected task (only non-null when exactly one is selected). */
    const selectedTask = useMemo(
        () => (selectionCount === 1 ? selectedTasksList[0] : null),
        [selectionCount, selectedTasksList]
    );

    const showReceiptActions = selectionCount > 0;

    const canActOnSelection =
        selectionCount === 1 &&
        !!selectedTask?.receipt?.receiptNo &&
        selectedTask.receiptNo !== "N/A";

    // ── Selection handlers ────────────────────────────────────────────────────

    /** Toggle a single task in/out of the selection map. */
    const toggleTaskSelection = useCallback((task: Task, selected: boolean) => {
        setSelectedTasksMap((prev) => {
            if (selected) return { ...prev, [task.id]: task };
            const next = { ...prev };
            delete next[task.id];
            return next;
        });
    }, []);

    /** Replace the entire selection (used by TanStack "select all" and pagination clear). */
    const replaceSelection = useCallback(
        (updaterOrValue: RowSelectionState | ((prev: RowSelectionState) => RowSelectionState)) => {
            // TanStack calls onRowSelectionChange with either a value or an updater fn.
            // We intercept it here and sync our selectedTasksMap.
            setSelectedTasksMap((prevMap) => {
                const prevRowSelection = Object.fromEntries(
                    Object.keys(prevMap).map((id) => [id, true])
                );
                const nextRowSelection =
                    typeof updaterOrValue === "function"
                        ? updaterOrValue(prevRowSelection)
                        : updaterOrValue;

                const nextMap: Record<string, Task> = {};
                // Keep tasks that are still selected (preserve cross-page selections)
                Object.entries(nextRowSelection).forEach(([id, isSelected]) => {
                    if (isSelected) {
                        // Try to resolve from existing map first, then from current page tasks
                        nextMap[id] = prevMap[id] ?? tasks.find((t) => t.id === id)!;
                    }
                });
                return nextMap;
            });
        },
        [tasks]
    );

    const clearSelection = useCallback(() => setSelectedTasksMap({}), []);



    // ── Data fetching ─────────────────────────────────────────────────────────

    useEffect(() => {
        if (hasInitialized.current) return;

        const init = async () => {
            try {
                const [fetchedStates, fetchedBanks] = await Promise.all([
                    getStateSecurityGroups(),
                    getBankDetails(),
                ]);
                setStates(fetchedStates);
                setBankDetails(fetchedBanks);
                hasInitialized.current = true;
            } catch (err) {
                console.error("Error fetching initial data:", err);
            }
        };
        init();
    }, []);

    /** Reset page to 0 when the debounced search query changes. */
    useEffect(() => {
        setPageIndex(0);
    }, [debouncedFilter, setPageIndex]);

    /** Reset pagination when advanced filters change. */
    useEffect(() => {
        setPageIndex(0);
        clearSelection();
    }, [advancedSearch.isFilterApplied, setPageIndex,clearSelection]);

    /** Standard paginated load (no advanced filters, no caseId). */
    async function loadTasks() {
        if (advancedSearch.isFilterApplied || caseIdParam) return;
        try {
            setLoading(true);
            setError(null);
            const response = await searchCasesPaginated({
                limit: pageSize,
                offset: pageIndex * pageSize,
                query: debouncedFilter,
                acceptanceStatus: acceptanceStatusFilter,
            });
            setTasks(response.tasks);
            updatePagination({
                totalRecords: response.totalRecords,
                totalPages: response.totalPages,
                hasNext: response.hasNext,
                hasPrevious: response.hasPrevious,
            });
            setCounts({
                casePendingCount: response.casePendingCount ?? 0,
                pending: response.pendingCount ?? 0,
                acceptancePending: response.acceptancePendingCount ?? 0,
                branchOpsInHand: response.branchOpsInHandCount ?? 0,
                verificationPending: response.verificationPendingCount ?? 0,
                verificationCompleted: response.verificationCompletedCount ?? 0,
                verifiedByHo: response.verifiedByHOCount ?? 0,
            });
        } catch (err) {
            const msg = err instanceof Error ? err.message : "Failed to load tasks";
            if (!msg.includes("401") && !msg.includes("403")) {
                toast({ title: "Error", description: msg, variant: "destructive" });
            }
            setError(msg);
            setTasks([]);
        } finally {
            setLoading(false);
        }
    }

    // Wrap in useCallback so we can pass it as a stable dep elsewhere
    const loadTasksCb = useCallback(loadTasks, [
        pageIndex,
        pageSize,
        debouncedFilter,
        acceptanceStatusFilter,
        advancedSearch.isFilterApplied,
        caseIdParam,
        toast,
        updatePagination,
    ]);

    useEffect(() => {
        loadTasksCb();
    }, [loadTasksCb]);

    /** Load with advanced filters applied. */
    const loadAdvancedFilterTasks = useCallback(async () => {
        if (!advancedSearch.isFilterApplied) return;
        try {
            setLoading(true);
            setError(null);
            const f = advancedSearch.appliedFilters;
            const response = await searchCasesPaginated({
                limit: pageSize,
                offset: pageIndex * pageSize,
                query: debouncedFilter,
                acceptanceStatus: acceptanceStatusFilter,
                lanNumber: f.lan,
                receiptNo: f.receipt,
                branchName: f.branch,
                agentName: f.agent,
                status: f.status,
                fromDate: f.dateRange.from
                    ? format(f.dateRange.from, "yyyy-MM-dd")
                    : undefined,
                toDate: f.dateRange.to
                    ? format(f.dateRange.to, "yyyy-MM-dd")
                    : undefined,
                dateType: f.dateType,
                dpdFrom: f.dpdFrom,
                dpdTo: f.dpdTo,
                state: f.state,
            });
            setTasks(response.tasks);
            setCounts({
                casePendingCount: response.casePendingCount ?? 0,
                pending: response.pendingCount ?? 0,
                acceptancePending: response.acceptancePendingCount ?? 0,
                branchOpsInHand: response.branchOpsInHandCount ?? 0,
                verificationPending: response.verificationPendingCount ?? 0,
                verificationCompleted: response.verificationCompletedCount ?? 0,
                verifiedByHo: response.verifiedByHOCount ?? 0,
            });
            updatePagination({
                totalRecords: response.totalRecords,
                totalPages: response.totalPages,
                hasNext: response.hasNext,
                hasPrevious: response.hasPrevious,
            });
        } catch (err) {
            const msg = err instanceof Error ? err.message : "Failed to load tasks";
            if (!msg.includes("401") && !msg.includes("403")) {
                toast({ title: "Error", description: msg, variant: "destructive" });
            }
            setError(msg);
            setTasks([]);
        } finally {
            setLoading(false);
        }
    }, [
        pageIndex,
        pageSize,
        debouncedFilter,
        acceptanceStatusFilter,
        advancedSearch.isFilterApplied,
        advancedSearch.appliedFilters,
        toast,
        updatePagination,
    ]);

    useEffect(() => {
        loadAdvancedFilterTasks();
    }, [loadAdvancedFilterTasks]);

    /** Auto-switch from "Verification Completed" to "Verified By HO" if empty on initial navigation */
    useEffect(() => {
        if (!loading && activeTab === acceptanceStatusTabs.VERIFICATION_COMPLETED && tasks.length === 0 && counts.verifiedByHo > 0 && isInitialNavWithCompletedTab.current) {
            isInitialNavWithCompletedTab.current = false;
            handleTabChange("Verified By HO");
        }
    }, [loading, activeTab, tasks, counts.verifiedByHo]);

    /** Load a single task when navigating via a notification deep-link. */
    useEffect(() => {
        if (!caseIdParam) return;
        const fetch = async () => {
            setLoading(true);
            setError(null);
            try {
                const task = await getTaskByCaseId(caseIdParam);
                setTasks(task ? [task] : []);
            } catch (err) {
                setError(err instanceof Error ? err.message : "Failed to fetch task");
                setTasks([]);
            } finally {
                setLoading(false);
            }
        };
        fetch();
    }, [caseIdParam]);

    /** Clear navigation state on mount */
    useEffect(() => {
        if (location.state?.lan || location.state?.tab || location.state?.receiptNo || location.state?.openHistory) {
            window.history.replaceState({}, document.title);
        }
    }, []);

    /** Highlight + auto-select the task matching URL params after tasks load. */
    useEffect(() => {
        if (tasks.length === 0 || !caseIdParam) return;

        const match = tasks.find((t) => t.id === caseIdParam);
        if (!match) return;

        setHighlightedTaskId(match.id);
        toggleTaskSelection(match, true);

        const scrollTimer = setTimeout(() => {
            highlightedRowRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
        }, 100);

        const clearTimer = setTimeout(() => setHighlightedTaskId(null), 5000);

        return () => {
            clearTimeout(scrollTimer);
            clearTimeout(clearTimer);
        };
    }, [caseIdParam, tasks, toggleTaskSelection]);

    // ── Action handlers ───────────────────────────────────────────────────────

    const openReceiptManagement = useCallback(
        (task: Task, mode: "edit" | "delete") => {
            if (!task.receipt?.receiptNo || task.receiptNo === "N/A") {
                toast({
                    title: "Receipt Unavailable",
                    description: "No receipt details are available for this task.",
                    variant: "destructive",
                });
                return;
            }
            setSelectedReceipt(task.receipt);
            setReceiptManagementMode(mode);
            setIsReceiptManagementOpen(true);
        },
        [toast]
    );

    const handleEditReceipt = useCallback(
        (task: Task) => openReceiptManagement(task, "edit"),
        [openReceiptManagement]
    );

    const handleReverseReceipt = useCallback(
        (task: Task) => openReceiptManagement(task, "delete"),
        [openReceiptManagement]
    );

    const handleReceiptManagementClose = useCallback(() => {
        setIsReceiptManagementOpen(false);
        setSelectedReceipt(null);
        setReceiptManagementMode("edit");
    }, []);

    const handleViewHistory = useCallback((task: Task) => {
        setSelectedTaskForHistory(task);
        setIsHistorySheetOpen(true);
    }, []);

    /** Auto-open history sheet if navigated from VerifyDepositsList */
    useEffect(() => {
        if (shouldOpenHistoryFromState && tasks.length > 0 && !isHistorySheetOpen) {
            const targetLan = location.state?.lan;
            if (targetLan) {
                const taskToShow = tasks.find(t => t.lan === targetLan);
                if (taskToShow) {
                    handleViewHistory(taskToShow);
                    setShouldOpenHistoryFromState(false);
                }
            } else {
                setShouldOpenHistoryFromState(false);
            }
        }
    }, [tasks, shouldOpenHistoryFromState, isHistorySheetOpen, handleViewHistory, location.state?.lan]);

    const handleAssignSuccess = useCallback(() => {
        clearSelection();
        if (advancedSearch.isFilterApplied) {
            loadAdvancedFilterTasks();
        } else {
            loadTasksCb();
        }
    }, [clearSelection, loadTasksCb, loadAdvancedFilterTasks, advancedSearch.isFilterApplied]);

    const handleDepositSuccess = useCallback(() => {
        clearSelection();
        loadTasksCb();
    }, [clearSelection, loadTasksCb]);

    // ── Export ────────────────────────────────────────────────────────────────

    const [isExportDialogOpen, setIsExportDialogOpen] = useState(false);
    const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
    const [isImporting, setIsImporting] = useState(false);

    const handleConfirmImport = async (file: File) => {
        setIsImportDialogOpen(false);
        setIsImporting(true);
        toast({
            title: "In Progress",
            description: "Importing...",
        });
        try {
            const message = await importExcelRest(file);
            toast({
                title: "Import Successful",
                description: message || "LMS Data imported successfully.",
            });
            loadTasksCb(); // Refresh the list if needed
        } catch (err) {
            toast({
                title: "Import Failed",
                description: err instanceof Error ? err.message : "Failed to import LMS data.",
                variant: "destructive",
            });
        } finally {
            setIsImporting(false);
        }
    };

    const handleConfirmExport = async (option: "current" | "all" | "bankDepositDetails") => {
        setIsExportDialogOpen(false);
        setIsExporting(true);
        toast({
            title: "In Progress",
            description: "Exporting...",
        });
        try {
            const af = advancedSearch.appliedFilters;
            let blob: Blob;
            let filename: string;

            if (option === "bankDepositDetails") {
                blob = await exportBankDepositDetails();
                filename = `bank_deposit_details_${format(new Date(), "yyyy-MM-dd_HH-mm-ss")}.xlsx`;
            } else {
                const exportAllTabs = option === "all";
                const payload = {
                    clientType: "WEB" as const,
                    lanNumber: af.lan,
                    receiptNo: af.receipt,
                    branchName: af.branch,
                    agentName: af.agent,
                    status: af.status,
                    fromDate: af.dateRange.from ? format(af.dateRange.from, "yyyy-MM-dd") : undefined,
                    toDate: af.dateRange.to ? format(af.dateRange.to, "yyyy-MM-dd") : undefined,
                    dateType: af.dateType,
                    dpdFrom: af.dpdFrom,
                    dpdTo: af.dpdTo,
                    state: af.state,
                    query: debouncedFilter,
                    acceptanceStatus: exportAllTabs ? undefined : acceptanceStatusFilter,
                };
                blob = await exportCasesRest(payload);
                filename = `tasks_export_${format(new Date(), "yyyy-MM-dd_HH-mm-ss")}.csv`;
            }

            downloadBlob(blob, filename);
            toast({
                title: "Export Successful",
                description: "Tasks exported successfully.",
            });
            setIsExportDialogOpen(false);
        } catch (err) {
            toast({
                title: "Export Failed",
                description: err instanceof Error ? err.message : "Failed to export tasks.",
                variant: "destructive",
            });
        } finally {
            setIsExporting(false);
        }
    };

    // ── Filter chip helpers ───────────────────────────────────────────────────

    const removeAppliedFilter = (type: string) => {
        const update: Partial<AdvancedFilterParams> = {};
        switch (type) {
            case "dateRange": update.dateRange = {}; break;
            case "state": update.state = ""; break;
            case "branch": update.branch = ""; break;
            case "agent": update.agent = ""; break;
            case "status": update.status = ""; break;
            case "disposition": update.disposition = ""; break;
            case "emiPendingBucket":
                update.emiPendingBucket = "";
                update.dpdFrom = undefined;
                update.dpdTo = undefined;
                break;
            case "lan": update.lan = ""; break;
            case "receipt": update.receipt = ""; break;
            default: return;
        }
        advancedSearch.updateFilter(update);
        advancedSearch.setAppliedFilters((prev: AdvancedFilterParams) => ({ ...prev, ...update }));
    };

    const appliedFilterChips = useMemo(() => {
        const chips: { label: string; value: string; type: string }[] = [];
        const af = advancedSearch.appliedFilters;
        const dateLabel = advancedSearch.formatDateRangeLabel(af.dateRange);
        const dateTypeLabel = af.dateType === "ACTIVITY_DATE" ? "Activity Date" : "Date Modified";

        if (dateLabel) chips.push({ label: dateTypeLabel, value: dateLabel, type: "dateRange" });
        if (af.state && af.state !== "all") chips.push({ label: "State", value: af.state, type: "state" });
        if (af.branch && af.branch !== "all") chips.push({ label: "Branch", value: af.branch, type: "branch" });
        if (af.agent && af.agent !== "all") chips.push({ label: "Agent", value: af.agent, type: "agent" });
        if (af.status && af.status !== "all") chips.push({ label: "Status", value: af.status.replace(/_/g, " "), type: "status" });
        if (af.disposition && af.disposition !== "all") chips.push({ label: "Disposition", value: af.disposition, type: "disposition" });
        if (af.emiPendingBucket && af.emiPendingBucket !== "all") {
            const bucket = advancedSearch.emiPendings.find(
                (b) => b.bucketCode === af.emiPendingBucket || b.id === af.emiPendingBucket
            );
            chips.push({ label: "EMI Pending Bucket", value: bucket?.bucketCode ?? af.emiPendingBucket, type: "emiPendingBucket" });
        }
        if (af.lan.trim()) chips.push({ label: "LAN", value: af.lan.trim(), type: "lan" });
        if (af.receipt.trim()) chips.push({ label: "Receipt", value: af.receipt.trim(), type: "receipt" });

        return chips;
    }, [advancedSearch.appliedFilters, advancedSearch.emiPendings, advancedSearch.formatDateRangeLabel]);

    // ── Columns (memoised; recreated only when callbacks / permissions change) ─
    const columns = useMemo(
        () => buildColumns(handleEditReceipt, handleViewHistory, canAccessCategory, activeTab),
        [handleEditReceipt, handleViewHistory, canAccessCategory, activeTab]
    );

    // ── Column Visibility ─────────────────────────────────────────────────────
    const [columnVisibility, setColumnVisibility] = useState<Record<string, boolean>>({
       lastModified: false,
    });

    // Reactive visibility: hide receipt columns when acceptanceStatusFilter is "Case Pending"
    useEffect(() => {
        if (acceptanceStatusFilter === "Case Pending") {
            setColumnVisibility((prev) => ({
                ...prev,
                receiptNo: false,
                paymentMode: false,
                transactionRefNo: false,
                receivedAmount: false,
            }));
        } else {
            setColumnVisibility((prev) => ({
                ...prev,
                receiptNo: true,
                paymentMode: true,
                transactionRefNo: true,
                receivedAmount: true,
            }));
        }
    }, [acceptanceStatusFilter]);

    // ── TanStack table ────────────────────────────────────────────────────────
    const table = useReactTable({
        data: tasks,
        columns,
        getRowId: (row) => row.id,
        state: {
            sorting,
            columnFilters,
            rowSelection,          // controlled — derived from selectedTasksMap
            globalFilter,
            columnSizing,
            columnVisibility,
            pagination: { pageIndex, pageSize },
        },
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        onRowSelectionChange: replaceSelection,   // ← our unified handler
        onGlobalFilterChange: setGlobalFilter,
        onColumnSizingChange: setColumnSizing,
        onColumnVisibilityChange: setColumnVisibility,
        onPaginationChange: (updater) => {
            if (typeof updater === "function") {
                const next = updater({ pageIndex, pageSize });
                setPageIndex(next.pageIndex);
            }
        },
        getCoreRowModel: getCoreRowModel(),
        getSortedRowModel: getSortedRowModel(),
        enableRowSelection: true,
        enableColumnResizing: true,
        columnResizeMode: "onChange",
        enableMultiSort: true,
        enableGlobalFilter: true,
        manualFiltering: true,
        manualPagination: true,
        pageCount: totalPages,
    });

    // ── Skeleton renderer ─────────────────────────────────────────────────────
    const renderTableSkeleton = (rowCount: number) =>
        Array.from({ length: rowCount }).map((_, i) => (
            <TableRow key={`skeleton-${i}`}>
                {table.getVisibleLeafColumns().map((col) => (
                    <TableCell
                        key={col.id}
                        style={{ width: col.getSize() }}
                        className={cn(
                            "whitespace-nowrap",
                            col.id === "actions" && "sticky right-0 z-10 bg-card shadow-[-4px_0_4px_-2px_rgba(0,0,0,0.1)]"
                        )}
                    >
                        <div
                            className={cn(
                                "h-4 rounded bg-muted animate-pulse",
                                col.id === "select" ? "w-6" : "w-24"
                            )}
                        />
                    </TableCell>
                ))}
            </TableRow>
        ));

    // ── Tab change helper ─────────────────────────────────────────────────────
    const handleTabChange = (value: TabValue) => {
        setActiveTab(value);
        setAcceptanceStatusFilter(value);
        setPageIndex(0);
        clearSelection();
    };

    const handleTabClear = () => {
        const defaultTab = filteredTabs[0]?.value || "Case Pending";
        setActiveTab(defaultTab);
        setAcceptanceStatusFilter(defaultTab);
    };

    // // ── AcceptReject guard ────────────────────────────────────────────────────
    // const handleAcceptRejectClick = () => {
    //     withLocation(() => {
    //         const tasksWithReceipts = selectedTasksList.filter((t) => t.receipt?.id);

    //         if (selectedTasksList.length === 0) {
    //             toast({
    //                 title: "No Tasks Selected",
    //                 description: "Please select at least one task to approve or reject.",
    //                 variant: "destructive",
    //             });
    //             return;
    //         }
    //         if (tasksWithReceipts.length === 0) {
    //             toast({
    //                 title: "No Valid Receipts",
    //                 description: "None of the selected tasks have a valid receipt.",
    //                 variant: "destructive",
    //             });
    //             return;
    //         }
    //         if (tasksWithReceipts.length < selectedTasksList.length) {
    //             toast({
    //                 title: "Some Tasks Skipped",
    //                 description: `${selectedTasksList.length - tasksWithReceipts.length} task(s) without receipts were skipped.`,
    //                 variant: "warning",
    //             });
    //         }
    //         approveReject.openApproveReject(tasksWithReceipts.map((t) => t.receipt!.id));
    //     });
    // };

    // ── Assign guard ──────────────────────────────────────────────────────────
    const canAssignTask = useMemo(() => {
        return !!advancedSearch.appliedFilters.branch && advancedSearch.appliedFilters.branch !== "all";
    }, [advancedSearch.appliedFilters.branch]);

    const handleAssignClick = () => {
        withLocation(() => {
            if (!canAssignTask) {
                toast({
                    title: "Branch Required",
                    description: "Please select a branch in Advanced Filter to assign tasks.",
                    variant: "warning",
                });
                setIsFilterBlinking(true);
                setTimeout(() => setIsFilterBlinking(false), 3000);
                return;
            }
            setIsSingleAssignDialogOpen(true);
        });
    };

    // ── Render ────────────────────────────────────────────────────────────────
    return (
        <div className="flex flex-col h-[calc(100vh-8rem)]">
            {/* ── Sticky header ── */}
            <div className="sticky top-0 z-30 pb-4">
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
                    <div>
                        <h1 className="text-2xl font-bold tracking-tight">Tasks</h1>
                        <p className="text-sm text-muted-foreground">
                            Here's a list of tasks for the loan accounts.
                        </p>
                    </div>
                </div>

                {/* Filter bar */}
                <div className="flex items-center justify-between">
                    {/* Left: search + DPD legend */}
                    <div className="flex items-center gap-4">
                        <div className="relative max-w-64 overflow-hidden rounded-md border border-gray-200 bg-white">
                            <Input
                                value={globalFilter ?? ""}
                                onChange={(e) => setGlobalFilter(e.target.value)}
                                placeholder=""
                                className="max-w-64 border-none focus-visible:ring-0 relative z-10 bg-transparent pr-8"
                            />

                            {!globalFilter && (
                                <div className="absolute inset-y-0 left-0 w-full flex items-center pointer-events-none overflow-hidden">
                                    <div className="w-full text-xs sm:text-sm text-muted-foreground whitespace-nowrap animate-marquee-rtl">
                                        Search by LAN, Receipt, Customer Name
                                    </div>
                                </div>
                            )}
                            {(loading || globalFilter !== debouncedFilter) ? (
                                <div className="absolute right-3 top-1/2 -translate-y-1/2 z-20">
                                    <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                                </div>
                            ) : globalFilter && (
                                <button
                                    onClick={() => setGlobalFilter("")}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 z-20 hover:text-foreground transition-colors"
                                >
                                    <X className="h-4 w-4 text-muted-foreground" />
                                </button>
                            )}

                        </div>

                        <div className="relative">
                            <Button
                                variant="ghost"
                                size="icon"
                                className={cn(
                                    "h-10 w-10 border border-gray-200 p-2 bg-white/20 transition-all",
                                    isFilterBlinking && "animate-pulse ring-2 ring-blue-500 bg-blue-50"
                                )}
                                onClick={() => advancedSearch.setIsAdvancedSearchOpen(true)}
                            >
                                <Filter className="h-9 w-9 text-blue-800" strokeWidth={2.5} />
                            </Button>
                            {advancedSearch.isFilterApplied && (
                                <div className="absolute -top-1 -right-1 flex items-center justify-center w-4 h-4 bg-red-500 rounded-full border-2 border-white">
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 20 20"
                                        fill="currentColor"
                                        className="w-2.5 h-2.5 text-white"
                                    >
                                        <path
                                            fillRule="evenodd"
                                            d="M16.704 5.29a1 1 0 010 1.42l-7.25 7.25a1 1 0 01-1.41 0l-3.75-3.75a1 1 0 111.41-1.42L9 11.59l6.29-6.3a1 1 0 011.41 0z"
                                            clipRule="evenodd"
                                        />
                                    </svg>
                                </div>
                            )}
                        </div>

                        <div className="flex items-center gap-4">
                            {[
                                { color: "bg-green-500", label: "0–30 DPD" },
                                { color: "bg-orange-500", label: "31–90 DPD" },
                                { color: "bg-red-500", label: ">90 DPD" },
                            ].map(({ color, label }) => (
                                <div key={label} className="flex items-center gap-2">
                                    <div className={`h-3 w-3 rounded-full ${color}`} />
                                    <span className="text-sm">{label}</span>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Right: action toolbar */}
                    <div className="flex items-center gap-2 flex-wrap">
                        {/* Receipt actions — only when something is selected */}
                        {showReceiptActions && activeTab !== acceptanceStatusTabs.CASE_PENDING && activeTab !== acceptanceStatusTabs.VERIFIED_BY_HO && (
                            <>
                                {canAccessCategory("ReceiptActions", "EDIT") && (
                                    <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                                        disabled={!selectedTask}
                                        onClick={() =>
                                            withLocation(() => selectedTask && handleEditReceipt(selectedTask))
                                        }
                                        title={selectedTask ? "Edit receipt" : "Select exactly one task to edit"}
                                    >
                                        <Pencil className="h-9 w-9 text-blue-800" strokeWidth={2.5} />
                                    </Button>
                                )}
                                {canAccessCategory("ReceiptActions", "DELETE") && (
                                    <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                                        disabled={!canActOnSelection}
                                        onClick={() =>
                                            withLocation(() => selectedTask && handleReverseReceipt(selectedTask))
                                        }
                                        title={canActOnSelection ? "Delete receipt" : "Select exactly one task to delete"}
                                    >
                                        <Trash className="h-9 w-9 text-rose-600" strokeWidth={2.5} />
                                    </Button>
                                )}
                            </>
                        )}
                        {canAccessCategory("ImportData") && <Button
                            variant="ghost"
                            size="icon"
                            className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                            onClick={() => setIsImportDialogOpen(true)}
                            disabled={isImporting}
                            title={isImporting ? "Importing in Progress..." : "Import LMS Data"}
                        >
                            {isImporting ? (
                                <Loader2 className="h-9 w-9 text-blue-800 animate-spin" strokeWidth={2.5} />
                            ) : (
                                <FileDown className="h-9 w-9 text-blue-800" strokeWidth={2.5} />
                            )}
                        </Button>}
                        {canAccessCategory("ExportData") && <Button
                            variant="ghost"
                            size="icon"
                            className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                            onClick={() => setIsExportDialogOpen(true)}
                            disabled={isExporting}
                            title={isExporting ? "Exporting in Progress..." : "Export all tasks"}
                        >
                            {isExporting ? (
                                <Loader2 className="h-9 w-9 text-blue-800 animate-spin" strokeWidth={2.5} />
                            ) : (
                                <FileUp className="h-9 w-9 text-blue-800" strokeWidth={2.5} />
                            )}
                        </Button>}

                        {/* {canAccessCategory("DepositCashinBank") && (
                            <Button
                                variant="ghost"
                                size="icon"
                                className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                                disabled={activeTab !== "Branch Ops In Hand" || selectionCount === 0}
                                onClick={() => withLocation(() => setIsDepositDialogOpen(true))}
                                title={
                                    activeTab !== "Branch Ops In Hand"
                                        ? "Only available in Branch Ops In Hand tab"
                                        : selectionCount === 0
                                            ? "Select at least one task"
                                            : "Deposit cash in bank"
                                }
                            >
                                <Banknote className="h-9 w-9 text-blue-800" strokeWidth={2.5} />
                            </Button>
                        )} */}

                        {/* {canAccessCategory("AcceptRejectCash") && (
                            <Button
                                variant="ghost"
                                size="icon"
                                className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                                disabled={selectionCount === 0 || activeTab !== "Acceptance Pending"}
                                onClick={handleAcceptRejectClick}
                                title="Accept / Reject Cash"
                            >
                                <HandCoins className="h-9 w-9" />
                            </Button>
                        )} */}

                        {canAccessCategory("AssignTasks") && (
                            <Button
                                variant="ghost"
                                size="icon"
                                className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                                disabled={selectionCount === 0 || activeTab !== acceptanceStatusTabs.CASE_PENDING}
                                onClick={handleAssignClick}
                                title={
                                    selectionCount === 0
                                        ? "Select tasks to assign"
                                        : `Assign ${selectionCount} task(s)`
                                }
                            >
                                <UserPlus className="h-9 w-9" />
                            </Button>
                        )}

                        {canAccessCategory("GenerateUPIPayment") && (
                            <Button variant="ghost" size="icon" className="h-10 w-10 border border-gray-200 p-2 bg-white/20" disabled>
                                <QrCode className="h-9 w-9" />
                            </Button>
                        )}

                        {canAccessCategory("AddNotesTasks") && (
                            <Button
                                variant="ghost"
                                size="icon"
                                className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                                disabled={selectionCount === 0}
                                onClick={() => withLocation(() => setIsNotesDialogOpen(true))}
                                title={selectionCount > 0 ? `Add notes to ${selectionCount} task(s)` : "Select tasks first"}
                            >
                                <File className="h-9 w-9" />
                            </Button>
                        )}

                        <Button
                            variant="ghost"
                            size="icon"
                            className="h-10 w-10 border border-gray-200 p-2 bg-white/20"
                            onClick={() => setIsGuideOpen(true)}
                        >
                            <Info className="h-9 w-9 text-blue-800" strokeWidth={2.5} />
                        </Button>

                        {/* View toggle */}
                        <div className="sm:flex items-center gap-1 border bg-muted p-1 rounded-md">
                            <Button
                                variant={view === "table" ? "secondary" : "ghost"}
                                size="icon"
                                className="h-7 w-7"
                                onClick={() => setView("table")}
                            >
                                <List className="h-4 w-4" />
                            </Button>
                            <Button
                                variant={view === "card" ? "secondary" : "ghost"}
                                size="icon"
                                className="h-7 w-7"
                                onClick={() => setView("card")}
                            >
                                <LayoutGrid className="h-4 w-4" />
                            </Button>
                        </div>

                        {/* Column visibility */}
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="outline" className="h-10">
                                    Columns <ChevronDown className="ml-2 h-4 w-4" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-[200px]">
                                {table
                                    .getAllColumns()
                                    .filter((col) => typeof col.accessorFn !== "undefined" && col.getCanHide())
                                    .map((col) => (
                                        <DropdownMenuCheckboxItem
                                            key={col.id}
                                            checked={col.getIsVisible()}
                                            onCheckedChange={(v) => col.toggleVisibility(!!v)}
                                        >
                                            {COLUMN_DISPLAY_NAMES[col.id] ?? col.id}
                                        </DropdownMenuCheckboxItem>
                                    ))}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                </div>
            </div>

            {/* Export Dialog */}
            <ExportTasksDialog
                open={isExportDialogOpen}
                onOpenChange={setIsExportDialogOpen}
                onConfirm={handleConfirmExport}
                isExporting={isExporting}
                currentTabName={TAB_CONFIG.find(t => t.value === activeTab)?.label || activeTab}
            />

            {/* Import Dialog For LMS Feed*/}
            <ImportDialog
                open={isImportDialogOpen}
                onOpenChange={setIsImportDialogOpen}
                onConfirm={handleConfirmImport}
            />

            {/* ── Tabs ── */}
            <Tabs
                value={activeTab ?? ""}
                onValueChange={(v) => handleTabChange(v as TabValue)}
                className="w-full mb-4"
            >
                <TabsList
                    className="grid w-full h-auto gap-1 bg-muted/50 p-1"
                    style={{ gridTemplateColumns: `repeat(${filteredTabs.length}, 1fr)` }}
                    >
                    {filteredTabs.map(({ value, label, icon: Icon }) => {
                        const countKey = (
                            {
                                "Case Pending": "casePendingCount",
                                "Pending": "pending",
                                "Acceptance Pending": "acceptancePending",
                                "Branch Ops In Hand": "branchOpsInHand",
                                "Verification Pending": "verificationPending",
                                "Verification Completed": "verificationCompleted",
                                "Verified By HO": "verifiedByHo",
                            } as Record<TabValue, keyof TabCounts>
                        )[value];

                        return (
                            <TabsTrigger
                                key={value}
                                value={value}
                                className="flex items-center gap-1.5 px-2 py-2 text-[11px] sm:text-xs lg:text-[13px] relative transition-all min-w-0"
                            >
                                <Icon className="h-3.5 w-3.5 shrink-0" />
                                <span className="truncate" title={label}>{label}</span>
                                <Badge
                                    variant={activeTab === value ? "default" : "secondary"}
                                    className="h-5 px-1.5 text-[10px] shrink-0"
                                >
                                    {counts[countKey]}
                                </Badge>
                                {activeTab === value && value !== (filteredTabs[0]?.value || "Case Pending") && (
                                    <span
                                        role="button"
                                        tabIndex={0}
                                        aria-label="Clear filter"
                                        onClick={(e) => { e.stopPropagation(); handleTabClear(); }}
                                        onKeyDown={(e) => {
                                            if (e.key === "Enter" || e.key === " ") {
                                                e.preventDefault();
                                                handleTabClear();
                                            }
                                        }}
                                        className="mr-1 hover:bg-primary-foreground/20 rounded-full p-0.5 transition-colors cursor-pointer inline-flex items-center justify-center shrink-0"
                                    >
                                        <X className="h-3 w-3" />
                                    </span>
                                )}
                            </TabsTrigger>
                        );
                    })}
                </TabsList>
            </Tabs>

            {/* ── Main content area ── */}
            <div className="flex-1 overflow-hidden flex flex-col min-h-0">
                {/* Applied filter chips */}
                {advancedSearch.isFilterApplied && appliedFilterChips.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2 mb-3">
                        <span className="text-sm font-semibold text-gray-800">Applied Filters:</span>
                        {appliedFilterChips.map((chip) => (
                            <span
                                key={`${chip.label}-${chip.value}`}
                                className="flex items-center gap-1 rounded-full bg-muted px-3 text-xs"
                            >
                                <span className="font-semibold">{chip.label}:</span>
                                <span className="font-semibold">{chip.value}</span>
                                <button
                                    aria-label={`Remove ${chip.label}`}
                                    className="ml-1 text-muted-foreground hover:text-foreground flex items-center justify-center"
                                    onClick={() => removeAppliedFilter(chip.type)}
                                >
                                    <X className="h-3 w-3" />
                                </button>
                            </span>
                        ))}
                        <Button
                            variant="link"
                            className="text-sm text-blue-800 px-0"
                            onClick={advancedSearch.resetFilters}
                        >
                            Clear All
                        </Button>
                    </div>
                )}

                {/* Table view */}
                {view === "table" ? (
                    <div className="h-[calc(100vh-180px)] flex flex-col rounded-xl border bg-card shadow-sm overflow-hidden">
                        <div className="flex-1 overflow-auto scrollbar-thin">
                            <Table className="w-full">
                                <TableHeader className="sticky top-0 z-20 bg-card">
                                    {table.getHeaderGroups().map((hg) => (
                                        <TableRow key={hg.id}>
                                            {hg.headers.map((header) => (
                                                <TableHead
                                                    key={header.id}
                                                    className={cn(
                                                        "bg-slate-50 text-muted-foreground font-semibold h-10",
    header.id === "actions" && "sticky right-0 z-30 bg-slate-50 text-slate-700 text-center shadow-[-4px_0_4px_-2px_rgba(0,0,0,0.1)] hover:text-white"
                                                    )}
                                                    style={{ width: header.getSize() }}
                                                >
                                                    {header.isPlaceholder
                                                        ? null
                                                        : flexRender(header.column.columnDef.header, header.getContext())}
                                                </TableHead>
                                            ))}
                                        </TableRow>
                                    ))}
                                </TableHeader>
                                <TableBody>
                                    {loading ? (
                                        renderTableSkeleton(12)
                                    ) : error ? (
                                        <TableRow>
                                            <TableCell
                                                colSpan={columns.length}
                                                className="h-24 text-center text-destructive"
                                            >
                                                Error: {error}
                                            </TableCell>
                                        </TableRow>
                                    ) : table.getRowModel().rows.length ? (
                                        table.getRowModel().rows.map((row) => {
                                            const isHighlighted = row.original.id === highlightedTaskId;
                                            return (
                                                <TableRow
                                                    key={row.id}
                                                    ref={isHighlighted ? highlightedRowRef : undefined}
                                                    className={cn(
                                                        isHighlighted &&
                                                        "bg-yellow-100 dark:bg-yellow-900/30 ring-2 ring-yellow-400 ring-inset animate-pulse"
                                                    )}
                                                >
                                                    {row.getVisibleCells().map((cell) => (
                                                        <TableCell
                                                            key={cell.id}
                                                            className={cn(
                                                                "whitespace-nowrap",
                                                                cell.column.id === "actions" && "sticky right-0 z-10 bg-card text-right shadow-[-4px_0_4px_-2px_rgba(0,0,0,0.1)]"
                                                            )}
                                                            style={{ width: cell.column.getSize() }}
                                                        >
                                                            {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                                        </TableCell>
                                                    ))}
                                                </TableRow>
                                            );
                                        })
                                    ) : (
                                        <TableRow>
                                            <TableCell colSpan={columns.length} className="h-24 text-center">
                                                No results.
                                            </TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </div>
                    </div>
                ) : (
                    /* Card view */
                    <div className="flex-1 overflow-auto scrollbar-thin">
                        {loading ? (
                            <div className="flex items-center justify-center h-24">
                                <p className="text-muted-foreground">Loading tasks...</p>
                            </div>
                        ) : error ? (
                            <div className="flex items-center justify-center h-24">
                                <p className="text-destructive">Error: {error}</p>
                            </div>
                        ) : tasks.length ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 p-4">
                                {tasks.map((task) => (
                                    <div
                                        key={task.id}
                                        className={`relative bg-white ${getDpdBorderClasses(task.dpd)} rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow`}
                                    >
                                        {/* Checkbox */}
                                        <div className="absolute top-4 left-4">
                                            <Checkbox
                                                checked={!!selectedTasksMap[task.id]}
                                                onCheckedChange={(v) => toggleTaskSelection(task, !!v)}
                                                aria-label="Select task"
                                            />
                                        </div>

                                        {/* Disposition badge */}
                                        <div className="absolute top-4 right-4">
                                            <Badge variant="secondary" className="bg-gray-100 text-gray-700 font-normal text-xs px-2 py-0.5 rounded">
                                                {task.disposition}
                                            </Badge>
                                        </div>

                                        <div className="mt-8 mb-1">
                                            <h3 className={cn("text-xl font-bold", getDpdTextClass(task.dpd))}>
                                                {task.receiptNo === "N/A" ? "N/A" : task.receiptNo}
                                            </h3>
                                        </div>

                                        <div className="mb-2">
                                            <span className="text-sm text-gray-500">{task.lan}</span>
                                        </div>

                                        <div className="mb-4">
                                            <span className="text-sm text-gray-500">Disposition: </span>
                                            <span className="text-sm font-bold text-gray-900">{task.disposition}</span>
                                        </div>

                                        <div className="grid grid-cols-2 gap-4 mb-4">
                                            <div className="space-y-3">
                                                <div>
                                                    <p className="text-xs text-gray-500 mb-1">EMI Overdue</p>
                                                    <p className="text-sm font-bold text-gray-900">
                                                        ₹{task.emiOverdue.toLocaleString("en-IN")}
                                                    </p>
                                                </div>
                                                <div>
                                                    <p className="text-xs text-gray-500 mb-1">DPD</p>
                                                    <p className="text-sm font-bold text-gray-900">{task.dpd}</p>
                                                </div>
                                            </div>
                                            <div className="space-y-3">
                                                <div>
                                                    <p className="text-xs text-gray-500 mb-1">Received Amount</p>
                                                    <p className="text-sm font-bold text-gray-900">
                                                        ₹{task.receivedAmount.toLocaleString("en-IN")}
                                                    </p>
                                                </div>
                                                <div>
                                                    <p className="text-xs text-gray-500 mb-1">Agent</p>
                                                    <p className="text-sm font-bold text-gray-900">{task.agentName}</p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="flex items-center justify-end gap-3 pt-3">
                                            {canAccessCategory("ReceiptActions", "EDIT") && activeTab !== acceptanceStatusTabs.CASE_PENDING && activeTab !== acceptanceStatusTabs.VERIFIED_BY_HO && (
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="h-10 w-10 p-0 hover:bg-transparent"
                                                    onClick={() => handleEditReceipt(task)}
                                                    title={
                                                        !(task.receipt?.receiptNo && task.receiptNo !== "N/A")
                                                            ? "No receipt available"
                                                            : "Edit receipt"
                                                    }
                                                >
                                                    <Pencil className={cn(
                                                        "h-7 w-7",
                                                        (task.receipt?.receiptNo && task.receiptNo !== "N/A")
                                                            ? "text-blue-600"
                                                            : "text-gray-400"
                                                    )} />
                                                </Button>
                                            )}
                                            {/* {canAccessCategory("DepositCashinBank") && (
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="h-10 w-10 p-0 hover:bg-transparent"
                                                    disabled={activeTab !== "Branch Ops In Hand"}
                                                    onClick={() => {
                                                        if (!selectedTasksMap[task.id]) {
                                                            toggleTaskSelection(task, true);
                                                        }
                                                        withLocation(() => setIsDepositDialogOpen(true));
                                                    }}
                                                    title={
                                                        activeTab !== "Branch Ops In Hand"
                                                            ? "Only available in Branch Ops In Hand tab"
                                                            : "Deposit cash in bank"
                                                    }
                                                >
                                                    <Banknote className={cn(
                                                        "h-7 w-7",
                                                        activeTab === "Branch Ops In Hand"
                                                            ? "text-blue-800"
                                                            : "text-gray-400"
                                                    )} />
                                                </Button>
                                            )} */}

                                            <Button
                                                variant="ghost"
                                                size="icon"
                                                className="h-10 w-10 p-0 hover:bg-transparent"
                                                onClick={() => handleViewHistory(task)}
                                                title="View task history"
                                            >
                                                <History className="h-7 w-7 text-gray-800" />
                                            </Button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="flex items-center justify-center h-24">
                                <p className="text-muted-foreground">No results.</p>
                            </div>
                        )}
                    </div>
                )}

                {/* Pagination */}
                <Pagination
                    table={table}
                    totalRecords={totalRecords}
                    totalPages={totalPages}
                    pageIndex={pageIndex}
                    setPageIndex={setPageIndex}
                    hasNext={hasNext}
                    hasPrevious={hasPrevious}
                    loading={loading}
                    entityName="Tasks"
                    selectionCount={selectionCount}
                    onClearSelection={clearSelection}
                />
            </div>

            {/* ── Sidebars / dialogs ── */}
            <AdvanceSearchTasks
                isOpen={advancedSearch.isAdvancedSearchOpen}
                setIsOpen={advancedSearch.setIsAdvancedSearchOpen}
                filters={advancedSearch.filters}
                updateFilter={advancedSearch.updateFilter}
                states={advancedSearch.states}
                branches={advancedSearch.branches}
                agents={advancedSearch.agents}
                isLoadingAgents={advancedSearch.isLoadingAgents}
                emiPendings={advancedSearch.emiPendings}
                isLoadingEmiPendings={advancedSearch.isLoadingEmiPendings}
                onApplyFilters={() => {
                    advancedSearch.applyFilters();
                    advancedSearch.setIsAdvancedSearchOpen(false);
                }}
                onResetFilters={advancedSearch.resetFilters}
            />

            <ReceiptManagement
                receipt={selectedReceipt}
                isServiceChargeType={selectedReceipt?.serviceChargeTypeId !== null ? true : false}
                isOpen={isReceiptManagementOpen}
                onClose={handleReceiptManagementClose}
                onSuccess={() => {
                    clearSelection();
                    loadTasksCb();
                }}
                mode={receiptManagementMode}
            />

            <AddTaskNotesDialog
                isOpen={isNotesDialogOpen}
                onOpenChange={setIsNotesDialogOpen}
                tasks={selectedTasksList}
            />

            <TaskHistorySheet
                isOpen={isHistorySheetOpen}
                onOpenChange={setIsHistorySheetOpen}
                task={selectedTaskForHistory}
            />

            {isSingleAssignDialogOpen && (
                <BulkAssignTaskSheet
                    isOpen={isSingleAssignDialogOpen}
                    onOpenChange={setIsSingleAssignDialogOpen}
                    selectedTasks={selectedTasksList}
                    onSuccess={handleAssignSuccess}
                    securityGroupId={advancedSearch.selectedSecurityGroupId}
                />
            )}

            {isDepositDialogOpen && (
                <DepositCashSheet
                    isOpen={isDepositDialogOpen}
                    onOpenChange={setIsDepositDialogOpen}
                    tasks={selectedTasksList}
                    bankDetails={bankDetails}
                    onSuccess={handleDepositSuccess}
                />
            )}

            <ApproveRejectTasks
                isOpen={approveReject.isOpen}
                onOpenChange={approveReject.setIsOpen}
                selectedTasks={selectedTasksList
                    .filter((t) => t.receipt?.id && approveReject.selectedReceiptIds.includes(t.receipt.id))
                    .map((t) => ({
                        id: t.receipt!.id,
                        receiptNo: t.receiptNo,
                        totalAmount: t.receivedAmount,
                    }))}
                decision={approveReject.decision}
                remarks={approveReject.remarks}
                setRemarks={approveReject.setRemarks}
                isSubmitting={approveReject.isSubmitting}
                onSubmit={approveReject.handleSubmit}
            />

            <TaskActionsGuide isOpen={isGuideOpen} setIsOpen={setIsGuideOpen} />

        </div>
    );
}