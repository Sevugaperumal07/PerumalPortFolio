import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { UserForm } from './UserForm';
import { createUser, linkUserToRole, linkSecurityToUser } from '@/lib/services/users';
import { getRoles } from '@/lib/services/roles';
import { getSecurityGroups } from '@/lib/services/security-groups';
import { getUsers } from '@/lib/services/users';
import { Card, CardContent } from '@/components/ui/card';
import type { Role, SecurityGroup, User } from '@/lib/types';

export default function AddUser() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<{
    roles: Role[];
    securityGroups: SecurityGroup[];
    managers: User[];
  } | null>(null);
  const [dataLoading, setDataLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadData() {
      try {
        setDataLoading(true);
        const [roles, securityGroups, allUsers] = await Promise.all([
          getRoles(),
          getSecurityGroups(),
          getUsers(),
        ]);

        const managers = allUsers.filter(
          user => user.userType && user.userType !== 'Agent'
        );

        setData({ roles, securityGroups, managers });
      } catch (err) {
        setError('Failed to load necessary data.');
      } finally {
        setDataLoading(false);
      }
    }
    loadData();
  }, []);

  const handleSubmit = async (data: any) => {
    try {
      setLoading(true);

      const { securityGroupIds, roleIds, status, ...userData } = data;
      const rolesToLink = roleIds || [];
      const securityGroupsToLink = securityGroupIds || [];

      const payload = {
        ...userData,
        deleted: status === 'Inactive'
      };

      // Validate required fields before API call
      if (!userData.userName || !userData.email || !userData.firstName || !userData.lastName) {
        toast({
          title: 'Validation Error',
          description: 'All identity fields are required',
          variant: 'destructive',
        });
        setLoading(false);
        return;
      }

      if (!userData.userType) {
        toast({
          title: 'Validation Error',
          description: 'User Type is required',
          variant: 'destructive',
        });
        setLoading(false);
        return;
      }

      if (!userData.userHash || userData.userHash.trim() === '') {
        toast({
          title: 'Validation Error',
          description: 'Password is required',
          variant: 'destructive',
        });
        setLoading(false);
        return;
      }

      if (rolesToLink.length === 0) {
        toast({
          title: 'Validation Error',
          description: 'At least one role is required',
          variant: 'destructive',
        });
        setLoading(false);
        return;
      }

      if (securityGroupsToLink.length === 0) {
        toast({
          title: 'Validation Error',
          description: 'At least one security group is required',
          variant: 'destructive',
        });
        setLoading(false);
        return;
      }

      const createdUser = await createUser(payload);

      if (rolesToLink.length > 0) {
        try {
          for (const roleId of rolesToLink) {
            await linkUserToRole(createdUser.id, roleId);
          }
        } catch (error) {
          toast({
            title: 'Warning',
            description: 'User created, but there was an issue linking roles.',
            variant: 'default',
          });
        }
      }

      if (securityGroupsToLink.length > 0) {
        try {
          for (const securityGroupId of securityGroupsToLink) {
            await linkSecurityToUser(createdUser.id, securityGroupId);
          }
        } catch (error) {
          toast({
            title: 'Warning',
            description: 'User created, but there was an issue linking security groups.',
            variant: 'default',
          });
        }
      }

      toast({
        title: 'Success',
        description: 'User created successfully',
      });
      navigate('/dashboard/users');
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to create user',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (dataLoading) {
    return (
      <div className="space-y-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold">Add User</h1>
          <p className="text-sm sm:text-base text-muted-foreground">Create a new user account</p>
        </div>
        <Card>
          <CardContent className="p-6">
            <p>Loading...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="space-y-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold">Add User</h1>
          <p className="text-sm sm:text-base text-muted-foreground">Create a new user account</p>
        </div>
        <Card>
          <CardContent className="p-6">
            <p className="text-destructive">{error || 'Could not load data.'}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold">Create New User</h1>
        <p className="text-sm sm:text-base text-muted-foreground">
          Fill out the form below to add a new user.
        </p>
      </div>

      <div className="rounded-lg border bg-card p-4 md:p-8">
        <UserForm
          roles={data.roles}
          securityGroups={data.securityGroups}
          managers={data.managers}
          onSubmit={handleSubmit}
          loading={loading}
        />
      </div>
    </div>
  );
}
