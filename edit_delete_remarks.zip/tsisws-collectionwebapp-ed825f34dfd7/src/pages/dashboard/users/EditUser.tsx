import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { getUserById, updateUser, getUsers, updateUserRolesAndSecurityGroups } from '@/lib/services/users';
import { getRoles } from '@/lib/services/roles';
import { getSecurityGroups } from '@/lib/services/security-groups';
import { graphqlRequest } from '@/lib/graphql/client';
import { GET_ROLES_BY_USER_ID, GET_SECURITY_GROUPS_BY_USER_ID } from '@/lib/graphql/queries/users';
import type { User, Role, SecurityGroup } from '@/lib/types';
import { UserForm } from './UserForm';
import { Card, CardContent } from '@/components/ui/card';

export default function EditUser() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<{
    roles: Role[];
    securityGroups: SecurityGroup[];
    managers: User[];
  } | null>(null);
  const [dataLoading, setDataLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      loadData();
    }
  }, [id]);

  const loadData = async () => {
    if (!id) return;

    try {
      setDataLoading(true);
      const [userData, roles, securityGroups, allUsers, userRolesData, userSecurityGroupsData] = await Promise.all([
        getUserById(id),
        getRoles(),
        getSecurityGroups(),
        getUsers(),
        graphqlRequest<{ getRolesByUserId: Role[] }>(GET_ROLES_BY_USER_ID, { userId: id }),
        graphqlRequest<{ getSecurityGroupsByUserId: { securityGroups: SecurityGroup[] } }>(GET_SECURITY_GROUPS_BY_USER_ID, { userId: id }),
      ]);

      // Get user's assigned roles and security groups
      const userRoles = userRolesData?.getRolesByUserId || [];
      const userSecurityGroups = userSecurityGroupsData?.getSecurityGroupsByUserId?.securityGroups || [];

      // Store current role and security group IDs for comparison during update
      const currentRoleIds = userRoles.map(role => role.id);
      const currentSecurityGroupIds = userSecurityGroups.map(sg => sg.id);

      // Add roleIds and securityGroupIds to userData for the form
      const userWithRelations = {
        ...userData,
        roleIds: currentRoleIds,
        securityGroupIds: currentSecurityGroupIds,
        // Store current IDs for comparison
        _currentRoleIds: currentRoleIds,
        _currentSecurityGroupIds: currentSecurityGroupIds,
      };

      setUser(userWithRelations);

      // Filter managers (non-agents)
      const managers = allUsers.filter(
        user => user.userType && user.userType !== 'Agent'
      );

      setData({ roles, securityGroups, managers });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to load user data';
      setError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setDataLoading(false);
    }
  };

  const handleSubmit = async (data: any) => {
    if (!id) {
      toast({
        title: 'Error',
        description: 'User ID is missing',
        variant: 'destructive',
      });
      return;
    }

    if (!user) {
      toast({
        title: 'Error',
        description: 'User data is not loaded',
        variant: 'destructive',
      });
      return;
    }

    try {
      setLoading(true);

      const { roleIds, securityGroupIds, status, ...userData } = data;
      const newRoleIds = roleIds || [];
      const newSecurityGroupIds = securityGroupIds || [];
      const currentRoleIds = (user as any)._currentRoleIds || [];
      const currentSecurityGroupIds = (user as any)._currentSecurityGroupIds || [];

      const payload = {
        ...userData,
        deleted: status === 'Inactive'
      };

      await updateUser(id, payload);

      if (
        JSON.stringify(newRoleIds.sort()) !== JSON.stringify(currentRoleIds.sort()) ||
        JSON.stringify(newSecurityGroupIds.sort()) !== JSON.stringify(currentSecurityGroupIds.sort())
      ) {
        try {
          await updateUserRolesAndSecurityGroups(
            id,
            newRoleIds,
            newSecurityGroupIds,
            currentRoleIds,
            currentSecurityGroupIds
          );
        } catch (error) {
          toast({
            title: 'Warning',
            description: 'User updated, but there was an issue updating roles or security groups.',
            variant: 'default',
          });
        }
      }

      toast({
        title: 'Success',
        description: 'User updated successfully',
      });
      navigate('/dashboard/users', { state: { userUpdated: true, userId: id } });
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to update user',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (dataLoading) {
    return (
      <div className="space-y-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold">Edit User</h1>
          <p className="text-sm sm:text-base text-muted-foreground">Update user information</p>
        </div>
        <Card>
          <CardContent className="p-6">
            <p>Loading...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error || !user || !data) {
    return (
      <div className="space-y-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold">Edit User</h1>
          <p className="text-sm sm:text-base text-muted-foreground">Update user information</p>
        </div>
        <Card>
          <CardContent className="p-6">
            <p className="text-destructive">{error || 'Could not load data.'}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold">Edit User</h1>
        <p className="text-sm sm:text-base text-muted-foreground">Update user information</p>
      </div>

      <div className="rounded-lg border bg-card p-4 md:p-8">
        <UserForm
          user={user}
          roles={data.roles}
          securityGroups={data.securityGroups}
          managers={data.managers}
          onSubmit={handleSubmit}
          loading={loading}
        />
      </div>
    </div>
  );
}

