
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { SearchableSelect } from '@/components/ui/searchable-select';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { MultiSelect } from '@/components/ui/multi-select';
import type { User, Role, SecurityGroup } from '@/lib/types';

// Create schema factory that adapts based on create/edit mode
const createUserFormSchema = (isCreateMode: boolean) => {
  const baseSchema = z.object({
    userName: z.string().min(1, 'Username is required').regex(/^[a-zA-Z\s]+$/, 'Special Characters and Numeric Values are not allowed'),
    email: z.string().email('Invalid email address'),
    firstName: z.string().min(1, 'First name is required').regex(/^[a-zA-Z\s]+$/, 'Special Characters and Numeric Values are not allowed'),
    lastName: z.string().min(1, 'Last name is required').regex(/^[a-zA-Z\s]+$/, 'Special Characters and Numeric Values are not allowed'),
    phoneMobile: z.string().optional(),
    phoneWork: z.string().optional(),
    department: z.string().optional(),
    title: z.string().optional(),
    userType: z.string().min(1, 'User Type is required'),
    status: z.enum(['Active', 'Inactive']).default('Active'),
    employeeCode: z.string().optional(),
    supervisor: z.string().optional(),
    supervisorEmail: z.union([z.string().email('Invalid email'), z.literal(''), z.undefined()]).optional(),
    addressStreet: z.string().optional(),
    addressCity: z.string().optional(),
    addressState: z.string().optional(),
    addressCountry: z.string().optional(),
    addressPostalcode: z.string().optional(),
    receiveNotifications: z.boolean().default(false),
    portalOnly: z.boolean().default(false),
    showOnEmployees: z.boolean().default(false),
    description: z.string().optional(),
    reportingManager: z.string(),
  });

  // Add conditional fields based on create/edit mode
  const schemaWithPassword = isCreateMode
    ? baseSchema.extend({
      userHash: z.string().min(1, 'Password is required'),
    })
    : baseSchema.extend({
      userHash: z.string().optional().or(z.literal('')),
    });

  const schemaWithRoles = schemaWithPassword.extend({
    roleIds: z.array(z.string()).min(1, 'At least one role is required'),
    securityGroupIds: z.array(z.string()).min(1, 'At least one security group is required'),
  });

  return schemaWithRoles;
};

type UserFormValues = z.infer<ReturnType<typeof createUserFormSchema>>;

interface UserFormProps {
  user?: User;
  roles?: Role[];
  securityGroups?: SecurityGroup[];
  managers?: User[];
  onSubmit: (data: UserFormValues) => Promise<void>;
  loading?: boolean;
}

const getManagerDisplayName = (manager: User): string => {
  if (manager.firstName || manager.lastName) {
    return `${manager.firstName || ''} ${manager.lastName || ''}`.trim();
  }
  return manager.userName || '';
};

export function UserForm({
  user,
  roles = [],
  securityGroups = [],
  managers = [],
  onSubmit,
  loading,
}: UserFormProps) {
  const isCreateMode = !user;
  const userFormSchema = createUserFormSchema(isCreateMode);

  const form = useForm<UserFormValues>({
    resolver: zodResolver(userFormSchema),
    mode: 'onChange',
    defaultValues: user ? {
      userName: user.userName || '',
      userHash: '',
      email: user.email || '',
      firstName: user.firstName || '',
      lastName: user.lastName || '',
      phoneMobile: user.phoneMobile || '',
      phoneWork: user.phoneWork || '',
      department: user.department || '',
      title: user.title || '',
      userType: (user.userType as any) || undefined,
      status: user.deleted ? 'Inactive' : 'Active',
      employeeCode: user.employeeCode || '',
      supervisor: (user as any).supervisor || '',
      supervisorEmail: (user as any).supervisorEmail || '',
      addressStreet: user.addressStreet || '',
      addressCity: user.addressCity || '',
      addressState: user.addressState || '',
      addressCountry: user.addressCountry || '',
      addressPostalcode: user.addressPostalcode || '',
      receiveNotifications: user.receiveNotifications ?? false,
      portalOnly: user.portalOnly ?? false,
      showOnEmployees: user.showOnEmployees ?? false,
      description: user.description || '',
      roleIds: (user as any).roleIds || [],
      securityGroupIds: (user as any).securityGroupIds || [],
      reportingManager: (user as any).reportingManager || '',
    } : {
      userName: '',
      userHash: '',
      email: '',
      firstName: '',
      lastName: '',
      phoneMobile: '',
      phoneWork: '',
      department: '',
      title: '',
      userType: undefined,
      status: 'Active',
      employeeCode: '',
      supervisor: '',
      supervisorEmail: '',
      addressStreet: '',
      addressCity: '',
      addressState: '',
      addressCountry: '',
      addressPostalcode: '',
      receiveNotifications: false,
      portalOnly: false,
      showOnEmployees: false,
      description: '',
      roleIds: [],
      securityGroupIds: [],
      reportingManager: '',
    },
  });


  const filteredManagers = user
    ? managers.filter((manager) => manager.id !== user.id)
    : managers;

  const roleOptions = roles.map((r) => ({ value: r.id, label: r.name }));
  const securityGroupOptions = securityGroups.map((sg) => ({
    value: sg.id,
    label: sg.name,
  }));

  const userTypeOptions = roles.map(role => role.name);
  const statusOptions = ['Active', 'Inactive'];

  // Debug: Log form state
  React.useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      console.log('Form field changed:', name, value);
    });
    return () => subscription.unsubscribe();
  }, [form]);

  // Trigger validation on mount for edit mode to ensure isValid is updated for pre-filled values
  React.useEffect(() => {
    if (user) {
      form.trigger();
    }
  }, [user, form]);

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();

    // Validate all fields before proceeding
    const isValid = await form.trigger();

    if (!isValid) {
      // Scroll to first error field
      const firstErrorField = Object.keys(form.formState.errors)[0];
      if (firstErrorField) {
        const element = document.querySelector(`[name="${firstErrorField}"]`);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }
      return;
    }

    // Clean up empty strings to undefined for optional fields BEFORE submission
    const rawData = form.getValues();
    const cleanedData = {
      ...rawData,
      // Remove userHash if it's empty (for edit mode, password is optional)
      userHash: rawData.userHash === '' ? undefined : rawData.userHash,
      userType: rawData.userType === '' ? undefined : rawData.userType,
      supervisorEmail: rawData.supervisorEmail === '' ? undefined : rawData.supervisorEmail,
    };

    // Ensure required fields are present for create mode
    if (isCreateMode) {
      if (!cleanedData.userHash || cleanedData.userHash.trim() === '') {
        form.setError('userHash', { message: 'Password is required' });
        return;
      }
      if (!cleanedData.userType || cleanedData.userType.trim() === '') {
        form.setError('userType', { message: 'User Type is required' });
        return;
      }
      if (!cleanedData.roleIds || cleanedData.roleIds.length === 0) {
        form.setError('roleIds', { message: 'At least one role is required' });
        return;
      }
      if (!cleanedData.securityGroupIds || cleanedData.securityGroupIds.length === 0) {
        form.setError('securityGroupIds', { message: 'At least one security group is required' });
        return;
      }
    }

    try {
      await onSubmit(cleanedData as any);
    } catch (error) {
      console.error('Error in onSubmit:', error);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={handleFormSubmit} className="space-y-8" noValidate>
        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Identity</CardTitle>
            </CardHeader>
            <CardContent className='grid md:grid-cols-2 gap-6'>
              <FormField
                control={form.control}
                name='firstName'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name <span className="text-red-500 ml-0.5">*</span></FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='lastName'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name <span className="text-red-500 ml-0.5">*</span></FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='userName'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username <span className="text-red-500 ml-0.5">*</span></FormLabel>
                    <FormControl>
                      {/* <Input {...field} disabled={!!user} /> */}
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='email'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email <span className="text-red-500 ml-0.5">*</span></FormLabel>
                    <FormControl>
                      <Input type='email' {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {!user && (
                <FormField
                  control={form.control}
                  name='userHash'
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password <span className="text-red-500 ml-0.5">*</span></FormLabel>
                      <FormControl>
                        <Input type='password' {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              <FormField
                control={form.control}
                name='userType'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>User Type <span className="text-red-500 ml-0.5">*</span></FormLabel>
                    <SearchableSelect
                      onValueChange={field.onChange}
                      value={field.value || ''}
                      placeholder='Select user type'
                      options={userTypeOptions.map((type) => ({
                        value: type,
                        label: type.replace(/_/g, ' ')
                      }))}
                    />
                    <FormMessage />
                  </FormItem>
                )}
              />

            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Organization</CardTitle>
            </CardHeader>
            <CardContent className='grid md:grid-cols-2 gap-6'>
              <FormField
                control={form.control}
                name='title'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Job Title</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='department'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='employeeCode'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Employee Code</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='reportingManager'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reporting Manager</FormLabel>
                    <SearchableSelect
                      onValueChange={field.onChange}
                      value={field.value || ''}
                      placeholder='Select a manager'
                      options={filteredManagers.map((m) => {
                        const value = getManagerDisplayName(m);
                        const label = `${value}${m.userType ? ` - (${m.userType})` : ''}`;
                        return { value, label };
                      })}
                    />
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='supervisor'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Supervisor Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='supervisorEmail'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Supervisor Email</FormLabel>
                    <FormControl>
                      <Input type='email' {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Contact & Address</CardTitle>
            </CardHeader>
            <CardContent className='space-y-6'>
              <div className='grid md:grid-cols-2 gap-6'>
                <FormField
                  control={form.control}
                  name='phoneMobile'
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mobile Phone</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name='reportingManager'
                  render={({ field }) => (
                    <input type="hidden" {...field} />
                  )}
                />

                <FormField
                  control={form.control}
                  name='phoneWork'
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Work Phone</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className='grid md:grid-cols-2 gap-6'>
                <FormField
                  control={form.control}
                  name='addressStreet'
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Street</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name='addressCity'
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>City</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name='addressState'
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>State</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name='addressPostalcode'
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Postal Code</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name='addressCountry'
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Country</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Access & Visibility</CardTitle>
            </CardHeader>
            <CardContent className='space-y-6'>
              <FormField
                control={form.control}
                name='roleIds'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Roles <span className="text-red-500 ml-0.5">*</span></FormLabel>
                    <MultiSelect
                      options={roleOptions}
                      selected={field.value || []}
                      onChange={field.onChange}
                      placeholder='Select roles...'
                    />
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='securityGroupIds'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Security Groups <span className="text-red-500 ml-0.5">*</span></FormLabel>
                    <MultiSelect
                      options={securityGroupOptions}
                      selected={field.value || []}
                      onChange={field.onChange}
                      placeholder='Select groups...'
                    />
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='status'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status <span className="text-red-500 ml-0.5">*</span></FormLabel>
                    <SearchableSelect
                      onValueChange={field.onChange}
                      value={field.value || 'Active'}
                      placeholder='Select status'
                      options={statusOptions.map((type) => ({
                        value: type,
                        label: type
                      }))}
                    />
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='description'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description / Notes</FormLabel>
                    <FormControl>
                      <Textarea {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className='flex flex-wrap gap-x-8 gap-y-4'>
                <FormField
                  control={form.control}
                  name='receiveNotifications'
                  render={({ field }) => (
                    <FormItem className='flex flex-row items-center space-x-3 space-y-0'>
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <FormLabel className='font-normal'>
                        Receive Notifications
                      </FormLabel>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name='portalOnly'
                  render={({ field }) => (
                    <FormItem className='flex flex-row items-center space-x-3 space-y-0'>
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <FormLabel className='font-normal'>Portal Only</FormLabel>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name='showOnEmployees'
                  render={({ field }) => (
                    <FormItem className='flex flex-row items-center space-x-3 space-y-0'>
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <FormLabel className='font-normal'>
                        Show on Employees Directory
                      </FormLabel>
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className='flex justify-end gap-2'>
          <Button
            type='button'
            variant='outline'
            onClick={() => window.history.back()}
          >
            Cancel
          </Button>
          <Button type='submit' disabled={loading || !form.formState.isValid}>
            {loading ? 'Saving...' : user ? 'Update User' : 'Save User'}
          </Button>
        </div>
      </form>
    </Form>
  );
}
