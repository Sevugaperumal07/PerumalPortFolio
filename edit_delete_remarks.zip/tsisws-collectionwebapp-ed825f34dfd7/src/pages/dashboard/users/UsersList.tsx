import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { cn } from "@/lib/utils";
import React from "react";
import { Link, useLocation } from "react-router-dom";
import type {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  RowSelectionState,
} from "@tanstack/react-table";
import {
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Plus, List, LayoutGrid, Pencil, Trash2, Eye, ChevronDown, Search, StickyNote, CirclePlus, LogOut, X } from "lucide-react";
import { getUsers, deleteUser, getUsersRoles, getUsersSecurityGroups, forceLogoutUser } from "@/lib/services/users";
import type { User, Role, SecurityGroup } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { UserCard } from "@/components/dashboard/user-card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useUserRole } from "@/contexts/UserRoleContext";
import ErrorStatusCode from "@/constants/ErrorStatusCode";

// Helper function to get user display name
const getUserDisplayName = (user: User): string => {
  if (user.firstName || user.lastName) {
    return `${user.firstName || ''} ${user.lastName || ''}`.trim();
  }
  return user.userName || 'N/A';
};

// Helper component to display tags with "+X more" functionality
// Skeleton loader for roles column
const RolesSkeleton = () => {
  return (
    <div className="flex items-center gap-1.5">
      <div className="h-5 w-16 bg-gray-200 rounded animate-pulse"></div>
      <div className="h-5 w-12 bg-gray-200 rounded animate-pulse"></div>
    </div>
  );
};

const TagsDisplay = ({ items, maxVisible = 2 }: { items: Array<{ id: string; name: string }> | undefined; maxVisible?: number }) => {
  if (!items || items.length === 0) {
    return <span className="text-muted-foreground"></span>;
  }

  const visibleItems = items.slice(0, maxVisible);
  const remainingCount = items.length - maxVisible;

  return (
    <div className="flex flex-wrap items-center gap-1">
      {visibleItems.map((item) => (
        <Badge key={item.id} variant="secondary" className="text-xs">
          {item.name}
        </Badge>
      ))}
      {remainingCount > 0 && (
        <Badge variant="secondary" className="text-xs">
          +{remainingCount} more
        </Badge>
      )}
    </div>
  );
};

// Filter Dropdown Component
interface FilterOption {
  value: string;
  label: string;
  count: number;
}

interface FilterDropdownProps {
  label: string;
  options: FilterOption[];
  selected: string[];
  onSelectionChange: (selected: string[]) => void;
  placeholder?: string;
}

const FilterDropdown = ({ label, options, selected, onSelectionChange, placeholder = "Search..." }: FilterDropdownProps) => {
  const [open, setOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const containerRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOpen(false);
        setSearchValue("");
      }
    };

    if (open) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }
  }, [open]);

  const filteredOptions = options.filter(option =>
    option.label.toLowerCase().includes(searchValue.toLowerCase())
  );

  const handleToggle = (value: string) => {
    if (selected.includes(value)) {
      onSelectionChange(selected.filter(v => v !== value));
    } else {
      onSelectionChange([...selected, value]);
    }
  };

  const hasSelection = selected.length > 0;

  return (
    <div ref={containerRef} className="relative">
      <Button
        variant="outline"
        className="gap-2 border-dashed border-gray-200 h-9"
        onClick={() => setOpen(!open)}
      >
        <CirclePlus className="h-4 w-4" />
        {label}
        {hasSelection && (
          <Badge variant="secondary" className="ml-1 h-3 px-1.5 text-xs">
            {selected.length}
          </Badge>
        )}
      </Button>
      {open && (
        <div className="absolute top-full left-0 z-50 mt-1 w-[280px] rounded-md border border-gray-200 bg-white shadow-lg">
          <div className="p-2">
            <div className="relative mb-2">
              <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <Input
                placeholder={placeholder}
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                className="pl-8 h-9 bg-white border-gray-200 text-sm focus:border-gray-300"
                autoFocus
              />
            </div>
            <div className="max-h-[300px] overflow-y-auto">
              {filteredOptions.length > 0 ? (
                filteredOptions.map((option) => {
                  const isSelected = selected.includes(option.value);
                  return (
                    <div
                      key={option.value}
                      className={`relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors ${isSelected
                        ? 'bg-[#fdf2f8] hover:bg-[#fce7f3]'
                        : 'bg-white hover:bg-[#fdf2f8]'
                        }`}
                      onClick={() => handleToggle(option.value)}
                    >
                      <div className="absolute left-2 flex h-4 w-4 items-center justify-center">
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => handleToggle(option.value)}
                          onClick={(event) => event.stopPropagation()}
                          className="border-gray-300"
                        />
                      </div>
                      <span className="ml-8 flex-1 truncate text-gray-900 font-normal">{option.label}</span>
                      {option.count > 0 && (
                        <span className="ml-auto mr-2 text-xs text-gray-500 font-normal min-w-[20px] text-right">
                          {option.count}
                        </span>
                      )}
                    </div>
                  );
                })
              ) : (
                <div className="py-6 text-center text-sm text-gray-500">
                  No options found
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const createColumns = (
  onDelete: (id: string) => void,
  onForceLogout: (id: string) => void,
  canAccessCategory: (category: string, action?: string) => boolean,
  loadingUserIds: Set<string>
): ColumnDef<User>[] => [
    {
      id: "select",
      header: ({ table }) => (
        <Checkbox
          checked={
            table.getIsAllPageRowsSelected() ||
            (table.getIsSomePageRowsSelected() && "indeterminate")
          }
          onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
          aria-label="Select all"
        />
      ),
      cell: ({ row }) => (
        <Checkbox
          checked={row.getIsSelected()}
          onCheckedChange={(value) => row.toggleSelected(!!value)}
          aria-label="Select row"
        />
      ),
      enableSorting: false,
      enableHiding: false,
    },
    {
      id: "name",
      header: "Name",
      accessorFn: (row) => getUserDisplayName(row),
      cell: ({ row }) => {
        const user = row.original;
        return <span className="font-medium">{getUserDisplayName(user)}</span>;
      },
    },
    {
      accessorKey: "email",
      header: "Email",
    },
    {
      accessorKey: "userType",
      header: "User Type",
      cell: ({ row }) => {
        const userType = row.original.userType;
        return <span>{userType || 'N/A'}</span>;
      },
    },
    {
      id: "roles",
      header: "Roles",
      cell: ({ row }) => {
        const userId = row.original.id;
        const isLoading = loadingUserIds.has(userId);
        const roles = row.original.roles;

        if (isLoading) {
          return <RolesSkeleton />;
        }

        return <TagsDisplay items={roles} maxVisible={2} />;
      },
    },
    {
      id: "securityGroups",
      header: "Security Groups",
      cell: ({ row }) => {
        const userId = row.original.id;
        const isLoading = loadingUserIds.has(userId);
        const securityGroups = row.original.securityGroups;

        if (isLoading) {
          return <RolesSkeleton />;
        }

        return <TagsDisplay items={securityGroups} maxVisible={2} />;
      },
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        const isDeleted = row.original.deleted;
        return (
          <Badge
            variant={isDeleted ? "secondary" : "secondary"}
            className={cn(
              "text-xs font-medium",
              isDeleted
                ? "bg-gray-100 text-gray-600 border-gray-200"
                : "bg-emerald-50 text-emerald-700 border-emerald-200"
            )}
          >
            {isDeleted ? "Inactive" : "Active"}
          </Badge>
        );
      },
    },
    {
      id: "actions",
      size: 120,
      minSize: 120,
      enableResizing: false,
      cell: ({ row }) => {
        const user = row.original;
        return (
          <div className="flex items-center justify-end gap-1 sm:gap-2">
            <Button
              variant="ghost"
              size="icon"
              asChild
              className="h-8 w-8 sm:h-10 sm:w-10 flex-shrink-0"
            >
              <Link to={`/dashboard/users/${user.id}`}>
                <Eye className="h-3 w-3 sm:h-4 sm:w-4" />
              </Link>
            </Button>
            {canAccessCategory("UsersWeb", "EDIT") && (<Button
              variant="ghost"
              size="icon"
              asChild
              className="h-8 w-8 sm:h-10 sm:w-10 flex-shrink-0"
            >
              <Link to={`/dashboard/users/${user.id}/edit`}>
                <Pencil className="h-3 w-3 sm:h-4 sm:w-4" />
              </Link>
            </Button>)}
            {canAccessCategory("UsersWeb", "DELETE") && (<Button
              variant="ghost"
              size="icon"
              className="text-destructive focus:text-white focus:bg-destructive cursor-pointer"
              onClick={() => onDelete(user.id)}
            >
              <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
            </Button>)}
            {canAccessCategory("TerminateAgentSession", "ACCESS") && (<Button
              variant="ghost"
              size="icon"
              className="text-destructive focus:text-white focus:bg-destructive cursor-pointer"
              onClick={() => onForceLogout(user.id)}
            >
              <LogOut className="h-3 w-3 sm:h-4 sm:w-4" />
            </Button>)}
          </div>
        );
      },
    },
  ];

export default function UsersList() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
  const [globalFilter, setGlobalFilter] = useState("");
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 20 });
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<string | null>(null);
  const [selectedUserTypes, setSelectedUserTypes] = useState<string[]>([]);
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>([]);
  const [forceLogoutDialogOpen, setForceLogoutDialogOpen] = useState(false);
  const [userToForceLogout, setUserToForceLogout] = useState<string | null>(null);
  const [forceLogoutComment, setForceLogoutComment] = useState("");
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [view, setView] = useState<"table" | "card">("table");
  const location = useLocation();
  const rolesLoadedRef = useRef<Set<string>>(new Set());
  const securityGroupsLoadedRef = useRef<Set<string>>(new Set());
  const isUpdatingRolesRef = useRef<boolean>(false);
  const [loadingUserIds, setLoadingUserIds] = useState<Set<string>>(new Set());
  const { canAccessCategory } = useUserRole();

  useEffect(() => {
    if (isMobile !== undefined) {
      setView(isMobile ? "card" : "table");
    }
  }, [isMobile]);

  const loadUsers = useCallback(async () => {
    try {
      setLoading(true);
      const data = await getUsers();
      setUsers(data);
      rolesLoadedRef.current.clear();
      securityGroupsLoadedRef.current.clear();
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : "Failed to load users";
      if (!errorMessage.includes("401") && !errorMessage.includes("403")) {
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
      }
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const loadRolesForVisibleUsers = useCallback(async (visibleUserIds: string[]) => {
    if (visibleUserIds.length === 0) return;

    const usersNeedingRoles = visibleUserIds.filter((id) => !rolesLoadedRef.current.has(id));
    const usersNeedingSecurityGroups = visibleUserIds.filter((id) => !securityGroupsLoadedRef.current.has(id));
    const usersToLoad = [...new Set([...usersNeedingRoles, ...usersNeedingSecurityGroups])];

    if (usersToLoad.length === 0) return;

    try {
      isUpdatingRolesRef.current = true;

      setLoadingUserIds((prev) => {
        const newSet = new Set(prev);
        usersToLoad.forEach((id) => newSet.add(id));
        return newSet;
      });

      const [rolesMap, securityGroupsMap] = await Promise.all([
        usersNeedingRoles.length > 0 ? getUsersRoles(usersNeedingRoles, 10) : Promise.resolve(new Map<string, Role[]>()),
        usersNeedingSecurityGroups.length > 0 ? getUsersSecurityGroups(usersNeedingSecurityGroups, 10) : Promise.resolve(new Map<string, SecurityGroup[]>()),
      ]);

      setUsers((prevUsers) => {
        const updated = prevUsers.map((user) => {
          const roles = rolesMap.get(user.id) ?? user.roles ?? [];
          const securityGroups = securityGroupsMap.get(user.id) ?? user.securityGroups ?? [];
          if (usersNeedingRoles.includes(user.id)) {
            rolesLoadedRef.current.add(user.id);
          }
          if (usersNeedingSecurityGroups.includes(user.id)) {
            securityGroupsLoadedRef.current.add(user.id);
          }
          return { ...user, roles, securityGroups };
        });
        return updated;
      });
    } catch (error) {
    } finally {
      setLoadingUserIds((prev) => {
        const newSet = new Set(prev);
        usersToLoad.forEach((id) => newSet.delete(id));
        return newSet;
      });

      setTimeout(() => {
        isUpdatingRolesRef.current = false;
      }, 100);
    }
  }, []);

  useEffect(() => {
    loadUsers();

    if (location.state?.refresh && window.history.state) {
      window.history.replaceState({ ...window.history.state, refresh: false }, '');
    }
  }, [location.pathname, location.state, loadUsers]);

  const handleDeleteClick = (id: string) => {
    setUserToDelete(id);
    setDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!userToDelete) return;
    try {
      await deleteUser(userToDelete);
      toast({
        title: "Success",
        description: "User deleted successfully",
      });
      setDeleteDialogOpen(false);
      setUserToDelete(null);
      loadUsers();
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to delete user",
        variant: "destructive",
      });
    }
  };

  const handleForceLogoutClick = (id: string) => {
    setUserToForceLogout(id);
    setForceLogoutComment("");
    setForceLogoutDialogOpen(true);
  };

  const confirmForceLogout = async () => {
    if (!userToForceLogout) return;
    if (!forceLogoutComment.trim()) {
      toast({
        title: "Error",
        description: "Reason for logout is required",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoggingOut(true);
      const data = await forceLogoutUser(userToForceLogout, forceLogoutComment);

      if (data?.errorCode === ErrorStatusCode.NO_ACTIVE_SESSIONS_FOUND) {
        toast({
          title: "Notice",
          description: data.message || "No active sessions found for the user",
          variant: "warning",
        });
        setForceLogoutDialogOpen(false);
        setUserToForceLogout(null);
        setForceLogoutComment("");
        return;
      }

      toast({
        title: "Success",
        description: "User session revoked successfully",
      });
      setForceLogoutDialogOpen(false);
      setUserToForceLogout(null);
      setForceLogoutComment("");
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to force logout user",
        variant: "destructive",
      });
    } finally {
      setIsLoggingOut(false);
    }
  };

  // All possible user types (based on UserForm schema)
  const ALL_USER_TYPES = [
    'Agent',
    'Manager',
    'Telecaller',
    'Branch_Ops',
    'Branch_Trainee_Officer',
    'National_Manager',
    'National_Branch_Ops'
  ];

  // All possible statuses (based on UserForm schema)
  const ALL_STATUSES = [
    'Active',
    'Inactive'
  ];

  // Helper function to format display label (convert underscores to spaces)
  const formatLabel = (value: string): string => {
    return value.replace(/_/g, ' ');
  };

  // Extract user types with counts - show all possible types
  const userTypeOptions = useMemo(() => {
    // Count users for each type
    const typeMap = new Map<string, number>();
    users.forEach(user => {
      if (user.userType) {
        typeMap.set(user.userType, (typeMap.get(user.userType) || 0) + 1);
      }
    });

    // Get all unique types from users (in case there are types not in ALL_USER_TYPES)
    const userTypesFromData = users
      .map(u => u.userType)
      .filter((type): type is string => typeof type === 'string' && type.length > 0);
    const uniqueUserTypesFromData = new Set(userTypesFromData);

    // Combine predefined types with types found in data
    const allTypes = Array.from(new Set([...ALL_USER_TYPES, ...uniqueUserTypesFromData]));

    // Create options for all possible types, even if count is 0
    return allTypes.map(userType => ({
      value: userType,
      label: formatLabel(userType),
      count: typeMap.get(userType) || 0,
    })).sort((a, b) => a.label.localeCompare(b.label));
  }, [users]);

  // Extract statuses with counts - show all possible statuses
  const statusOptions = useMemo(() => {
    // Count users for each status based on deleted flag
    const statusMap = new Map<string, number>();
    users.forEach(user => {
      const status = user.deleted ? 'Inactive' : 'Active';
      statusMap.set(status, (statusMap.get(status) || 0) + 1);
    });

    // Create options for all possible statuses from ALL_STATUSES
    return ALL_STATUSES.map(status => ({
      value: status,
      label: status,
      count: statusMap.get(status) || 0,
    })).sort((a, b) => a.label.localeCompare(b.label));
  }, [users]);

  // Filter users based on selected user types and statuses
  const filteredUsers = useMemo(() => {
    return users.filter(user => {
      const matchesUserType = selectedUserTypes.length === 0 ||
        (user.userType && selectedUserTypes.includes(user.userType));
      const userStatus = user.deleted ? 'Inactive' : 'Active';
      const matchesStatus = selectedStatuses.length === 0 ||
        selectedStatuses.includes(userStatus);
      return matchesUserType && matchesStatus;
    });
  }, [users, selectedUserTypes, selectedStatuses]);

  const columns = createColumns(handleDeleteClick, handleForceLogoutClick, canAccessCategory, loadingUserIds);

  const table = useReactTable({
    data: filteredUsers,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onRowSelectionChange: setRowSelection,
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    enableRowSelection: true,
    globalFilterFn: (row, _columnId, filterValue) => {
      const searchValue = filterValue.toLowerCase();
      const name = getUserDisplayName(row.original).toLowerCase();
      const email = row.original.email?.toLowerCase() || "";
      const employeeCode = row.original.employeeCode?.toLowerCase() || "";
      return name.includes(searchValue) || email.includes(searchValue) || employeeCode.includes(searchValue);
    },
    initialState: {
      pagination: {
        pageIndex: 0,
        pageSize: 20,
      },
    },
    state: {
      sorting,
      columnFilters,
      rowSelection,
      globalFilter,
      pagination,
    },
    onPaginationChange: (updater) => {
      // Don't update pagination if we're currently updating roles
      if (isUpdatingRolesRef.current) {
        return;
      }

      setPagination((old) => {
        const newPagination = typeof updater === 'function' ? updater(old) : updater;
        // Only validate pageIndex if it's being explicitly changed
        // Don't reset it when data updates
        const maxPageIndex = Math.max(0, Math.ceil(filteredUsers.length / newPagination.pageSize) - 1);
        const validPageIndex = Math.min(Math.max(0, newPagination.pageIndex), maxPageIndex);

        // Only update if pageIndex actually changed or is invalid
        if (newPagination.pageIndex !== old.pageIndex || validPageIndex !== newPagination.pageIndex) {
          return {
            ...newPagination,
            pageIndex: validPageIndex,
          };
        }
        return old;
      });
    },
  });

  // Track previous page index and refresh state
  const previousPageIndexRef = useRef<number>(-1);
  const refreshRolesRef = useRef<{ userId?: string; shouldRefresh: boolean }>({ shouldRefresh: false });

  // Detect refresh from edit pages
  useEffect(() => {
    const isFromUserEdit = location.state?.userUpdated;
    const updatedUserId = location.state?.userId;
    const isFromRoleEdit = location.state?.roleUpdated;

    if (isFromUserEdit || isFromRoleEdit) {
      refreshRolesRef.current = {
        userId: updatedUserId,
        shouldRefresh: true,
      };

      // Clear state
      if (location.state && window.history.state) {
        const newState = { ...window.history.state };
        if (newState.userUpdated) delete newState.userUpdated;
        if (newState.userId) delete newState.userId;
        if (newState.roleUpdated) delete newState.roleUpdated;
        window.history.replaceState(newState, '');
      }
    }
  }, [location.state]);

  // Load roles whenever users are loaded, page changes, or refresh is needed
  useEffect(() => {
    if (loading || users.length === 0) {
      return;
    }

    const currentPageIndex = pagination.pageIndex;
    const isInitialLoad = previousPageIndexRef.current === -1;
    const isPageChange = !isInitialLoad && currentPageIndex !== previousPageIndexRef.current;

    const isRefresh = refreshRolesRef.current.shouldRefresh;
    const refreshUserId = isRefresh ? refreshRolesRef.current.userId : undefined;

    const visibleRows = table.getRowModel().rows;
    const visibleUserIds = visibleRows.length > 0 ? visibleRows.map((row) => row.original.id) : [];
    const usersNeedingRoles = visibleUserIds.filter((userId) =>
      !rolesLoadedRef.current.has(userId) || !securityGroupsLoadedRef.current.has(userId)
    );
    const hasUsersNeedingRoles = usersNeedingRoles.length > 0;
    if (!isInitialLoad && !isPageChange && !isRefresh && !hasUsersNeedingRoles) {
      return;
    }

    if (isRefresh) {
      if (refreshUserId) {
        rolesLoadedRef.current.delete(refreshUserId);
        securityGroupsLoadedRef.current.delete(refreshUserId);
        setUsers((prevUsers) =>
          prevUsers.map((user) =>
            user.id === refreshUserId ? { ...user, roles: [], securityGroups: [] } : user
          )
        );
      } else {
        rolesLoadedRef.current.clear();
        securityGroupsLoadedRef.current.clear();
        setUsers((prevUsers) =>
          prevUsers.map((user) => ({ ...user, roles: [], securityGroups: [] }))
        );
      }

      refreshRolesRef.current.shouldRefresh = false;
    }

    if (visibleRows.length === 0) {
      return;
    }

    if (isPageChange || isInitialLoad) {
      visibleUserIds.forEach((userId) => {
        rolesLoadedRef.current.delete(userId);
        securityGroupsLoadedRef.current.delete(userId);
      });
      setUsers((prevUsers) =>
        prevUsers.map((user) =>
          visibleUserIds.includes(user.id) ? { ...user, roles: [], securityGroups: [] } : user
        )
      );
      previousPageIndexRef.current = currentPageIndex;
      if (visibleUserIds.length > 0) {
        loadRolesForVisibleUsers(visibleUserIds);
      }
      return;
    }
    if (isRefresh && refreshUserId) {
      rolesLoadedRef.current.delete(refreshUserId);
      securityGroupsLoadedRef.current.delete(refreshUserId);

      if (visibleUserIds.includes(refreshUserId)) {
        loadRolesForVisibleUsers([refreshUserId]);
      }

      const otherUserIds = visibleUserIds.filter(id => id !== refreshUserId);
      if (otherUserIds.length > 0) {
        loadRolesForVisibleUsers(otherUserIds);
      }
    } else if (hasUsersNeedingRoles) {
      loadRolesForVisibleUsers(usersNeedingRoles);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, users.length, pagination.pageIndex, table.getRowModel().rows.length, loadRolesForVisibleUsers]);

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">Loading...</div>
    );
  }

  const selectedRows = table.getFilteredSelectedRowModel().rows.length;
  const totalRows = table.getFilteredRowModel().rows.length;

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <div className="sticky top-0 z-30 pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Users</h1>
            <p className="text-sm text-muted-foreground">Manage all users in the system.</p>
          </div>
        </div>

        <div className="flex items-center py-2 gap-2 flex-wrap">
          <div className="relative max-w-sm w-full">
            <Input
              placeholder="Search by Name, Email, Code"
              value={globalFilter ?? ""}
              onChange={(event) => setGlobalFilter(event.target.value)}
              className="pr-8"
            />
            {globalFilter && (
              <button
                onClick={() => setGlobalFilter("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 hover:text-foreground transition-colors"
              >
                <X className="h-4 w-4 text-muted-foreground" />
              </button>
            )}
          </div>

          <FilterDropdown
            label="User Type"
            options={userTypeOptions}
            selected={selectedUserTypes}
            onSelectionChange={setSelectedUserTypes}
            placeholder="User Type"
          />
          <FilterDropdown
            label="Status"
            options={statusOptions}
            selected={selectedStatuses}
            onSelectionChange={setSelectedStatuses}
            placeholder="Status"
          />
          <div className="flex items-center gap-2 ml-auto">
            <Button variant="ghost" size="icon" className="h-9 w-9 border text-muted-foreground hover:text-white">
              <StickyNote className="h-8 w-8" />
            </Button>
            {canAccessCategory("UsersWeb", "CREATE") && (<Button asChild className="bg-primary">
              <Link to="/dashboard/users/new">
                <Plus className="mr-2 h-4 w-4" />
                Add User
              </Link>
            </Button>)}
            <div className="sm:flex items-center gap-1 border bg-muted p-1 rounded-md hidden">
              <Button
                variant={view === "table" ? "secondary" : "ghost"}
                size="icon"
                className="h-7 w-7"
                onClick={() => setView("table")}
              >
                <List className="h-4 w-4" />
              </Button>
              <Button
                variant={view === "card" ? "secondary" : "ghost"}
                size="icon"
                className="h-7 w-7"
                onClick={() => setView("card")}
              >
                <LayoutGrid className="h-4 w-4" />
              </Button>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="h-9 hidden sm:flex">
                  Columns
                  <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[200px]">
                {table
                  .getAllColumns()
                  .filter(
                    (column) =>
                      typeof column.accessorFn !== "undefined" &&
                      column.getCanHide()
                  )
                  .map((column) => {
                    return (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                          column.toggleVisibility(!!value)
                        }
                      >
                        {column.id}
                      </DropdownMenuCheckboxItem>
                    );
                  })}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col min-h-0">
        {view === "table" && !isMobile ? (
          <div className="flex-1 flex flex-col min-h-0 rounded-lg border bg-card shadow-sm overflow-hidden">
            <div className="flex-1 overflow-auto scrollbar-thin">
              <Table className="w-full">
                <TableHeader className="sticky top-0 z-20 bg-card">
                  {table.getHeaderGroups().map((headerGroup) => (
                    <TableRow key={headerGroup.id}>
                      {headerGroup.headers.map((header) => (
                        <TableHead key={header.id} className="bg-card">
                          {header.isPlaceholder
                            ? null
                            : flexRender(
                              header.column.columnDef.header,
                              header.getContext(),
                            )}
                        </TableHead>
                      ))}
                    </TableRow>
                  ))}
                </TableHeader>
                <TableBody>
                  {table.getRowModel().rows?.length ? (
                    table.getRowModel().rows.map((row) => (
                      <TableRow key={row.id}>
                        {row.getVisibleCells().map((cell) => (
                          <TableCell
                            key={cell.id}
                            className="whitespace-nowrap"
                          >
                            {flexRender(
                              cell.column.columnDef.cell,
                              cell.getContext(),
                            )}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={columns.length}
                        className="h-24 text-center"
                      >
                        No results.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto scrollbar-thin">
            <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-1">
              {table.getRowModel().rows?.length ? (
                table
                  .getRowModel()
                  .rows.map((row) => (
                    <UserCard key={row.original.id} user={row.original} />
                  ))
              ) : (
                <div className="col-span-full text-center py-8 text-muted-foreground">
                  No results.
                </div>
              )}
            </div>
          </div>
        )}

        <div className="sticky bottom-0 z-30 pt-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2">
              <p className="text-xs sm:text-sm text-muted-foreground">
                {selectedRows} of {totalRows} row(s) selected.
              </p>
            </div>
            <div className="flex items-center justify-center sm:justify-end gap-2">
              <Button
                variant="outline"
                size="sm"
                className="text-xs sm:text-sm"
                onClick={() => table.previousPage()}
                disabled={!table.getCanPreviousPage()}
              >
                Previous
              </Button>
              <span className="text-xs sm:text-sm px-2">
                Page {table.getState().pagination.pageIndex + 1} of{" "}
                {table.getPageCount()}
              </span>
              <Button
                variant="outline"
                size="sm"
                className="text-xs sm:text-sm"
                onClick={() => table.nextPage()}
                disabled={!table.getCanNextPage()}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the
              user.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={forceLogoutDialogOpen} onOpenChange={setForceLogoutDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Force Logout User</DialogTitle>
            <DialogDescription>
              This will revoke the user's active session. Please provide a reason for this action.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="reason">Reason</Label>
              <Textarea
                id="reason"
                placeholder="e.g., Suspicious activity detected"
                value={forceLogoutComment}
                onChange={(e) => setForceLogoutComment(e.target.value)}
                className="min-h-[100px]"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setForceLogoutDialogOpen(false);
                setUserToForceLogout(null);
                setForceLogoutComment("");
              }}
              disabled={isLoggingOut}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={confirmForceLogout}
              disabled={isLoggingOut || !forceLogoutComment.trim()}
            >
              {isLoggingOut ? "Processing..." : "Confirm Force Logout"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}