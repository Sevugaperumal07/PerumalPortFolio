import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { getUserById } from '@/lib/services/users';
import { graphqlRequest } from '@/lib/graphql/client';
import { GET_ROLES_BY_USER_ID, GET_SECURITY_GROUPS_BY_USER_ID } from '@/lib/graphql/queries/users';
import type { User, Role, SecurityGroup } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

// Helper function to format user type (replace underscores with spaces)
const formatUserType = (userType?: string): string => {
  if (!userType) return 'N/A';
  return userType.replace(/_/g, ' ');
};

// Helper function to format address
const formatAddress = (user: User): string => {
  const parts = [
    user.addressStreet,
    user.addressCity,
    user.addressState,
    user.addressCountry,
    user.addressPostalcode
  ].filter(Boolean);

  if (parts.length === 0) return '...';
  return parts.join(', ');
};

// Helper function to format date
const formatDate = (dateString?: string): string => {
  if (!dateString) return 'N/A';
  try {
    return format(new Date(dateString), 'd MMMM yyyy \'at\' h:mm a');
  } catch {
    return 'N/A';
  }
};

// Helper function to get user display name
const getUserDisplayName = (user: User): string => {
  if (user.firstName || user.lastName) {
    return `${user.userType ? formatUserType(user.userType) : ''} ${user.firstName || ''} ${user.lastName || ''}`.trim();
  }
  return user.userName || 'N/A';
};

export default function ViewUser() {
  const { id } = useParams<{ id: string }>();
  const [user, setUser] = useState<User | null>(null);
  const [roles, setRoles] = useState<Role[]>([]);
  const [securityGroups, setSecurityGroups] = useState<SecurityGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (id) {
      loadUser();
    }
  }, [id]);

  const loadUser = async () => {
    if (!id) return;

    try {
      setLoading(true);
      const [userData, rolesData, securityGroupsData] = await Promise.all([
        getUserById(id),
        graphqlRequest<{ getRolesByUserId: Role[] }>(GET_ROLES_BY_USER_ID, { userId: id }),
        graphqlRequest<{ getSecurityGroupsByUserId: { securityGroups: SecurityGroup[] } }>(GET_SECURITY_GROUPS_BY_USER_ID, { userId: id }),
      ]);

      setUser(userData);
      setRoles(rolesData?.getRolesByUserId || []);
      setSecurityGroups(securityGroupsData?.getSecurityGroupsByUserId?.securityGroups || []);
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to load user',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center p-8">Loading...</div>;
  }

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center p-8 gap-4">
        <p className="text-muted-foreground">User not found</p>
        <Button asChild>
          <Link to="/dashboard/users">Back to Users</Link>
        </Button>
      </div>
    );
  }

  const displayName = getUserDisplayName(user);
  const address = formatAddress(user);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <Card className="w-full">
          <CardHeader className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-2xl font-semibold">{displayName}</h1>
              <p className="text-sm text-muted-foreground mt-1">{user.email}</p>
            </div>
            <div className="flex justify-between items-center gap-3">
              <div className={cn(
                "text-xs px-2 py-1 rounded-full border font-semibold",
                user.deleted
                  ? "bg-gray-100 text-gray-600 border-gray-200"
                  : "bg-emerald-50 text-emerald-700 border-emerald-200"
              )}>
                {user.deleted ? 'Inactive' : 'Active'}
              </div>
            </div>
          </CardHeader>
        </Card>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        {/* Identity & Access */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold">Identity & Access</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm text-muted-foreground">Username</label>
              <p className="mt-1 font-semibold">{user.userName || 'N/A'}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">User Type</label>
              <p className="mt-1 font-semibold">{formatUserType(user.userType)}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Roles</label>
              {roles.length > 0 ? (
                <div className="mt-1 flex flex-wrap gap-1">
                  {roles.map((role) => (
                    <Badge key={role.id} variant="secondary" className="text-xs">
                      {role.name}
                    </Badge>
                  ))}
                </div>
              ) : (
                <p className="mt-1 font-semibold text-muted-foreground">-</p>
              )}
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Security Groups</label>
              {securityGroups.length > 0 ? (
                <div className="mt-1 flex flex-wrap gap-1">
                  {securityGroups.map((sg) => (
                    <Badge key={sg.id} variant="secondary" className="text-xs">
                      {sg.name}
                    </Badge>
                  ))}
                </div>
              ) : (
                <p className="mt-1 font-semibold text-muted-foreground">-</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Organization */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold">Organization</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm text-muted-foreground">Job Title</label>
              <p className="mt-1 font-semibold">{user.title || 'N/A'}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Department</label>
              <p className="mt-1 font-semibold">{user.department || 'N/A'}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Employee Code</label>
              <p className="mt-1 font-semibold">{user.employeeCode || 'N/A'}</p>
            </div>
            <div className="border-t pt-4 mt-4">
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-muted-foreground">Reporting Manager</label>
                  <p className="mt-1 font-semibold">{user.reportingManager || 'N/A'}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Supervisor Name</label>
                  <p className="mt-1 font-semibold">{user.supervisor || 'N/A'}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Supervisor Email</label>
                  <p className="mt-1 font-semibold">{user.supervisorEmail || 'N/A'}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact & Address */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold">Contact & Address</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm text-muted-foreground">Mobile Phone</label>
              <p className="mt-1 font-semibold">{user.phoneMobile || 'N/A'}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Work Phone</label>
              <p className="mt-1 font-semibold">{user.phoneWork || 'N/A'}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Address</label>
              <p className="mt-1 font-semibold">{address}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Settings & Metadata */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-semibold">Settings & Metadata</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-sm text-muted-foreground">Receive Notifications</label>
              <div className="mt-1">
                <Badge variant="secondary" className="text-xs">
                  {user.receiveNotifications ? 'Yes' : 'No'}
                </Badge>
              </div>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Portal Only User</label>
              <div className="mt-1">
                <Badge variant="secondary" className="text-xs">
                  {user.portalOnly ? 'Yes' : 'No'}
                </Badge>
              </div>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Show on Directory</label>
              <div className="mt-1">
                <Badge variant="secondary" className="text-xs">
                  {user.showOnEmployees ? 'Yes' : 'No'}
                </Badge>
              </div>
            </div>
          </div>
          <div>
            <label className="text-sm text-muted-foreground">Description / Notes</label>
            <p className="mt-1 font-semibold">{user.description || 'N/A'}</p>
          </div>
          <div className="border-t pt-4 mt-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="text-sm text-muted-foreground">User ID</label>
                <p className="mt-1 font-semibold">{user.id || 'N/A'}</p>
              </div>
              <div>
                <label className="text-sm text-muted-foreground">Date Created</label>
                <p className="mt-1 font-semibold">{formatDate(user.dateEntered)}</p>
              </div>
              <div>
                <label className="text-sm text-muted-foreground">Created By</label>
                <p className="mt-1 font-semibold">{user.createdBy || 'system'}</p>
              </div>
              <div>
                <label className="text-sm text-muted-foreground">Last Modified</label>
                <p className="mt-1 font-semibold">{formatDate(user.dateModified)}</p>
              </div>
              <div>
                <label className="text-sm text-muted-foreground">Modified By</label>
                <p className="mt-1 font-semibold">{user.modifiedUserId || '-'}</p>
              </div>
              <div>
                <label className="text-sm text-muted-foreground">Status</label>
                <div className="mt-1">
                  <Badge
                    variant="secondary"
                    className={cn(
                      "text-xs font-medium",
                      user.deleted
                        ? "bg-gray-100 text-gray-600 border-gray-200"
                        : "bg-emerald-50 text-emerald-700 border-emerald-200"
                    )}
                  >
                    {user.deleted ? 'Inactive' : 'Active'}
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
