import { useState, useEffect, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/contexts/UserRoleContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { Eye, EyeOff } from 'lucide-react';
import { OTP_TYPES } from '@/lib/types';
import splashLogo from "@/assets/splash.png";
import { LOGIN_RESPONSE_STATUS } from '@/constants/LoginResponseStatus';
import { validateEmail } from '@/lib/utils/validation';

const REMEMBER_ME_KEY = 'login_remember_email';

// ─── Component ────────────────────────────────────────────────────────────────

// ─── Component ────────────────────────────────────────────────────────────────
export default function Login() {
  const [email, setEmail]               = useState('');
  const [password, setPassword]         = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe]     = useState(false);
  const [loading, setLoading]           = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('Login');

  // Per-field error messages (only shown after the user has touched / blurred the field)
  const [emailError, setEmailError]     = useState('');
  const [emailTouched, setEmailTouched] = useState(false);

  const { login }           = useAuth();
  const { refreshRoleData } = useUserRole();
  const navigate            = useNavigate();
  const location            = useLocation();
  const { toast }           = useToast();

  // ── Restore remembered email on mount ──────────────────────────────────────
  useEffect(() => {
    const savedEmail = localStorage.getItem(REMEMBER_ME_KEY);
    if (savedEmail) {
      setEmail(savedEmail);
      setRememberMe(true);
    }
  }, []);



  // ── Handlers ────────────────────────────────────────────────────────────────
  const togglePasswordVisibility = useCallback(() => {
    setShowPassword((prev) => !prev);
  }, []);

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setEmail(val);
    if (emailTouched) setEmailError(validateEmail(val));
  };

  const handleEmailBlur = () => {
    setEmailTouched(true);
    setEmailError(validateEmail(email));
  };



  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Mark email field touched so error shows on submit even if never blurred
    setEmailTouched(true);

    const emailErr = validateEmail(email);
    setEmailError(emailErr);

    // Gate: do not call the API if client-side validation fails
    if (emailErr) return;

    setLoading(true);
    setLoadingMessage('Logging in...');

    try {
      // 1. Persist or clear remembered email (password is NEVER stored)
      if (rememberMe) {
        localStorage.setItem(REMEMBER_ME_KEY, email);
      } else {
        localStorage.removeItem(REMEMBER_ME_KEY);
      }

      // 2. Authenticate
      const response = await login({ email, password, clientType: 'WEB' });

      if (response.status === LOGIN_RESPONSE_STATUS.PASSWORD_CHANGE_REQUIRED) {
        navigate('/login/verify-otp', { 
          state: { email, otpType: OTP_TYPES.RESET_PASSWORD } 
        });
        return;
      }

      // 3. Refresh role matrix so permissions are ready before navigation
      await refreshRoleData();

      const fromLocation = (location.state as any)?.from;
      if (fromLocation && typeof fromLocation === 'object') {
        const target = `${fromLocation.pathname || ''}${fromLocation.search || ''}${fromLocation.hash || ''}`;
        navigate(target || '/dashboard/cases', { replace: true });
      } else {
        navigate('/dashboard/cases', { replace: true });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to login',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
      setLoadingMessage('Login');
    }
  };

  // ── Render ──────────────────────────────────────────────────────────────────
  return (
    <div className="flex min-h-screen items-center justify-center bg-muted/40 p-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="text-center items-center">
          <div className="mb-2 transition-all duration-500 animate-in fade-in zoom-in">
            <img
              src={splashLogo}
              alt="Infinity Fincorp Logo"
              className="h-16 sm:h-20 w-auto object-contain"
            />
          </div>
          <CardTitle className="text-base text-gray-800">Login</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4 mt-[-2rem]" noValidate>

            {/* ── Email ── */}
            <div className="space-y-1">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="email@example.com"
                value={email}
                onChange={handleEmailChange}
                onBlur={handleEmailBlur}
                required
                disabled={loading}
                autoComplete="email"
                aria-invalid={!!emailError}
                aria-describedby={emailError ? 'email-error' : undefined}
                className={emailError ? 'border-destructive focus-visible:ring-destructive' : ''}
              />
              {emailError && (
                <p id="email-error" role="alert" className="text-xs text-destructive mt-1">
                  {emailError}
                </p>
              )}
            </div>

            {/* ── Password ── */}
            <div className="space-y-1">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={loading}
                  autoComplete="current-password"
                  className="pr-10"
                />
                <button
                  type="button"
                  onClick={togglePasswordVisibility}
                  disabled={loading}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute inset-y-0 right-0 flex items-center px-3 text-muted-foreground hover:text-foreground focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 rounded-r-md transition-colors disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" aria-hidden="true" />
                  ) : (
                    <Eye className="h-4 w-4" aria-hidden="true" />
                  )}
                </button>
              </div>
            </div>

            {/* ── Remember Me & Forgot Password ── */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember-me"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked === true)}
                  disabled={loading}
                  aria-label="Remember my email"
                />
                <Label
                  htmlFor="remember-me"
                  className="text-sm font-normal cursor-pointer select-none text-gray-600"
                >
                  Remember me
                </Label>
              </div>
              <Button
                type="button"
                variant="link"
                className="px-0 h-auto text-xs font-semibold text-[#2979FF] hover:no-underline hover:opacity-80 transition-all"
                onClick={() => {
                  navigate('/login/verify-otp', { 
                    state: { email, otpType: OTP_TYPES.FORGET_PASSWORD } 
                  });
                }}
                disabled={loading}
              >
                Forgot Password?
              </Button>
            </div>

            {/* ── Submit ── */}
            <Button
              type="submit"
              className="w-full"
              disabled={loading}
              aria-busy={loading}
            >
              {loading ? loadingMessage : 'Login'}
            </Button>

          </form>
        </CardContent>
      </Card>
    </div>
  );
}
