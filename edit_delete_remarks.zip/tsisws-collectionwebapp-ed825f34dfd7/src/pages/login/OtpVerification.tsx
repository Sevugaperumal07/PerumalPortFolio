import { useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { ChevronLeft, Mail, Loader2, Info } from "lucide-react";
import { useOtpVerification } from "@/hooks/login/useOtpVerification";
import { OTP_TYPES, type OtpType } from "@/lib/types";
import splashLogo from "@/assets/splash.png";

export default function OtpVerification() {
  const navigate = useNavigate();
  const location = useLocation();
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Retrieve email and flow type from state
  const state = location.state as { email?: string; otpType?: OtpType };
  const otpType = state?.otpType || OTP_TYPES.RESET_PASSWORD;

  const {
    email,
    setEmail,
    emailError,
    handleEmailBlur,
    otpSent,
    sending,
    confirming,
    otp,
    resendEnabled,
    handleSendOTP,
    handleOtpChange,
    handleOtpKeyDown,
    handleOtpPaste,
    handleConfirm,
    handleResend,
    formatTimer,
    otpComplete,
  } = useOtpVerification(state?.email || "", otpType);

  return (
    <div className="min-h-screen bg-[#EFEFEF] font-sans flex flex-col">
      {/* AppBar */}
      <div className="bg-[#EFEFEF] flex items-center justify-center relative px-8 py-8 shrink-0">
        <button 
          onClick={() => navigate(-1)}
          className="absolute left-8 p-2 hover:bg-white/50 rounded-full transition-colors"
          aria-label="Go back"
        >
          <ChevronLeft size={24} color="#1A3A5C" />
        </button>
      </div>

      {/* Main Content - Centered */}
      <div className="flex-1 flex flex-col items-center justify-center px-5 pb-10">
        <span className="text-[20px] font-bold text-[#1A3A5C] mb-6 text-center animate-in fade-in slide-in-from-top-2 duration-700">
          {otpSent ? "Verify OTP" : "OTP Verification to Reset Password"}
        </span>
        <div className="w-full max-w-md">
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            {!otpSent ? (
               /* Step 1 — Send OTP */
               <div className="bg-white rounded-2xl p-6 shadow-sm">
                 <div className="flex justify-center mb-6 animate-in fade-in zoom-in duration-500">
                   <img
                     src={splashLogo}
                     alt="Infinity Fincorp Logo"
                     className="h-14 w-auto object-contain"
                   />
                 </div>
                 <p className="text-[13px] text-[#212121]/60 text-center mb-6 leading-relaxed">
                    We'll send a one-time password to your registered email address.
                 </p>

                 {otpType === OTP_TYPES.RESET_PASSWORD && (
                    <div className="flex items-start gap-2.5 bg-[#E3F2FD] border border-[#2979FF]/10 rounded-xl p-3 mb-6 animate-in fade-in slide-in-from-top-2 duration-500">
                      <Info className="w-4 h-4 text-[#2979FF] mt-0.5 shrink-0" />
                      <p className="text-[12px] font-medium text-[#1A3A5C]/80 leading-snug">
                        This is your first login. You need to reset your default password.
                      </p>
                    </div>
                  )}

                 {/* Email Row */}
                 <div className={`flex items-center gap-2.5 bg-[#EFEFEF] rounded-full px-4 py-2.5 mb-6 transition-all border ${emailError ? 'border-destructive' : 'border-transparent'}`}>
                   <Mail size={18} color={emailError ? "#ef4444" : "#2979FF"} />
                   <input
                     type="email"
                     placeholder="Enter your registered email"
                     value={email}
                     onChange={(e) => setEmail(e.target.value)}
                     onBlur={handleEmailBlur}
                     disabled={otpSent || sending}
                     className="bg-transparent border-none outline-none text-sm font-semibold text-[#212121] w-full placeholder:text-[#212121]/30 disabled:opacity-70"
                   />
                 </div>
                 {emailError && (
                    <p role="alert" className="text-[11px] text-destructive px-4 mb-4 animate-in fade-in slide-in-from-top-1">
                      {emailError}
                    </p>
                 )}

                 <button
                   onClick={() => handleSendOTP(inputRefs)}
                   disabled={sending}
                   className={`w-full py-3.5 rounded-full text-white text-[15px] font-semibold transition-all duration-300 ${
                     sending
                       ? "bg-[#2979FF]/60 cursor-not-allowed"
                       : "bg-[#2979FF] hover:opacity-90 active:scale-[0.98]"
                   }`}
                 >
                   {sending ? (
                     <span className="flex items-center justify-center gap-2">
                       <Loader2 className="animate-spin w-4 h-4" />
                       Sending...
                     </span>
                   ) : (
                     "Send OTP"
                   )}
                 </button>
               </div>
            ) : (
               /* Step 2 — Verify OTP */
               <div className="bg-white rounded-2xl p-6 shadow-sm animate-in fade-in slide-in-from-right-4 duration-500">
                 <div className="flex justify-center mb-6 animate-in fade-in zoom-in duration-500">
                   <img
                     src={splashLogo}
                     alt="Infinity Fincorp Logo"
                     className="h-14 w-auto object-contain"
                   />
                 </div>
                 <p className="text-sm font-semibold text-[#1A3A5C] text-center mb-6">
                   Enter the OTP sent to <br/>
                   <span className="text-[#2979FF] text-xs font-normal">{email}</span>
                 </p>

                 {/* OTP Boxes */}
                 <div className="flex gap-2 justify-center mb-8">
                   {[0, 1, 2, 3, 4, 5].map((idx) => (
                     <input
                       key={idx}
                       ref={(el) => {
                         inputRefs.current[idx] = el;
                       }}
                       value={otp[idx] || ''}
                       onChange={(e) => handleOtpChange(e.target.value, idx, inputRefs)}
                       onKeyDown={(e) => handleOtpKeyDown(e, idx, inputRefs)}
                       onPaste={idx === 0 ? (e) => handleOtpPaste(e, inputRefs) : undefined}
                       maxLength={1}
                       inputMode="numeric"
                       style={{ height: 52 }}
                       className={`w-11 text-center text-[22px] font-semibold rounded-lg bg-white text-[#2979FF] outline-none transition-all duration-150 focus:ring-[3px] focus:ring-[#2979FF]/20 ${
                         otp[idx]
                           ? "border-[2px] border-[#2979FF]"
                           : "border-[1.5px] border-gray-300"
                       }`}
                     />
                   ))}
                 </div>

                 <div className="flex flex-col gap-4">
                   <button
                       onClick={() => handleConfirm(() => navigate("/login/reset-password"))}
                       disabled={!otpComplete || confirming}
                       className={`w-full py-3.5 rounded-full text-white text-[15px] font-semibold transition-all duration-200 ${
                       !otpComplete || confirming
                           ? "bg-[#2979FF]/40 cursor-not-allowed"
                           : "bg-[#2979FF] hover:opacity-90 active:scale-[0.98]"
                       }`}
                   >
                       {confirming ? (
                       <span className="flex items-center justify-center gap-2">
                           <Loader2 className="animate-spin w-4 h-4" />
                           Verifying...
                       </span>
                       ) : (
                       "Confirm"
                       )}
                   </button>

                   {/* Resend Logic */}
                   <div className="text-center">
                       {resendEnabled ? (
                           <button 
                               onClick={() => handleResend(inputRefs)}
                               className="text-[13px] font-bold text-[#2979FF] hover:underline"
                           >
                               Resend OTP
                           </button>
                       ) : (
                           <p className="text-[13px] text-[#212121]/60">
                               Resend OTP in <span className="text-[#1A3A5C] font-bold w-12 inline-block text-left">{formatTimer()}</span>
                           </p>
                       )}
                   </div>
                 </div>
               </div>
              )}
           </div>
        </div>
      </div>
    </div>
  );
}
