import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Eye, EyeOff, CheckCircle2, XCircle, ShieldCheck } from 'lucide-react';
import { usePasswordForm } from '@/hooks/login/useResetPasswordForm';
import splashLogo from "@/assets/splash.png";

// ─── Component ────────────────────────────────────────────────────────────────
export default function ResetPassword() {
  const navigate = useNavigate();

  const {
    newPassword,
    confirmPassword,
    showNew,
    showConfirm,
    toggleShowNew,
    toggleShowConfirm,
    newError,
    confirmError,
    loading,
    success,
    ruleResults,
    isNewPasswordValid,
    isConfirmValid,
    handleNewPasswordChange,
    handleNewPasswordBlur,
    handleConfirmPasswordChange,
    handleConfirmPasswordBlur,
    handleSubmit,
  } = usePasswordForm();

  // ── Auto-navigation Timer ──────────────────────────────────────────────────
  const [timer, setTimer] = useState(10);

  useEffect(() => {
    if (!success) return;

    const interval = setInterval(() => {
      setTimer((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          navigate('/login', { replace: true });
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [success, navigate]);

  // ── Success state ──────────────────────────────────────────────────────────
  if (success) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-muted/40 p-4">
        <Card className="w-full max-w-sm text-center">
          <CardHeader className="items-center gap-2 pb-2">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-green-100">
              <ShieldCheck className="h-7 w-7 text-green-600" aria-hidden="true" />
            </div>
            <CardTitle className="text-lg">Password Reset Successful</CardTitle>
            <CardDescription>
              Your password has been updated. You can now log in with your new password.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              className="w-full"
              onClick={() => navigate('/login', { replace: true })}
            >
              Back to Login <span className="font-bold text-white">{timer}s</span>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // ── Main form ──────────────────────────────────────────────────────────────
  return (
    <div className="flex min-h-screen items-center justify-center bg-muted/40 p-4">
      <Card className="w-full max-w-sm">

        {/* Header */}
        <CardHeader className="text-center items-center">
          <div className="mb-2 transition-all duration-500 animate-in fade-in zoom-in">
            <img
              src={splashLogo}
              alt="Infinity Fincorp Logo"
              className="h-16 sm:h-20 w-auto object-contain"
            />
          </div>
          <CardTitle className="text-base text-gray-800">Create New Password</CardTitle>
        </CardHeader>

        <CardContent>
          <form
            className="space-y-4"
            noValidate
          >

            {/* ── New Password ── */}
            <div className="space-y-1">
              <Label htmlFor="new-password">New Password</Label>
              <div className="relative">
                <Input
                  id="new-password"
                  type={showNew ? 'text' : 'password'}
                  placeholder="Enter new password"
                  value={newPassword}
                  onChange={handleNewPasswordChange}
                  onBlur={handleNewPasswordBlur}
                  onCopy={(e) => e.preventDefault()}
                  onCut={(e) => e.preventDefault()}
                  required
                  disabled={loading}
                  autoComplete="new-password"
                  aria-invalid={!!newError}
                  aria-describedby="new-password-rules"
                  className={`pr-10 ${newError ? 'border-destructive focus-visible:ring-destructive' : ''}`}
                />
                <button
                  type="button"
                  onClick={toggleShowNew}
                  disabled={loading}
                  aria-label={showNew ? 'Hide new password' : 'Show new password'}
                  className="absolute inset-y-0 right-0 flex items-center px-3 text-muted-foreground hover:text-foreground focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 rounded-r-md transition-colors disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {showNew
                    ? <EyeOff className="h-4 w-4" aria-hidden="true" />
                    : <Eye    className="h-4 w-4" aria-hidden="true" />}
                </button>
              </div>

              {/* Strength checklist — shown after first interaction */}
              {newPassword.length > 0 && (
                <ul
                  id="new-password-rules"
                  className="mt-2 space-y-1"
                  aria-label="Password requirements"
                >
                  {ruleResults.map((rule) => (
                    <li key={rule.id} className="flex items-center gap-1.5 text-xs">
                      {rule.passed
                        ? <CheckCircle2 className="h-3.5 w-3.5 text-green-500 shrink-0" aria-hidden="true" />
                        : <XCircle      className="h-3.5 w-3.5 text-destructive shrink-0" aria-hidden="true" />}
                      <span className={rule.passed ? 'text-green-600' : 'text-destructive'}>
                        {rule.label}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* ── Confirm Password ── */}
            <div className="space-y-1">
              <Label htmlFor="confirm-password">Confirm Password</Label>
              <div className="relative">
                <Input
                  id="confirm-password"
                  type={showConfirm ? 'text' : 'password'}
                  placeholder="Re-enter new password"
                  value={confirmPassword}
                  onChange={handleConfirmPasswordChange}
                  onPaste={(e) => e.preventDefault()}
                  onCopy={(e) => e.preventDefault()}
                  onCut={(e) => e.preventDefault()}
                  onBlur={handleConfirmPasswordBlur}
                  required
                  disabled={loading}
                  autoComplete="new-password"
                  aria-invalid={!!confirmError}
                  aria-describedby={confirmError ? 'confirm-password-error' : undefined}
                  className={`pr-10 ${confirmError ? 'border-destructive focus-visible:ring-destructive' : ''}`}
                />
                <button
                  type="button"
                  onClick={toggleShowConfirm}
                  disabled={loading}
                  aria-label={showConfirm ? 'Hide confirm password' : 'Show confirm password'}
                  className="absolute inset-y-0 right-0 flex items-center px-3 text-muted-foreground hover:text-foreground focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 rounded-r-md transition-colors disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {showConfirm
                    ? <EyeOff className="h-4 w-4" aria-hidden="true" />
                    : <Eye    className="h-4 w-4" aria-hidden="true" />}
                </button>
              </div>

              {/* Mismatch / empty error */}
              {confirmError && (
                <p id="confirm-password-error" role="alert" className="text-xs text-destructive mt-1">
                  {confirmError}
                </p>
              )}

              {/* Match success indicator */}
              {confirmPassword.length > 0 && !confirmError && (
                <p className="flex items-center gap-1.5 text-xs text-green-600 mt-1">
                  <CheckCircle2 className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                  Passwords match
                </p>
              )}
            </div>

            {/* ── Error Display ── */}
            {newError && (newPassword.length === 0 || !newError.includes('meet all requirements')) && (
              <p role="alert" className="text-xs text-destructive mt-1 font-medium animate-in fade-in slide-in-from-top-1">
                {newError}
              </p>
            )}

            {/* ── Submit ── */}
            <Button
              type="button"
              className="w-full"
              onClick={() => handleSubmit()}
              disabled={loading || !isNewPasswordValid || !isConfirmValid}
              aria-busy={loading}
            >
              {loading ? 'Updating password…' : 'Set New Password'}
            </Button>

            {/* ── Back to login ── */}
            <Button
              type="button"
              variant="ghost"
              className="w-full text-muted-foreground"
              onClick={() => navigate('/login')}
              disabled={loading}
            >
              Back to Login
            </Button>

          </form>
        </CardContent>
      </Card>
    </div>
  );
}
