/// <reference types="vitest" />
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  // =======================
  // Serve at root in production
  // =======================
  base: '/', // root deployment

  plugins: [react()],

  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },

  // =======================
  // DEV SERVER
  // =======================
  server: {
    host: true,
    port: 5173,
    strictPort: true,
    proxy: {
      "/notificationsproxy": {
        target: "http://172.235.1.82:8094",
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/notificationsproxy/, ""),
      },
      "/notesproxy": {
        target: "http://172.235.1.82:8100",
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/notesproxy/, ""),
      },
      "/testproxy": {
        target: "http://172.235.1.82:8081",
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/testproxy/, ""),
      },
      "/screenshotproxy": {
        target: "http://172.235.1.82:8092",
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/screenshotproxy/, ""),
      }
    },
  },

  // =======================
  // PRODUCTION BUILD
  // =======================
  build: {
    outDir: 'dist',
    sourcemap: false,
  },

  optimizeDeps: {
    include: ['@tanstack/react-table'],
  },

  // =======================
  // TESTING
  // =======================
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: './src/test/setup.ts',
    css: true,
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      exclude: [
        'node_modules/',
        'src/test/',
        '/*.d.ts',
        '/.config.',
        '**/mockData',
        'dist/',
      ],
    },
  },
});